(function () {
  'use strict';
  var OVERRIDE_KEY = 'novapulse_device_mode_override';
  var listeners = [];
  var currentDevice = 'desktop';
  var currentOrientation = 'landscape';
  var isTouchDevice = false;
  var currentPlatform = 'web';
  function detectPlatform() {
    var ua = navigator.userAgent || '';
    if (window.electronAPI || (typeof process !== 'undefined' && process.versions && process.versions.electron)) {
      return 'windows';
    }
    if (/Android/i.test(ua)) {
      return 'android';
    }
    if (/iPhone|iPad|iPod/i.test(ua)) {
      return 'ios';
    }
    if (/Windows NT/i.test(ua)) {
      return 'windows';
    }
    return 'web';
  }
  function detectTouch() {
    return ('ontouchstart' in window) ||
           (navigator.maxTouchPoints > 0) ||
           (navigator.msMaxTouchPoints > 0);
  }
  function detectOrientation() {
    if (window.screen && window.screen.orientation && window.screen.orientation.type) {
      return window.screen.orientation.type.startsWith('portrait') ? 'portrait' : 'landscape';
    }
    return window.innerHeight >= window.innerWidth ? 'portrait' : 'landscape';
  }
  function calculateDeviceCategory(width, height, touch, platform) {
    try {
      var override = localStorage.getItem(OVERRIDE_KEY);
      if (override && (override === 'desktop' || override === 'tablet' || override === 'mobile')) {
        return override;
      }
    } catch (e) {
    }
    var minDim = Math.min(width, height);
    var maxDim = Math.max(width, height);
    var ua = navigator.userAgent || '';
    var isExplicitTabletUA = /(iPad|Tablet|(Android(?!.*Mobile)))/i.test(ua);
    if (isExplicitTabletUA) {
      return 'tablet';
    }
    if (width < 768) {
      if (width < 600 || touch) {
        return 'mobile';
      }
    }
    if (width >= 768 && width <= 1024) {
      return 'tablet';
    }
    if (touch && width > 1024 && width <= 1280 && minDim >= 700) {
      return 'tablet';
    }
    return 'desktop';
  }
  function applyDeviceAttributes(device, orientation, touch, platform) {
    var root = document.documentElement;
    var body = document.body;
    root.setAttribute('data-device', device);
    root.setAttribute('data-orientation', orientation);
    root.setAttribute('data-touch', touch ? 'true' : 'false');
    root.setAttribute('data-platform', platform);
    if (body) {
      body.classList.remove('device-desktop', 'device-tablet', 'device-mobile', 'orientation-portrait', 'orientation-landscape');
      body.classList.add('device-' + device);
      body.classList.add('orientation-' + orientation);
    }
  }
  function evaluateDevice() {
    var width = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth || 1280;
    var height = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight || 720;
    var touch = detectTouch();
    var orientation = detectOrientation();
    var platform = detectPlatform();
    var device = calculateDeviceCategory(width, height, touch, platform);
    var changed = (device !== currentDevice) || (orientation !== currentOrientation);
    currentDevice = device;
    currentOrientation = orientation;
    isTouchDevice = touch;
    currentPlatform = platform;
    applyDeviceAttributes(device, orientation, touch, platform);
    if (changed) {
      var eventData = {
        device: device,
        orientation: orientation,
        width: width,
        height: height,
        touch: touch,
        platform: platform
      };
      try {
        window.dispatchEvent(new CustomEvent('nova:device-changed', { detail: eventData }));
      } catch (e) {
        var evt = document.createEvent('CustomEvent');
        evt.initCustomEvent('nova:device-changed', false, false, eventData);
        window.dispatchEvent(evt);
      }
      listeners.forEach(function (fn) {
        try {
          fn(eventData);
        } catch (err) {
          console.error('[DeviceDetector] Listener error:', err);
        }
      });
    }
    syncSettingsDeviceModeButtons();
  }
  var resizeTimer = null;
  window.addEventListener('resize', function () {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(evaluateDevice, 100);
  });
  window.addEventListener('orientationchange', function () {
    setTimeout(evaluateDevice, 150);
  });
  evaluateDevice();
  function syncSettingsDeviceModeButtons() {
    var grid = document.getElementById('settingsDeviceModeGrid');
    if (!grid) return;
    var currentOverride = 'auto';
    try {
      currentOverride = localStorage.getItem(OVERRIDE_KEY) || 'auto';
    } catch (e) {}
    grid.querySelectorAll('.btn-device-mode').forEach(function (btn) {
      var mode = btn.getAttribute('data-device-mode');
      if (mode === currentOverride) {
        btn.classList.add('active');
        btn.style.background = 'linear-gradient(135deg, rgba(6,182,212,0.22), rgba(59,130,246,0.22))';
        btn.style.borderColor = 'var(--theme-primary, #06b6d4)';
        btn.style.color = '#ffffff';
        btn.style.boxShadow = '0 0 12px rgba(6,182,212,0.25)';
      } else {
        btn.classList.remove('active');
        btn.style.background = 'rgba(255, 255, 255, 0.05)';
        btn.style.borderColor = 'rgba(255, 255, 255, 0.1)';
        btn.style.color = '#cbd5e1';
        btn.style.boxShadow = 'none';
      }
    });
  }
  function initSettingsDeviceSwitcherUI() {
    var oldPill = document.getElementById('novaDeviceSwitcherPill');
    if (oldPill && oldPill.parentNode) oldPill.parentNode.removeChild(oldPill);
    var grid = document.getElementById('settingsDeviceModeGrid');
    if (!grid) return;
    grid.querySelectorAll('.btn-device-mode').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.stopPropagation();
        var mode = btn.getAttribute('data-device-mode');
        window.NovaPulseDevice.setOverride(mode);
        syncSettingsDeviceModeButtons();
        if (typeof window.showNovaToast === 'function') {
          window.showNovaToast('Switched presentation layer to ' + mode.toUpperCase(), 'fa-layer-group');
        }
      });
    });
    syncSettingsDeviceModeButtons();
  }
  document.addEventListener('DOMContentLoaded', function () {
    applyDeviceAttributes(currentDevice, currentOrientation, isTouchDevice, currentPlatform);
    initSettingsDeviceSwitcherUI();
  });
  window.NovaPulseDevice = {
    getDevice: function () { return currentDevice; },
    getOrientation: function () { return currentOrientation; },
    isTouch: function () { return isTouchDevice; },
    getPlatform: function () { return currentPlatform; },
    setOverride: function (mode) {
      if (mode === 'auto') {
        try { localStorage.removeItem(OVERRIDE_KEY); } catch (e) {}
      } else if (mode === 'desktop' || mode === 'tablet' || mode === 'mobile') {
        try { localStorage.setItem(OVERRIDE_KEY, mode); } catch (e) {}
      }
      evaluateDevice();
    },
    getOverride: function () {
      try { return localStorage.getItem(OVERRIDE_KEY) || 'auto'; } catch (e) { return 'auto'; }
    },
    onDeviceChange: function (fn) {
      if (typeof fn === 'function') listeners.push(fn);
    },
    refresh: evaluateDevice
  };
})();