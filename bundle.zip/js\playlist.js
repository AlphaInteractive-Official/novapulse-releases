const Playlist = (function () {
  let items = [];
  let currentIndex = -1;
  let repeatMode = 'off'; // 'off' | 'current' | 'playlist'
  let isShuffle = false;
  let shuffledIndices = [];
  let onPlaylistChangeCbs = [];
  let onItemChangeCbs = [];
  function init() {
    try {
      const savedRepeat = localStorage.getItem('ultimatePlayer.repeatMode');
      if (savedRepeat && ['off', 'current', 'playlist'].includes(savedRepeat)) {
        repeatMode = savedRepeat;
      }
      const savedShuffle = localStorage.getItem('ultimatePlayer.shuffle');
      if (savedShuffle !== null) {
        isShuffle = savedShuffle === 'true';
      }
      const savedItems = localStorage.getItem('ultimatePlayer.playlist');
      if (savedItems) {
        const parsed = JSON.parse(savedItems);
        if (Array.isArray(parsed)) {
          items = parsed.filter(it => {
            if (!it || !it.name) return false;
            const filename = it.filename || it.name || '';
            if (/\.f\d+(\.[a-z0-9]+)?$/i.test(filename) || /\.f\d+$/i.test(filename)) {
              return false;
            }
            return true;
          });
        }
      }
      const savedIndex = localStorage.getItem('ultimatePlayer.currentIndex');
      if (savedIndex !== null && items.length > 0) {
        const idx = parseInt(savedIndex, 10);
        if (!isNaN(idx) && idx >= 0 && idx < items.length) {
          currentIndex = idx;
        } else {
          currentIndex = 0;
        }
      } else if (items.length > 0) {
        currentIndex = 0;
      }
    } catch (e) {
      console.warn('Playlist.init: failed to restore state, using defaults:', e);
      items = [];
      currentIndex = -1;
    }
    rebuildShuffleOrder();
  }
  function saveState() {
    try {
      localStorage.setItem('ultimatePlayer.playlist', JSON.stringify(items));
      localStorage.setItem('ultimatePlayer.currentIndex', currentIndex.toString());
      localStorage.setItem('ultimatePlayer.repeatMode', repeatMode);
      localStorage.setItem('ultimatePlayer.shuffle', isShuffle.toString());
    } catch (e) {
      console.warn('Error saving playlist state to localStorage:', e);
    }
  }
  function rebuildShuffleOrder() {
    shuffledIndices = items.map((_, i) => i);
    if (!isShuffle) return;
    for (let i = shuffledIndices.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffledIndices[i], shuffledIndices[j]] = [shuffledIndices[j], shuffledIndices[i]];
    }
    if (currentIndex >= 0) {
      const curPos = shuffledIndices.indexOf(currentIndex);
      if (curPos > 0) {
        shuffledIndices.splice(curPos, 1);
        shuffledIndices.unshift(currentIndex);
      }
    }
  }
  function notifyPlaylistChange() {
    onPlaylistChangeCbs.forEach(cb => {
      try { cb(items, currentIndex); } catch (e) { console.error('Playlist: onPlaylistChange listener failed:', e); }
    });
  }
  function notifyItemChange(item, index, autoPlay, isRestart) {
    try {
      const raw = localStorage.getItem('novapulse_active_playlist');
      if (raw && item) {
        const state = JSON.parse(raw);
        state.trackIndex = index;
        state.trackName = item.name || '';
        state.trackId = item.id || '';
        state.timestamp = Date.now();
        localStorage.setItem('novapulse_active_playlist', JSON.stringify(state));
      }
    } catch(e) {}
    onItemChangeCbs.forEach(cb => {
      try { cb(item, index, autoPlay, isRestart); } catch (e) { console.error('Playlist: onItemChange listener failed:', e); }
    });
  }
  function getItems() {
    return items;
  }
  function getCurrentIndex() {
    return currentIndex;
  }
  function getCurrentItem() {
    if (currentIndex >= 0 && currentIndex < items.length) {
      return items[currentIndex];
    }
    return null;
  }
  function addItem(mediaItem, autoSelectIfEmpty = true) {
    if (!mediaItem) return;
    const exists = items.some(it => it.id === mediaItem.id);
    if (exists) return;
    const shouldAutoSelect = items.length === 0 && autoSelectIfEmpty;
    items.push(mediaItem);
    if (shouldAutoSelect) currentIndex = 0;
    rebuildShuffleOrder();
    saveState();
    notifyPlaylistChange();
    if (shouldAutoSelect) notifyItemChange(items[0], 0, false);
  }
  function addItems(mediaItems) {
    if (!Array.isArray(mediaItems)) return;
    let addedAny = false;
    for (const m of mediaItems) {
      if (!m) continue;
      if (!items.some(it => it.id === m.id)) {
        items.push(m);
        addedAny = true;
      }
    }
    if (addedAny) {
      const shouldAutoSelect = currentIndex === -1 && items.length > 0;
      if (shouldAutoSelect) currentIndex = 0;
      rebuildShuffleOrder();
      saveState();
      notifyPlaylistChange();
      if (shouldAutoSelect) notifyItemChange(items[0], 0, false);
    }
  }
  function removeItem(index) {
    if (index < 0 || index >= items.length) return;
    items.splice(index, 1);
    let clearedQueue = false;
    let removedActiveTrack = false;
    if (items.length === 0) {
      currentIndex = -1;
      clearedQueue = true;
    } else if (index === currentIndex) {
      currentIndex = Math.min(currentIndex, items.length - 1);
      removedActiveTrack = true;
    } else if (index < currentIndex) {
      currentIndex--;
    }
    rebuildShuffleOrder();
    saveState();
    notifyPlaylistChange();
    if (clearedQueue) {
      notifyItemChange(null, -1, false);
    } else if (removedActiveTrack) {
      notifyItemChange(items[currentIndex], currentIndex, true);
    }
  }
  function clear() {
    items = [];
    currentIndex = -1;
    shuffledIndices = [];
    saveState();
    notifyPlaylistChange();
    notifyItemChange(null, -1, false);
  }
  let currentTrackPlays = 0;
  function selectIndex(index, autoPlay = true, keepPlayCount = false) {
    if (index >= 0 && index < items.length) {
      if (!keepPlayCount) {
        currentTrackPlays = 0;
      }
      currentIndex = index;
      saveState();
      notifyPlaylistChange();
      notifyItemChange(items[currentIndex], currentIndex, autoPlay);
    }
  }
  function moveItem(fromIndex, toIndex) {
    if (
      fromIndex < 0 || fromIndex >= items.length ||
      toIndex < 0 || toIndex >= items.length ||
      fromIndex === toIndex
    ) return;
    const playingItemId = currentIndex >= 0 ? (items[currentIndex] ? items[currentIndex].id : null) : null;
    const [moved] = items.splice(fromIndex, 1);
    items.splice(toIndex, 0, moved);
    if (playingItemId !== null) {
      const newIdx = items.findIndex(it => it.id === playingItemId);
      if (newIdx !== -1) {
        currentIndex = newIdx;
      }
    }
    rebuildShuffleOrder();
    saveState();
    notifyPlaylistChange();
  }
  function playNow(mediaItem) {
    if (!mediaItem) return;
    const exists = items.some(it => it.id === mediaItem.id);
    if (!exists) {
      items.push(mediaItem);
      rebuildShuffleOrder();
    }
    const idx = items.findIndex(it => it.id === mediaItem.id);
    if (idx !== -1) {
      currentTrackPlays = 0;
      currentIndex = idx;
      saveState();
      notifyPlaylistChange();
      notifyItemChange(items[currentIndex], currentIndex, true); // autoPlay = true
    }
  }
  function setQueue(newItems, activeIndex = 0, autoPlay = true) {
    if (!Array.isArray(newItems) || newItems.length === 0) {
      clear();
      return;
    }
    const unique = [];
    const seen = new Set();
    for (const it of newItems) {
      if (it && it.id && !seen.has(it.id)) {
        const filename = it.filename || it.name || '';
        if (/\.f\d+(\.[a-z0-9]+)?$/i.test(filename) || /\.f\d+$/i.test(filename)) {
          continue;
        }
        seen.add(it.id);
        unique.push(it);
      }
    }
    if (unique.length === 0) {
      clear();
      return;
    }
    const targetItem = newItems[activeIndex];
    items = unique;
    const resolvedIdx = targetItem ? items.findIndex(it => it.id === targetItem.id) : -1;
    currentIndex = resolvedIdx !== -1 ? resolvedIdx : Math.max(0, Math.min(activeIndex, items.length - 1));
    currentTrackPlays = 0;
    rebuildShuffleOrder();
    saveState();
    notifyPlaylistChange();
    if (items[currentIndex]) {
      notifyItemChange(items[currentIndex], currentIndex, autoPlay);
    }
  }
  function onMediaEnded() {
    if (items.length === 0) return;
    const currentItem = items[currentIndex];
    const isInfinite = currentItem && (
      currentItem.repeatCount === 'infinite' ||
      currentItem.repeatCount === 'Infinity' ||
      currentItem.repeatCount === '∞' ||
      currentItem.repeatCount === 'inf' ||
      currentItem.repeatCount === Infinity
    );
    if (isInfinite) {
      currentTrackPlays++;
      if (typeof showNovaToast === 'function') {
        showNovaToast(`Looping "${currentItem.name || 'Track'}" (∞ Infinite - Play ${currentTrackPlays + 1})`, 'fa-repeat');
      }
      if (items[currentIndex]) {
        notifyItemChange(items[currentIndex], currentIndex, true, true);
      }
      return;
    }
    const targetRepeats = (currentItem && currentItem.repeatCount && currentItem.repeatCount > 1) 
      ? parseInt(currentItem.repeatCount, 10) 
      : 1;
    currentTrackPlays++;
    if (currentTrackPlays < targetRepeats) {
      if (typeof showNovaToast === 'function') {
        showNovaToast(`Looping "${currentItem.name || 'Track'}": Play ${currentTrackPlays + 1} of ${targetRepeats}`, 'fa-repeat');
      }
      if (items[currentIndex]) {
        notifyItemChange(items[currentIndex], currentIndex, true, true);
      }
      return;
    }
    currentTrackPlays = 0;
    if (repeatMode === 'current') {
      if (items[currentIndex]) {
        notifyItemChange(items[currentIndex], currentIndex, true, true);
      }
    } else if (isShuffle) {
      const curShufPos = shuffledIndices.indexOf(currentIndex);
      if (curShufPos !== -1 && curShufPos + 1 < shuffledIndices.length) {
        selectIndex(shuffledIndices[curShufPos + 1], true);
      } else if (repeatMode === 'playlist') {
        rebuildShuffleOrder();
        selectIndex(shuffledIndices[0], true);
      }
    } else if (currentIndex + 1 < items.length) {
      selectIndex(currentIndex + 1, true);
    } else if (repeatMode === 'playlist') {
      selectIndex(0, true);
    }
  }
  function setItemRepeatCount(index, count) {
    if (index >= 0 && index < items.length) {
      if (count === 'infinite' || count === 'Infinity' || count === '∞' || count === 'inf' || count === Infinity) {
        items[index].repeatCount = 'infinite';
      } else {
        items[index].repeatCount = Math.max(1, parseInt(count, 10) || 1);
      }
      saveState();
      notifyPlaylistChange();
    }
  }
  function getItemRepeatCount(index) {
    if (index >= 0 && index < items.length) {
      const rc = items[index].repeatCount;
      if (rc === 'infinite' || rc === 'Infinity' || rc === '∞' || rc === 'inf' || rc === Infinity) {
        return 'infinite';
      }
      return Math.max(1, parseInt(rc, 10) || 1);
    }
    return 1;
  }
  function getCurrentTrackPlays() {
    return currentTrackPlays;
  }
  function next(autoPlay = true) {
    if (items.length === 0) return;
    currentTrackPlays = 0;
    if (isShuffle) {
      const curShufPos = shuffledIndices.indexOf(currentIndex);
      if (curShufPos !== -1 && curShufPos + 1 < shuffledIndices.length) {
        selectIndex(shuffledIndices[curShufPos + 1], autoPlay);
      } else if (repeatMode === 'playlist') {
        rebuildShuffleOrder();
        selectIndex(shuffledIndices[0], autoPlay);
      }
    } else if (currentIndex + 1 < items.length) {
      selectIndex(currentIndex + 1, autoPlay);
    } else if (repeatMode === 'playlist') {
      selectIndex(0, autoPlay);
    }
  }
  function previous(currentTime, autoPlay = true) {
    if (items.length === 0) return;
    currentTrackPlays = 0;
    if (currentTime > 3) {
      if (items[currentIndex]) {
        notifyItemChange(items[currentIndex], currentIndex, autoPlay, true);
      }
      return;
    }
    if (isShuffle) {
      const curShufPos = shuffledIndices.indexOf(currentIndex);
      if (curShufPos > 0) {
        selectIndex(shuffledIndices[curShufPos - 1], autoPlay);
      } else if (repeatMode === 'playlist') {
        selectIndex(shuffledIndices[shuffledIndices.length - 1], autoPlay);
      }
    } else if (currentIndex > 0) {
      selectIndex(currentIndex - 1, autoPlay);
    } else if (repeatMode === 'playlist') {
      selectIndex(items.length - 1, autoPlay);
    } else {
      if (items[currentIndex]) {
        notifyItemChange(items[currentIndex], currentIndex, autoPlay, true);
      }
    }
  }
  function cycleRepeatMode() {
    if (repeatMode === 'off') repeatMode = 'playlist';
    else if (repeatMode === 'playlist') repeatMode = 'current';
    else repeatMode = 'off';
    saveState();
    return repeatMode;
  }
  function getRepeatMode() {
    return repeatMode;
  }
  function toggleShuffle() {
    isShuffle = !isShuffle;
    rebuildShuffleOrder();
    saveState();
    return isShuffle;
  }
  function setShuffle(val) {
    isShuffle = !!val;
    rebuildShuffleOrder();
    saveState();
    return isShuffle;
  }
  function getIsShuffle() {
    return isShuffle;
  }
  async function fetchServerPlaylists() {
    try {
      const res = await fetch('/api/playlists');
      const data = await res.json();
      return data.ok ? data.playlists : [];
    } catch (e) {
      console.error('Failed to fetch server playlists:', e);
      return [];
    }
  }
  async function createServerPlaylist(name, description = '', items = [], color = '#00F5FF', icon = 'fa-music', thumbnail = '', category = 'mixed') {
    try {
      const cleanItems = Array.isArray(items) ? items : [];
      const thumb = cleanItems.length > 0 ? (thumbnail || cleanItems[0].thumbnail || '') : '';
      const id = 'pl_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
      const now = new Date().toISOString();
      const playlistObj = {
        id,
        name: (name || 'My Playlist').trim(),
        description: (description || '').trim(),
        items: cleanItems,
        color: color || '#00F5FF',
        icon: icon || 'fa-music',
        thumbnail: thumb,
        category: category || 'mixed',
        createdAt: now,
        updatedAt: now
      };
      if (window.NovaPulseAndroid && typeof window.NovaPulseAndroid.savePlaylistJson === 'function') {
        const nativeRes = window.NovaPulseAndroid.savePlaylistJson(id, JSON.stringify(playlistObj));
        try {
          const parsed = JSON.parse(nativeRes);
          if (parsed && parsed.ok) return parsed.playlist || playlistObj;
        } catch (err) {}
        return playlistObj;
      }
      const res = await fetch('/api/playlists', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, description, items, color, icon, thumbnail, category })
      });
      const data = await res.json();
      return data.ok ? data.playlist : null;
    } catch (e) {
      console.error('Failed to create playlist on server:', e);
      return null;
    }
  }
  async function deleteServerPlaylist(id) {
    try {
      if (window.NovaPulseAndroid && typeof window.NovaPulseAndroid.deletePlaylist === 'function') {
        window.NovaPulseAndroid.deletePlaylist(id);
        return true;
      }
      const res = await fetch('/api/playlists/' + id, { method: 'DELETE' });
      const data = await res.json();
      return data.ok;
    } catch (e) {
      console.error('Failed to delete playlist:', e);
      return false;
    }
  }
  async function addMediaToServerPlaylist(playlistId, mediaItem) {
    try {
      const res = await fetch('/api/playlists/' + playlistId + '/items', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ item: mediaItem })
      });
      const data = await res.json();
      return data.ok ? data.playlist : null;
    } catch (e) {
      console.error('Failed to add item to playlist:', e);
      return null;
    }
  }
  async function getServerPlaylist(id) {
    try {
      const res = await fetch('/api/playlists/' + id);
      const data = await res.json();
      return data.ok ? data.playlist : null;
    } catch (e) {
      console.error('Failed to get playlist from server:', e);
      return null;
    }
  }
  async function updateServerPlaylist(id, updates) {
    try {
      if (window.NovaPulseAndroid && typeof window.NovaPulseAndroid.savePlaylistJson === 'function') {
        let existing = await getServerPlaylist(id) || {};
        const merged = { ...existing, ...updates, id, updatedAt: new Date().toISOString() };
        window.NovaPulseAndroid.savePlaylistJson(id, JSON.stringify(merged));
        return merged;
      }
      const res = await fetch('/api/playlists/' + id, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates)
      });
      const data = await res.json();
      return data.ok ? data.playlist : null;
    } catch (e) {
      console.error('Failed to update playlist on server:', e);
      return null;
    }
  }
  async function removeItemFromServerPlaylist(playlistId, mediaId) {
    try {
      const res = await fetch('/api/playlists/' + playlistId + '/items/' + encodeURIComponent(mediaId), {
        method: 'DELETE'
      });
      const data = await res.json();
      return data.ok ? data.playlist : null;
    } catch (e) {
      console.error('Failed to remove item from server playlist:', e);
      return null;
    }
  }
  try { init(); } catch (e) { console.warn('Playlist auto-init:', e); }
  return {
    init,
    getItems,
    getCurrentIndex,
    getCurrentItem,
    addItem,
    addItems,
    removeItem,
    clear,
    fetchServerPlaylists,
    createServerPlaylist,
    deleteServerPlaylist,
    addMediaToServerPlaylist,
    getServerPlaylist,
    updateServerPlaylist,
    removeItemFromServerPlaylist,
    selectIndex,
    moveItem,   // Phase 2: drag-and-drop reorder
    playNow,    // Phase 2: play now action
    setQueue,   // Atomically set full playlist queue
    next,
    previous,
    onMediaEnded,
    cycleRepeatMode,
    getRepeatMode,
    toggleShuffle,
    setShuffle,
    getIsShuffle,
    isShuffle: getIsShuffle,
    setItemRepeatCount,
    getItemRepeatCount,
    getCurrentTrackPlays,
    onPlaylistChange: (cb) => { if (typeof cb === 'function') onPlaylistChangeCbs.push(cb); },
    onItemChange: (cb) => { if (typeof cb === 'function') onItemChangeCbs.push(cb); }
  };
})();