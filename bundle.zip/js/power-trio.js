// power-trio.js - Killer Triad: AI Precision Cloud Trimmer, GhostDrive Turbo-Pipe & Neural Vault Spoken-Word Search
(function () {
  'use strict';

  // State
  let cachedInfo = null;
  let cachedChapters = [];
  let videoDuration = 0;
  let neuralSearchDebounceTimer = null;

  // -------------------------------------------------------------
  // Helpers
  // -------------------------------------------------------------
  function formatSecondsToTimestamp(seconds) {
    if (isNaN(seconds) || seconds < 0) seconds = 0;
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }

  function parseTimestampToSeconds(ts) {
    if (!ts) return 0;
    const clean = String(ts).trim();
    const parts = clean.split(':').map(Number);
    if (parts.length === 3) {
      return (parts[0] || 0) * 3600 + (parts[1] || 0) * 60 + (parts[2] || 0);
    } else if (parts.length === 2) {
      return (parts[0] || 0) * 60 + (parts[1] || 0);
    } else if (parts.length === 1) {
      return isNaN(parts[0]) ? 0 : parts[0];
    }
    return 0;
  }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function highlightMatches(text, query) {
    if (!text) return '';
    if (!query) return escapeHtml(text);
    const qEscaped = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`(${qEscaped})`, 'gi');
    const escaped = escapeHtml(text);
    return escaped.replace(regex, '<mark>$1</mark>');
  }

  // -------------------------------------------------------------
  // Feature 1: AI Precision Cloud Trimmer
  // -------------------------------------------------------------
  function updateTrimmerDurationDisplay() {
    const sInput = document.getElementById('trimmerStartTime');
    const eInput = document.getElementById('trimmerEndTime');
    const txtEl = document.getElementById('trimmerDurationText');
    if (!sInput || !eInput || !txtEl) return;

    const sSec = parseTimestampToSeconds(sInput.value);
    const eSec = parseTimestampToSeconds(eInput.value);
    const diff = Math.max(0, eSec - sSec);

    const m = Math.floor(diff / 60);
    const s = Math.floor(diff % 60);
    const h = Math.floor(m / 60);

    if (h > 0) {
      txtEl.textContent = `${h}h ${m % 60}m ${String(s).padStart(2, '0')}s Clip`;
    } else {
      txtEl.textContent = `${String(m).padStart(2, '0')}m ${String(s).padStart(2, '0')}s Clip`;
    }
  }

  function initTrimmerPreview(info) {
    cachedInfo = info;
    videoDuration = info.duration || 0;
    cachedChapters = Array.isArray(info.chapters) ? info.chapters : [];

    const sInput = document.getElementById('trimmerStartTime');
    const eInput = document.getElementById('trimmerEndTime');
    if (sInput) sInput.value = '00:00:00';
    if (eInput) {
      const defaultEnd = videoDuration > 0 ? Math.min(videoDuration, 60) : 60;
      eInput.value = formatSecondsToTimestamp(defaultEnd);
    }

    updateTrimmerDurationDisplay();

    // Populate Chapters
    const chaptersBox = document.getElementById('trimmerChaptersBox');
    const chapterSelect = document.getElementById('trimmerChapterSelect');
    const chapterBadge = document.getElementById('trimmerChapterCountBadge');

    if (chaptersBox && chapterSelect) {
      if (cachedChapters.length > 0) {
        chaptersBox.style.display = 'block';
        if (chapterBadge) chapterBadge.textContent = `${cachedChapters.length} chapters auto-detected`;

        chapterSelect.innerHTML = '<option value="">-- Choose a Detected Chapter to Auto-Clip --</option>';
        cachedChapters.forEach((ch, idx) => {
          const sFormatted = formatSecondsToTimestamp(ch.startTime);
          const eFormatted = formatSecondsToTimestamp(ch.endTime);
          const opt = document.createElement('option');
          opt.value = idx;
          opt.textContent = `${ch.title} (${sFormatted} → ${eFormatted})`;
          chapterSelect.appendChild(opt);
        });
      } else {
        chaptersBox.style.display = 'none';
      }
    }
  }

  function setupTrimmerEvents() {
    const sInput = document.getElementById('trimmerStartTime');
    const eInput = document.getElementById('trimmerEndTime');
    const chapterSelect = document.getElementById('trimmerChapterSelect');
    const btnDownloadClip = document.getElementById('btnDownloadClip');

    if (sInput) {
      sInput.addEventListener('input', updateTrimmerDurationDisplay);
      sInput.addEventListener('change', () => {
        sInput.value = formatSecondsToTimestamp(parseTimestampToSeconds(sInput.value));
        updateTrimmerDurationDisplay();
      });
    }

    if (eInput) {
      eInput.addEventListener('input', updateTrimmerDurationDisplay);
      eInput.addEventListener('change', () => {
        eInput.value = formatSecondsToTimestamp(parseTimestampToSeconds(eInput.value));
        updateTrimmerDurationDisplay();
      });
    }

    if (chapterSelect) {
      chapterSelect.addEventListener('change', () => {
        const idx = parseInt(chapterSelect.value, 10);
        if (!isNaN(idx) && cachedChapters[idx]) {
          const ch = cachedChapters[idx];
          if (sInput) sInput.value = formatSecondsToTimestamp(ch.startTime);
          if (eInput) eInput.value = formatSecondsToTimestamp(ch.endTime);
          updateTrimmerDurationDisplay();
          if (typeof window.showNovaToast === 'function') {
            window.showNovaToast(`Snapped to Chapter: ${ch.title}`, 'fa-scissors');
          }
        }
      });
    }

    // Quick presets
    document.querySelectorAll('.trimmer-preset-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        const preset = chip.dataset.preset;
        const dur = videoDuration > 0 ? videoDuration : 300;

        if (preset === 'first30') {
          if (sInput) sInput.value = '00:00:00';
          if (eInput) eInput.value = formatSecondsToTimestamp(Math.min(dur, 30));
        } else if (preset === 'first60') {
          if (sInput) sInput.value = '00:00:00';
          if (eInput) eInput.value = formatSecondsToTimestamp(Math.min(dur, 60));
        } else if (preset === 'first5m') {
          if (sInput) sInput.value = '00:00:00';
          if (eInput) eInput.value = formatSecondsToTimestamp(Math.min(dur, 300));
        } else if (preset === 'last60') {
          const s = Math.max(0, dur - 60);
          if (sInput) sInput.value = formatSecondsToTimestamp(s);
          if (eInput) eInput.value = formatSecondsToTimestamp(dur);
        } else if (preset === 'full') {
          if (sInput) sInput.value = '00:00:00';
          if (eInput) eInput.value = formatSecondsToTimestamp(dur);
        }

        updateTrimmerDurationDisplay();
      });
    });

    // Download clip trigger
    if (btnDownloadClip) {
      btnDownloadClip.addEventListener('click', () => {
        const meta = typeof window.getActiveDownloadUrlAndMeta === 'function' 
          ? window.getActiveDownloadUrlAndMeta() 
          : { url: '', titleHint: 'Video Clip' };

        if (!meta.url) {
          alert('Please inspect or enter a valid video URL first!');
          return;
        }

        const startTs = sInput ? sInput.value.trim() : '00:00:00';
        const endTs = eInput ? eInput.value.trim() : '00:01:00';

        const formatRadio = document.querySelector('input[name="trimmerFormatType"]:checked');
        const clipMode = (formatRadio && formatRadio.value === 'audio') ? 'audio' : 'max';

        const titleHint = `${meta.titleHint} [Clip ${startTs}-${endTs}]`;

        if (typeof window.triggerDownload === 'function') {
          window.triggerDownload({
            url: meta.url,
            mode: clipMode,
            timeRange: { start: startTs, end: endTs },
            browserCookies: meta.browserCookies,
            ghostDriveTurbo: meta.ghostDriveTurbo,
            titleHint: titleHint
          }, btnDownloadClip);
        } else {
          alert('Download engine starting...');
        }
      });
    }
  }

  // -------------------------------------------------------------
  // Feature 2: GhostDrive Turbo-Pipe Engine
  // -------------------------------------------------------------
  function setupGhostDrive() {
    const btn = document.getElementById('btnToggleGhostDrive');
    const label = document.getElementById('ghostDriveStatusLabel');
    const dot = document.getElementById('ghostDriveDot');
    if (!btn) return;

    // Load persisted state or default to true
    let isGhostDrive = localStorage.getItem('novapulse_ghostdrive_active');
    if (isGhostDrive === null) isGhostDrive = 'true';
    window.__ghostDriveActive = isGhostDrive === 'true';

    function renderGhostDriveState() {
      if (window.__ghostDriveActive) {
        btn.classList.add('active');
        if (dot) dot.style.background = '#4ade80';
        if (label) {
          label.textContent = '16x Active';
          label.style.color = '#4ade80';
        }
      } else {
        btn.classList.remove('active');
        if (dot) dot.style.background = '#64748b';
        if (label) {
          label.textContent = 'Standard 1x';
          label.style.color = '#94a3b8';
        }
      }
    }

    renderGhostDriveState();

    btn.addEventListener('click', (e) => {
      e.preventDefault();
      window.__ghostDriveActive = !window.__ghostDriveActive;
      localStorage.setItem('novapulse_ghostdrive_active', String(window.__ghostDriveActive));
      renderGhostDriveState();

      if (typeof window.showNovaToast === 'function') {
        if (window.__ghostDriveActive) {
          window.showNovaToast('GhostDrive Turbo: 16-Socket Anti-Throttle & BotGuard Shield Activated!', 'fa-bolt');
        } else {
          window.showNovaToast('GhostDrive Turbo Deactivated (Standard Speed)', 'fa-info-circle');
        }
      }
    });
  }

  // -------------------------------------------------------------
  // Feature 3: Neural Vault & Spoken-Word Search
  // -------------------------------------------------------------
  let isNeuralSearchOpen = false;

  function setupNeuralSearch() {
    const btnToggle = document.getElementById('btnToggleNeuralSearch');
    const resultsPanel = document.getElementById('neuralSearchResults');
    const searchInput = document.getElementById('libSearchInput');

    if (!btnToggle || !resultsPanel) return;

    function renderEmptyPrompt() {
      resultsPanel.innerHTML = `
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px;">
          <div class="neural-search-title">
            <i class="fa-solid fa-brain" style="color: #ff1f3d;"></i>
            <span>Neural Spoken-Word Search</span>
          </div>
          <button class="notif-icon-action-btn" id="btnCloseNeuralSearch" title="Close spoken search" style="background:none; border:none; color:#94a3b8; cursor:pointer; font-size:1rem;">
            <i class="fa-solid fa-xmark"></i>
          </button>
        </div>
        <div style="text-align: center; padding: 22px 14px; color: #94a3b8;">
          <i class="fa-solid fa-waveform-lines" style="font-size: 2.2rem; color: #00F5FF; margin-bottom: 10px; display: inline-block;"></i>
          <div style="font-weight: 700; color: #fff; font-size: 1rem; margin-bottom: 4px;">Universal Voice &amp; Dialogue Indexer</div>
          <p style="font-size: 0.82rem; margin: 0; color: #cbd5e1; max-width: 520px; margin: 0 auto;">Type any spoken phrase, lyrics, quote, or lecture topic to find exact timestamps across all your downloaded media.</p>
        </div>
      `;
      const closeBtn = document.getElementById('btnCloseNeuralSearch');
      if (closeBtn) {
        closeBtn.onclick = () => toggleNeuralSearch(false);
      }
    }

    function toggleNeuralSearch(forceState = null) {
      isNeuralSearchOpen = forceState !== null ? forceState : !isNeuralSearchOpen;

      if (isNeuralSearchOpen) {
        btnToggle.classList.add('active');
        btnToggle.style.background = 'rgba(255, 31, 61, 0.2)';
        btnToggle.style.borderColor = '#ff1f3d';
        resultsPanel.style.display = 'block';
        if (searchInput) {
          searchInput.placeholder = 'Search spoken dialogue, quotes, lyrics...';
          searchInput.focus();
          if (searchInput.value.trim().length >= 2) {
            triggerNeuralSearch(searchInput.value.trim());
          } else {
            renderEmptyPrompt();
          }
        }
      } else {
        btnToggle.classList.remove('active');
        btnToggle.style.background = 'rgba(255, 31, 61, 0.08)';
        btnToggle.style.borderColor = 'rgba(255, 31, 61, 0.4)';
        resultsPanel.style.display = 'none';
        if (searchInput) {
          searchInput.placeholder = 'Filter in library...';
          // Trigger normal library filter re-render
          if (typeof window.Library !== 'undefined' && typeof window.Library.setFilter === 'function') {
            window.Library.setFilter(searchInput.value.trim());
          }
        }
      }
    }

    btnToggle.addEventListener('click', (e) => {
      e.preventDefault();
      toggleNeuralSearch();
    });

    if (searchInput) {
      searchInput.addEventListener('input', () => {
        if (!isNeuralSearchOpen) return;
        const q = searchInput.value.trim();
        clearTimeout(neuralSearchDebounceTimer);
        if (q.length < 2) {
          renderEmptyPrompt();
          return;
        }
        neuralSearchDebounceTimer = setTimeout(() => {
          triggerNeuralSearch(q);
        }, 250);
      });
    }

    async function triggerNeuralSearch(query) {
      resultsPanel.innerHTML = `
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px;">
          <div class="neural-search-title">
            <i class="fa-solid fa-spinner fa-spin" style="color: #ff1f3d;"></i>
            <span>Scanning audio transcripts for "<span style="color:#00F5FF;">${escapeHtml(query)}</span>"...</span>
          </div>
        </div>
      `;

      try {
        const res = await fetch('/api/transcripts/search?q=' + encodeURIComponent(query));
        const data = await res.json();

        if (!data.ok) {
          resultsPanel.innerHTML = `
            <div style="padding: 18px; color: #f87171; text-align: center;">
              <i class="fa-solid fa-triangle-exclamation"></i> Search error: ${escapeHtml(data.error || 'Server error')}
            </div>
          `;
          return;
        }

        renderNeuralResults(data);
      } catch (err) {
        resultsPanel.innerHTML = `
          <div style="padding: 18px; color: #f87171; text-align: center;">
            <i class="fa-solid fa-triangle-exclamation"></i> Search failed: ${escapeHtml(err.message)}
          </div>
        `;
      }
    }

    function renderNeuralResults(data) {
      const { query } = data;
      // Flatten matches from data.results or fallback to data.hits
      let flatHits = [];
      if (Array.isArray(data.results)) {
        data.results.forEach(res => {
          if (Array.isArray(res.matches)) {
            res.matches.forEach(m => {
              flatHits.push({
                mediaId: res.mediaId,
                mediaUrl: res.mediaUrl,
                thumbnail: res.thumbnail,
                videoTitle: res.mediaName,
                start: m.start,
                end: m.end,
                timeStr: m.timeStr,
                text: m.text
              });
            });
          }
        });
      } else if (Array.isArray(data.hits)) {
        flatHits = data.hits;
      }

      if (flatHits.length === 0) {
        resultsPanel.innerHTML = `
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px;">
            <div class="neural-search-title">
              <i class="fa-solid fa-brain" style="color: #ff1f3d;"></i>
              <span>Neural Spoken Search Results</span>
            </div>
            <button class="notif-icon-action-btn" id="btnCloseNeuralSearch" title="Close" style="background:none; border:none; color:#94a3b8; cursor:pointer;"><i class="fa-solid fa-xmark"></i></button>
          </div>
          <div style="text-align: center; padding: 24px; color: #94a3b8;">
            <i class="fa-solid fa-comment-slash" style="font-size: 2rem; color: #64748b; margin-bottom: 10px; display: inline-block;"></i>
            <div style="font-weight: 700; color: #fff; font-size: 0.95rem;">No spoken quotes found for "${escapeHtml(query)}"</div>
            <p style="font-size: 0.8rem; margin: 4px 0 0;">Try synonyms or shorter spoken phrases.</p>
          </div>
        `;
        const closeBtn = document.getElementById('btnCloseNeuralSearch');
        if (closeBtn) closeBtn.onclick = () => toggleNeuralSearch(false);
        return;
      }

      let html = `
        <div class="neural-search-header">
          <div class="neural-search-title">
            <i class="fa-solid fa-brain" style="color: #ff1f3d;"></i>
            <span>Spoken-Word Matches: <strong style="color: #00F5FF;">${flatHits.length}</strong> for "<span style="color: #ff4d6d;">${escapeHtml(query)}</span>"</span>
          </div>
          <button class="notif-icon-action-btn" id="btnCloseNeuralSearch" title="Close spoken search" style="background:none; border:none; color:#94a3b8; cursor:pointer; font-size:1.05rem;">
            <i class="fa-solid fa-xmark"></i>
          </button>
        </div>
        <div class="neural-hits-grid">
      `;

      flatHits.forEach((hit, idx) => {
        const thumb = hit.thumbnail || 'assets/icons/novapulse.png';
        html += `
          <div class="neural-hit-card" data-idx="${idx}" data-start="${hit.start}" data-time="${escapeHtml(hit.timeStr)}" data-media-id="${escapeHtml(hit.mediaId || '')}" data-media-url="${escapeHtml(hit.mediaUrl || '')}" data-video-title="${escapeHtml(hit.videoTitle || '')}">
            <img class="neural-hit-thumb" src="${escapeHtml(thumb)}" alt="Thumbnail" onerror="this.src='assets/icons/novapulse.png'" />
            <div class="neural-hit-info">
              <div class="neural-hit-title" title="${escapeHtml(hit.videoTitle)}">${escapeHtml(hit.videoTitle)}</div>
              <div class="neural-hit-quote">"${highlightMatches(hit.text, query)}"</div>
              <div class="neural-hit-action-row">
                <span class="neural-time-pill"><i class="fa-solid fa-play" style="font-size: 0.6rem;"></i> ${hit.timeStr}</span>
                <span style="font-size: 0.72rem; color: #94a3b8; display: inline-flex; align-items: center; gap: 4px;">
                  <i class="fa-solid fa-bolt" style="color: #ff1f3d;"></i> Jump to exact second
                </span>
              </div>
            </div>
          </div>
        `;
      });

      html += `</div>`;
      resultsPanel.innerHTML = html;

      const closeBtn = document.getElementById('btnCloseNeuralSearch');
      if (closeBtn) closeBtn.onclick = () => toggleNeuralSearch(false);

      // Handle hit card click -> Jump to exact second in Player Studio
      resultsPanel.querySelectorAll('.neural-hit-card').forEach(card => {
        card.addEventListener('click', () => {
          const startSec = parseFloat(card.dataset.start) || 0;
          const timeStr = card.dataset.time;
          const videoTitle = card.dataset.videoTitle;
          const mediaId = card.dataset.mediaId;
          const mediaUrl = card.dataset.mediaUrl;

          // Find matching media in library
          let matchedItem = null;
          if (typeof window.Library !== 'undefined' && typeof window.Library.getMediaList === 'function') {
            const list = window.Library.getMediaList() || [];
            matchedItem = list.find(m => {
              if (mediaId && m.id === mediaId) return true;
              if (mediaUrl && m.url === mediaUrl) return true;
              if (videoTitle && m.name && m.name.toLowerCase().includes(videoTitle.toLowerCase().slice(0, 20))) return true;
              return false;
            });
          }

          if (!matchedItem) {
            matchedItem = {
              id: mediaId || ('media_' + Date.now()),
              name: videoTitle || 'Media File',
              url: mediaUrl || ('/api/media/' + encodeURIComponent(videoTitle + '.mp4')),
              type: 'video'
            };
          }

          if (typeof window.playLibraryTrackWithQueue === 'function') {
            window.playLibraryTrackWithQueue(matchedItem);
          } else if (typeof window.switchView === 'function') {
            window.switchView('player');
          }

          // Seek video element to startSec
          setTimeout(() => {
            const vEl = document.getElementById('mainVideoPlayer');
            if (vEl) {
              vEl.currentTime = startSec;
              vEl.play().catch(() => {});
            }
            if (typeof window.showNovaToast === 'function') {
              window.showNovaToast(`Jumped to spoken quote at ${timeStr}!`, 'fa-bolt');
            }
          }, 350);
        });
      });
    }
  }

  // -------------------------------------------------------------
  // Initialization
  // -------------------------------------------------------------
  function initPowerTrio() {
    setupTrimmerEvents();
    setupGhostDrive();
    setupNeuralSearch();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initPowerTrio);
  } else {
    initPowerTrio();
  }

  // Export public interface
  window.PowerTrio = {
    initTrimmerPreview,
    formatSecondsToTimestamp,
    parseTimestampToSeconds
  };

})();
