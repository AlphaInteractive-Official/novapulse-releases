/**
 * notifications.js - NovaPulse Notification Center
 * Interactive, glassmorphic, persistent notification hub with action buttons and category filtering.
 */
(function() {
  const STORAGE_KEY = 'novapulse_notifications_v3';
  const SOUND_KEY = 'novapulse_notif_sound_enabled';
  const MAX_NOTIFS = 50;

  let notifications = [];
  let currentFilter = 'all';
  let soundEnabled = localStorage.getItem(SOUND_KEY) !== 'false';

  const DEFAULT_SEEDS = [
    {
      id: 'notif_sys_engine_ready',
      title: 'NovaPulse Engine Active',
      desc: 'Alpha Interactive Core v4.1 + GPU Hardware Acceleration Initialized.',
      category: 'system',
      level: 'engine',
      icon: 'fa-bolt',
      iconClass: 'notif-icon-engine',
      timestamp: Date.now() - 45000,
      unread: true,
      actions: [
        { label: 'System Engine', icon: 'fa-microchip', type: 'engine_info' }
      ]
    },
    {
      id: 'notif_sys_storage_synced',
      title: 'Hardware Storage Synced',
      desc: 'Real hardware partition detected with active storage monitoring.',
      category: 'system',
      level: 'storage',
      icon: 'fa-hard-drive',
      iconClass: 'notif-icon-storage',
      timestamp: Date.now() - 180000,
      unread: true,
      actions: [
        { label: 'Storage Health', icon: 'fa-chart-pie', type: 'navigate', view: 'storage' }
      ]
    },
    {
      id: 'notif_sys_vault_ready',
      title: 'AES-256 Vault Online',
      desc: 'Encrypted storage vault ready with zero-trace decrypted streaming.',
      category: 'system',
      level: 'vault',
      icon: 'fa-shield-halved',
      iconClass: 'notif-icon-vault',
      timestamp: Date.now() - 600000,
      unread: true,
      actions: [
        { label: 'Secure Vault', icon: 'fa-lock', type: 'navigate', view: 'vault' }
      ]
    }
  ];

  function load() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        notifications = JSON.parse(raw);
        if (!Array.isArray(notifications) || notifications.length === 0) {
          notifications = [...DEFAULT_SEEDS];
          save();
        }
      } else {
        notifications = [...DEFAULT_SEEDS];
        save();
      }
    } catch (e) {
      notifications = [...DEFAULT_SEEDS];
    }
  }

  function save() {
    try {
      if (notifications.length > MAX_NOTIFS) {
        notifications = notifications.slice(0, MAX_NOTIFS);
      }
      localStorage.setItem(STORAGE_KEY, JSON.stringify(notifications));
    } catch (e) {}
  }

  function playNotificationSound() {
    if (!soundEnabled) return;
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.1); // A5
      gain.gain.setValueAtTime(0.09, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.28);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.3);
    } catch (e) {}
  }

  function formatRelativeTime(ts) {
    if (!ts) return 'Just now';
    const diff = Math.floor((Date.now() - ts) / 1000);
    if (diff < 20) return 'Just now';
    if (diff < 60) return `${diff}s ago`;
    const mins = Math.floor(diff / 60);
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    const days = Math.floor(hrs / 24);
    return `${days}d ago`;
  }

  function escapeHtml(str) {
    return String(str === null || str === undefined ? '' : str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function updateUnreadBadge() {
    const unreadCount = notifications.filter(n => n.unread).length;
    const headerNotifDot = document.getElementById('headerNotifDot');
    const notifBadgePill = document.getElementById('notifBadgePill');
    const notifSubCount = document.getElementById('notifSubCount');

    if (headerNotifDot) {
      headerNotifDot.style.display = unreadCount > 0 ? 'block' : 'none';
    }

    if (notifBadgePill) {
      if (unreadCount > 0) {
        notifBadgePill.textContent = `${unreadCount} new`;
        notifBadgePill.className = 'notif-count-pill';
      } else {
        notifBadgePill.textContent = 'All caught up';
        notifBadgePill.className = 'notif-count-pill caught-up';
      }
    }

    if (notifSubCount) {
      if (unreadCount > 0) {
        notifSubCount.textContent = `${unreadCount} unread notification${unreadCount === 1 ? '' : 's'}`;
      } else {
        notifSubCount.textContent = 'All system & download activity caught up';
      }
    }

    // Update tab counts
    const countAll = notifications.length;
    const countDownload = notifications.filter(n => n.category === 'download').length;
    const countSystem = notifications.filter(n => n.category === 'system').length;
    const countAlert = notifications.filter(n => n.category === 'alert').length;

    const elAll = document.getElementById('tabCountAll');
    const elDownload = document.getElementById('tabCountDownload');
    const elSystem = document.getElementById('tabCountSystem');
    const elAlert = document.getElementById('tabCountAlert');

    if (elAll) elAll.textContent = countAll;
    if (elDownload) elDownload.textContent = countDownload;
    if (elSystem) elSystem.textContent = countSystem;
    if (elAlert) elAlert.textContent = countAlert;
  }

  function renderList() {
    const container = document.getElementById('notifPopoverList');
    if (!container) return;

    let items = notifications;
    if (currentFilter !== 'all') {
      items = notifications.filter(n => n.category === currentFilter);
    }

    if (items.length === 0) {
      container.innerHTML = `
        <div class="notif-empty-state">
          <div class="notif-empty-icon">
            <i class="fa-solid fa-check"></i>
          </div>
          <div class="notif-empty-title">All caught up!</div>
          <div class="notif-empty-desc">No ${currentFilter === 'all' ? '' : currentFilter + ' '}notifications right now. Live events will appear here automatically.</div>
        </div>
      `;
      return;
    }

    container.innerHTML = items.map(item => {
      const actionsHtml = (item.actions && item.actions.length > 0) ? `
        <div class="notif-card-actions">
          ${item.actions.map((act, idx) => `
            <button class="notif-action-btn ${act.type === 'play' ? 'primary' : (act.type === 'retry' ? 'retry' : 'secondary')}" data-notif-id="${item.id}" data-action-idx="${idx}">
              ${act.icon ? `<i class="fa-solid ${act.icon}"></i>` : ''} ${escapeHtml(act.label)}
            </button>
          `).join('')}
        </div>
      ` : '';

      return `
        <div class="notif-card ${item.unread ? 'unread' : 'read'}" data-id="${item.id}">
          <div class="notif-card-icon ${item.iconClass || 'notif-icon-engine'}">
            <i class="fa-solid ${item.icon || 'fa-bell'}"></i>
          </div>
          <div class="notif-card-content">
            <div class="notif-card-top">
              <span class="notif-card-title" title="${escapeHtml(item.title)}">${escapeHtml(item.title)}</span>
              <span class="notif-card-time">${formatRelativeTime(item.timestamp)}</span>
            </div>
            <div class="notif-card-desc">${escapeHtml(item.desc)}</div>
            ${actionsHtml}
          </div>
          <div class="notif-card-aside">
            ${item.unread ? '<span class="notif-card-dot" title="Unread"></span>' : ''}
            <button class="notif-card-dismiss" data-dismiss-id="${item.id}" title="Dismiss">
              <i class="fa-solid fa-xmark"></i>
            </button>
          </div>
        </div>
      `;
    }).join('');

    // Wire dismiss buttons
    container.querySelectorAll('.notif-card-dismiss').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const id = btn.getAttribute('data-dismiss-id');
        remove(id);
      });
    });

    // Wire action buttons
    container.querySelectorAll('.notif-action-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const notifId = btn.getAttribute('data-notif-id');
        const actIdx = parseInt(btn.getAttribute('data-action-idx'), 10);
        executeAction(notifId, actIdx);
      });
    });

    // Wire clicking on a card to mark it as read
    container.querySelectorAll('.notif-card').forEach(card => {
      card.addEventListener('click', (e) => {
        if (e.target.closest('button')) return;
        const id = card.getAttribute('data-id');
        markAsRead(id);
      });
    });
  }

  function executeAction(notifId, actIdx) {
    const notif = notifications.find(n => n.id === notifId);
    if (!notif || !notif.actions || !notif.actions[actIdx]) return;
    const act = notif.actions[actIdx];

    // Mark as read on interaction
    markAsRead(notifId);

    // Close notification dropdown
    closePopover();

    if (act.type === 'play') {
      if (typeof switchView === 'function') switchView('player');
      if (typeof Player !== 'undefined') {
        const itemObj = {
          name: act.mediaName || notif.title || 'Media Video',
          url: act.mediaUrl,
          type: 'video'
        };
        setTimeout(() => {
          Player.loadMedia(itemObj, 0, true);
        }, 150);
      }
    } else if (act.type === 'folder') {
      if (typeof openFolder === 'function') {
        openFolder(act.path || '');
      } else {
        fetch('/api/open-folder', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ folderPath: act.path || '' })
        }).catch(e => console.error(e));
      }
    } else if (act.type === 'retry') {
      if (act.taskId) {
        if (typeof showNovaToast === 'function') {
          showNovaToast('Retrying download...', 'fa-rotate-right');
        }
        fetch(`/api/downloads/${act.taskId}/resume`, { method: 'POST' })
          .then(res => res.json())
          .then(data => {
            if (typeof switchView === 'function') switchView('downloads');
          })
          .catch(e => console.error('Retry request failed', e));
      }
    } else if (act.type === 'navigate') {
      if (typeof switchView === 'function') {
        switchView(act.view);
      }
    } else if (act.type === 'engine_info') {
      const modal = document.getElementById('novaMultiEngineModal');
      if (modal) modal.style.display = 'flex';
    }
  }

  function markAsRead(id) {
    const item = notifications.find(n => n.id === id);
    if (item && item.unread) {
      item.unread = false;
      save();
      updateUnreadBadge();
      renderList();
    }
  }

  function markAllAsRead() {
    notifications.forEach(n => { n.unread = false; });
    save();
    updateUnreadBadge();
    renderList();
    if (typeof showNovaToast === 'function') {
      showNovaToast('All notifications marked as read', 'fa-check-double');
    }
  }

  function clearAll() {
    notifications = [];
    save();
    updateUnreadBadge();
    renderList();
    if (typeof showNovaToast === 'function') {
      showNovaToast('Notification history cleared', 'fa-trash-can');
    }
  }

  function remove(id) {
    notifications = notifications.filter(n => n.id !== id);
    save();
    updateUnreadBadge();
    renderList();
  }

  function add(item) {
    const notif = {
      id: item.id || ('notif_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6)),
      title: item.title || 'Notification',
      desc: item.desc || item.message || '',
      category: item.category || 'system',
      level: item.level || 'info',
      icon: item.icon || 'fa-bell',
      iconClass: item.iconClass || 'notif-icon-engine',
      timestamp: item.timestamp || Date.now(),
      unread: item.unread !== undefined ? item.unread : true,
      actions: item.actions || []
    };

    notifications.unshift(notif);
    if (notifications.length > MAX_NOTIFS) {
      notifications = notifications.slice(0, MAX_NOTIFS);
    }
    save();
    updateUnreadBadge();
    renderList();
    playNotificationSound();
  }

  function getBasename(filePath) {
    if (!filePath) return '';
    const clean = filePath.replace(/\\/g, '/');
    const segs = clean.split('/');
    return segs[segs.length - 1] || clean;
  }

  function closePopover() {
    const backdrop = document.getElementById('novaNotifBackdrop');
    const popover = document.getElementById('novaNotifPopover');
    if (backdrop) {
      backdrop.style.display = 'none';
      backdrop.classList.remove('active', 'open');
    }
    if (popover) {
      popover.style.display = 'none';
      popover.classList.remove('open');
    }
  }

  function openPopover() {
    const backdrop = document.getElementById('novaNotifBackdrop');
    const popover = document.getElementById('novaNotifPopover');
    if (backdrop) {
      backdrop.style.display = 'flex';
      backdrop.classList.add('active', 'open');
    }
    if (popover) {
      popover.style.display = 'flex';
      popover.classList.add('open');
    }
    renderList();
    updateUnreadBadge();
  }

  function togglePopover() {
    const backdrop = document.getElementById('novaNotifBackdrop');
    const popover = document.getElementById('novaNotifPopover');
    const isHidden = backdrop 
      ? (!backdrop.classList.contains('active') && (backdrop.style.display === 'none' || window.getComputedStyle(backdrop).display === 'none'))
      : (popover && (popover.style.display === 'none' || window.getComputedStyle(popover).display === 'none'));
    if (isHidden) {
      openPopover();
    } else {
      closePopover();
    }
  }

  let isInitialized = false;

  function init() {
    load();

    const headerNotifBtn = document.getElementById('headerNotifBtn');
    const novaNotifPopover = document.getElementById('novaNotifPopover');
    const btnMarkAllRead = document.getElementById('btnMarkAllRead');
    const btnClearNotifs = document.getElementById('btnClearNotifs');
    const notifStorageQuickLink = document.getElementById('notifStorageQuickLink');
    const notifToggleSoundBtn = document.getElementById('notifToggleSoundBtn');
    const notifSoundIcon = document.getElementById('notifSoundIcon');

    if (notifSoundIcon) {
      notifSoundIcon.className = soundEnabled ? 'fa-solid fa-volume-high' : 'fa-solid fa-volume-xmark';
    }

    updateUnreadBadge();

    // Prevent duplicate event listener registration if init is called multiple times
    if (isInitialized) return;
    isInitialized = true;

    if (headerNotifBtn) {
      headerNotifBtn.onclick = (e) => {
        if (e) {
          e.preventDefault();
          e.stopPropagation();
        }
        togglePopover();
      };
    }

    if (btnMarkAllRead) {
      btnMarkAllRead.onclick = (e) => {
        if (e) e.stopPropagation();
        markAllAsRead();
      };
    }

    if (btnClearNotifs) {
      btnClearNotifs.onclick = (e) => {
        if (e) e.stopPropagation();
        clearAll();
      };
    }

    if (notifStorageQuickLink) {
      notifStorageQuickLink.onclick = (e) => {
        if (e) e.stopPropagation();
        closePopover();
        if (typeof switchView === 'function') switchView('storage');
      };
    }

    if (notifToggleSoundBtn) {
      notifToggleSoundBtn.onclick = (e) => {
        if (e) e.stopPropagation();
        soundEnabled = !soundEnabled;
        localStorage.setItem(SOUND_KEY, String(soundEnabled));
        if (notifSoundIcon) {
          notifSoundIcon.className = soundEnabled ? 'fa-solid fa-volume-high' : 'fa-solid fa-volume-xmark';
        }
        if (typeof showNovaToast === 'function') {
          showNovaToast(soundEnabled ? 'Notification chime enabled' : 'Notification chime muted', soundEnabled ? 'fa-volume-high' : 'fa-volume-xmark');
        }
      };
    }

    // Filter tabs
    const filterTabs = document.querySelectorAll('.notif-filter-tab');
    filterTabs.forEach(tab => {
      tab.onclick = (e) => {
        if (e) e.stopPropagation();
        filterTabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        currentFilter = tab.getAttribute('data-filter') || 'all';
        renderList();
      };
    });

    // Close on outside click (ignoring clicks inside popover or on the toggle button)
    document.addEventListener('click', (e) => {
      const popover = document.getElementById('novaNotifPopover');
      if (popover && window.getComputedStyle(popover).display !== 'none') {
        const btn = document.getElementById('headerNotifBtn');
        if (!popover.contains(e.target) && !e.target.closest('#headerNotifBtn')) {
          closePopover();
        }
      }
    });

    // Close on Escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        closePopover();
      }
    });
  }

  // Public API
  window.NotificationCenter = {
    init,
    add,
    remove,
    clearAll,
    markAllAsRead,
    markAsRead,
    toggle: togglePopover,
    open: openPopover,
    close: closePopover,

    // Specialized helpers for downloads & engine events
    pushDownloadCompleted({ title, savedFile, outputDir, total }) {
      let mediaUrl = null;
      if (savedFile) {
        try {
          const norm = savedFile.replace(/\\/g, '/');
          const rel = norm.split('/Videos/')[1] ? ('Videos/' + norm.split('/Videos/')[1]) : getBasename(norm);
          mediaUrl = '/api/media/' + rel.split('/').map(seg => encodeURIComponent(seg)).join('/');
        } catch (e) {}
      }

      const actions = [];
      if (mediaUrl) {
        actions.push({
          label: 'Play',
          icon: 'fa-play',
          type: 'play',
          mediaUrl,
          mediaName: title
        });
      }
      actions.push({
        label: 'Folder',
        icon: 'fa-folder-open',
        type: 'folder',
        path: outputDir || ''
      });

      add({
        title: 'Download Complete',
        desc: `"${title || 'Media'}" was saved successfully${total ? ' (' + total + ')' : ''}.`,
        category: 'download',
        level: 'success',
        icon: 'fa-circle-check',
        iconClass: 'notif-icon-success',
        actions
      });
    },

    pushDownloadFailed({ taskId, title, error }) {
      add({
        title: 'Download Failed',
        desc: `"${title || 'Media'}" halted: ${error || 'Connection interrupted.'}`,
        category: 'alert',
        level: 'error',
        icon: 'fa-triangle-exclamation',
        iconClass: 'notif-icon-error',
        actions: [
          { label: 'Retry', icon: 'fa-rotate-right', type: 'retry', taskId },
          { label: 'View Queue', icon: 'fa-list-check', type: 'navigate', view: 'downloads' }
        ]
      });
    },

    pushNightShiftScheduled({ title, message }) {
      add({
        title: '🌙 Queued for Night Shift',
        desc: `"${title || 'Media'}" scheduled for off-peak download window (1 AM - 7 AM).`,
        category: 'download',
        level: 'night',
        icon: 'fa-moon',
        iconClass: 'notif-icon-night',
        actions: [
          { label: 'View Queue', icon: 'fa-list-check', type: 'navigate', view: 'downloads' }
        ]
      });
    },

    pushSystemAlert({ title, message, level = 'info', icon = 'fa-bolt', actions = [] }) {
      add({
        title,
        desc: message,
        category: 'system',
        level,
        icon,
        iconClass: level === 'storage' ? 'notif-icon-storage' : (level === 'vault' ? 'notif-icon-vault' : 'notif-icon-engine'),
        actions
      });
    }
  };

  // Auto-boot when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    setTimeout(init, 50);
  }
})();
