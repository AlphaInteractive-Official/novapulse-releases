/**
 * NovaPulse System Media Notification & Lock-Screen Controller
 * Powers Android Notification Shade, Windows Media Flyout & macOS Control Center
 * Alpha Interactive (c) 2026. All rights reserved.
 */
(function() {
  let isMediaSessionSupported = 'mediaSession' in navigator;
  let activeMediaItem = null;

  function init() {
    if (!isMediaSessionSupported) {
      console.log('MediaSession API not supported in this client environment.');
      return;
    }

    setupMediaActionHandlers();
    listenToPlayerEvents();
    console.log('NovaPulse System Media Notification Controller initialized.');
  }

  function setupMediaActionHandlers() {
    try {
      // 1. Play & Pause
      navigator.mediaSession.setActionHandler('play', () => {
        if (window.Player && typeof window.Player.play === 'function') {
          window.Player.play();
        }
      });

      navigator.mediaSession.setActionHandler('pause', () => {
        if (window.Player && typeof window.Player.pause === 'function') {
          window.Player.pause();
        }
      });

      navigator.mediaSession.setActionHandler('stop', () => {
        if (window.Player && typeof window.Player.pause === 'function') {
          window.Player.pause();
        }
      });

      // 2. Seek Backward (10s like YouTube/Spotify)
      navigator.mediaSession.setActionHandler('seekbackward', (details) => {
        if (window.Player && typeof window.Player.seek === 'function') {
          const offset = details.seekOffset || 10;
          const target = Math.max(0, (window.Player.getCurrentTime() || 0) - offset);
          window.Player.seek(target);
        }
      });

      // 3. Seek Forward (10s)
      navigator.mediaSession.setActionHandler('seekforward', (details) => {
        if (window.Player && typeof window.Player.seek === 'function') {
          const offset = details.seekOffset || 10;
          const dur = window.Player.getDuration() || 0;
          const target = dur > 0 ? Math.min(dur, (window.Player.getCurrentTime() || 0) + offset) : (window.Player.getCurrentTime() || 0) + offset;
          window.Player.seek(target);
        }
      });

      // 4. Seek To specific scrubber position (Android notification scrubber bar)
      try {
        navigator.mediaSession.setActionHandler('seekto', (details) => {
          if (details.seekTime !== undefined && details.seekTime !== null && window.Player && typeof window.Player.seek === 'function') {
            window.Player.seek(details.seekTime);
          }
        });
      } catch (e) {}

      // 5. Next & Previous Track
      try {
        navigator.mediaSession.setActionHandler('nexttrack', () => {
          if (window.Playlist && typeof window.Playlist.next === 'function') {
            window.Playlist.next(true);
          }
        });
      } catch (e) {}

      try {
        navigator.mediaSession.setActionHandler('previoustrack', () => {
          if (window.Playlist && typeof window.Playlist.previous === 'function') {
            const curTime = (window.Player && typeof window.Player.getCurrentTime === 'function') ? window.Player.getCurrentTime() : 0;
            window.Playlist.previous(curTime, true);
          }
        });
      } catch (e) {}

    } catch (err) {
      console.warn('Error configuring MediaSession action handlers:', err);
    }
  }

  function listenToPlayerEvents() {
    // 1. Listen for custom player item events
    window.addEventListener('novapulse-player-item', (e) => {
      if (e.detail) {
        updateMetadata(e.detail);
      }
    });

    // 2. Hook into Player callbacks if already defined or on poll
    const hookPlayer = () => {
      if (window.Player) {
        // State change callback (Playing / Paused)
        if (typeof window.Player.onPlayStateChange === 'function') {
          window.Player.onPlayStateChange((isPlaying) => {
            syncPlaybackState(isPlaying);
          });
        }

        // Time update callback (Scrubber synchronization)
        if (typeof window.Player.onTimeUpdate === 'function') {
          window.Player.onTimeUpdate((currentTime, duration) => {
            syncPositionState(currentTime, duration);
          });
        }
      } else {
        setTimeout(hookPlayer, 300);
      }
    };
    hookPlayer();
  }

  function updateMetadata(item) {
    if (!item || !isMediaSessionSupported) return;
    activeMediaItem = item;

    const title = item.title || item.name || 'NovaPulse Media Track';
    const artist = item.uploader || item.channel || item.artist || 'NovaPulse Media Engine';
    const album = 'Alpha Interactive Media Suite';

    // Build responsive artwork array with local fallback
    const artworkSrc = item.thumbnail || item.thumbnailUrl || '/assets/icons/android-chrome-512x512.png';
    const artworkList = [
      { src: artworkSrc, sizes: '96x96', type: 'image/png' },
      { src: artworkSrc, sizes: '192x192', type: 'image/png' },
      { src: artworkSrc, sizes: '512x512', type: 'image/png' }
    ];

    try {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: title,
        artist: artist,
        album: album,
        artwork: artworkList
      });
    } catch (e) {
      console.warn('Failed setting MediaMetadata:', e);
    }

    // Bridge to Android Native APK if active
    if (window.AlphaDeviceBridge && typeof window.AlphaDeviceBridge.updateMediaNotification === 'function') {
      try {
        window.AlphaDeviceBridge.updateMediaNotification(title, artist, true);
      } catch (e) {}
    }
  }

  function syncPlaybackState(isPlaying) {
    if (!isMediaSessionSupported) return;
    try {
      navigator.mediaSession.playbackState = isPlaying ? 'playing' : 'paused';
    } catch (e) {}

    // Android APK Native Bridge sync
    if (window.AlphaDeviceBridge && typeof window.AlphaDeviceBridge.updateMediaNotificationState === 'function') {
      try {
        window.AlphaDeviceBridge.updateMediaNotificationState(isPlaying);
      } catch (e) {}
    }
  }

  function syncPositionState(currentTime, duration) {
    if (!isMediaSessionSupported || !navigator.mediaSession.setPositionState) return;
    try {
      if (duration && !isNaN(duration) && duration > 0 && currentTime >= 0) {
        const rate = (window.Player && typeof window.Player.getPlaybackRate === 'function') ? (window.Player.getPlaybackRate() || 1) : 1;
        navigator.mediaSession.setPositionState({
          duration: duration,
          playbackRate: rate,
          position: Math.min(currentTime, duration)
        });
      }
    } catch (e) {
      // Ignored for fast seek micro-jitter
    }
  }

  // Public interface
  window.NovaMediaSession = {
    updateMetadata,
    syncPlaybackState,
    syncPositionState
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
