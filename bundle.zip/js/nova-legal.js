/**
 * NovaPulse Media Engine — Universal Legal, Consent & Cold-Boot Intro Engine
 * Alpha Interactive (c) 2026. All rights reserved.
 */
(function() {
  const CONSENT_STORAGE_KEY = 'novapulse_consent_v1';
  let hasInspectedFullTerms = false;

  // Global full terms document (100% Neutral Global International Framework)
  const FULL_TERMS_TEXT = `
    <div class="legal-doc-wrap">
      <div class="legal-doc-header">
        <h2 style="margin: 0 0 6px; font-size: 1.4rem; color: #fff;">NovaPulse Media Engine — Universal Terms of Service &amp; Privacy Policy</h2>
        <div style="font-size: 0.8rem; color: var(--accent-cyan); font-weight: 600;">Published by Alpha Interactive &bull; Effective Worldwide</div>
      </div>

      <div class="legal-section">
        <h3>1. Nature of the Software &amp; Personal Client-Side Utility</h3>
        <p>NovaPulse Media Engine (the "Software"), developed by Alpha Interactive, is an offline, client-side media management utility designed exclusively for <b>personal, non-commercial media organization, fair-use playback, and local file archiving</b>.</p>
        <p>The Software runs entirely on the end-user's local hardware (personal computer, mobile phone, or tablet). Alpha Interactive does not host, stream, proxy, cache, index, or distribute any third-party video, audio, image, or torrent streams on any central servers.</p>
      </div>

      <div class="legal-section">
        <h3>2. Global Compliance &amp; Zero-Tolerance Policy</h3>
        <p>Users must comply with all applicable local, national, and international laws within their territorial jurisdiction. Users are strictly prohibited from utilizing NovaPulse to fetch, process, store, or redistribute:</p>
        <ul>
          <li>Non-consensual imagery, exploitative material, or abuse content of any kind;</li>
          <li>Terror-related material, hate speech, or defamatory publications;</li>
          <li>Malicious computer code, exploits, or proprietary commercial datasets;</li>
          <li>Any media restricted or banned under criminal or civil statutes in the user's country of residence.</li>
        </ul>
      </div>

      <div class="legal-section">
        <h3>3. Strict Non-Redistribution &amp; Fair Use</h3>
        <p>NovaPulse is licensed solely for the private individual consumption of the end-user. Any commercial redistribution, unauthorized public rebroadcasting, syndication, automated mirroring, or reselling of media retrieved using the Software is strictly prohibited and immediately terminates the user's license.</p>
      </div>

      <div class="legal-section">
        <h3>4. Disclaimer of Warranty &amp; Universal Indemnification</h3>
        <p>Alpha Interactive neither monitors, endorses, nor exercises any editorial control over external third-party URLs, magnet hashes, or web protocols entered by the user. <b>The end-user assumes 100% sole legal responsibility</b> for any link processed and any downstream use of downloaded files.</p>
        <p>Under no circumstances shall Alpha Interactive, its founders, contributors, or affiliates be held liable for any direct, indirect, incidental, punitive, or consequential damages, copyright claims, or legal actions resulting from user misuse of the Software. The user agrees to defend, indemnify, and hold harmless Alpha Interactive from all claims, damages, and legal costs.</p>
      </div>

      <div class="legal-section">
        <h3>5. Zero Telemetry &amp; Absolute Privacy Guarantee</h3>
        <ul>
          <li><b>No Central Logs:</b> NovaPulse collects zero browsing records, zero search histories, and zero IP logs.</li>
          <li><b>Direct Device-to-Host Communication:</b> Web streams are queried directly between your personal device and the remote web server. No URL is ever transmitted to Alpha Interactive.</li>
          <li><b>Local Sandboxed Storage:</b> All media files, encrypted vault records, bookmarks, and configurations reside exclusively in local device storage.</li>
          <li><b>No Advertising or Third-Party SDKs:</b> The Software is 100% free of advertising trackers, behavioral beacons, and third-party data brokers.</li>
        </ul>
      </div>

      <div class="legal-section">
        <h3>6. Termination of Access</h3>
        <p>Alpha Interactive reserves the right to revoke permission, block software updates, or render client components inoperable on any hardware platform verified to be engaging in commercial piracy or automated network abuse.</p>
      </div>
    </div>
  `;

  // 1. Initialize Cold-Boot Splash and Consent Flow
  function init() {
    setupSplashSequence();
    bindLegalModalEvents();
  }

  // 2. Cinematic Cold-Boot Splash Sequence
  function setupSplashSequence() {
    const splash = document.getElementById('novaIntroSplash');
    if (!splash) return;

    // Run cinematic intro for 1.2 seconds, then smoothly dissolve
    setTimeout(() => {
      splash.classList.add('splash-dissolve');
      setTimeout(() => {
        splash.style.display = 'none';
        checkFirstLaunchConsent();
      }, 550);
    }, 1250);
  }

  // 3. First-Launch Consent Check
  function checkFirstLaunchConsent() {
    const consent = localStorage.getItem(CONSENT_STORAGE_KEY);
    if (!consent) {
      showFirstLaunchModal();
    }
  }

  function showFirstLaunchModal() {
    const modal = document.getElementById('novaPrivacyFirstLaunchModal');
    if (!modal) return;
    
    // Reset cards state to Card 1
    const cardStep1 = document.getElementById('legalCardStep1');
    const cardStep2 = document.getElementById('legalCardStep2');
    if (cardStep1) cardStep1.style.display = 'block';
    if (cardStep2) cardStep2.style.display = 'none';

    modal.style.display = 'flex';
  }

  // 4. Modal Event Bindings & Transitions
  function bindLegalModalEvents() {
    // Open full terms from Step 1
    const btnOpenFull1 = document.getElementById('btnOpenFullTermsFromPrompt');
    if (btnOpenFull1) {
      btnOpenFull1.addEventListener('click', () => {
        hasInspectedFullTerms = true;
        openFullTermsModal();
      });
    }

    // Open full terms from Step 2
    const btnBackToReadTerms = document.getElementById('btnBackToReadTerms');
    if (btnBackToReadTerms) {
      btnBackToReadTerms.addEventListener('click', () => {
        hasInspectedFullTerms = true;
        openFullTermsModal();
      });
    }

    // Settings trigger button
    const btnOpenLegalSettings = document.getElementById('btnOpenLegalSettings');
    if (btnOpenLegalSettings) {
      btnOpenLegalSettings.addEventListener('click', () => {
        openFullTermsModal();
      });
    }

    // Step 1: Accept Button Clicked
    const btnAcceptFirstLaunch = document.getElementById('btnAcceptFirstLaunch');
    if (btnAcceptFirstLaunch) {
      btnAcceptFirstLaunch.addEventListener('click', () => {
        // If user already opened and reviewed full terms, proceed directly to final approval
        if (hasInspectedFullTerms) {
          finalizeConsent();
        } else {
          // Trigger the cinematic 3D transition into Step 2 (Double-Verification Shield)
          transitionToStep2();
        }
      });
    }

    // Step 1: Decline Button Clicked
    const btnDeclineFirstLaunch = document.getElementById('btnDeclineFirstLaunch');
    if (btnDeclineFirstLaunch) {
      btnDeclineFirstLaunch.addEventListener('click', () => {
        handleDeclineExit();
      });
    }

    // Step 2: Affirmation Checkbox
    const chkAffirm = document.getElementById('chkAffirmSoleLiability');
    const btnFinalAffirm = document.getElementById('btnFinalAffirmLaunch');
    if (chkAffirm && btnFinalAffirm) {
      chkAffirm.addEventListener('change', () => {
        btnFinalAffirm.disabled = !chkAffirm.checked;
        if (chkAffirm.checked) {
          btnFinalAffirm.classList.remove('btn-disabled');
          btnFinalAffirm.classList.add('pulse-glow');
        } else {
          btnFinalAffirm.classList.add('btn-disabled');
          btnFinalAffirm.classList.remove('pulse-glow');
        }
      });
    }

    // Step 2: Final Affirmation Confirmation
    if (btnFinalAffirm) {
      btnFinalAffirm.addEventListener('click', () => {
        if (chkAffirm && chkAffirm.checked) {
          finalizeConsent();
        }
      });
    }

    // Close Full Terms Modal
    const btnCloseFullTerms = document.getElementById('btnCloseFullTerms');
    const btnCloseFullTermsBtn = document.getElementById('btnCloseFullTermsBtn');
    const fullTermsModal = document.getElementById('novaFullTermsModal');
    if (btnCloseFullTerms && fullTermsModal) {
      btnCloseFullTerms.addEventListener('click', () => {
        fullTermsModal.style.display = 'none';
      });
    }
    if (btnCloseFullTermsBtn && fullTermsModal) {
      btnCloseFullTermsBtn.addEventListener('click', () => {
        fullTermsModal.style.display = 'none';
      });
    }
  }

  // 5. Animated Transition: Step 1 -> Step 2 (Double-Verification Shield)
  function transitionToStep2() {
    const cardStep1 = document.getElementById('legalCardStep1');
    const cardStep2 = document.getElementById('legalCardStep2');
    if (!cardStep1 || !cardStep2) return;

    // Animate Card 1 out with high-tech slide & fade
    cardStep1.classList.add('card-transition-out');
    
    setTimeout(() => {
      cardStep1.style.display = 'none';
      cardStep1.classList.remove('card-transition-out');
      
      cardStep2.style.display = 'block';
      cardStep2.classList.add('card-transition-in');
      
      setTimeout(() => {
        cardStep2.classList.remove('card-transition-in');
      }, 400);
    }, 280);
  }

  // 6. Finalize Consent and Save Proof of Assent
  function finalizeConsent() {
    const modal = document.getElementById('novaPrivacyFirstLaunchModal');
    if (modal) modal.style.display = 'none';

    const consentRecord = {
      version: '1.0-universal',
      acceptedAt: new Date().toISOString(),
      platform: navigator.platform || 'Unknown',
      affirmationConfirmed: true
    };
    localStorage.setItem(CONSENT_STORAGE_KEY, JSON.stringify(consentRecord));

    if (typeof showNovaToast === 'function') {
      showNovaToast('Universal Fair-Use Terms Accepted. Welcome to NovaPulse!', 'fa-shield-halved');
    }
  }

  // 7. Handle Decline & Exit Scenario
  function handleDeclineExit() {
    const confirmExit = confirm(
      'To protect both our platform and your privacy, NovaPulse operates strictly under our Universal Fair-Use Terms. Without acceptance, the engine cannot download or process media.\n\nDo you want to exit NovaPulse now?'
    );

    if (confirmExit) {
      // 1. Android APK Exit
      if (window.navigator && window.navigator.app && typeof window.navigator.app.exitApp === 'function') {
        window.navigator.app.exitApp();
        return;
      }
      // 2. Desktop Window Close
      try {
        window.close();
      } catch (e) {}

      // 3. Fallback Screen Lock for Web Viewport
      const modal = document.getElementById('novaPrivacyFirstLaunchModal');
      if (modal) {
        modal.innerHTML = `
          <div class="modal-box glassmorphism" style="max-width: 460px; text-align: center; padding: 32px 24px; border: 1px solid rgba(239, 68, 68, 0.4);">
            <div style="width: 56px; height: 56px; border-radius: 50%; background: rgba(239, 68, 68, 0.15); border: 1px solid rgba(239, 68, 68, 0.4); display: flex; align-items: center; justify-content: center; margin: 0 auto 16px; color: var(--accent-red); font-size: 1.6rem;">
              <i class="fa-solid fa-ban"></i>
            </div>
            <h3 style="margin: 0 0 8px; color: #fff; font-size: 1.25rem;">Access Suspended</h3>
            <p style="color: var(--text-muted); font-size: 0.88rem; line-height: 1.5; margin: 0 0 24px;">
              You have declined our Universal Terms of Service. Media extraction and playback capabilities are unavailable without agreement to our personal fair-use policy.
            </p>
            <button class="btn-primary" onclick="location.reload()" style="padding: 10px 24px; border-radius: 999px;">
              <i class="fa-solid fa-rotate-right"></i> Review &amp; Accept Terms
            </button>
          </div>
        `;
      }
    }
  }

  // 8. Open Full Terms Modal Viewer
  function openFullTermsModal() {
    let fullModal = document.getElementById('novaFullTermsModal');
    if (!fullModal) return;

    const body = fullModal.querySelector('.modal-body');
    if (body) {
      body.innerHTML = FULL_TERMS_TEXT;
    }
    fullModal.style.display = 'flex';
  }

  // Expose to window
  window.NovaLegal = {
    openTerms: openFullTermsModal,
    showFirstLaunchModal: showFirstLaunchModal
  };

  // Run on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
