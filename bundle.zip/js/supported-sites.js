/**
 * NovaPulse Media Engine — Supported Sites & Platform Catalog Hub
 * Full-featured, high-performance platform catalog supporting 1,752+ extractors.
 * Includes 18 categorized platform hubs, smooth wheel & drag scroller, and multi-engine roadmap.
 */

(function() {
  let catalog = null;
  let currentCategory = 'all';
  let searchQuery = '';
  let statusFilter = 'all'; // 'all' | 'active' | 'broken'
  let viewMode = 'cards'; // 'cards' | 'chips'

  // Performance & Progressive Rendering
  let activeRenderList = [];
  let renderedCount = 0;
  const CHUNK_SIZE = 48;
  let scrollObserver = null;

  async function fetchCatalog() {
    if (catalog) return catalog;
    try {
      const res = await fetch('/api/supported-sites');
      if (res.ok) {
        catalog = await res.json();
        return catalog;
      }
    } catch (e) {
      console.warn('API fetch failed, falling back to static catalog', e);
    }

    try {
      const resStatic = await fetch('/supported_sites_catalog.json');
      catalog = await resStatic.json();
      return catalog;
    } catch (e2) {
      console.error('Failed to load catalog:', e2);
      return null;
    }
  }

  async function initSupportedSites() {
    const data = await fetchCatalog();
    if (!data) return;

    renderStats(data.stats);
    renderCategoryTabs(data.stats.categories);
    setupTabsScroller();
    setupToolbar(data.extractors);
    setupCompatibilityChecker();
    setupDrmModal();
    setupMultiEngineModal();
    renderUnifiedCatalog(data.extractors);
  }

  function renderStats(stats) {
    const elTotal = document.getElementById('ssStatTotal');
    const elActive = document.getElementById('ssStatActive');
    const elBroken = document.getElementById('ssStatBroken');

    if (elTotal) elTotal.textContent = stats.total.toLocaleString();
    if (elActive) elActive.textContent = stats.active.toLocaleString();
    if (elBroken) elBroken.textContent = stats.broken;
  }

  function renderCategoryTabs(categoryCounts) {
    const tabsContainer = document.getElementById('ssCategoryTabs');
    if (!tabsContainer) return;

    // 18 Detailed, Specialized Categories for Comprehensive Media Support
    const categories = [
      { id: 'all', label: 'All Platforms', icon: 'fa-globe', count: catalog ? catalog.stats.total : '1,752' },
      { id: 'social', label: 'Social & Shorts', icon: 'fa-hashtag', count: categoryCounts.social || 0 },
      { id: 'video', label: 'Video Hubs', icon: 'fa-film', count: categoryCounts.video || 0 },
      { id: 'streaming', label: 'Livestreams & Creators', icon: 'fa-tower-broadcast', count: categoryCounts.streaming || 0 },
      { id: 'gaming', label: 'Gaming & Clips', icon: 'fa-gamepad', count: categoryCounts.gaming || 0 },
      { id: 'audio', label: 'Music & Audio', icon: 'fa-music', count: categoryCounts.audio || 0 },
      { id: 'podcasts', label: 'Podcasts & Radio', icon: 'fa-podcast', count: categoryCounts.podcasts || 0 },
      { id: 'tv_broadcasting', label: 'TV & Broadcasting', icon: 'fa-tv', count: categoryCounts.tv_broadcasting || 0 },
      { id: 'news', label: 'News & Journalism', icon: 'fa-newspaper', count: categoryCounts.news || 0 },
      { id: 'anime_animation', label: 'Anime & Cartoons', icon: 'fa-wand-magic-sparkles', count: categoryCounts.anime_animation || 0 },
      { id: 'movies_cinema', label: 'Movies & Cinema', icon: 'fa-clapperboard', count: categoryCounts.movies_cinema || 0 },
      { id: 'education', label: 'Education & Courses', icon: 'fa-graduation-cap', count: categoryCounts.education || 0 },
      { id: 'sports', label: 'Sports & Racing', icon: 'fa-medal', count: categoryCounts.sports || 0 },
      { id: 'creative_art', label: 'Art & Comics', icon: 'fa-palette', count: categoryCounts.creative_art || 0 },
      { id: 'cloud_storage', label: 'Cloud & Drives', icon: 'fa-cloud-arrow-down', count: categoryCounts.cloud_storage || 0 },
      { id: 'asian_global', label: 'Asian & Regional', icon: 'fa-earth-asia', count: categoryCounts.asian_global || 0 },
      { id: 'adult', label: 'Mature (18+)', icon: 'fa-shield-heart', count: categoryCounts.adult || 0 },
      { id: 'generic', label: 'Direct Streams', icon: 'fa-satellite-dish', count: categoryCounts.generic || 0 },
      { id: 'general', label: 'General Web', icon: 'fa-globe-americas', count: categoryCounts.general || 0 }
    ];

    tabsContainer.innerHTML = '';
    
    // Also sync the category dropdown selector and custom animated popover
    const catDropdown = document.getElementById('ssCategoryDropdown');
    const badgeCount = document.getElementById('ssDropdownCountBadge');
    const trigger = document.getElementById('ssDropdownTrigger');
    const triggerIcon = document.getElementById('ssTriggerIcon');
    const triggerLabel = document.getElementById('ssTriggerLabel');
    const triggerCount = document.getElementById('ssTriggerCount');
    const popover = document.getElementById('ssDropdownPopover');
    const optionsList = document.getElementById('ssCategoryOptionsList');
    const btnClosePopover = document.getElementById('btnCloseCategoryPopover');
    const btnResetAll = document.getElementById('btnResetToAllPlatforms');

    // Populate native select fallback
    if (catDropdown) {
      catDropdown.innerHTML = '';
      categories.forEach(cat => {
        const opt = document.createElement('option');
        opt.value = cat.id;
        opt.textContent = `${cat.label} (${cat.count})`;
        if (cat.id === currentCategory) opt.selected = true;
        catDropdown.appendChild(opt);
      });
    }

    // Function to apply category selection
    function applyCategory(catId) {
      currentCategory = catId;
      const matched = categories.find(c => c.id === currentCategory) || categories[0];

      // Update trigger UI
      if (triggerLabel) triggerLabel.textContent = matched.label;
      if (triggerCount) triggerCount.textContent = `(${matched.count})`;
      if (triggerIcon) {
        triggerIcon.className = `fa-solid ${matched.icon} ss-trigger-icon`;
      }
      if (badgeCount) {
        badgeCount.textContent = `${matched.count} Platforms`;
      }
      if (catDropdown) {
        catDropdown.value = matched.id;
      }

      // Update active state in popover list
      if (optionsList) {
        optionsList.querySelectorAll('.ss-cat-option-item').forEach(el => {
          el.classList.toggle('active', el.getAttribute('data-cat') === currentCategory);
        });
      }

      // Show / hide the Quick Clear button if not 'all'
      if (btnResetAll) {
        btnResetAll.style.display = currentCategory === 'all' ? 'none' : 'inline-flex';
      }

      // Close popover
      if (popover) {
        popover.classList.remove('open');
        setTimeout(() => { if (!popover.classList.contains('open')) popover.style.display = 'none'; }, 220);
      }
      if (trigger) trigger.setAttribute('aria-expanded', 'false');

      // Update category title in meta bar
      const catNameEl = document.getElementById('ssActiveCategoryName');
      if (catNameEl && matched) catNameEl.textContent = matched.label;

      if (catalog) renderUnifiedCatalog(catalog.extractors);
    }

    // Render animated custom options in popover
    if (optionsList) {
      optionsList.innerHTML = '';
      categories.forEach(cat => {
        const item = document.createElement('div');
        item.className = `ss-cat-option-item ${cat.id === currentCategory ? 'active' : ''}`;
        item.setAttribute('data-cat', cat.id);
        item.innerHTML = `
          <div class="ss-cat-opt-main">
            <div class="ss-cat-opt-icon">
              <i class="fa-solid ${cat.icon}"></i>
            </div>
            <div class="ss-cat-opt-text">
              <span class="ss-cat-opt-name">${escapeHtml(cat.label)}</span>
              <span class="ss-cat-opt-desc">${cat.id === 'all' ? 'Explore all 1,752 supported websites' : 'Platform extractors in this category'}</span>
            </div>
          </div>
          <div class="ss-cat-opt-badge">${cat.count}</div>
        `;

        item.addEventListener('click', () => {
          applyCategory(cat.id);
        });

        optionsList.appendChild(item);
      });
    }

    // Toggle popover on trigger click
    if (trigger && popover) {
      trigger.onclick = (e) => {
        e.stopPropagation();
        const isOpen = popover.classList.contains('open');
        if (isOpen) {
          popover.classList.remove('open');
          setTimeout(() => { popover.style.display = 'none'; }, 220);
          trigger.setAttribute('aria-expanded', 'false');
        } else {
          popover.style.display = 'block';
          // Trigger reflow for slide animation
          popover.offsetHeight;
          popover.classList.add('open');
          trigger.setAttribute('aria-expanded', 'true');
        }
      };
    }

    // Close popover button (Cross button to return to supported websites)
    if (btnClosePopover && popover) {
      btnClosePopover.onclick = (e) => {
        e.stopPropagation();
        popover.classList.remove('open');
        setTimeout(() => { popover.style.display = 'none'; }, 220);
        if (trigger) trigger.setAttribute('aria-expanded', 'false');
      };
    }

    // Quick Reset to All Platforms (X button on header)
    if (btnResetAll) {
      btnResetAll.onclick = (e) => {
        e.stopPropagation();
        applyCategory('all');
      };
    }

    // Click outside to dismiss popover
    document.addEventListener('click', (e) => {
      if (popover && popover.classList.contains('open')) {
        const customDropdown = document.getElementById('ssCustomDropdown');
        if (customDropdown && !customDropdown.contains(e.target)) {
          popover.classList.remove('open');
          setTimeout(() => { popover.style.display = 'none'; }, 220);
          if (trigger) trigger.setAttribute('aria-expanded', 'false');
        }
      }
    });

    categories.forEach(cat => {
      const btn = document.createElement('button');
      btn.className = `ss-tab-btn ${cat.id === currentCategory ? 'active' : ''}`;
      btn.setAttribute('data-cat', cat.id);
      btn.innerHTML = `
        <i class="fa-solid ${cat.icon}"></i>
        <span>${cat.label}</span>
        <span class="ss-tab-count">${cat.count}</span>
      `;
      btn.addEventListener('click', () => {
        currentCategory = cat.id;
        document.querySelectorAll('.ss-tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        // Sync dropdown value
        if (catDropdown) catDropdown.value = cat.id;
        
        // Auto scroll active tab into view smoothly
        btn.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });

        // Update category label
        const catNameEl = document.getElementById('ssActiveCategoryName');
        if (catNameEl) catNameEl.textContent = cat.label;

        if (catalog) {
          renderUnifiedCatalog(catalog.extractors);
        }
      });
      tabsContainer.appendChild(btn);
    });
  }

  /**
   * Buttery-smooth horizontal scrolling: left/right buttons, mouse wheel translation, and drag panning.
   */
  function setupTabsScroller() {
    const tabsContainer = document.getElementById('ssCategoryTabs');
    const btnLeft = document.getElementById('ssTabScrollLeft');
    const btnRight = document.getElementById('ssTabScrollRight');

    if (!tabsContainer) return;

    // Left and Right arrow navigation
    if (btnLeft) {
      btnLeft.addEventListener('click', () => {
        tabsContainer.scrollBy({ left: -280, behavior: 'smooth' });
      });
    }
    if (btnRight) {
      btnRight.addEventListener('click', () => {
        tabsContainer.scrollBy({ left: 280, behavior: 'smooth' });
      });
    }

    // Intercept vertical mouse wheel to perform horizontal scroll smoothly
    tabsContainer.addEventListener('wheel', (e) => {
      if (Math.abs(e.deltaY) > 0) {
        e.preventDefault();
        tabsContainer.scrollLeft += e.deltaY * 1.3;
      }
    }, { passive: false });

    // Drag-to-scroll implementation
    let isDown = false;
    let startX = 0;
    let scrollStart = 0;
    let hasDragged = false;

    tabsContainer.addEventListener('mousedown', (e) => {
      isDown = true;
      hasDragged = false;
      tabsContainer.classList.add('is-dragging');
      startX = e.pageX - tabsContainer.offsetLeft;
      scrollStart = tabsContainer.scrollLeft;
    });

    window.addEventListener('mouseup', () => {
      if (!isDown) return;
      isDown = false;
      tabsContainer.classList.remove('is-dragging');
    });

    tabsContainer.addEventListener('mouseleave', () => {
      if (isDown) {
        isDown = false;
        tabsContainer.classList.remove('is-dragging');
      }
    });

    tabsContainer.addEventListener('mousemove', (e) => {
      if (!isDown) return;
      const x = e.pageX - tabsContainer.offsetLeft;
      const walk = (x - startX) * 1.4;
      if (Math.abs(walk) > 4) {
        hasDragged = true;
      }
      tabsContainer.scrollLeft = scrollStart - walk;
    });

    // Prevent button click trigger when user was actually dragging
    tabsContainer.addEventListener('click', (e) => {
      if (hasDragged) {
        e.stopPropagation();
        e.preventDefault();
      }
    }, true);
  }

  function setupToolbar(extractors) {
    const input = document.getElementById('ssSearchInput');
    const clearBtn = document.getElementById('ssClearSearchBtn');

    if (input) {
      let debounceTimer = null;
      input.addEventListener('input', (e) => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => {
          searchQuery = e.target.value.trim();
          if (clearBtn) clearBtn.style.display = searchQuery ? 'block' : 'none';
          renderUnifiedCatalog(extractors);
        }, 120);
      });
    }

    if (clearBtn) {
      clearBtn.addEventListener('click', () => {
        if (input) input.value = '';
        searchQuery = '';
        clearBtn.style.display = 'none';
        renderUnifiedCatalog(extractors);
      });
    }

    // Status filter buttons
    const statusBtns = document.querySelectorAll('.ss-filter-btn');
    statusBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        statusBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        statusFilter = btn.getAttribute('data-status') || 'all';
        renderUnifiedCatalog(extractors);
      });
    });

    // View mode toggle
    const btnCards = document.getElementById('ssViewCardsBtn');
    const btnChips = document.getElementById('ssViewChipsBtn');
    if (btnCards && btnChips) {
      btnCards.addEventListener('click', () => {
        viewMode = 'cards';
        btnCards.classList.add('active');
        btnChips.classList.remove('active');
        renderUnifiedCatalog(extractors);
      });
      btnChips.addEventListener('click', () => {
        viewMode = 'chips';
        btnChips.classList.add('active');
        btnCards.classList.remove('active');
        renderUnifiedCatalog(extractors);
      });
    }
  }

  function renderUnifiedCatalog(extractors) {
    const container = document.getElementById('ssUnifiedGrid');
    const countEl = document.getElementById('ssMatchingExtractorsCount');
    if (!container) return;

    let filtered = extractors;

    // 1. Filter by category
    if (currentCategory !== 'all') {
      filtered = filtered.filter(item => item.category === currentCategory);
    }

    // 2. Filter by search query
    if (searchQuery) {
      const q = searchQuery.toLowerCase().trim();
      filtered = filtered.filter(item => 
        (item.displayName && item.displayName.toLowerCase().includes(q)) ||
        item.name.toLowerCase().includes(q) || 
        item.category.toLowerCase().includes(q)
      );
    }

    // 3. Filter by status
    if (statusFilter !== 'all') {
      filtered = filtered.filter(item => item.status === statusFilter);
    }

    // Sort: Featured first, then alphabetical
    filtered.sort((a, b) => {
      if (a.isFeatured && !b.isFeatured) return -1;
      if (!a.isFeatured && b.isFeatured) return 1;
      return (a.displayName || a.name).localeCompare(b.displayName || b.name);
    });

    // Update count indicator
    const totalInCat = currentCategory === 'all' 
      ? extractors.length 
      : extractors.filter(e => e.category === currentCategory).length;

    if (countEl) {
      if (searchQuery || statusFilter !== 'all') {
        countEl.textContent = `Showing ${filtered.length.toLocaleString()} of ${totalInCat.toLocaleString()} platforms`;
      } else {
        countEl.textContent = `All ${filtered.length.toLocaleString()} Platforms Available`;
      }
    }

    container.innerHTML = '';

    if (filtered.length === 0) {
      container.innerHTML = `
        <div class="ss-empty-state">
          <i class="fa-solid fa-magnifying-glass"></i>
          <h4>No platforms found matching your filters</h4>
          <p>Try clearing your search query or reset status filters.</p>
        </div>
      `;
      return;
    }

    activeRenderList = filtered;
    renderedCount = 0;

    if (viewMode === 'chips') {
      container.className = 'ss-unified-grid chips-view';
    } else {
      container.className = 'ss-unified-grid cards-view';
    }

    // Render initial progressive batch without freezing the DOM
    appendNextChunk(container);
  }

  function appendNextChunk(container) {
    if (renderedCount >= activeRenderList.length) return;

    const nextBatch = activeRenderList.slice(renderedCount, renderedCount + CHUNK_SIZE);
    renderedCount += nextBatch.length;

    // Remove old sentinel
    const oldSentinel = document.getElementById('ssRenderSentinel');
    if (oldSentinel) oldSentinel.remove();

    if (viewMode === 'chips') {
      renderChipsBatch(container, nextBatch);
    } else {
      renderCardsBatch(container, nextBatch);
    }

    // If more items remain, attach sleek sentinel
    if (renderedCount < activeRenderList.length) {
      const remaining = activeRenderList.length - renderedCount;
      const sentinel = document.createElement('div');
      sentinel.id = 'ssRenderSentinel';
      sentinel.style.gridColumn = '1 / -1';
      sentinel.style.padding = '24px 0';
      sentinel.style.textAlign = 'center';
      sentinel.innerHTML = `
        <button class="btn-subtle" id="ssBtnLoadMore" style="margin: 0 auto; display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; font-size: 0.88rem;">
          <i class="fa-solid fa-angles-down"></i> Show Next ${Math.min(remaining, CHUNK_SIZE)} Platforms (${remaining.toLocaleString()} more)
        </button>
      `;
      container.appendChild(sentinel);

      const loadMoreBtn = document.getElementById('ssBtnLoadMore');
      if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', () => {
          appendNextChunk(container);
        });
      }

      // Smooth auto-load on scroll
      if ('IntersectionObserver' in window) {
        if (scrollObserver) scrollObserver.disconnect();
        scrollObserver = new IntersectionObserver((entries) => {
          if (entries[0].isIntersecting) {
            appendNextChunk(container);
          }
        }, { rootMargin: '300px' });
        scrollObserver.observe(sentinel);
      }
    }
  }

  function renderCardsBatch(container, batch) {
    const frag = document.createDocumentFragment();

    batch.forEach(p => {
      const card = document.createElement('div');
      
      if (p.isFeatured && p.featuredData) {
        // Spotlight Featured Card
        const f = p.featuredData;
        card.className = 'ss-card featured-spotlight';
        card.innerHTML = `
          <div class="ss-card-top">
            <div class="ss-card-icon" style="color: ${f.color || '#22d3ee'}; background: ${(f.color || '#22d3ee')}18; border-color: ${(f.color || '#22d3ee')}33;">
              <i class="${f.icon || p.icon}"></i>
            </div>
            <div class="ss-card-header-meta">
              <div class="ss-card-title-wrap">
                <h4 class="ss-card-name">${escapeHtml(f.name)}</h4>
                <span class="ss-featured-pill"><i class="fa-solid fa-star"></i> Popular</span>
              </div>
              <span class="ss-auth-badge ${f.auth}">${f.auth === 'public' ? 'Public / No Login' : 'Cookies Recommended'}</span>
            </div>
          </div>

          <p class="ss-card-desc">${escapeHtml(f.description)}</p>

          <div class="ss-quality-banner">
            <i class="fa-solid fa-sliders"></i>
            <span>${escapeHtml(f.qualities)}</span>
          </div>

          <div class="ss-feature-tags">
            ${f.features.slice(0, 4).map(feat => `<span class="ss-feat-pill"><i class="fa-solid fa-check"></i> ${escapeHtml(feat)}</span>`).join('')}
          </div>

          <div class="ss-card-actions">
            <button class="btn-subtle btn-mini btn-copy-example" data-url="${escapeHtml(f.example)}" title="Copy example URL">
              <i class="fa-regular fa-copy"></i> Example
            </button>
            <button class="btn-primary btn-mini btn-try-platform" data-url="${escapeHtml(f.example)}" title="Test in Universal Downloader">
              <i class="fa-solid fa-bolt"></i> Test in Downloader
            </button>
          </div>
        `;

        card.querySelector('.btn-copy-example').addEventListener('click', (e) => {
          const url = e.currentTarget.getAttribute('data-url');
          navigator.clipboard.writeText(url).then(() => {
            if (typeof showNovaToast === 'function') showNovaToast('Example URL copied to clipboard!', 'fa-copy');
          });
        });

        card.querySelector('.btn-try-platform').addEventListener('click', (e) => {
          const url = e.currentTarget.getAttribute('data-url');
          openInDownloader(url);
        });

      } else {
        // Standard Unified Platform Card
        card.className = `ss-card standard-card ${p.status === 'broken' ? 'status-broken' : ''}`;
        card.innerHTML = `
          <div class="ss-card-top">
            <div class="ss-card-icon standard">
              <i class="${p.icon}"></i>
            </div>
            <div class="ss-card-header-meta">
              <div class="ss-card-title-wrap">
                <h4 class="ss-card-name" title="${escapeHtml(p.name)}">${escapeHtml(p.displayName || p.name)}</h4>
                <span class="ss-category-tag">${escapeHtml(p.category.replace('_', ' '))}</span>
              </div>
              ${p.status === 'broken'
                ? '<span class="ss-status-tag broken" title="Upstream website modified format — requires NovaPulse engine update">Altered</span>'
                : '<span class="ss-status-tag active"><i class="fa-solid fa-check"></i> Active</span>'}
            </div>
          </div>

          <div class="ss-card-actions standard-actions">
            <span class="ss-extractor-id"><code>${escapeHtml(p.name)}</code></span>
            <button class="btn-subtle btn-mini btn-try-platform" data-name="${escapeHtml(p.name)}" title="Test downloading from this platform">
              <i class="fa-solid fa-arrow-up-right-from-square"></i> Test
            </button>
          </div>
        `;

        card.querySelector('.btn-try-platform').addEventListener('click', (e) => {
          const rawName = e.currentTarget.getAttribute('data-name');
          const cleanDomain = rawName.split(':')[0].toLowerCase().replace(/[^a-z0-9]/g, '');
          openInDownloader(`https://${cleanDomain}.com`);
        });
      }

      frag.appendChild(card);
    });

    container.appendChild(frag);
  }

  function renderChipsBatch(container, batch) {
    const frag = document.createDocumentFragment();

    batch.forEach(p => {
      const chip = document.createElement('div');
      chip.className = `ss-chip ${p.isFeatured ? 'featured' : ''} ${p.status === 'broken' ? 'broken' : ''}`;
      chip.title = `Extractor: ${p.name} (${p.category}) — Click to test in Downloader`;
      chip.innerHTML = `
        <i class="${p.icon}"></i>
        <span class="ss-chip-name">${escapeHtml(p.displayName || p.name)}</span>
        <span class="ss-chip-cat">${escapeHtml(p.category.replace('_', ' '))}</span>
        <button class="ss-chip-action" title="Test in Downloader">
          <i class="fa-solid fa-arrow-up-right-from-square"></i>
        </button>
      `;

      chip.addEventListener('click', () => {
        const cleanDomain = p.name.split(':')[0].toLowerCase().replace(/[^a-z0-9]/g, '');
        openInDownloader(`https://${cleanDomain}.com`);
      });

      frag.appendChild(chip);
    });

    container.appendChild(frag);
  }

  function setupCompatibilityChecker() {
    const input = document.getElementById('ssCheckerInput');
    const btn = document.getElementById('ssCheckerBtn');
    const resultBox = document.getElementById('ssCheckerResult');

    if (!btn || !input || !resultBox) return;

    async function runCheck() {
      const url = input.value.trim();
      if (!url) {
        input.focus();
        return;
      }

      btn.disabled = true;
      btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Checking...';
      resultBox.style.display = 'none';

      try {
        const res = await fetch('/api/supported-sites/check', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ url })
        });
        const data = await res.json();
        renderCheckResult(data, url);
      } catch (err) {
        renderCheckResult({
          ok: false,
          supported: false,
          isDrm: false,
          serviceName: 'Engine Communication Error',
          badge: 'ERROR',
          badgeColor: '#ef4444',
          message: 'Unable to communicate with the NovaPulse extraction engine: ' + err.message
        }, url);
      } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-radar"></i> Check URL';
      }
    }

    btn.addEventListener('click', runCheck);
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') runCheck();
    });
  }

  function renderCheckResult(data, testedUrl) {
    const resultBox = document.getElementById('ssCheckerResult');
    if (!resultBox) return;

    resultBox.style.display = 'block';

    if (data.isDrm) {
      resultBox.className = 'ss-result-card is-drm';
      resultBox.innerHTML = `
        <div class="ss-result-header">
          <div class="ss-result-title-group">
            <span class="ss-result-badge drm"><i class="fa-solid fa-shield-halved"></i> ${escapeHtml(data.badge)}</span>
            <h3>${escapeHtml(data.serviceName)}</h3>
          </div>
          <div style="display:flex; align-items:center; gap:10px;">
            <span class="ss-result-verdict not-supported"><i class="fa-solid fa-ban"></i> Cannot Download</span>
            <button class="modal-close" style="font-size:1.2rem; cursor:pointer;" onclick="this.closest('#ssCheckerResult').style.display='none'">&times;</button>
          </div>
        </div>
        <p class="ss-result-msg">${escapeHtml(data.message)}</p>
        <div class="ss-result-tip drm-tip">
          <i class="fa-solid fa-circle-exclamation"></i>
          <span><b>Why?</b> Commercial subscription platforms (Netflix, Prime, Disney+) use Widevine L1/L3 hardware DRM keys to protect video streams. Decrypting hardware-encrypted DRM is legally prohibited under DMCA 1201 and outside NovaPulse proprietary architecture.</span>
        </div>
      `;
    } else if (data.supported) {
      resultBox.className = 'ss-result-card is-supported';
      resultBox.innerHTML = `
        <div class="ss-result-header">
          <div class="ss-result-title-group">
            <span class="ss-result-badge supported" style="background:${data.badgeColor}22; color:${data.badgeColor}; border-color:${data.badgeColor}44;">
              <i class="fa-solid fa-circle-check"></i> ${escapeHtml(data.badge)}
            </span>
            <h3>${escapeHtml(data.serviceName)}</h3>
          </div>
          <div style="display:flex; align-items:center; gap:10px;">
            <span class="ss-result-verdict supported"><i class="fa-solid fa-circle-check"></i> Fully Supported</span>
            <button class="modal-close" style="font-size:1.2rem; cursor:pointer;" onclick="this.closest('#ssCheckerResult').style.display='none'">&times;</button>
          </div>
        </div>
        <p class="ss-result-msg">${escapeHtml(data.message)}</p>
        ${data.qualities ? `
          <div class="ss-result-qualities">
            <i class="fa-solid fa-sliders"></i> <b>Supported Quality:</b> ${escapeHtml(data.qualities)}
          </div>
        ` : ''}
        <div class="ss-result-actions">
          <button class="btn-primary" id="btnCheckerSendToDownloader">
            <i class="fa-solid fa-bolt"></i> Send to Downloader &amp; Analyze
          </button>
        </div>
      `;

      const sendBtn = document.getElementById('btnCheckerSendToDownloader');
      if (sendBtn) {
        sendBtn.addEventListener('click', () => {
          openInDownloader(testedUrl);
        });
      }
    } else {
      resultBox.className = 'ss-result-card is-unsupported';
      resultBox.innerHTML = `
        <div class="ss-result-header">
          <div class="ss-result-title-group">
            <span class="ss-result-badge error">${escapeHtml(data.badge || 'UNSUPPORTED')}</span>
            <h3>${escapeHtml(data.serviceName || 'Unrecognized Platform')}</h3>
          </div>
          <button class="modal-close" style="font-size:1.2rem; cursor:pointer;" onclick="this.closest('#ssCheckerResult').style.display='none'">&times;</button>
        </div>
        <p class="ss-result-msg">${escapeHtml(data.message)}</p>
      `;
    }
  }

  function setupDrmModal() {
    const openBtn = document.getElementById('btnOpenDrmModal');
    const modal = document.getElementById('novaDrmLimitsModal');
    const closeBtn = document.getElementById('closeDrmModalBtn');
    const closeSubtle = document.getElementById('closeDrmModalSubtle');

    if (!modal) return;

    if (openBtn) {
      openBtn.addEventListener('click', () => {
        modal.style.display = 'flex';
      });
    }

    if (closeBtn) closeBtn.addEventListener('click', () => modal.style.display = 'none');
    if (closeSubtle) closeSubtle.addEventListener('click', () => modal.style.display = 'none');
    modal.addEventListener('click', (e) => {
      if (e.target === modal) modal.style.display = 'none';
    });
  }

  function setupMultiEngineModal() {
    const openBtn = document.getElementById('btnOpenMultiEngineModal');
    const modal = document.getElementById('novaMultiEngineModal');
    const closeBtn = document.getElementById('closeMultiEngineModalBtn');
    const closeSubtle = document.getElementById('closeMultiEngineModalSubtle');

    if (!modal) return;

    if (openBtn) {
      openBtn.addEventListener('click', () => {
        modal.style.display = 'flex';
      });
    }

    if (closeBtn) closeBtn.addEventListener('click', () => modal.style.display = 'none');
    if (closeSubtle) closeSubtle.addEventListener('click', () => modal.style.display = 'none');
    modal.addEventListener('click', (e) => {
      if (e.target === modal) modal.style.display = 'none';
    });
  }

  function openInDownloader(url) {
    if (typeof Nova !== 'undefined' && Nova.switchView) {
      Nova.switchView('home');
    } else if (typeof switchView === 'function') {
      switchView('home');
    }
    const input = document.getElementById('urlInput');
    if (input) {
      input.value = url;
      input.focus();
      const analyzeBtn = document.getElementById('analyzeBtn');
      if (analyzeBtn) {
        setTimeout(() => analyzeBtn.click(), 250);
      }
    }
  }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  window.loadAndRenderSupportedSites = initSupportedSites;
  window.SupportedSites = {
    init: initSupportedSites,
    openInDownloader
  };
})();
