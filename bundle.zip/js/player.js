// player.js - Core Media Player Module (Phase 1 + Phase 2)
const Player = (function () {
  let mediaEl = null;
  let videoContainer = null;
  let currentItem = null;
  let isMuted = false;
  let previousVolume = 1;
  let savePositionTimer = null;
  let audioCtx = null;
  let gainNode = null;
  let audioSourceNode = null;
  let amplificationLevel = 1.0;
  let hlsInstance = null;


  // A-B Repeat state
  let abPointA = null;
  let abPointB = null;
  let abActive = false;
  let onABChangeCb = null;

  // Subtitle state
  let availableSubtitles = [];
  let currentSubtitleId = 'off'; // 'off' or subtitle id
  let onSubtitleChangeCb = null;

  // Audio track capability detection
  let audioTracksAvailable = false;
  let audioTracksList = [];

  // Callbacks arrays supporting multiple listeners
  let onTimeUpdateCbs = [];
  let onEndedCbs = [];
  let onPlayStateChangeCbs = [];
  let onErrorCbs = [];

  // Embed iframe bridge state (for online embeds like YouTube)
  let isEmbedActive = false;
  let embedDuration = 0;
  let embedCurrentTime = 0;
  let isEmbedPlaying = false;
  let embedPlaybackRate = 1.0;
  let embedTicker = null;

  function sendEmbedCommand(func, args) {
    const iframe = document.getElementById('onlineEmbedIframe');
    if (!iframe || !iframe.contentWindow) return;
    try {
      const payload = JSON.stringify({
        event: 'command',
        func: func,
        args: Array.isArray(args) ? args : []
      });
      iframe.contentWindow.postMessage(payload, '*');
    } catch (e) {
      console.warn('sendEmbedCommand failed:', func, e);
    }
  }

  function startEmbedTicker() {
    stopEmbedTicker();
    embedTicker = setInterval(() => {
      if (isEmbedActive && isEmbedPlaying) {
        embedCurrentTime += 1 * embedPlaybackRate;
        if (embedDuration > 0 && embedCurrentTime >= embedDuration) {
          embedCurrentTime = embedDuration;
          stopEmbedTicker();
          isEmbedPlaying = false;
          onPlayStateChangeCbs.forEach(cb => { try { cb(false); } catch (e) {} });
          onEndedCbs.forEach(cb => { try { cb(); } catch (e) {} });
        }
        onTimeUpdateCbs.forEach(cb => { try { cb(embedCurrentTime, embedDuration); } catch (e) {} });
      }
    }, 1000);
  }

  function stopEmbedTicker() {
    if (embedTicker) {
      clearInterval(embedTicker);
      embedTicker = null;
    }
  }

  function setEmbedMode(active, item) {
    isEmbedActive = Boolean(active);
    if (isEmbedActive) {
      if (mediaEl) {
        try {
          mediaEl.pause();
          mediaEl.removeAttribute('src');
          mediaEl.load();
        } catch(e) {}
      }
      const errBanner = document.getElementById('playerErrorBanner');
      if (errBanner) errBanner.style.display = 'none';
      if (item) {
        currentItem = item;
        embedDuration = item.duration || 0;
      }
      embedCurrentTime = 0;
      isEmbedPlaying = true;
      startEmbedTicker();
      onPlayStateChangeCbs.forEach(cb => { try { cb(true); } catch(e){} });
      onTimeUpdateCbs.forEach(cb => { try { cb(embedCurrentTime, embedDuration); } catch(e){} });
    } else {
      stopEmbedTicker();
    }
  }

  function getIsEmbedActive() {
    const iframe = document.getElementById('onlineEmbedIframe');
    return isEmbedActive || Boolean(iframe && iframe.style.display !== 'none' && iframe.src);
  }

  function init(containerEl, audioElement) {
    videoContainer = containerEl;
    mediaEl = audioElement;

    const existingVideo = containerEl.querySelector('video');
    if (existingVideo) {
      mediaEl = existingVideo;
    }

    bindMediaEvents(mediaEl);
    bindKeyboardShortcuts();
    initFullscreenHUD();
    initAmbilight();

    // Restore saved volume and speed
    const savedVol = localStorage.getItem('ultimatePlayer.volume');
    if (savedVol !== null) {
      setVolume(parseFloat(savedVol));
    }
    const savedSpeed = localStorage.getItem('ultimatePlayer.speed');
    if (savedSpeed !== null) {
      setPlaybackRate(parseFloat(savedSpeed));
    }
  }

  function bindMediaEvents(el) {
    if (!el) return;

    const triggerTimeSync = () => {
      onTimeUpdateCbs.forEach(cb => {
        try { cb(el.currentTime, el.duration); } catch (e) { console.error(e); }
      });
    };

    el.addEventListener('loadedmetadata', triggerTimeSync);
    el.addEventListener('durationchange', triggerTimeSync);

    el.addEventListener('timeupdate', () => {
      // A-B repeat engine
      if (abActive && abPointA !== null && abPointB !== null) {
        if (el.currentTime >= abPointB) {
          el.currentTime = abPointA;
        }
      }
      triggerTimeSync();
      scheduleSavePosition();
    });

    el.addEventListener('play', () => {
      if (ambilightEnabled) startAmbilightLoop();
      onPlayStateChangeCbs.forEach(cb => {
        try { cb(true); } catch (e) { console.error(e); }
      });
      if (currentItem) {
        recordWatchHistory(currentItem, el.currentTime || 0, el.duration || (currentItem && currentItem.duration) || 0);
      }
    });

    el.addEventListener('playing', () => {
      if (ambilightEnabled) startAmbilightLoop();
      onPlayStateChangeCbs.forEach(cb => {
        try { cb(true); } catch (e) { console.error(e); }
      });
      if (currentItem) {
        recordWatchHistory(currentItem, el.currentTime || 0, el.duration || (currentItem && currentItem.duration) || 0);
      }
    });

    el.addEventListener('pause', () => {
      stopAmbilightLoop();
      onPlayStateChangeCbs.forEach(cb => {
        try { cb(false); } catch (e) { console.error(e); }
      });
      saveCurrentPositionNow();
    });

    el.addEventListener('ended', () => {
      stopAmbilightLoop();
      // Don't fire ended when A-B repeat is active
      if (abActive) return;
      localStorage.removeItem('ultimatePlayer.position');
      onPlayStateChangeCbs.forEach(cb => {
        try { cb(false); } catch (e) { console.error(e); }
      });
      onEndedCbs.forEach(cb => {
        try { cb(); } catch (e) { console.error(e); }
      });
    });

    el.addEventListener('error', (e) => {
      console.warn('Playback error encountered:', el.error);
      onPlayStateChangeCbs.forEach(cb => {
        try { cb(false); } catch (e) { console.error(e); }
      });
      let msg = 'Browser cannot decode or play this format natively.';
      if (el.error) {
        switch (el.error.code) {
          case MediaError.MEDIA_ERR_ABORTED:
            msg = 'Playback was aborted.'; break;
          case MediaError.MEDIA_ERR_NETWORK:
            msg = 'A network error interrupted playback.'; break;
          case MediaError.MEDIA_ERR_DECODE:
            msg = 'Playback failed — decoding error (codec may not be supported).'; break;
          case MediaError.MEDIA_ERR_SRC_NOT_SUPPORTED:
            msg = 'Format not supported or file not found.'; break;
        }
      }
      onErrorCbs.forEach(cb => {
        try { cb(msg, currentItem); } catch (err) { console.error(err); }
      });
    });
  }

  // ─── Keyboard Shortcuts ──────────────────────────────────────────
  function bindKeyboardShortcuts() {
    document.addEventListener('keydown', (e) => {
      // Ignore when focused on text inputs
      const tag = (e.target.tagName || '').toLowerCase();
      if (tag === 'input' || tag === 'textarea' || tag === 'select') return;
      if (e.target.isContentEditable) return;

      switch (e.key) {
        case ' ':
          e.preventDefault();
          togglePlay();
          break;
        case 'ArrowLeft':
          e.preventDefault();
          if (mediaEl && !isNaN(mediaEl.duration)) {
            seek(Math.max(0, mediaEl.currentTime - 5));
          }
          break;
        case 'ArrowRight':
          e.preventDefault();
          if (mediaEl && !isNaN(mediaEl.duration)) {
            seek(Math.min(mediaEl.duration, mediaEl.currentTime + 5));
          }
          break;
        case 'ArrowUp':
          e.preventDefault();
          setVolume(Math.min(1, getVolume() + 0.05));
          if (onKeyboardVolumeCb) onKeyboardVolumeCb(getVolume());
          break;
        case 'ArrowDown':
          e.preventDefault();
          setVolume(Math.max(0, getVolume() - 0.05));
          if (onKeyboardVolumeCb) onKeyboardVolumeCb(getVolume());
          break;
        case 'm':
        case 'M':
          toggleMute();
          if (onKeyboardVolumeCb) onKeyboardVolumeCb(getVolume());
          break;
        case 'f':
        case 'F':
          toggleFullscreen();
          break;
        case 'n':
        case 'N':
          if (onKeyboardNextCb) onKeyboardNextCb();
          break;
        case 'p':
        case 'P':
          if (onKeyboardPrevCb) onKeyboardPrevCb();
          break;
        case 'r':
        case 'R':
          if (onKeyboardRepeatCb) onKeyboardRepeatCb();
          break;
        case 's':
        case 'S':
          if (onKeyboardShuffleCb) onKeyboardShuffleCb();
          break;
        case '.':
        case '>':
          e.preventDefault();
          stepFrame(1);
          break;
        case ',':
        case '<':
          e.preventDefault();
          stepFrame(-1);
          break;
        case 'a':
        case 'A':
          if (!e.ctrlKey && !e.metaKey && !e.altKey) {
            e.preventDefault();
            setAbPointA();
          }
          break;
        case 'b':
        case 'B':
          if (!e.ctrlKey && !e.metaKey && !e.altKey) {
            e.preventDefault();
            setAbPointB();
          }
          break;
        case 'c':
        case 'C':
          if (!e.ctrlKey && !e.metaKey && !e.altKey && abActive) {
            e.preventDefault();
            clearAbRepeat();
          }
          break;
      }
    });
  }

  // Keyboard action callbacks (wired from app.js)
  let onKeyboardVolumeCb = null;
  let onKeyboardNextCb = null;
  let onKeyboardPrevCb = null;
  let onKeyboardRepeatCb = null;
  let onKeyboardShuffleCb = null;

  // ─── A-B Repeat ──────────────────────────────────────────────────
  function setAbPointA() {
    if (!mediaEl || isNaN(mediaEl.currentTime)) return;
    abPointA = mediaEl.currentTime;
    // Reset B if A is now >= B
    if (abPointB !== null && abPointA >= abPointB) {
      abPointB = null;
    }
    abActive = abPointA !== null && abPointB !== null;
    if (onABChangeCb) onABChangeCb(abPointA, abPointB, abActive);
  }

  function setAbPointB() {
    if (!mediaEl || isNaN(mediaEl.currentTime)) return;
    if (abPointA === null) return; // Must set A first
    const t = mediaEl.currentTime;
    if (t <= abPointA) return; // B must be after A
    abPointB = t;
    abActive = true;
    if (onABChangeCb) onABChangeCb(abPointA, abPointB, abActive);
  }

  function clearAbRepeat() {
    abPointA = null;
    abPointB = null;
    abActive = false;
    if (onABChangeCb) onABChangeCb(null, null, false);
  }

  function getAbState() {
    return { a: abPointA, b: abPointB, active: abActive };
  }

  // ─── Precision Frame-by-Frame Scrubbing ──────────────────────────
  function stepFrame(deltaFrames = 1) {
    if (!mediaEl || isNaN(mediaEl.duration)) return;
    pause();
    const frameDuration = 1 / 30; // standard 30fps baseline
    const target = Math.max(0, Math.min(mediaEl.duration, mediaEl.currentTime + (deltaFrames * frameDuration)));
    mediaEl.currentTime = target;
    if (typeof showNovaToast === 'function') {
      showNovaToast(`Frame: ${deltaFrames > 0 ? '+1' : '-1'} (${target.toFixed(3)}s)`, 'fa-step-forward');
    }
  }

  // ─── Reactive Ambilight Engine ──────────────────────────────────
  let ambilightEnabled = localStorage.getItem('novapulse_ambilight_v2') === 'true';
  let ambilightCanvas = null;
  let ambilightCtx = null;
  let ambilightRafId = null;

  function initAmbilight() {
    ambilightCanvas = document.getElementById('ambilightCanvas');
    if (!ambilightCanvas) return;
    try {
      ambilightCtx = ambilightCanvas.getContext('2d', { willReadFrequently: false });
      ambilightCanvas.width = 64;
      ambilightCanvas.height = 36;
      if (ambilightEnabled) {
        ambilightCanvas.classList.add('active');
        if (mediaEl && !mediaEl.paused) startAmbilightLoop();
      } else {
        ambilightCanvas.classList.remove('active');
      }
    } catch (e) {
      console.warn('Ambilight init error:', e);
    }
  }

  function startAmbilightLoop() {
    if (ambilightRafId) cancelAnimationFrame(ambilightRafId);
    if (!ambilightEnabled || !ambilightCanvas || !ambilightCtx || !mediaEl) return;

    let lastDraw = 0;
    const render = (time) => {
      // Throttle to ~10 FPS (100ms) to ensure ZERO GPU frame drop / video lag
      if (time - lastDraw >= 100) {
        if (!mediaEl.paused && !mediaEl.ended && mediaEl.videoWidth > 0) {
          try {
            ambilightCtx.drawImage(mediaEl, 0, 0, ambilightCanvas.width, ambilightCanvas.height);
          } catch (e) {}
        }
        lastDraw = time;
      }
      if (ambilightEnabled && !mediaEl.paused && !mediaEl.ended) {
        ambilightRafId = requestAnimationFrame(render);
      } else {
        ambilightRafId = null;
      }
    };
    ambilightRafId = requestAnimationFrame(render);
  }

  function stopAmbilightLoop() {
    if (ambilightRafId) {
      cancelAnimationFrame(ambilightRafId);
      ambilightRafId = null;
    }
    if (ambilightCtx && ambilightCanvas) {
      ambilightCtx.clearRect(0, 0, ambilightCanvas.width, ambilightCanvas.height);
    }
  }

  function toggleAmbilight(forcedState) {
    ambilightEnabled = typeof forcedState === 'boolean' ? forcedState : !ambilightEnabled;
    localStorage.setItem('novapulse_ambilight_v2', ambilightEnabled ? 'true' : 'false');
    if (ambilightCanvas) {
      if (ambilightEnabled) {
        ambilightCanvas.classList.add('active');
        if (mediaEl && !mediaEl.paused) startAmbilightLoop();
      } else {
        ambilightCanvas.classList.remove('active');
        stopAmbilightLoop();
      }
    }
    return ambilightEnabled;
  }

  function isAmbilightActive() {
    return ambilightEnabled;
  }

  // ─── Position Saving & Resuming ──────────────────────────────────
  
  // ─── Watch History & Fullscreen HUD State ────────────────────────
  const WATCH_HISTORY_KEY = 'novapulse_watch_history';
  let isFsLocked = false;
  let fsIdleTimer = null;
  const FS_IDLE_DELAY = 15000; // 15 seconds of inactivity

  function getWatchHistory() {
    try {
      const raw = localStorage.getItem(WATCH_HISTORY_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch(e) { return []; }
  }

  function clearWatchHistory() {
    localStorage.removeItem(WATCH_HISTORY_KEY);
    try {
      fetch('/api/history', { method: 'DELETE' }).catch(() => {});
    } catch(e) {}
    const badge = document.getElementById('navHistoryCount');
    if (badge) badge.textContent = '0';
    if (typeof window.loadAndRenderHistory === 'function') window.loadAndRenderHistory();
  }

  function removeFromWatchHistory(id) {
    try {
      let list = getWatchHistory();
      list = list.filter(it => it.id !== id);
      localStorage.setItem(WATCH_HISTORY_KEY, JSON.stringify(list));
      const badge = document.getElementById('navHistoryCount');
      if (badge) badge.textContent = list.length;
      if (typeof window.loadAndRenderHistory === 'function') window.loadAndRenderHistory();
      return list;
    } catch(e) { return []; }
  }

  function recordWatchHistory(item, cur, dur) {
    if (!item || !item.id) return;
    try {
      let list = getWatchHistory();
      list = list.filter(entry => entry && entry.id !== item.id);

      const curTime = (typeof cur === 'number' && !isNaN(cur)) ? Math.max(0, cur) : 0;
      const duration = (typeof dur === 'number' && !isNaN(dur) && dur > 0) ? dur : (item.duration || 0);
      const percent = (duration > 0 && curTime > 0) ? Math.min(100, Math.round((curTime / duration) * 100)) : 0;

      const entry = {
        id: item.id,
        name: item.name || 'Untitled Media',
        url: item.url || '',
        thumbnail: item.thumbnail || '',
        type: item.type || 'video',
        extension: item.extension || 'mp4',
        size: item.size || 0,
        duration: duration,
        currentTime: curTime,
        percent: percent,
        watchedAt: Date.now()
      };

      list.unshift(entry);
      if (list.length > 250) list = list.slice(0, 250);
      localStorage.setItem(WATCH_HISTORY_KEY, JSON.stringify(list));

      // Sync with backend history persistence
      try {
        fetch('/api/history', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(entry)
        }).catch(() => {});
      } catch (e) {}

      const badge = document.getElementById('navHistoryCount');
      if (badge) badge.textContent = list.length;

      if (typeof window.loadAndRenderHistory === 'function') {
        window.loadAndRenderHistory();
      }
    } catch (e) {
      console.warn('Failed to record watch history:', e);
    }
  }

  const POSITIONS_KEY = 'ultimatePlayer.mediaPositions';

  function getSavedMediaPositions() {
    try {
      const raw = localStorage.getItem(POSITIONS_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch (e) {
      return {};
    }
  }

  function scheduleSavePosition() {
    if (savePositionTimer) return;
    savePositionTimer = setTimeout(() => {
      savePositionTimer = null;
      saveCurrentPositionNow();
    }, 1500);
  }

  function saveCurrentPositionNow() {
    if (!mediaEl || isNaN(mediaEl.currentTime) || !currentItem || !currentItem.id) return;
    const cur = mediaEl.currentTime;
    const dur = mediaEl.duration || (currentItem && currentItem.duration) || 0;

    localStorage.setItem('ultimatePlayer.position', cur.toString());

    // Record into personal Watch History Timeline
    if (mediaEl && !mediaEl.paused) {
      recordWatchHistory(currentItem, cur, dur);
    }

    // Exact Playback Resume per video ID
    try {
      const positions = getSavedMediaPositions();
      // If within 5s of the end or >= 98%, reset to 0 so replaying begins at start
      if (dur > 0 && (dur - cur <= 5 || cur / dur >= 0.98)) {
        delete positions[currentItem.id];
      } else if (cur > 1) {
        positions[currentItem.id] = {
          time: cur,
          duration: dur,
          percent: dur > 0 ? Math.round((cur / dur) * 100) : 0,
          updatedAt: Date.now()
        };
      }
      localStorage.setItem(POSITIONS_KEY, JSON.stringify(positions));

      localStorage.setItem('ultimatePlayer.lastPlayed', JSON.stringify({
        id: currentItem.id,
        name: currentItem.name,
        thumbnail: currentItem.thumbnail,
        extension: currentItem.extension,
        time: cur,
        duration: dur,
        percent: dur > 0 ? Math.round((cur / dur) * 100) : 0
      }));
    } catch (e) {}

    // Persist to server metadata store asynchronously if >= 5 min
    try {
      if (dur >= FIVE_MINUTES && cur > 3) {
        fetch(`/api/media-item/${currentItem.id}/meta`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ playbackPosition: cur, duration: dur })
        }).catch(() => {});
      }
    } catch (e) {}
  }

  // ─── Subtitle & Audio Track Management ──────────────────────────
  function notifySubtitleChange() {
    if (!onSubtitleChangeCb) return;
    try {
      onSubtitleChangeCb(availableSubtitles, currentSubtitleId);
    } catch (e) {
      console.warn('Subtitle UI listener failed (playback unaffected):', e);
    }
  }

  function clearSubtitleTracks() {
    if (!mediaEl) return;
    const oldTracks = mediaEl.querySelectorAll('track');
    oldTracks.forEach(t => t.remove());
    availableSubtitles = [];
    currentSubtitleId = 'off';
    notifySubtitleChange();
  }

  function mountSubtitles(subtitles) {
    clearSubtitleTracks();
    if (!mediaEl || !Array.isArray(subtitles)) return;

    availableSubtitles = [...subtitles];

    availableSubtitles.forEach((sub, idx) => {
      const track = document.createElement('track');
      track.kind = 'subtitles';
      track.src = sub.url;
      track.srclang = sub.language || 'en';
      track.label = sub.label || sub.name || `Track ${idx + 1}`;
      track.id = 'track_' + (sub.id || idx);
      // Native tracks are disabled by default
      track.default = false;
      mediaEl.appendChild(track);
    });

    currentSubtitleId = 'off';
    notifySubtitleChange();
  }

  function setSubtitleTrack(trackId) {
    if (!mediaEl) return;
    const textTracks = mediaEl.textTracks;

    if (trackId === 'off' || !trackId) {
      // Disable all tracks
      for (let i = 0; i < textTracks.length; i++) {
        textTracks[i].mode = 'disabled';
      }
      currentSubtitleId = 'off';
    } else {
      // Find the index of the requested track in availableSubtitles
      const subIndex = availableSubtitles.findIndex(s => s.id === trackId);
      for (let i = 0; i < textTracks.length; i++) {
        if (i === subIndex) {
          textTracks[i].mode = 'showing';
        } else {
          textTracks[i].mode = 'disabled';
        }
      }
      currentSubtitleId = trackId;
    }

    notifySubtitleChange();
  }

  function getSubtitleTracks() {
    return availableSubtitles;
  }

  function getCurrentSubtitleId() {
    return currentSubtitleId;
  }

  function toggleCaptions() {
    if (availableSubtitles.length === 0) return;
    if (currentSubtitleId === 'off') {
      // Turn on first available track
      setSubtitleTrack(availableSubtitles[0].id);
    } else {
      // Turn off
      setSubtitleTrack('off');
    }
  }

  function detectAudioTracks() {
    if (!mediaEl) {
      audioTracksAvailable = false;
      audioTracksList = [];
      return;
    }
    // Safe detection only
    try {
      if (mediaEl.audioTracks && typeof mediaEl.audioTracks.length === 'number') {
        audioTracksAvailable = true;
        audioTracksList = [];
        for (let i = 0; i < mediaEl.audioTracks.length; i++) {
          const t = mediaEl.audioTracks[i];
          audioTracksList.push({
            id: t.id || i.toString(),
            label: t.label || `Audio Track ${i + 1}`,
            language: t.language || 'und',
            enabled: t.enabled
          });
        }
      } else {
        audioTracksAvailable = false;
        audioTracksList = [];
      }
    } catch (e) {
      audioTracksAvailable = false;
      audioTracksList = [];
    }
  }

  function getAudioTrackInfo() {
    return {
      available: audioTracksAvailable,
      tracks: audioTracksList
    };
  }

  let pendingCanPlayHandler = null;

  function loadItem(item, autoPlay = true, resumePosition = 0, isRestart = false) {
    if (isRestart) {
      resumePosition = 0;
    }

    if (!mediaEl) {
      const vEl = document.getElementById('mainVideoPlayer');
      const vCont = document.getElementById('videoViewport');
      if (vEl && vCont) {
        init(vCont, vEl);
      }
    }

    if (!mediaEl || !item) return;

    // Fast-path for per-track loop / repeat: instant gapless replay from 0 without re-fetching or reloading DOM media
    if (isRestart && currentItem && (currentItem.id === item.id || mediaEl.src)) {
      try {
        mediaEl.currentTime = 0;
        if (autoPlay) {
          const p = mediaEl.play();
          if (p && typeof p.catch === 'function') {
            p.catch(err => {
              console.warn('Playback restart caught:', err);
              onPlayStateChangeCbs.forEach(cb => { try { cb(false); } catch(e){} });
            });
          }
        }
        onPlayStateChangeCbs.forEach(cb => { try { cb(true); } catch(e){} });
        return;
      } catch (loopErr) {
        console.warn('Fast restart failed, falling back to full reload:', loopErr);
      }
    }

    currentItem = item;
    try {
      window.dispatchEvent(new CustomEvent('novapulse-player-item', { detail: item }));
    } catch (e) {}
    clearAbRepeat(); // Reset A-B on each new track
    setPlaybackRate(1.0); // Reset to standard 1.0x on each newly loaded media item (BUG-009)
    const speedSelect = document.getElementById('playbackSpeedSelect');
    if (speedSelect) speedSelect.value = '1';

    try {
      clearSubtitleTracks(); // Clear any previous subtitle tracks
    } catch (e) {
      console.warn('Could not clear previous subtitle tracks:', e);
    }

    if (pendingCanPlayHandler) {
      mediaEl.removeEventListener('canplay', pendingCanPlayHandler);
      mediaEl.removeEventListener('loadeddata', pendingCanPlayHandler);
      pendingCanPlayHandler = null;
    }

    try {
      if (!mediaEl.paused) mediaEl.pause();
    } catch(e) {}

    if (!item.url && item.id && item.id.startsWith('media_')) {
      try {
        const b64 = item.id.replace(/^media_/, '').replace(/-/g, '+').replace(/_/g, '/');
        const relPath = decodeURIComponent(escape(atob(b64)));
        item.url = '/api/media/' + relPath.replace(/\\/g, '/').split('/').map(seg => encodeURIComponent(seg)).join('/');
      } catch (e) {
        item.url = '/api/media/' + encodeURIComponent(item.id.replace(/^media_/, ''));
      }
    }

    // Immediately hide video placeholder overlay when loading media item
    const placeholder = document.getElementById('videoPlaceholder');
    if (placeholder) {
      placeholder.style.display = 'none';
      placeholder.style.opacity = '0';
      placeholder.style.pointerEvents = 'none';
    }

    if (hlsInstance) {
      hlsInstance.destroy();
      hlsInstance = null;
    }

    const isHls = item.url && (item.url.includes('.m3u8') || item.type === 'hls');

    let mediaUrl = item.url;
    if (mediaUrl && mediaUrl.startsWith('/api/media/')) {
      // Protect any unencoded '#' in media filenames from being treated as browser URL fragments and truncated
      const [pathPart, queryPart] = mediaUrl.split('?');
      const fixedPath = pathPart.replace(/#(?!t=\d)/g, '%23');
      mediaUrl = fixedPath + (queryPart !== undefined ? '?' + queryPart : '');
    }
    const token = localStorage.getItem('novapulse_auth_token');
    if (token && mediaUrl && mediaUrl.startsWith('/api/')) {
      mediaUrl += (mediaUrl.includes('?') ? '&' : '?') + 'token=' + encodeURIComponent(token);
    }

    if (isHls && window.Hls && Hls.isSupported()) {
      hlsInstance = new Hls({ enableWorker: true });
      hlsInstance.loadSource(mediaUrl);
      hlsInstance.attachMedia(mediaEl);
    } else {
      mediaEl.src = mediaUrl;
      mediaEl.load();
    }

    // Determine resume position if not explicitly forced (> 0)
    let effectiveResume = resumePosition;
    const knownDuration = (item && item.duration) || 0;

    if (!effectiveResume || effectiveResume <= 0) {
      // Exact playback resume per video ID
      const positions = getSavedMediaPositions();
      const saved = positions[item.id];
      if (saved && saved.time > 1) {
        if (!saved.duration || saved.time < saved.duration - 5) {
          effectiveResume = saved.time;
        }
      } else if (item.playbackPosition && item.playbackPosition > 1) {
        effectiveResume = item.playbackPosition;
      }
    }

    // Immediately record into personal watch history so active media appears at top of timeline
    recordWatchHistory(item, effectiveResume || 0, item.duration || 0);

    const onReady = () => {
      mediaEl.removeEventListener('canplay', onReady);
      mediaEl.removeEventListener('loadeddata', onReady);
      if (pendingCanPlayHandler === onReady) {
        pendingCanPlayHandler = null;
      }
      detectAudioTracks();

      const startPlayback = () => {
        if (!autoPlay) return;
        const p = mediaEl.play();
        if (p && typeof p.catch === 'function') {
          p.catch(err => {
            console.warn('Playback start caught:', err);
            onPlayStateChangeCbs.forEach(cb => { try { cb(false); } catch(e){} });
          });
        }
      };

      if (effectiveResume > 0) {
        try {
          const maxDur = isNaN(mediaEl.duration) ? effectiveResume + 10 : mediaEl.duration;
          if (effectiveResume < maxDur) {
            let seekHandled = false;
            const onSeeked = () => {
              if (seekHandled) return;
              seekHandled = true;
              mediaEl.removeEventListener('seeked', onSeeked);
              startPlayback();
            };
            mediaEl.addEventListener('seeked', onSeeked, { once: true });
            mediaEl.currentTime = effectiveResume;
            if (typeof showNovaToast === 'function') {
              const mins = Math.floor(effectiveResume / 60);
              const secs = Math.floor(effectiveResume % 60);
              const toastMsg = `Resumed "${item.name}" from ${mins}:${secs < 10 ? '0' : ''}${secs}`;
              const resumeKey = `resume_${item.id}_${mins}_${secs}`;
              if (window.__lastResumedToastKey !== resumeKey) {
                window.__lastResumedToastKey = resumeKey;
                showNovaToast(toastMsg, 'fa-clock-rotate-left', 15000);
              }
            }
            // Safety timeout in case browser doesn't dispatch seeked event
            setTimeout(() => {
              if (!seekHandled) {
                seekHandled = true;
                mediaEl.removeEventListener('seeked', onSeeked);
                startPlayback();
              }
            }, 500);
            return;
          }
        } catch (e) {}
      }

      startPlayback();
    };

    // Register the readiness handlers *before* touching subtitles so that a
    // subtitle/UI problem can never prevent the track from loading and playing.
    pendingCanPlayHandler = onReady;
    mediaEl.addEventListener('canplay', onReady);
    mediaEl.addEventListener('loadeddata', onReady);

    // Mount companion subtitles if present (best-effort only)

    if (Array.isArray(item.subtitles) && item.subtitles.length > 0) {
      try {
        mountSubtitles(item.subtitles);
      } catch (e) {
        console.warn('Could not mount companion subtitles:', e);
      }
    }
  }

  function play() {
    if (getIsEmbedActive()) {
      sendEmbedCommand('playVideo');
      isEmbedPlaying = true;
      startEmbedTicker();
      onPlayStateChangeCbs.forEach(cb => { try { cb(true); } catch(e){} });
      return Promise.resolve();
    }
    if (mediaEl && mediaEl.src) {
      if (mediaEl.error) {
        const cur = mediaEl.currentTime;
        mediaEl.load();
        if (cur > 0) mediaEl.currentTime = cur;
      }
      return mediaEl.play().catch(err => {
        console.warn('Play was interrupted:', err);
      });
    }
  }

  function pause() {
    if (getIsEmbedActive()) {
      sendEmbedCommand('pauseVideo');
      isEmbedPlaying = false;
      stopEmbedTicker();
      onPlayStateChangeCbs.forEach(cb => { try { cb(false); } catch(e){} });
      return;
    }
    if (mediaEl) {
      mediaEl.pause();
      saveCurrentPositionNow();
    }
  }

  function togglePlay() {
    if (getIsEmbedActive()) {
      if (isEmbedPlaying) {
        pause();
      } else {
        play();
      }
      return;
    }
    if (!mediaEl || !mediaEl.src) return;
    if (mediaEl.paused) {
      play();
    } else {
      pause();
    }
  }

  function seek(seconds) {
    if (getIsEmbedActive()) {
      const targetSec = Math.max(0, seconds);
      embedCurrentTime = targetSec;
      sendEmbedCommand('seekTo', [targetSec, true]);
      onTimeUpdateCbs.forEach(cb => { try { cb(embedCurrentTime, embedDuration); } catch (e) {} });
      return;
    }
    if (mediaEl && !isNaN(mediaEl.duration)) {
      mediaEl.currentTime = Math.max(0, Math.min(seconds, mediaEl.duration));
      saveCurrentPositionNow();
    }
  }

  let currentVolume = 1.0;


  function updateAudioGain() {
    const effectiveVol = isMuted ? 0 : currentVolume;
    if (mediaEl) {
      // Ensure media element volume directly tracks effective volume (0 to 1.0)
      mediaEl.volume = Math.max(0, Math.min(1, effectiveVol));
      mediaEl.muted = isMuted || effectiveVol === 0;
    }
    if (gainNode) {
      const targetGain = effectiveVol * amplificationLevel;
      try {
        if (gainNode.gain.setValueAtTime && audioCtx) {
          gainNode.gain.setValueAtTime(targetGain, audioCtx.currentTime);
        } else {
          gainNode.gain.value = targetGain;
        }
      } catch (e) {
        gainNode.gain.value = targetGain;
      }
    }
    if (audioCtx && audioCtx.state === 'suspended' && effectiveVol > 0) {
      audioCtx.resume().catch(() => {});
    }
  }

  function setVolume(val) {
    const num = Math.max(0, parseFloat(val) || 0);
    if (num > 1.0) {
      currentVolume = 1.0;
      amplificationLevel = num;
    } else {
      currentVolume = num;
      amplificationLevel = 1.0;
    }
    if (num > 0) {
      previousVolume = num <= 1.0 ? num : 1.0;
      isMuted = false;
    }
    updateAudioGain();
    localStorage.setItem('ultimatePlayer.volume', num.toString());
  }

  function getVolume() {
    if (isMuted) return 0;
    return amplificationLevel > 1.0 ? amplificationLevel : currentVolume;
  }

  function toggleMute() {
    isMuted = !isMuted;
    if (!isMuted && currentVolume === 0) {
      currentVolume = previousVolume > 0 ? previousVolume : 1;
    }
    updateAudioGain();
    return isMuted;
  }

  function setAmplification(level) {
    amplificationLevel = Math.max(1.0, Math.min(3.0, parseFloat(level) || 1.0));
    initAudioNodes();
    updateAudioGain();
  }

  function getAmplification() {
    return amplificationLevel;
  }

  function setRepeatMode(mode) {
    if (getIsEmbedActive()) {
      // Loop iframe if supported or command
      if (mode === 'current') {
        sendEmbedCommand('setLoop', [true]);
      } else {
        sendEmbedCommand('setLoop', [false]);
      }
    }
    if (mediaEl) {
      // If repeating current track, enable native HTML5 loop for 100% reliable continuous looping
      mediaEl.loop = (mode === 'current');
    }
  }

  function setPlaybackRate(rate) {
    const r = parseFloat(rate) || 1;
    embedPlaybackRate = r;
    if (getIsEmbedActive()) {
      sendEmbedCommand('setPlaybackRate', [r]);
    }
    if (mediaEl) {
      mediaEl.playbackRate = r;
    }
    localStorage.setItem('ultimatePlayer.speed', r.toString());
  }

  function getPlaybackRate() {
    if (getIsEmbedActive()) return embedPlaybackRate;
    return mediaEl ? mediaEl.playbackRate : 1;
  }

  function getCurrentTime() {
    if (getIsEmbedActive()) return embedCurrentTime;
    return mediaEl && !isNaN(mediaEl.currentTime) ? mediaEl.currentTime : 0;
  }

  function getDuration() {
    if (getIsEmbedActive()) return embedDuration || (currentItem ? currentItem.duration : 0) || 0;
    return mediaEl && !isNaN(mediaEl.duration) ? mediaEl.duration : 0;
  }

  function isPaused() {
    if (getIsEmbedActive()) return !isEmbedPlaying;
    return mediaEl ? mediaEl.paused : true;
  }

  function hasSource() {
    if (getIsEmbedActive()) return true;
    return Boolean(mediaEl && mediaEl.src && mediaEl.src !== '');
  }

  function hasError() {
    return Boolean(mediaEl && mediaEl.error);
  }

  
  // ─── Fullscreen Gestures, Inactivity & Screen Lock Engine ────────
  function initFullscreenHUD() {
    if (!videoContainer) return;

    let isFsLocked = false;
    let fsIdleTimer = null;
    const FS_IDLE_DELAY = 15000; // 15 seconds of inactivity

    // Helper: format duration in H:MM:SS (if >= 60 min or forced) or MM:SS
    function fmtTime(sec, forceHours = false) {
      if (isNaN(sec) || sec < 0) return forceHours ? '0:00:00' : '00:00';
      const total = Math.floor(sec);
      const h = Math.floor(total / 3600);
      const m = Math.floor((total % 3600) / 60);
      const s = total % 60;
      const pad = n => (n < 10 ? '0' + n : n);
      if (h > 0 || forceHours) return `${h}:${pad(m)}:${pad(s)}`;
      return `${pad(m)}:${pad(s)}`;
    }

    // Double-click/double-tap is unified in tap handler below

    // Also support double right-click seamlessly
    let lastRightClickTime = 0;
    videoContainer.addEventListener('contextmenu', (e) => {
      if (e.target.closest('button, input, select, .fs-ai-drawer, .fs-unlock-pill')) return;
      if (isFsLocked) return;
      const now = Date.now();
      if (now - lastRightClickTime < 350) {
        e.preventDefault();
        toggleFullscreen();
        lastRightClickTime = 0;
        return;
      }
      lastRightClickTime = now;
    });

    // 2. Inactivity Timer (5 seconds)
    function resetFsInactivity() {
      const isFs = Boolean(document.fullscreenElement) || videoContainer.classList.contains('is-fullscreen');
      if (!isFs) {
        videoContainer.classList.remove('fs-idle');
        return;
      }

      videoContainer.classList.remove('fs-idle');
      if (fsIdleTimer) clearTimeout(fsIdleTimer);

      if (isFsLocked) {
        const unlockBar = document.getElementById('fsUnlockBar');
        if (unlockBar) {
          unlockBar.style.display = 'flex';
          unlockBar.style.opacity = '1';
        }
        fsIdleTimer = setTimeout(() => {
          videoContainer.classList.add('fs-idle');
          if (unlockBar) unlockBar.style.opacity = '0';
        }, FS_IDLE_DELAY);
        return;
      }

      fsIdleTimer = setTimeout(() => {
        const activeFs = Boolean(document.fullscreenElement) || videoContainer.classList.contains('is-fullscreen');
        if (activeFs) {
          videoContainer.classList.add('fs-idle');
        }
      }, FS_IDLE_DELAY);
    }

    // ── Visual Ripple Pill Indicator for YouTube-style Double Tap (+5s / -5s / Play / Pause) ──
    function showGestureIndicator(side, text, iconHtml) {
      let overlay = document.getElementById('fsGestureIndicator');
      if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'fsGestureIndicator';
        overlay.className = 'fs-gesture-indicator';
        videoContainer.appendChild(overlay);
      }
      overlay.className = 'fs-gesture-indicator ' + side + ' active';
      overlay.innerHTML = `<div class="fs-gesture-bubble">${iconHtml}<span>${text}</span></div>`;
      clearTimeout(overlay._timer);
      overlay._timer = setTimeout(() => {
        overlay.className = 'fs-gesture-indicator ' + side;
      }, 650);
    }

    // ── Unified 3-Section Double-Tap & Single-Tap Gesture Engine ──
    let tapTimer = null;
    let tapCount = 0;
    let lastTapTime = 0;
    let lastTapSide = 'middle';

    function getTapSide(clientX) {
      if (!videoContainer) return 'middle';
      const rect = videoContainer.getBoundingClientRect();
      const relativeX = clientX - rect.left;
      const width = rect.width;
      if (relativeX < width * 0.33) {
        return 'left';
      } else if (relativeX > width * 0.67) {
        return 'right';
      } else {
        return 'middle';
      }
    }

    function handleViewportGesture(e) {
      if (e.target.closest('button, input, select, .fs-ai-drawer, .fs-seek-container, .fs-unlock-pill')) return;
      
      const now = Date.now();
      const timeDiff = now - lastTapTime;
      lastTapTime = now;

      // Extract click or touch coordinate
      let clientX = e.clientX;
      if (typeof clientX === 'undefined' && e.changedTouches && e.changedTouches[0]) {
        clientX = e.changedTouches[0].clientX;
      }
      if (typeof clientX === 'undefined') {
        const rect = videoContainer.getBoundingClientRect();
        clientX = rect.left + rect.width / 2;
      }

      const currentSide = getTapSide(clientX);

      // Detect double-tap (< 340ms) on same or compatible section
      if (timeDiff > 0 && timeDiff < 340) {
        tapCount = 2;
        if (tapTimer) {
          clearTimeout(tapTimer);
          tapTimer = null;
        }
      } else {
        tapCount = 1;
        lastTapSide = currentSide;
      }

      if (tapCount === 1) {
        tapTimer = setTimeout(() => {
          tapCount = 0;
          tapTimer = null;
          // SINGLE TAP / CLICK: Toggle Fullscreen HUD controls with 15s display duration
          const isFs = Boolean(document.fullscreenElement) || videoContainer.classList.contains('is-fullscreen') || videoContainer.classList.contains('mobile-landscape-fs');
          if (!isFs) return;
          if (videoContainer.classList.contains('fs-idle')) {
            resetFsInactivity();
          } else {
            videoContainer.classList.add('fs-idle');
          }
        }, 300);
      } else if (tapCount === 2) {
        tapCount = 0;
        if (tapTimer) {
          clearTimeout(tapTimer);
          tapTimer = null;
        }

        if (isFsLocked) return;

        const effectiveSide = currentSide;
        const curTime = getCurrentTime();
        const duration = getDuration();

        if (effectiveSide === 'left') {
          // Double Tap LEFT: Rewind 5 seconds
          const target = Math.max(0, curTime - 5);
          seek(target);
          showGestureIndicator('left', '5s', '<i class="fa-solid fa-backward-fast"></i>');
          resetFsInactivity();
        } else if (effectiveSide === 'right') {
          // Double Tap RIGHT: Forward 5 seconds
          const target = duration > 0 ? Math.min(duration, curTime + 5) : curTime + 5;
          seek(target);
          showGestureIndicator('right', '5s', '<i class="fa-solid fa-forward-fast"></i>');
          resetFsInactivity();
        } else {
          // Double Tap MIDDLE: Toggle Play / Pause
          togglePlay();
          const willPlay = mediaEl ? mediaEl.paused : false;
          showGestureIndicator('middle', '', willPlay ? '<i class="fa-solid fa-play"></i>' : '<i class="fa-solid fa-pause"></i>');
          resetFsInactivity();
        }
      }
    }

    let lastTouchStartTime = 0;
    videoContainer.addEventListener('touchstart', (e) => {
      lastTouchStartTime = Date.now();
    }, { passive: true });

    videoContainer.addEventListener('touchend', (e) => {
      if (e.target.closest('button, input, select, .fs-ai-drawer, .fs-seek-container, .fs-unlock-pill')) return;
      if (Date.now() - lastTouchStartTime < 280) {
        handleViewportGesture(e);
      }
    }, { passive: true });

    videoContainer.addEventListener('click', (e) => {
      if (e.target.closest('button, input, select, .fs-ai-drawer, .fs-seek-container, .fs-unlock-pill')) return;
      if (Date.now() - lastTouchStartTime > 350) {
        handleViewportGesture(e);
      }
    });

    // Fullscreen state listener
    document.addEventListener('fullscreenchange', () => {
      const isFs = Boolean(document.fullscreenElement);
      videoContainer.classList.toggle('is-fullscreen', isFs);
      if (!isFs) {
        videoContainer.classList.remove('fs-locked', 'fs-idle', 'mobile-landscape-fs');
        isFsLocked = false;
        const unlockBar = document.getElementById('fsUnlockBar');
        if (unlockBar) unlockBar.style.display = 'none';
        const aiDrawer = document.getElementById('fsAiDrawer');
        if (aiDrawer) aiDrawer.style.display = 'none';
        const statsEl = document.getElementById('statsForNerds');
        if (statsEl) statsEl.style.display = 'none';
        if (fsIdleTimer) clearTimeout(fsIdleTimer);
      }
      syncFsHudUI();
    });

    // 3. Wire Controls
    const btnFsExitTop = document.getElementById('btnFsExitTop');
    const btnFsExit = document.getElementById('btnFsExit');
    const btnFsToggle = document.getElementById('btnFsToggle');
    const btnFsPlay = document.getElementById('btnFsPlay');
    const btnFsRewind = document.getElementById('btnFsRewind');
    const btnFsForward = document.getElementById('btnFsForward');
    const btnFsSpeed = document.getElementById('btnFsSpeed');
    const btnFsMute = document.getElementById('btnFsMute');
    const fsVolSlider = document.getElementById('fsVolSlider');
    const fsSeekSlider = document.getElementById('fsSeekSlider');
    const fsSeekFill = document.getElementById('fsSeekFill');
    const btnFsLock = document.getElementById('btnFsLock');
    const btnFsUnlock = document.getElementById('btnFsUnlock');
    const btnFsAskAi = document.getElementById('btnFsAskAi');
    const btnCloseFsAi = document.getElementById('btnCloseFsAi');
    const btnFsAiSend = document.getElementById('btnFsAiSend');
    const fsAiInput = document.getElementById('fsAiInput');
    const fsAiDrawer = document.getElementById('fsAiDrawer');
    const btnFsLanguage = document.getElementById('btnFsLanguage');
    const btnFsStats = document.getElementById('btnFsStats');

    if (btnFsExitTop) btnFsExitTop.addEventListener('click', toggleFullscreen);
    if (btnFsExit) btnFsExit.addEventListener('click', toggleFullscreen);
    if (btnFsToggle) btnFsToggle.addEventListener('click', toggleFullscreen);

    if (btnFsPlay) {
      btnFsPlay.addEventListener('click', () => togglePlay());
    }
    if (btnFsRewind) {
      btnFsRewind.addEventListener('click', () => seek(Math.max(0, getCurrentTime() - 10)));
    }
    if (btnFsForward) {
      btnFsForward.addEventListener('click', () => seek(Math.min(getDuration(), getCurrentTime() + 10)));
    }
    if (btnFsSpeed) {
      btnFsSpeed.addEventListener('click', () => {
        const speeds = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0];
        const curSpeed = getPlaybackRate();
        const nextSpeed = speeds[(speeds.indexOf(curSpeed) + 1) % speeds.length] || 1.0;
        setPlaybackRate(nextSpeed);
        btnFsSpeed.textContent = `${nextSpeed}x`;
      });
    }
    if (btnFsMute) {
      btnFsMute.addEventListener('click', () => {
        toggleMute();
        if (fsVolSlider) fsVolSlider.value = isMuted() ? 0 : getVolume();
      });
    }
    if (fsVolSlider) {
      fsVolSlider.addEventListener('input', (e) => {
        setVolume(parseFloat(e.target.value));
      });
    }

    if (fsSeekSlider) {
      let isSeeking = false;
      fsSeekSlider.addEventListener('mousedown', () => { isSeeking = true; });
      fsSeekSlider.addEventListener('input', (e) => {
        const pct = parseFloat(e.target.value);
        if (fsSeekFill) fsSeekFill.style.width = pct + '%';
      });
      fsSeekSlider.addEventListener('change', (e) => {
        const dur = getDuration();
        if (dur > 0) {
          seek((parseFloat(e.target.value) / 100) * dur);
        }
        isSeeking = false;
      });
    }

    // 4. Screen Lock Feature
    function lockScreen() {
      isFsLocked = true;
      videoContainer.classList.add('fs-locked');
      const unlockBar = document.getElementById('fsUnlockBar');
      if (unlockBar) {
        unlockBar.style.display = 'flex';
        unlockBar.style.opacity = '1';
      }
      if (typeof showNovaToast === 'function') {
        showNovaToast('Screen Locked — Controls hidden', 'fa-lock');
      }
      resetFsInactivity();
    }

    function unlockScreen() {
      isFsLocked = false;
      videoContainer.classList.remove('fs-locked', 'fs-idle');
      const unlockBar = document.getElementById('fsUnlockBar');
      if (unlockBar) {
        unlockBar.style.display = 'none';
      }
      if (typeof showNovaToast === 'function') {
        showNovaToast('Screen Unlocked', 'fa-lock-open');
      }
      resetFsInactivity();
    }

    if (btnFsLock) btnFsLock.addEventListener('click', lockScreen);
    if (btnFsUnlock) btnFsUnlock.addEventListener('click', unlockScreen);

    // Escape or double click unlocks if locked
    document.addEventListener('keydown', (e) => {
      if (isFsLocked && (e.key === 'Escape' || e.key === 'l' || e.key === 'L')) {
        unlockScreen();
      }
    });

    // 5. Ask DELTA V1 In-Fullscreen Drawer
    if (btnFsAskAi) {
      btnFsAskAi.addEventListener('click', () => {
        if (!fsAiDrawer) return;
        const isHidden = fsAiDrawer.style.display === 'none' || !fsAiDrawer.style.display;
        fsAiDrawer.style.display = isHidden ? 'flex' : 'none';
        if (isHidden) {
          const timeCtx = document.getElementById('fsAiTimeContext');
          if (timeCtx) timeCtx.textContent = '@ ' + fmtTime(getCurrentTime());
          if (fsAiInput) fsAiInput.focus();
        }
      });
    }

    if (btnCloseFsAi) {
      btnCloseFsAi.addEventListener('click', () => {
        if (fsAiDrawer) fsAiDrawer.style.display = 'none';
      });
    }

    async function handleFsAiSubmit() {
      if (!fsAiInput) return;
      const question = fsAiInput.value.trim();
      if (!question) return;
      fsAiInput.value = '';

      const respArea = document.getElementById('fsAiResponseArea');
      if (respArea) {
        respArea.innerHTML = `
          <div class="fs-ai-user-bubble">${question}</div>
          <div class="fs-ai-thinking"><i class="fa-solid fa-circle-notch fa-spin"></i> DELTA V1 analyzing scene @ ${fmtTime(getCurrentTime())}...</div>
        `;
      }

      if (typeof AiNotebook !== 'undefined' && typeof AiNotebook.askQuestion === 'function') {
        await AiNotebook.askQuestion(question, getCurrentTime());
        // Mirror message in response area
        const notebookMsgs = document.getElementById('notebookMessages');
        if (notebookMsgs && respArea) {
          const lastAssistant = notebookMsgs.querySelector('.notebook-msg.assistant:last-child .notebook-msg-body');
          if (lastAssistant) {
            respArea.innerHTML = `
              <div class="fs-ai-user-bubble">${question}</div>
              <div class="fs-ai-assistant-bubble">${lastAssistant.innerHTML}</div>
            `;
            // Wire citation buttons in fullscreen
            respArea.querySelectorAll('.citation-link').forEach(btn => {
              btn.addEventListener('click', () => {
                const timeStr = btn.getAttribute('data-time');
                const parts = timeStr.split(':').map(Number);
                let sec = 0;
                if (parts.length === 2) sec = (parts[0] * 60) + parts[1];
                else if (parts.length === 3) sec = (parts[0] * 3600) + (parts[1] * 60) + parts[2];
                if (!isNaN(sec)) seek(sec);
              });
            });
          }
        }
      }
    }

    if (btnFsAiSend) btnFsAiSend.addEventListener('click', handleFsAiSubmit);
    if (fsAiInput) {
      fsAiInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          handleFsAiSubmit();
        }
      });
    }

    if (btnFsLanguage) {
      btnFsLanguage.addEventListener('click', () => {
        const btnCaptions = document.getElementById('btnCaptions');
        if (btnCaptions) btnCaptions.click();
      });
    }

    if (btnFsStats) {
      btnFsStats.addEventListener('click', (e) => {
        e.stopPropagation();
        const statsEl = document.getElementById('statsForNerds');
        if (statsEl) {
          statsEl.style.display = 'none';
        }
      });
    }

    // 6. Time Update Sync for Fullscreen HUD
    onTimeUpdateCbs.push((cur, dur) => {
      syncFsHudUI();
    });

    onPlayStateChangeCbs.push((playing) => {
      if (btnFsPlay) {
        btnFsPlay.innerHTML = playing ? '<i class="fa-solid fa-pause"></i>' : '<i class="fa-solid fa-play"></i>';
      }
    });

    let fsShowRemainingTime = false;
    const badgeEl = document.getElementById('fsTimeBadge');
    const textEl = document.getElementById('fsTimeText');

    function toggleFsRemaining() {
      fsShowRemainingTime = !fsShowRemainingTime;
      syncFsHudUI();
    }
    if (badgeEl) {
      badgeEl.style.cursor = 'pointer';
      badgeEl.title = 'Click to toggle remaining time';
      badgeEl.addEventListener('click', toggleFsRemaining);
    }
    if (textEl) {
      textEl.style.cursor = 'pointer';
      textEl.title = 'Click to toggle remaining time';
      textEl.addEventListener('click', toggleFsRemaining);
    }

    function syncFsHudUI() {
      const cur = getCurrentTime();
      const dur = getDuration();
      const hasHours = (dur >= 3600) || (cur >= 3600);
      let durStr = fmtTime(dur, hasHours);
      if (fsShowRemainingTime && dur > 0) {
        durStr = '-' + fmtTime(Math.max(0, dur - cur), hasHours);
      }
      const timeStr = `${fmtTime(cur, hasHours)} / ${durStr}`;

      const titleEl = document.getElementById('fsVideoTitle');
      if (titleEl && currentItem) titleEl.textContent = currentItem.name || 'NovaPulse Media Engine';

      if (badgeEl) badgeEl.textContent = timeStr;
      if (textEl) textEl.textContent = timeStr;

      if (fsSeekSlider && dur > 0) {
        const pct = (cur / dur) * 100;
        fsSeekSlider.value = pct;
        if (fsSeekFill) fsSeekFill.style.width = pct + '%';
      }
    }
  }

  function toggleFullscreen() {
    const target = videoContainer || mediaEl;
    if (!target) return;
    const isMobile = document.documentElement.getAttribute('data-device') === 'mobile' ||
                     document.body.classList.contains('device-mobile') ||
                     window.innerWidth <= 768;

    const isCustomFs = target.classList.contains('mobile-landscape-fs') || target.classList.contains('is-fullscreen');
    const isNativeFs = Boolean(document.fullscreenElement || document.webkitFullscreenElement);

    if (!isNativeFs && !isCustomFs) {
      // ENTER FULLSCREEN
      target.classList.add('mobile-landscape-fs', 'is-fullscreen');
      const statsEl = document.getElementById('statsForNerds');
      if (statsEl) statsEl.style.display = 'none';

      if (window.ReactNativeWebView && typeof window.ReactNativeWebView.postMessage === 'function') {
        window.ReactNativeWebView.postMessage(JSON.stringify({ type: 'FULLSCREEN_ENTER' }));
      }
      if (screen.orientation && screen.orientation.lock) {
        screen.orientation.lock('landscape').catch(() => {});
      }
      if (!isMobile) {
        if (target.requestFullscreen) target.requestFullscreen().catch(() => {});
        else if (target.webkitRequestFullscreen) target.webkitRequestFullscreen();
      }
    } else {
      // EXIT FULLSCREEN
      target.classList.remove('mobile-landscape-fs', 'is-fullscreen', 'fs-idle', 'fs-locked');
      const statsEl = document.getElementById('statsForNerds');
      if (statsEl) statsEl.style.display = 'none';
      const unlockBar = document.getElementById('fsUnlockBar');
      if (unlockBar) unlockBar.style.display = 'none';
      const aiDrawer = document.getElementById('fsAiDrawer');
      if (aiDrawer) aiDrawer.style.display = 'none';

      if (window.ReactNativeWebView && typeof window.ReactNativeWebView.postMessage === 'function') {
        window.ReactNativeWebView.postMessage(JSON.stringify({ type: 'FULLSCREEN_EXIT' }));
      }
      if (screen.orientation && screen.orientation.unlock) {
        try { screen.orientation.unlock(); } catch (e) {}
      }
      if (document.fullscreenElement || document.webkitFullscreenElement) {
        if (document.exitFullscreen) document.exitFullscreen().catch(() => {});
        else if (document.webkitExitFullscreen) document.webkitExitFullscreen();
      }
    }
  }

  function takeSnapshot() {
    if (getIsEmbedActive()) {
      if (currentItem && currentItem.thumbnail) {
        const a = document.createElement('a');
        a.href = currentItem.thumbnail;
        a.target = '_blank';
        a.download = `${(currentItem.name || 'stream_thumbnail').replace(/[^a-zA-Z0-9_-]/g, '_')}.jpg`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        return currentItem.thumbnail;
      }
      return 'embed-stream-snapshot';
    }
    if (!mediaEl || currentItem?.type === 'audio') return null;
    try {
      const canvas = document.createElement('canvas');
      canvas.width = mediaEl.videoWidth || 1920;
      canvas.height = mediaEl.videoHeight || 1080;
      const ctx = canvas.getContext('2d');
      if (videoFilters) {
        ctx.filter = `brightness(${videoFilters.brightness}%) contrast(${videoFilters.contrast}%) saturate(${videoFilters.saturate}%) hue-rotate(${videoFilters.hueRotate}deg) sepia(${videoFilters.sepia}%) blur(${videoFilters.blur}px)`;
      }
      ctx.drawImage(mediaEl, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/png');
      const a = document.createElement('a');
      a.href = dataUrl;
      const safeTitle = (currentItem ? currentItem.name : 'novapulse_frame').replace(/[^a-zA-Z0-9_-]/g, '_');
      a.download = `${safeTitle}_${Math.floor(getCurrentTime())}s.png`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      return dataUrl;
    } catch (e) {
      console.warn('Snapshot capture failed:', e);
      return null;
    }
  }

  async function togglePiP() {
    if (!mediaEl || currentItem?.type === 'audio') return false;
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
        return false;
      } else if (document.pictureInPictureEnabled && mediaEl.requestPictureInPicture) {
        await mediaEl.requestPictureInPicture();
        return true;
      }
    } catch (e) {
      console.warn('PiP toggle failed:', e);
    }
    return false;
  }


  // 5-Band Equalizer filters
  let eqFilters = {};
  const EQ_FREQS = [60, 250, 1000, 4000, 14000];

  function initAudioNodes() {
    if (audioCtx || !mediaEl) return;
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) {
        audioCtx = new AudioCtx();
        gainNode = audioCtx.createGain();
        audioSourceNode = audioCtx.createMediaElementSource(mediaEl);

        // Build 5-band equalizer chain
        let prevNode = audioSourceNode;
        EQ_FREQS.forEach(freq => {
          const filter = audioCtx.createBiquadFilter();
          filter.type = freq <= 60 ? 'lowshelf' : (freq >= 14000 ? 'highshelf' : 'peaking');
          filter.frequency.value = freq;
          filter.gain.value = 0;
          prevNode.connect(filter);
          prevNode = filter;
          eqFilters[freq] = filter;
        });

        // Soft-knee broadcast limiter to safely prevent distortion/clipping when boosted up to 200%
        let compressorNode = null;
        try {
          compressorNode = audioCtx.createDynamicsCompressor();
          compressorNode.threshold.setValueAtTime(-14, audioCtx.currentTime);
          compressorNode.knee.setValueAtTime(24, audioCtx.currentTime);
          compressorNode.ratio.setValueAtTime(12, audioCtx.currentTime);
          compressorNode.attack.setValueAtTime(0.003, audioCtx.currentTime);
          compressorNode.release.setValueAtTime(0.25, audioCtx.currentTime);
        } catch (compErr) {
          console.warn('Compressor setup warning:', compErr);
        }

        prevNode.connect(gainNode);
        if (compressorNode) {
          gainNode.connect(compressorNode);
          compressorNode.connect(audioCtx.destination);
        } else {
          gainNode.connect(audioCtx.destination);
        }
        updateAudioGain();
      }
    } catch (e) {
      console.warn('AudioContext / Equalizer setup exception:', e);
    }
  }

  // Auto-resume AudioContext if throttled by browser during background tab / window switch
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden && audioCtx && audioCtx.state === 'suspended' && mediaEl && !mediaEl.paused) {
      audioCtx.resume().catch(() => {});
    }
  });

  function setEqualizerBand(freq, gainVal) {
    initAudioNodes();
    if (eqFilters[freq]) {
      eqFilters[freq].gain.value = parseFloat(gainVal) || 0;
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
  }

  function setEqualizerPreset(preset) {
    initAudioNodes();
    const presets = {
      flat: { 60: 0, 250: 0, 1000: 0, 4000: 0, 14000: 0 },
      bass: { 60: 8, 250: 5, 1000: 1, 4000: -1, 14000: -2 },
      vocal: { 60: -2, 250: 1, 1000: 6, 4000: 4, 14000: 2 },
      electronic: { 60: 7, 250: 3, 1000: -2, 4000: 3, 14000: 6 },
      cinema: { 60: 6, 250: 2, 1000: 3, 4000: 4, 14000: 5 },
      treble: { 60: -3, 250: -1, 1000: 2, 4000: 6, 14000: 9 }
    };
    const target = presets[preset] || presets.flat;
    Object.keys(target).forEach(freq => {
      setEqualizerBand(Number(freq), target[freq]);
    });
    return target;
  }

  // ─── Video FX & Color Grading ───────────────────────────────────

  let videoFilters = {
    brightness: 100,
    contrast: 100,
    saturate: 100,
    hueRotate: 0,
    sepia: 0,
    blur: 0
  };

  function applyVideoFilterCss() {
    if (!mediaEl) return;
    const { brightness, contrast, saturate, hueRotate, sepia, blur } = videoFilters;
    mediaEl.style.filter = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturate}%) hue-rotate(${hueRotate}deg) sepia(${sepia}%) blur(${blur}px)`;
  }

  function setVideoFilter(key, val) {
    if (key in videoFilters) {
      videoFilters[key] = parseFloat(val);
      applyVideoFilterCss();
    }
  }

  function setVideoFilters(newFilters) {
    videoFilters = { ...videoFilters, ...newFilters };
    applyVideoFilterCss();
  }

  function resetVideoFilters() {
    videoFilters = {
      brightness: 100,
      contrast: 100,
      saturate: 100,
      hueRotate: 0,
      sepia: 0,
      blur: 0
    };
    applyVideoFilterCss();
  }

  function getVideoFilters() {
    return { ...videoFilters };
  }

  function applyVideoFxPreset(preset) {
    const presets = {
      none: { brightness: 100, contrast: 100, saturate: 100, hueRotate: 0, sepia: 0, blur: 0 },
      cyberpunk: { brightness: 110, contrast: 135, saturate: 180, hueRotate: 290, sepia: 10, blur: 0 },
      cinema: { brightness: 95, contrast: 120, saturate: 90, hueRotate: 0, sepia: 15, blur: 0 },
      vibrant: { brightness: 105, contrast: 115, saturate: 160, hueRotate: 0, sepia: 0, blur: 0 },
      night: { brightness: 80, contrast: 90, saturate: 85, hueRotate: 30, sepia: 35, blur: 0 },
      noir: { brightness: 100, contrast: 140, saturate: 0, hueRotate: 0, sepia: 0, blur: 0 },
      warm: { brightness: 105, contrast: 105, saturate: 110, hueRotate: 15, sepia: 40, blur: 0 },
      matrix: { brightness: 100, contrast: 130, saturate: 120, hueRotate: 90, sepia: 25, blur: 0 }
    };
    const chosen = presets[preset] || presets.none;
    setVideoFilters(chosen);
    return chosen;
  }

  // ─── Playback Diagnostics & Stats for Nerds ──────────────────────
  function getDiagnosticsStats() {
    if (!mediaEl) return null;
    let res = `${mediaEl.videoWidth || 0}x${mediaEl.videoHeight || 0}`;
    let viewport = videoContainer ? `${videoContainer.clientWidth}x${videoContainer.clientHeight}` : '--';
    let frames = '-- / --';
    if (typeof mediaEl.getVideoPlaybackQuality === 'function') {
      const q = mediaEl.getVideoPlaybackQuality();
      frames = `${q.totalVideoFrames} total / ${q.droppedVideoFrames} dropped`;
    }

    let bufferAhead = 0;
    if (mediaEl.buffered && mediaEl.buffered.length > 0) {
      const cur = mediaEl.currentTime;
      for (let i = 0; i < mediaEl.buffered.length; i++) {
        if (mediaEl.buffered.start(i) <= cur && cur <= mediaEl.buffered.end(i)) {
          bufferAhead = (mediaEl.buffered.end(i) - cur).toFixed(1);
          break;
        }
      }
    }

    const duration = mediaEl.duration || 0;
    const bufHealth = duration > 0 ? Math.min(100, Math.round((bufferAhead / 30) * 100)) + '%' : 'N/A';
    const bitrateEst = currentItem && currentItem.size && duration > 0 ? ((currentItem.size * 8) / (duration * 1000)).toFixed(0) + ' kbps' : 'Dynamic';

    return {
      resolution: res !== '0x0' ? res : (currentItem && currentItem.type === 'audio' ? 'Audio Stream (No Video)' : 'Loading...'),
      viewport: viewport,
      frames: frames,
      buffer: `${bufferAhead}s (${bufHealth})`,
      bitrate: bitrateEst,
      speed: `${mediaEl.playbackRate}x (Pitch ${mediaEl.preservesPitch !== false ? 'Preserved' : 'Unlocked'})`,
      audio: audioCtx ? `WebAudio ${audioCtx.sampleRate}Hz (Boost ${(amplificationLevel * 100).toFixed(0)}%)` : 'HTML5 Standard',
      engine: hlsInstance ? 'HLS.js Stream Pipeline' : 'Native HTML5 Media Core'
    };
  }

  // ─── Sleep Timer Manager ─────────────────────────────────────────
  let sleepTimerInterval = null;
  let sleepTimerRemainingSecs = 0;
  let onSleepTimerTickCb = null;

  function setSleepTimer(minutes, onTick, onComplete) {
    cancelSleepTimer();
    if (minutes <= 0) return;

    sleepTimerRemainingSecs = Math.round(minutes * 60);
    onSleepTimerTickCb = onTick;

    if (onSleepTimerTickCb) onSleepTimerTickCb(sleepTimerRemainingSecs);

    sleepTimerInterval = setInterval(() => {
      sleepTimerRemainingSecs--;
      if (onSleepTimerTickCb) onSleepTimerTickCb(sleepTimerRemainingSecs);

      if (sleepTimerRemainingSecs <= 0) {
        cancelSleepTimer();
        pause();
        if (typeof onComplete === 'function') onComplete();
      }
    }, 1000);
  }

  function cancelSleepTimer() {
    if (sleepTimerInterval) {
      clearInterval(sleepTimerInterval);
      sleepTimerInterval = null;
    }
    sleepTimerRemainingSecs = 0;
    if (onSleepTimerTickCb) onSleepTimerTickCb(0);
  }

  function getSleepTimerRemaining() {
    return sleepTimerRemainingSecs;
  }

  // ─── Local Subtitle Loader (.srt / .vtt converter) ─────────────────
  function srtToVtt(srtContent) {
    let vtt = 'WEBVTT\n\n';
    vtt += srtContent
      .replace(/\r\n|\r/g, '\n')
      .replace(/(\d\d:\d\d:\d\d),(\d\d\d)/g, '$1.$2');
    return vtt;
  }

  async function loadLocalSubtitleFile(file) {
    if (!file || !mediaEl) return false;
    try {
      const text = await file.text();
      let vttText = text;
      if (file.name.endsWith('.srt') || !text.startsWith('WEBVTT')) {
        vttText = srtToVtt(text);
      }
      const blob = new Blob([vttText], { type: 'text/vtt' });
      const blobUrl = URL.createObjectURL(blob);

      const trackObj = {
        id: 'local_' + Date.now(),
        label: file.name.replace(/\.[^/.]+$/, '') + ' (Local)',
        language: 'en',
        url: blobUrl
      };

      availableSubtitles.push(trackObj);

      const track = document.createElement('track');
      track.kind = 'subtitles';
      track.src = trackObj.url;
      track.srclang = trackObj.language;
      track.label = trackObj.label;
      track.id = 'track_' + trackObj.id;
      track.default = true;
      mediaEl.appendChild(track);

      setSubtitleTrack(trackObj.id);
      return true;
    } catch (err) {
      console.error('Failed to load local subtitle file:', err);
      return false;
    }
  }

  return {
    init,
    loadItem,
    play,
    pause,
    togglePlay,
    seek,
    setVolume,
    getVolume,
    toggleMute,
    setAmplification,
    getAmplification,
    initAudioNodes,
    setEqualizerBand,
    setEqualizerPreset,
    takeSnapshot,
    togglePiP,

    // Video FX
    setVideoFilter,
    setVideoFilters,
    resetVideoFilters,
    getVideoFilters,
    applyVideoFxPreset,

    // Diagnostics
    getDiagnosticsStats,

    // Sleep Timer
    setSleepTimer,
    cancelSleepTimer,
    getSleepTimerRemaining,

    // Subtitle Local Loader
    loadLocalSubtitleFile,

    setPlaybackRate,
    getPlaybackRate,
    getCurrentTime,
    getDuration,
    isPaused,
    hasSource,
    hasError,
    toggleFullscreen,
    // A-B repeat
    setAbPointA,
    setAbPointB,
    clearAbRepeat,
    getAbState,
    // Frame step & Ambilight
    stepFrame,
    toggleAmbilight,
    isAmbilightActive,
    // Callbacks
    onTimeUpdate: (cb) => { if (typeof cb === 'function') onTimeUpdateCbs.push(cb); },
    onEnded: (cb) => { if (typeof cb === 'function') onEndedCbs.push(cb); },
    onPlayStateChange: (cb) => { if (typeof cb === 'function') onPlayStateChangeCbs.push(cb); },
    onError: (cb) => { if (typeof cb === 'function') onErrorCbs.push(cb); },
    onABChange: (cb) => { onABChangeCb = cb; },
    // Keyboard action hooks (set by app.js)
    onKeyboardVolume: (cb) => { onKeyboardVolumeCb = cb; },
    onKeyboardNext: (cb) => { onKeyboardNextCb = cb; },
    onKeyboardPrev: (cb) => { onKeyboardPrevCb = cb; },
    onKeyboardRepeat: (cb) => { onKeyboardRepeatCb = cb; },
    onKeyboardShuffle: (cb) => { onKeyboardShuffleCb = cb; },
    // Subtitles & Tracks (Phase 3)
    setSubtitleTrack,
    getSubtitleTracks,
    getCurrentSubtitleId,
    toggleCaptions,
    clearSubtitleTracks,
    getAudioTrackInfo,
    onSubtitleChange: (cb) => { onSubtitleChangeCb = cb; },
    setRepeatMode,
    getSavedMediaPositions,
    getWatchHistory,
    clearWatchHistory,
    removeFromWatchHistory,
    recordWatchHistory,
    getCurrentItem: () => currentItem,
    setEmbedMode,
    getIsEmbedActive,
    sendEmbedCommand
  };
})();

