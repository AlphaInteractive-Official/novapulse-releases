/**
 * NovaPulse Zero-Click Browser Sniffer & IDM Companion Controller
 */

const BrowserSniffer = (function () {
  let streams = [];
  let pollInterval = null;

  function init() {
    bindControls();
    loadStreams();
  }

  function getAuthToken() {
    return localStorage.getItem('novapulse_auth_token') || 'DEFAULT0725';
  }

  function bindControls() {
    // Clear streams button
    const btnClear = document.getElementById('btnClearSnifferStreams');
    if (btnClear) {
      btnClear.addEventListener('click', async () => {
        if (!confirm('Clear all caught browser streams?')) return;
        try {
          const res = await fetch('/api/sniffer/clear', {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${getAuthToken()}` }
          });
          const data = await res.json();
          if (data && data.ok) {
            if (typeof showNovaToast === 'function') showNovaToast('Streams log cleared', 'fa-trash-can');
            loadStreams();
          }
        } catch (err) {
          alert('Clear error: ' + err.message);
        }
      });
    }

    // Refresh streams button
    const btnRefresh = document.getElementById('btnRefreshSnifferStreams');
    if (btnRefresh) {
      btnRefresh.addEventListener('click', () => {
        loadStreams();
      });
    }

    // Copy Extension Path Button
    const btnCopyPath = document.getElementById('btnCopyExtPath');
    if (btnCopyPath) {
      btnCopyPath.addEventListener('click', () => {
        const extPath = (window.location.origin || '') + '/extension';
        navigator.clipboard.writeText(extPath).then(() => {
          if (typeof showNovaToast === 'function') {
            showNovaToast('Extension folder path copied to clipboard!', 'fa-copy');
          } else {
            alert('Extension path copied: ' + extPath);
          }
        });
      });
    }

    // Deep Page Inspector
    const btnInspect = document.getElementById('btnInspectPageMedia');
    const inputUrl = document.getElementById('inputDeepInspectUrl');
    if (btnInspect && inputUrl) {
      btnInspect.addEventListener('click', async () => {
        const url = inputUrl.value.trim();
        if (!url) {
          alert('Please enter a webpage URL to inspect');
          return;
        }

        const resultsContainer = document.getElementById('deepInspectResults');
        btnInspect.disabled = true;
        btnInspect.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Sniffing Streams...';
        if (resultsContainer) {
          resultsContainer.style.display = 'block';
          resultsContainer.innerHTML = `
            <div style="text-align: center; padding: 30px; color: var(--text-muted);">
              <i class="fa-solid fa-spinner fa-spin" style="font-size: 1.8rem; color: var(--accent-cyan); margin-bottom: 12px; display: block;"></i>
              Inspecting DOM, network streams, and video manifests for <strong>${escapeHtml(url)}</strong>...
            </div>
          `;
        }

        try {
          const res = await fetch('/api/sniffer/inspect-page', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${getAuthToken()}`
            },
            body: JSON.stringify({ url })
          });
          const data = await res.json();
          renderInspectionResults(data);
        } catch (err) {
          if (resultsContainer) {
            resultsContainer.innerHTML = `<div style="color: #ef4444; padding: 16px;">Inspection error: ${escapeHtml(err.message)}</div>`;
          }
        } finally {
          btnInspect.disabled = false;
          btnInspect.innerHTML = '<i class="fa-solid fa-bolt"></i> Deep Sniff Streams';
        }
      });
    }
  }

  function renderInspectionResults(data) {
    const resultsContainer = document.getElementById('deepInspectResults');
    if (!resultsContainer) return;

    if (!data || !data.ok) {
      resultsContainer.innerHTML = `
        <div style="padding: 16px; background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.25); border-radius: 12px; color: #f87171;">
          <i class="fa-solid fa-triangle-exclamation"></i> <strong>Inspection Failed:</strong> ${escapeHtml(data?.error || 'Could not extract streams')}
        </div>
      `;
      return;
    }

    const title = data.title || 'Extracted Media Stream';
    const thumbnail = data.thumbnail || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=200&auto=format&fit=crop&q=80';
    const duration = data.duration ? `${Math.floor(data.duration / 60)}m ${data.duration % 60}s` : 'Unknown duration';
    const uploader = data.uploader ? `by ${data.uploader}` : '';
    const formats = Array.isArray(data.formats) ? data.formats : [];

    resultsContainer.innerHTML = `
      <div class="sniffer-inspect-card">
        <img src="${thumbnail}" class="sniffer-inspect-thumb" alt="Thumb" onerror="this.src='https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=200&auto=format&fit=crop&q=80'" />
        <div style="flex: 1; min-width: 0;">
          <h4 style="margin: 0 0 4px; font-size: 1.1rem; color: #fff; font-weight: 700;">${escapeHtml(title)}</h4>
          <div style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 12px;">
            <span><i class="fa-regular fa-clock"></i> ${duration}</span> &bull; 
            <span>${escapeHtml(uploader)}</span> &bull;
            <span style="color: var(--accent-cyan);">${formats.length} formats available</span>
          </div>

          <div style="display: flex; gap: 8px; flex-wrap: wrap;">
            <button class="btn-primary btn-mini btn-quick-download" data-url="${escapeHtml(data.pageUrl)}" data-format="video" data-quality="1080p">
              <i class="fa-solid fa-bolt"></i> Download 1080p (MP4)
            </button>
            <button class="btn-subtle btn-mini btn-quick-download" data-url="${escapeHtml(data.pageUrl)}" data-format="video" data-quality="best">
              <i class="fa-solid fa-crown" style="color: #f59e0b;"></i> Download Best (4K/HD)
            </button>
            <button class="btn-subtle btn-mini btn-quick-download" data-url="${escapeHtml(data.pageUrl)}" data-format="audio" data-quality="audio">
              <i class="fa-solid fa-music" style="color: #a855f7;"></i> Extract Audio (MP3)
            </button>
          </div>
        </div>
      </div>
    `;

    resultsContainer.querySelectorAll('.btn-quick-download').forEach(btn => {
      btn.addEventListener('click', async () => {
        const targetUrl = btn.getAttribute('data-url');
        const format = btn.getAttribute('data-format');
        const quality = btn.getAttribute('data-quality');
        btn.disabled = true;
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Queuing...';

        try {
          const res = await fetch('/api/sniffer/catch', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${getAuthToken()}`
            },
            body: JSON.stringify({
              url: targetUrl,
              title,
              pageUrl: targetUrl,
              mediaType: format,
              quality,
              format,
              autoDownload: true
            })
          });
          const resData = await res.json();
          if (resData && resData.ok) {
            btn.innerHTML = '<i class="fa-solid fa-check"></i> Queued in Downloads!';
            if (typeof showNovaToast === 'function') {
              showNovaToast('Media added to Download Queue!', 'fa-circle-check');
            }
            loadStreams();
          } else {
            alert('Queue failed: ' + (resData?.error || 'Unknown error'));
            btn.disabled = false;
          }
        } catch (e) {
          alert('Network error: ' + e.message);
          btn.disabled = false;
        }
      });
    });
  }

  async function loadStreams() {
    const tbody = document.getElementById('snifferStreamsTableBody');
    const countBadge = document.getElementById('snifferStreamCountBadge');
    if (!tbody) return;

    try {
      const res = await fetch('/api/sniffer/streams', {
        headers: { 'Authorization': `Bearer ${getAuthToken()}` }
      });
      const data = await res.json();
      if (data && data.ok) {
        streams = Array.isArray(data.streams) ? data.streams : [];
        if (countBadge) countBadge.textContent = streams.length;
        renderStreamsTable();
      }
    } catch (err) {
      console.warn('Could not load sniffed streams:', err);
    }
  }

  function renderStreamsTable() {
    const tbody = document.getElementById('snifferStreamsTableBody');
    if (!tbody) return;

    if (streams.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="5" style="text-align: center; padding: 40px 16px; color: var(--text-muted);">
            <i class="fa-solid fa-radar" style="font-size: 1.8rem; color: #a855f7; display: block; margin-bottom: 10px; opacity: 0.6;"></i>
            No media streams caught by the companion extension yet.<br>
            <span style="font-size: 0.8rem;">Browse any video site with the NovaPulse Companion extension, or use the Deep Sniff box above.</span>
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = streams.map(s => {
      const timeStr = s.detectedAt ? new Date(s.detectedAt).toLocaleTimeString() : 'Just now';
      const statusClass = s.downloadStatus === 'enqueued' ? 'status-pill-queued' : 'status-pill-caught';
      const statusLabel = s.downloadStatus === 'enqueued' ? 'Queued' : 'Captured';

      return `
        <tr>
          <td>
            <div style="font-weight: 700; color: #fff; font-size: 0.88rem; max-width: 280px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${escapeHtml(s.title)}">
              ${escapeHtml(s.title)}
            </div>
            <div style="font-size: 0.75rem; color: var(--accent-cyan); display: flex; align-items: center; gap: 6px;">
              <i class="fa-solid fa-globe"></i> ${escapeHtml(s.pageDomain || 'Web')}
            </div>
          </td>
          <td>
            <span class="sub-pill"><i class="fa-solid fa-film"></i> ${escapeHtml(s.resolution || 'Auto')}</span>
          </td>
          <td style="font-size: 0.8rem; color: var(--text-muted);">${timeStr}</td>
          <td>
            <span class="${statusClass}">&#9679; ${statusLabel}</span>
          </td>
          <td style="text-align: right;">
            <button class="btn-primary btn-mini btn-table-download" data-url="${escapeHtml(s.url)}" data-title="${escapeHtml(s.title)}">
              <i class="fa-solid fa-download"></i> Download
            </button>
          </td>
        </tr>
      `;
    }).join('');

    tbody.querySelectorAll('.btn-table-download').forEach(btn => {
      btn.addEventListener('click', async () => {
        const url = btn.getAttribute('data-url');
        const title = btn.getAttribute('data-title');
        btn.disabled = true;
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';

        try {
          const res = await fetch('/api/sniffer/catch', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${getAuthToken()}`
            },
            body: JSON.stringify({
              url,
              title,
              autoDownload: true,
              quality: '1080p',
              format: 'video'
            })
          });
          const data = await res.json();
          if (data && data.ok) {
            if (typeof showNovaToast === 'function') {
              showNovaToast('Added to Download Queue!', 'fa-circle-check');
            }
            loadStreams();
          } else {
            alert('Download failed: ' + (data?.error || 'Unknown error'));
            btn.disabled = false;
            btn.innerHTML = '<i class="fa-solid fa-download"></i> Download';
          }
        } catch (e) {
          alert('Network error: ' + e.message);
          btn.disabled = false;
          btn.innerHTML = '<i class="fa-solid fa-download"></i> Download';
        }
      });
    });
  }

  function onOpen() {
    loadStreams();
    if (!pollInterval) {
      pollInterval = setInterval(loadStreams, 5000);
    }
  }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  return {
    init,
    loadStreams,
    onOpen
  };
})();

window.BrowserSniffer = BrowserSniffer;

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => BrowserSniffer.init());
} else {
  BrowserSniffer.init();
}
