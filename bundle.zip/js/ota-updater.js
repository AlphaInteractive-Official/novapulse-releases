/**
 * NovaPulse Live OTA (Over-The-Air) Online Auto-Update & Mobile Sync Engine
 * Real-time Server -> Client / Android APK synchronization
 */
(function() {
  const CLIENT_VERSION = '4.1.0';
  let clientBuildHash = localStorage.getItem('np_build_hash') || null;
  let updateBannerVisible = false;

  async function checkServerUpdate() {
    try {
      const url = `/api/update/status?version=${encodeURIComponent(CLIENT_VERSION)}&hash=${encodeURIComponent(clientBuildHash || '')}`;
      const res = await fetch(url);
      if (!res.ok) return;
      const data = await res.json();
      
      if (data && data.ok && data.update) {
        if (!clientBuildHash) {
          clientBuildHash = data.update.buildHash;
          localStorage.setItem('np_build_hash', clientBuildHash);
        } else if (data.update.hasUpdate && !updateBannerVisible) {
          renderUpdateBanner(data.update);
        }
      }
    } catch (err) {
      // Quiet fail on network offline
    }
  }

  function renderUpdateBanner(updateInfo) {
    if (updateBannerVisible) return;
    updateBannerVisible = true;

    const banner = document.createElement('div');
    banner.id = 'novaOtaUpdatePill';
    banner.style.cssText = `
      position: fixed;
      top: 18px;
      left: 50%;
      transform: translateX(-50%);
      background: linear-gradient(135deg, rgba(15, 23, 42, 0.98), rgba(255, 31, 61, 0.9));
      color: #fff;
      padding: 10px 20px;
      border-radius: 999px;
      display: flex;
      align-items: center;
      gap: 14px;
      font-size: 0.86rem;
      font-weight: 600;
      box-shadow: 0 12px 36px rgba(0, 0, 0, 0.7), 0 0 20px rgba(255, 31, 61, 0.5);
      z-index: 100000;
      animation: npSlideDown 0.4s cubic-bezier(0.16, 1, 0.3, 1);
      border: 1px solid rgba(255, 255, 255, 0.25);
    `;

    banner.innerHTML = `
      <div style="display: flex; align-items: center; gap: 8px;">
        <i class="fa-solid fa-arrows-rotate fa-spin" style="color: #fff;"></i>
        <span>Server Updated! <b>v${updateInfo.latestVersion}</b> available</span>
      </div>
      <button id="btnApplyOtaUpdate" style="
        background: #fff;
        color: #ff1f3d;
        border: none;
        padding: 5px 12px;
        border-radius: 999px;
        font-weight: 700;
        font-size: 0.78rem;
        cursor: pointer;
        transition: transform 0.2s ease;
      ">Apply Now</button>
      <button id="btnCloseOtaUpdate" style="
        background: none;
        border: none;
        color: rgba(255,255,255,0.7);
        cursor: pointer;
        font-size: 0.9rem;
      ">&times;</button>
    `;

    document.body.appendChild(banner);

    document.getElementById('btnApplyOtaUpdate')?.addEventListener('click', () => {
      localStorage.setItem('np_build_hash', updateInfo.buildHash);
      window.location.reload();
    });

    document.getElementById('btnCloseOtaUpdate')?.addEventListener('click', () => {
      banner.remove();
      updateBannerVisible = false;
    });

    // Auto-update after 5s if user is not actively playing media
    setTimeout(() => {
      const activeVideo = document.getElementById('playerVideo');
      const isPlaying = activeVideo && !activeVideo.paused && !activeVideo.ended;
      if (!isPlaying) {
        localStorage.setItem('np_build_hash', updateInfo.buildHash);
        window.location.reload();
      }
    }, 6000);
  }

  // Listen to SSE updates if events stream is active
  if (typeof window.EventSource !== 'undefined') {
    try {
      const evtSource = new EventSource('/api/events');
      evtSource.addEventListener('message', (e) => {
        try {
          const msg = JSON.parse(e.data);
          if (msg.type === 'app_update' && msg.buildHash !== clientBuildHash) {
            renderUpdateBanner({
              latestVersion: msg.version || CLIENT_VERSION,
              buildHash: msg.buildHash,
              releaseNotes: msg.releaseNotes || []
            });
          }
        } catch (err) {}
      });
    } catch (e) {}
  }

  // Device Connect & APK Sync Modal
  window.openDeviceSyncModal = async function() {
    let modal = document.getElementById('deviceSyncModal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'deviceSyncModal';
      modal.style.cssText = `
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.75);
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 99999;
      `;
      modal.innerHTML = `
        <div style="
          background: #0d1017;
          border: 1px solid rgba(255, 255, 255, 0.12);
          border-radius: 18px;
          padding: 28px;
          max-width: 480px;
          width: 90%;
          box-shadow: 0 24px 60px rgba(0,0,0,0.8);
          color: #f1f5f9;
        ">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 18px;">
            <h3 style="margin:0; font-size: 1.25rem; display:flex; align-items:center; gap: 10px;">
              <i class="fa-solid fa-mobile-screen" style="color: #ff1f3d;"></i>
              Phone & APK Connect
            </h3>
            <button onclick="document.getElementById('deviceSyncModal').style.display='none'" style="background:none; border:none; color:#8b92a0; font-size:1.4rem; cursor:pointer;">&times;</button>
          </div>
          <p style="font-size:0.86rem; color:#8b92a0; margin: 0 0 16px;">
            Connect your Android phone, tablet, or APK over local Wi-Fi. All changes on your computer automatically sync to your phone in real time!
          </p>
          <div style="background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.08); border-radius: 12px; padding: 14px; margin-bottom: 18px;">
            <div style="font-size:0.75rem; text-transform:uppercase; color:#ff4d6d; font-weight:700; margin-bottom:6px;">Your Phone Access URL:</div>
            <div style="display:flex; gap: 8px; align-items:center;">
              <input type="text" id="syncLanUrlInput" readonly style="
                flex:1;
                background:#06080c;
                border:1px solid rgba(255,255,255,0.1);
                color:#fff;
                padding:8px 12px;
                border-radius:8px;
                font-family:monospace;
                font-size:0.88rem;
              " value="Loading...">
              <button id="btnCopyLanUrl" class="btn-primary btn-mini" style="padding:8px 14px; white-space:nowrap;">
                <i class="fa-solid fa-copy"></i> Copy
              </button>
            </div>
          </div>
          <div style="display:flex; gap: 10px; align-items:center; font-size: 0.8rem; color:#10b981; margin-bottom: 18px;">
            <span style="display:inline-block; width:8px; height:8px; background:#10b981; border-radius:50%;"></span>
            <span>Online Auto-Sync: Active (Automatic OTA updates enabled)</span>
          </div>
          <div style="text-align:right;">
            <button onclick="document.getElementById('deviceSyncModal').style.display='none'" class="btn-subtle" style="padding:8px 18px; border-radius:8px;">Done</button>
          </div>
        </div>
      `;
      document.body.appendChild(modal);

      modal.addEventListener('click', (e) => {
        if (e.target === modal) modal.style.display = 'none';
      });

      document.getElementById('btnCopyLanUrl')?.addEventListener('click', () => {
        const input = document.getElementById('syncLanUrlInput');
        if (input) {
          navigator.clipboard.writeText(input.value);
          const btn = document.getElementById('btnCopyLanUrl');
          btn.innerHTML = '<i class="fa-solid fa-check"></i> Copied!';
          setTimeout(() => { btn.innerHTML = '<i class="fa-solid fa-copy"></i> Copy'; }, 2000);
        }
      });
    }

    try {
      const res = await fetch('/api/update/connect-info');
      const data = await res.json();
      if (data && data.ok && data.connection) {
        const inp = document.getElementById('syncLanUrlInput');
        if (inp) inp.value = data.connection.fullUrl;
      }
    } catch (e) {}

    modal.style.display = 'flex';
  };

  // Start periodic check every 35s
  checkServerUpdate();
  setInterval(checkServerUpdate, 35000);
})();
