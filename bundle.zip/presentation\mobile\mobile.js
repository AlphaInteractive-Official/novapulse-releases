(function () {
  'use strict';
  var isInitialized = false;
  function initMobilePresentation() {
    if (isInitialized) return;
    isInitialized = true;
    var menuToggle = document.getElementById('mobileMenuToggle');
    var sidebar = document.querySelector('.nova-sidebar');
    var backdrop = document.getElementById('mobileSidebarBackdrop');
    if (!backdrop) {
      backdrop = document.createElement('div');
      backdrop.id = 'mobileSidebarBackdrop';
      document.body.appendChild(backdrop);
    }
        function openDrawer() {
      if (sidebar) sidebar.classList.add('mobile-sidebar-open');
      document.body.classList.add('mobile-sidebar-open');
      if (backdrop) backdrop.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
    function closeDrawer() {
      if (sidebar) sidebar.classList.remove('mobile-sidebar-open');
      document.body.classList.remove('mobile-sidebar-open');
      if (backdrop) backdrop.classList.remove('active');
      document.body.style.overflow = '';
    }
    if (menuToggle) {
      menuToggle.addEventListener('click', function (e) {
        e.stopPropagation();
        if (sidebar && sidebar.classList.contains('mobile-sidebar-open')) {
          closeDrawer();
        } else {
          openDrawer();
        }
      });
    }
    if (backdrop) {
      backdrop.addEventListener('click', function () {
        closeDrawer();
      });
    }
    if (sidebar) {
      sidebar.querySelectorAll('.nova-nav-btn, .nav-item').forEach(function (btn) {
        btn.addEventListener('click', function () {
          closeDrawer();
        });
      });
    }
    var touchStartX = 0;
    var touchStartY = 0;
    if (sidebar) {
      sidebar.addEventListener('touchstart', function (e) {
        touchStartX = e.touches[0].clientX;
        touchStartY = e.touches[0].clientY;
      }, { passive: true });
      sidebar.addEventListener('touchend', function (e) {
        var touchEndX = e.changedTouches[0].clientX;
        var touchEndY = e.changedTouches[0].clientY;
        var diffX = touchEndX - touchStartX;
        var diffY = Math.abs(touchEndY - touchStartY);
        if (diffX < -60 && diffY < 100) {
          closeDrawer();
        }
      }, { passive: true });
    }
    console.log('[NovaPulse] Mobile presentation layer active.');
  }
  if (document.documentElement.getAttribute('data-device') === 'mobile') {
    initMobilePresentation();
  }
  window.addEventListener('nova:device-changed', function (e) {
    if (e.detail && e.detail.device === 'mobile') {
      initMobilePresentation();
    }
  });
  window.NovaPulseMobile = {
    init: initMobilePresentation
  };
})();