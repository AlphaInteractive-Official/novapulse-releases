const AiNotebook = (function () {
  let currentTranscript = null;
  let originalTranscript = null;
  let translatedTranscript = null;
  let isViewingTranslated = false;
  let isTranslating = false;
  let activeCueIndex = -1;
  let autoScrollEnabled = true;
  let chatHistory = [];
  let currentVideoItem = null;
  let isAiResponding = false;
  let currentStudyDeck = null;
  let activeStudySubTab = 'takeaways';
  let currentFlashcardIndex = 0;
  let flashcardsMastered = new Set();
  let quizAnswers = {};
  function init() {
    bindTabs();
    bindTranscriptControls();
    bindAiChatControls();
    bindStudyDeckControls();
    if (typeof Playlist !== 'undefined' && typeof Playlist.onItemChange === 'function') {
      Playlist.onItemChange((item) => {
        onTrackChanged(item);
      });
    }
    if (typeof Player !== 'undefined' && typeof Player.onTimeUpdate === 'function') {
      Player.onTimeUpdate((currentTime, duration) => {
        syncTranscriptWithTime(currentTime);
      });
    }
    window.addEventListener('novapulse-player-item', (e) => {
      if (e && e.detail) onTrackChanged(e.detail);
    });
    if (typeof Player !== 'undefined' && typeof Player.getCurrentItem === 'function') {
      const it = Player.getCurrentItem();
      if (it) onTrackChanged(it);
    }
  }
  function getAuthToken() {
    return localStorage.getItem('novapulse_auth_token') || 'DEFAULT0725';
  }
  function bindTabs() {
    const tabPlaylistBtn = document.getElementById('tabPlaylistBtn');
    const tabTranscriptBtn = document.getElementById('tabTranscriptBtn');
    const tabAiNotebookBtn = document.getElementById('tabAiNotebookBtn');
    const tabStudyDeckBtn = document.getElementById('tabStudyDeckBtn');
    const panelPlaylist = document.getElementById('panelPlaylist');
    const panelTranscript = document.getElementById('panelTranscript');
    const panelAiNotebook = document.getElementById('panelAiNotebook');
    const panelStudyDeck = document.getElementById('panelStudyDeck');
    const btnPlayerLaunchStudyDeck = document.getElementById('btnPlayerLaunchStudyDeck');
    function switchSideTab(tabName) {
      if (tabPlaylistBtn) tabPlaylistBtn.classList.toggle('active', tabName === 'playlist');
      if (tabTranscriptBtn) tabTranscriptBtn.classList.toggle('active', tabName === 'transcript');
      if (tabAiNotebookBtn) tabAiNotebookBtn.classList.toggle('active', tabName === 'notebook');
      if (tabStudyDeckBtn) tabStudyDeckBtn.classList.toggle('active', tabName === 'study-deck');
      if (panelPlaylist) panelPlaylist.style.display = tabName === 'playlist' ? 'flex' : 'none';
      if (panelTranscript) panelTranscript.style.display = tabName === 'transcript' ? 'flex' : 'none';
      if (panelAiNotebook) panelAiNotebook.style.display = tabName === 'notebook' ? 'flex' : 'none';
      if (panelStudyDeck) panelStudyDeck.style.display = tabName === 'study-deck' ? 'flex' : 'none';
      if (tabName === 'transcript' && !currentTranscript && currentVideoItem) {
        fetchTranscriptForMedia(currentVideoItem.id);
      }
      if (tabName === 'study-deck' && currentVideoItem) {
        fetchStudyDeck(currentVideoItem.id);
      }
    }
    if (tabPlaylistBtn) tabPlaylistBtn.addEventListener('click', () => switchSideTab('playlist'));
    if (tabTranscriptBtn) tabTranscriptBtn.addEventListener('click', () => switchSideTab('transcript'));
    if (tabAiNotebookBtn) tabAiNotebookBtn.addEventListener('click', () => switchSideTab('notebook'));
    if (tabStudyDeckBtn) tabStudyDeckBtn.addEventListener('click', () => switchSideTab('study-deck'));
    if (btnPlayerLaunchStudyDeck) {
      btnPlayerLaunchStudyDeck.addEventListener('click', () => switchSideTab('study-deck'));
    }
  }
  function onTrackChanged(item) {
    if (!item || !item.id) return;
    if (currentVideoItem && currentVideoItem.id === item.id && currentTranscript) {
      return; // Already loaded for this track
    }
    currentVideoItem = item;
    currentTranscript = null;
    currentStudyDeck = null;
    activeCueIndex = -1;
    currentFlashcardIndex = 0;
    flashcardsMastered.clear();
    quizAnswers = {};
    renderEmptyTranscript('Loading transcript for ' + (item.name || 'video') + '...');
    fetchTranscriptForMedia(item.id);
  }
  function renderEmptyTranscript(message = 'No Transcript Loaded') {
    const container = document.getElementById('transcriptContainer');
    if (!container) return;
    container.innerHTML = `
      <div class="empty-playlist" id="emptyTranscript">
        <i class="fa-solid fa-align-left" style="font-size: 1.8rem; color: var(--accent-cyan); margin-bottom: 8px;"></i>
        <p style="margin: 0 0 4px; font-weight: 700; color: #fff;">${escapeHtml(message)}</p>
        <small style="color: var(--text-muted); display: block; margin-bottom: 12px;">Auto-extracts subtitles or generates audio transcript with AI.</small>
        <button class="btn-primary btn-mini" id="btnManualFetchTranscript">
          <i class="fa-solid fa-wand-magic-sparkles"></i> Load / Generate Transcript
        </button>
      </div>
    `;
    const btn = document.getElementById('btnManualFetchTranscript');
    if (btn) {
      btn.addEventListener('click', () => {
        if (currentVideoItem) fetchTranscriptForMedia(currentVideoItem.id, true);
        else if (typeof showNovaToast === 'function') showNovaToast('Please play a video first', 'fa-info');
      });
    }
  }
  async function fetchTranscriptForMedia(mediaId, showFeedback = false) {
    const container = document.getElementById('transcriptContainer');
    if (container) {
      container.innerHTML = `
        <div style="padding: 32px 16px; text-align: center; color: var(--text-muted);">
          <i class="fa-solid fa-spinner fa-spin" style="font-size: 1.8rem; color: var(--accent-cyan); margin-bottom: 12px;"></i>
          <div style="font-weight: 700; color: #fff; margin-bottom: 4px;">Loading Video Transcript</div>
          <small>Checking subtitle tracks & analyzing audio cues...</small>
        </div>
      `;
    }
    try {
      const res = await fetch(`/api/media-item/${encodeURIComponent(mediaId)}/transcript`, {
        headers: {
          'Authorization': `Bearer ${getAuthToken()}`
        }
      });
      const data = await res.json();
      if (data && data.ok && Array.isArray(data.cues) && data.cues.length > 0) {
        currentTranscript = data;
        originalTranscript = data;
        translatedTranscript = null;
        isViewingTranslated = false;
        renderTranscriptCues(data.cues);
        updateTranslateButtonState();
        if (showFeedback && typeof showNovaToast === 'function') {
          showNovaToast(`Loaded ${data.cues.length} transcript cues!`, 'fa-circle-check');
        }
      } else {
        originalTranscript = null;
        translatedTranscript = null;
        updateTranslateButtonState();
        renderEmptyTranscript(data.message || 'No transcript available for this file.');
      }
    } catch (err) {
      console.warn('Transcript fetch error:', err);
      renderEmptyTranscript('Could not load transcript: ' + err.message);
    }
  }
  function renderTranscriptCues(cues) {
    const container = document.getElementById('transcriptContainer');
    if (!container) return;
    if (!cues || cues.length === 0) {
      renderEmptyTranscript('No subtitle or spoken cues found.');
      return;
    }
    container.innerHTML = cues.map((cue, idx) => `
      <div class="transcript-cue" data-index="${idx}" data-start="${cue.start}" data-end="${cue.end}">
        <span class="cue-timestamp" title="Click to seek">${cue.timeStr}</span>
        <span class="cue-text">${escapeHtml(cue.text)}</span>
      </div>
    `).join('');
    container.querySelectorAll('.transcript-cue').forEach(el => {
      el.addEventListener('click', () => {
        const startSec = parseFloat(el.getAttribute('data-start'));
        if (!isNaN(startSec) && typeof Player !== 'undefined') {
          Player.seek(startSec);
          if (Player.isPaused && Player.isPaused()) {
            Player.play();
          }
        }
      });
    });
  }
  function syncTranscriptWithTime(currentTime) {
    if (!currentTranscript || !currentTranscript.cues) return;
    const container = document.getElementById('transcriptContainer');
    if (!container) return;
    const cues = currentTranscript.cues;
    let foundIdx = -1;
    for (let i = 0; i < cues.length; i++) {
      if (currentTime >= cues[i].start && currentTime <= (cues[i].end + 0.3)) {
        foundIdx = i;
        break;
      }
    }
    if (foundIdx !== -1 && foundIdx !== activeCueIndex) {
      activeCueIndex = foundIdx;
      container.querySelectorAll('.transcript-cue').forEach((el, idx) => {
        if (idx === foundIdx) {
          el.classList.add('active');
          if (autoScrollEnabled) {
            el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
          }
        } else {
          el.classList.remove('active');
        }
      });
    }
  }
  function updateTranslateButtonState() {
    const btn = document.getElementById('btnTranslateTranscript');
    if (!btn) return;
    if (!currentTranscript || !currentTranscript.cues || currentTranscript.cues.length === 0) {
      btn.style.display = 'none';
      return;
    }
    btn.style.display = 'inline-flex';
    if (isTranslating) {
      btn.disabled = true;
      btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> <span>Translating...</span>';
    } else if (isViewingTranslated) {
      btn.disabled = false;
      btn.classList.add('active');
      btn.innerHTML = '<i class="fa-solid fa-rotate-left"></i> <span id="translateBtnText">Show Original</span>';
    } else {
      btn.disabled = false;
      btn.classList.remove('active');
      btn.innerHTML = '<i class="fa-solid fa-language"></i> <span id="translateBtnText">Translate to EN</span>';
    }
  }
  async function toggleTranslateTranscript() {
    if (!currentVideoItem || isTranslating) return;
    if (isViewingTranslated) {
      if (originalTranscript) {
        currentTranscript = originalTranscript;
        isViewingTranslated = false;
        renderTranscriptCues(originalTranscript.cues);
        updateTranslateButtonState();
        if (typeof showNovaToast === 'function') {
          showNovaToast('Switched to original transcript', 'fa-rotate-left');
        }
      }
      return;
    }
    if (translatedTranscript && translatedTranscript.cues) {
      currentTranscript = translatedTranscript;
      isViewingTranslated = true;
      renderTranscriptCues(translatedTranscript.cues);
      updateTranslateButtonState();
      if (typeof showNovaToast === 'function') {
        showNovaToast('Showing translated English transcript', 'fa-language');
      }
      return;
    }
    isTranslating = true;
    updateTranslateButtonState();
    try {
      const res = await fetch(`/api/media-item/${encodeURIComponent(currentVideoItem.id)}/translate-transcript`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${getAuthToken()}`
        }
      });
      const data = await res.json();
      if (data && data.ok && Array.isArray(data.cues) && data.cues.length > 0) {
        translatedTranscript = data;
        currentTranscript = data;
        isViewingTranslated = true;
        renderTranscriptCues(data.cues);
        if (typeof showNovaToast === 'function') {
          showNovaToast(`Translated ${data.cues.length} cues to English! (Free Engine)`, 'fa-circle-check');
        }
      } else {
        alert('Could not translate transcript: ' + (data.error || 'Unknown error'));
      }
    } catch (err) {
      alert('Translation network error: ' + err.message);
    } finally {
      isTranslating = false;
      updateTranslateButtonState();
    }
  }
  function bindTranscriptControls() {
    const searchInput = document.getElementById('transcriptSearchInput');
    const autoScrollBtn = document.getElementById('btnAutoScrollTranscript');
    const copyBtn = document.getElementById('btnCopyTranscript');
    const fetchBtn = document.getElementById('btnFetchTranscript');
    const translateBtn = document.getElementById('btnTranslateTranscript');
    if (translateBtn) {
      translateBtn.addEventListener('click', () => {
        toggleTranslateTranscript();
      });
    }
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        const query = e.target.value.trim().toLowerCase();
        const container = document.getElementById('transcriptContainer');
        if (!container) return;
        container.querySelectorAll('.transcript-cue').forEach(el => {
          const text = el.querySelector('.cue-text')?.textContent.toLowerCase() || '';
          const time = el.querySelector('.cue-timestamp')?.textContent.toLowerCase() || '';
          if (!query || text.includes(query) || time.includes(query)) {
            el.style.display = 'flex';
          } else {
            el.style.display = 'none';
          }
        });
      });
    }
    if (autoScrollBtn) {
      autoScrollBtn.addEventListener('click', () => {
        autoScrollEnabled = !autoScrollEnabled;
        autoScrollBtn.style.color = autoScrollEnabled ? 'var(--accent-cyan)' : 'var(--text-muted)';
        if (typeof showNovaToast === 'function') {
          showNovaToast(autoScrollEnabled ? 'Auto-scroll Follow: On' : 'Auto-scroll Follow: Off', 'fa-arrows-to-dot');
        }
      });
    }
    if (copyBtn) {
      copyBtn.addEventListener('click', () => {
        if (!currentTranscript || !currentTranscript.fullText) {
          if (typeof showNovaToast === 'function') showNovaToast('No transcript to copy', 'fa-info');
          return;
        }
        navigator.clipboard.writeText(currentTranscript.fullText).then(() => {
          if (typeof showNovaToast === 'function') showNovaToast('Copied full transcript to clipboard!', 'fa-copy');
        }).catch(err => {
          alert('Could not copy to clipboard: ' + err.message);
        });
      });
    }
    if (fetchBtn) {
      fetchBtn.addEventListener('click', () => {
        if (currentVideoItem) fetchTranscriptForMedia(currentVideoItem.id, true);
        else if (typeof showNovaToast === 'function') showNovaToast('Please play a video first', 'fa-info');
      });
    }
  }
  function bindAiChatControls() {
    const notebookInput = document.getElementById('notebookInput');
    const sendBtn = document.getElementById('btnSendNotebook');
    const clearBtn = document.getElementById('btnClearAiChat');
    if (sendBtn && notebookInput) {
      sendBtn.addEventListener('click', () => {
        const text = notebookInput.value.trim();
        if (text) {
          askQuestion(text);
          notebookInput.value = '';
        }
      });
      notebookInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          const text = notebookInput.value.trim();
          if (text) {
            askQuestion(text);
            notebookInput.value = '';
          }
        }
      });
    }
    if (clearBtn) {
      clearBtn.addEventListener('click', () => {
        chatHistory = [];
        const msgContainer = document.getElementById('notebookMessages');
        if (msgContainer) {
          msgContainer.innerHTML = `
            <div class="notebook-input-wrap">
              <input type="text" id="notebookInput" placeholder="Ask anything about this video..." autocomplete="off" />
              <button id="btnSendNotebook" title="Send question">
                <i class="fa-solid fa-paper-plane"></i>
              </button>
            </div>
            <div class="notebook-msg assistant">
              <div class="notebook-msg-header">
                <span class="ai-avatar"><i class="fa-solid fa-brain"></i></span>
                <strong>NovaPulse DELTA V1</strong>
                <span class="delta-model-badge">Alpha Delta V1</span>
              </div>
              <div class="notebook-msg-body">
                Chat reset! Ask me anything about this video. Every fact I give you will have clickable [timestamp] citations so you can jump right to that moment in the video.
              </div>
            </div>
          `;
          bindAiChatControls();
        }
        if (typeof showNovaToast === 'function') showNovaToast('AI Chat history cleared', 'fa-rotate-right');
      });
    }
    document.querySelectorAll('.notebook-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        const type = chip.getAttribute('data-prompt');
        let promptText = '';
        if (type === 'summary') {
          promptText = 'Please provide an executive summary and key takeaway notes for this video with [timestamp] citations.';
        } else if (type === 'key-takeaways') {
          promptText = 'What are the top 5 most important takeaways and concepts from this video? Cite exact timestamps.';
        } else if (type === 'chapters') {
          promptText = 'Please provide a structured chapter timeline and outline of this video with exact [timestamps] and descriptions.';
        } else if (type === 'quiz') {
          promptText = 'Give me 3 review questions based on this video to test my understanding, and hint which [timestamps] have the answers.';
        }
        if (promptText) askQuestion(promptText);
      });
    });
  }
  function appendChatMessage(role, content) {
    const msgContainer = document.getElementById('notebookMessages');
    if (!msgContainer) return null;
    const div = document.createElement('div');
    div.className = `notebook-msg ${role}`;
    const isAssistant = role === 'assistant';
    const headerHtml = isAssistant
      ? `<div class="notebook-msg-header">
           <span class="ai-avatar"><i class="fa-solid fa-brain"></i></span>
           <strong>NovaPulse DELTA V1</strong>
           <span class="delta-model-badge">Alpha Delta V1</span>
         </div>`
      : `<div class="notebook-msg-header" style="color: var(--accent-cyan); justify-content: flex-end;">
           <strong>You</strong>
         </div>`;
    div.innerHTML = `
      ${headerHtml}
      <div class="notebook-msg-body">${formatMarkdownWithCitations(content)}</div>
    `;
    msgContainer.appendChild(div);
    msgContainer.scrollTop = msgContainer.scrollHeight;
    div.querySelectorAll('.citation-link').forEach(btn => {
      btn.addEventListener('click', () => {
        const timeStr = btn.getAttribute('data-time');
        const seconds = parseTimeToSeconds(timeStr);
        if (!isNaN(seconds) && typeof Player !== 'undefined') {
          Player.seek(seconds);
          if (Player.isPaused && Player.isPaused()) {
            Player.play();
          }
          if (typeof showNovaToast === 'function') {
            showNovaToast(`Seeked to ${timeStr}`, 'fa-clock');
          }
        }
      });
    });
    return div;
  }
  function appendThinkingMessage() {
    const msgContainer = document.getElementById('notebookMessages');
    if (!msgContainer) return null;
    const div = document.createElement('div');
    div.className = 'notebook-msg assistant thinking-msg';
    div.innerHTML = `
      <div class="notebook-msg-header">
        <span class="ai-avatar"><i class="fa-solid fa-brain"></i></span>
        <strong>NovaPulse DELTA V1</strong>
        <span class="delta-model-badge">Alpha Delta V1</span>
      </div>
      <div class="notebook-msg-body" style="display: flex; align-items: center; gap: 8px; color: var(--accent-purple);">
        <i class="fa-solid fa-circle-notch fa-spin"></i> Analyzing video transcript & generating grounded answer...
      </div>
    `;
    msgContainer.appendChild(div);
    msgContainer.scrollTop = msgContainer.scrollHeight;
    return div;
  }
  async function askQuestion(question, customTime = null) {
    if (isAiResponding) return;
    isAiResponding = true;
    appendChatMessage('user', question);
    chatHistory.push({ role: 'user', content: question });
    const thinkingEl = appendThinkingMessage();
    try {
      const mediaId = currentVideoItem ? currentVideoItem.id : null;
      const videoTitle = currentVideoItem ? currentVideoItem.name : 'Current Video';
      const transcriptText = currentTranscript ? currentTranscript.fullText : '';
      const currentPlaybackTime = (customTime !== null && !isNaN(customTime)) 
        ? customTime 
        : ((typeof Player !== 'undefined' && Player.getCurrentTime) ? Player.getCurrentTime() : 0);
      const res = await fetch('/api/ai/ask', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${getAuthToken()}`
        },
        body: JSON.stringify({
          mediaId,
          question,
          transcriptText,
          videoTitle,
          chatHistory,
          currentPlaybackTime
        })
      });
      const data = await res.json();
      if (thinkingEl) thinkingEl.remove();
      if (data && data.ok) {
        appendChatMessage('assistant', data.answer);
        chatHistory.push({ role: 'assistant', content: data.answer });
      } else {
        appendChatMessage('assistant', '⚠️ ' + (data.error || 'Failed to generate AI response. Please check connection.'));
      }
    } catch (err) {
      if (thinkingEl) thinkingEl.remove();
      appendChatMessage('assistant', '⚠️ Network error communicating with NovaPulse AI: ' + err.message);
    } finally {
      isAiResponding = false;
    }
  }
  function formatMathFormula(mathStr) {
    let s = mathStr.trim();
    s = s.replace(/\\times/g, '×').replace(/\\div/g, '÷').replace(/\\pm/g, '±')
         .replace(/\\le(q)?/g, '≤').replace(/\\ge(q)?/g, '≥').replace(/\\ne(q)?/g, '≠')
         .replace(/\\approx/g, '≈').replace(/\\cdot/g, '·')
         .replace(/\\alpha/g, 'α').replace(/\\beta/g, 'β').replace(/\\theta/g, 'θ')
         .replace(/\\pi/g, 'π').replace(/\\delta/g, 'δ').replace(/\\lambda/g, 'λ')
         .replace(/\\sigma/g, 'σ').replace(/\\mu/g, 'μ')
         .replace(/\\frac\{([^}]+)\}\{([^}]+)\}/g, '<sup>$1</sup>&frasl;<sub>$2</sub>')
         .replace(/\\sqrt\{([^}]+)\}/g, '√<span style="text-decoration:overline">$1</span>')
         .replace(/([a-zA-Z0-9])_\{([^}]+)\}/g, '$1<sub>$2</sub>')
         .replace(/([a-zA-Z0-9])_([a-zA-Z0-9]+)/g, '$1<sub>$2</sub>')
         .replace(/([a-zA-Z0-9\)])\^\{([^}]+)\}/g, '$1<sup>$2</sup>')
         .replace(/([a-zA-Z0-9\)])\^([a-zA-Z0-9]+)/g, '$1<sup>$2</sup>');
    return `<span class="math-expr">${s}</span>`;
  }
  function parseMarkdownTables(text) {
    const lines = text.split('\n');
    const result = [];
    let inTable = false;
    let tableRows = [];
    function flushTable() {
      if (tableRows.length === 0) return;
      let html = '<div class="notebook-table-wrap"><table class="notebook-table">';
      if (tableRows.length >= 2 && /^\|?(\s*:?-+:?\s*\|)+\s*:?-+:?\s*\|?$/.test(tableRows[1].trim())) {
        const headerCells = tableRows[0].split('|').map(c => c.trim()).filter((c, i, a) => !(i === 0 && c === '') && !(i === a.length - 1 && c === ''));
        html += '<thead><tr>' + headerCells.map(c => `<th>${c}</th>`).join('') + '</tr></thead><tbody>';
        for (let r = 2; r < tableRows.length; r++) {
          const cells = tableRows[r].split('|').map(c => c.trim()).filter((c, i, a) => !(i === 0 && c === '') && !(i === a.length - 1 && c === ''));
          html += '<tr>' + cells.map(c => `<td>${c}</td>`).join('') + '</tr>';
        }
        html += '</tbody>';
      } else {
        html += '<tbody>';
        for (let r = 0; r < tableRows.length; r++) {
          const cells = tableRows[r].split('|').map(c => c.trim()).filter((c, i, a) => !(i === 0 && c === '') && !(i === a.length - 1 && c === ''));
          html += '<tr>' + cells.map(c => `<td>${c}</td>`).join('') + '</tr>';
        }
        html += '</tbody>';
      }
      html += '</table></div>';
      result.push(html);
      tableRows = [];
      inTable = false;
    }
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (line.startsWith('|') || (line.includes('|') && line.split('|').length >= 3)) {
        inTable = true;
        tableRows.push(line);
      } else {
        if (inTable) flushTable();
        result.push(lines[i]);
      }
    }
    if (inTable) flushTable();
    return result.join('\n');
  }
  function formatCitationsInText(text) {
    return text.replace(/(?:`\s*)?(?:▶\s*|\[)?(\d{1,2}:\d{2}(?::\d{2})?)(?:\])?(?:\s*(?:`\s*)?[-–—]\s*(?:`\s*)?(?:▶\s*|\[)?(\d{1,2}:\d{2}(?::\d{2})?)(?:\])?)?(?:\s*`)?/g, (m, t1, t2) => {
      if (!t1) return m;
      if (t2) {
        return `<button class="citation-link citation-pill" data-time="${t1}" title="Seek to ${t1}"><i class="fa-solid fa-play"></i> ${t1} – ${t2}</button>`;
      }
      return `<button class="citation-link citation-pill" data-time="${t1}" title="Seek to ${t1}"><i class="fa-solid fa-play"></i> ${t1}</button>`;
    });
  }
  function formatMarkdownWithCitations(rawText) {
    if (!rawText) return '';
    let formatted = parseMarkdownTables(rawText);
    const tableTokens = [];
    formatted = formatted.replace(/<div class="notebook-table-wrap">[\s\S]*?<\/div>/g, (m) => {
      tableTokens.push(m);
      return `___TABLE_TOKEN_${tableTokens.length - 1}___`;
    });
    formatted = escapeHtml(formatted);
    formatted = formatted.replace(/\\\[([\s\S]*?)\\\]/g, (m, inner) => formatMathFormula(inner));
    formatted = formatted.replace(/\\\(([\s\S]*?)\\\)/g, (m, inner) => formatMathFormula(inner));
    formatted = formatCitationsInText(formatted);
    formatted = formatted.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    formatted = formatted.replace(/\*(.*?)\*/g, '<em>$1</em>');
    formatted = formatted.replace(/^### (.*$)/gim, '<h4 style="margin:8px 0 4px; color:var(--accent-cyan);">$1</h4>');
    formatted = formatted.replace(/^## (.*$)/gim, '<h3 style="margin:10px 0 6px; color:#fff;">$1</h3>');
    formatted = formatted.replace(/^# (.*$)/gim, '<h2 style="margin:12px 0 8px; color:#fff;">$1</h2>');
    formatted = formatted.replace(/^\s*[-*]\s+(.*$)/gim, '<li style="margin-bottom:3px;">$1</li>');
    formatted = formatted.replace(/\n\n/g, '<p></p>');
    formatted = formatted.replace(/\n/g, '<br>');
    tableTokens.forEach((tbl, idx) => {
      let tContent = tbl;
      tContent = tContent.replace(/\\\[([\s\S]*?)\\\]/g, (m, inner) => formatMathFormula(inner));
      tContent = tContent.replace(/\\\(([\s\S]*?)\\\)/g, (m, inner) => formatMathFormula(inner));
      tContent = formatCitationsInText(tContent);
      formatted = formatted.replace(`___TABLE_TOKEN_${idx}___`, tContent);
    });
    return formatted;
  }
  function parseTimeToSeconds(str) {
    if (!str) return 0;
    const parts = str.trim().split(':').map(Number);
    if (parts.length === 2) {
      return (parts[0] * 60) + parts[1];
    } else if (parts.length === 3) {
      return (parts[0] * 3600) + (parts[1] * 60) + parts[2];
    }
    return parseFloat(str) || 0;
  }
  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }
  async function fetchStudyDeck(mediaId, forceRefresh = false) {
    if (!mediaId) return;
    const container = document.getElementById('studyDeckContainer');
    if (!container) return;
    if (!forceRefresh && currentStudyDeck && currentStudyDeck.mediaId === mediaId) {
      renderStudyDeck(currentStudyDeck);
      return;
    }
    container.innerHTML = `
      <div style="padding: 40px 16px; text-align: center; color: var(--text-muted);">
        <i class="fa-solid fa-spinner fa-spin" style="font-size: 2rem; color: var(--accent-cyan); margin-bottom: 14px;"></i>
        <div style="font-weight: 700; color: #fff; font-size: 1rem; margin-bottom: 6px;">Generating Video Study Deck</div>
        <small style="display: block; max-width: 280px; margin: 0 auto; line-height: 1.5;">
          Synthesizing core takeaways, active recall flashcards, glossary, and exam quiz...
        </small>
      </div>
    `;
    try {
      let res;
      if (forceRefresh) {
        res = await fetch('/api/ai/study-deck/generate', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${getAuthToken()}`
          },
          body: JSON.stringify({
            mediaId,
            videoTitle: currentVideoItem ? currentVideoItem.name : 'Video',
            forceRefresh: true
          })
        });
      } else {
        res = await fetch(`/api/ai/study-deck/${encodeURIComponent(mediaId)}`, {
          headers: { 'Authorization': `Bearer ${getAuthToken()}` }
        });
      }
      const data = await res.json();
      if (data && data.ok && data.deck) {
        currentStudyDeck = data.deck;
        const fcBadge = document.getElementById('fcCountBadge');
        if (fcBadge && Array.isArray(data.deck.flashcards)) {
          fcBadge.textContent = data.deck.flashcards.length;
        }
        const qzBadge = document.getElementById('quizCountBadge');
        if (qzBadge && Array.isArray(data.deck.quiz)) {
          qzBadge.textContent = data.deck.quiz.length;
        }
        renderStudyDeck(currentStudyDeck);
        if (typeof showNovaToast === 'function') {
          showNovaToast('Study Deck generated with citations!', 'fa-graduation-cap');
        }
      } else {
        container.innerHTML = `
          <div style="padding: 30px 16px; text-align: center;">
            <i class="fa-solid fa-circle-exclamation" style="font-size: 1.8rem; color: #ef4444; margin-bottom: 8px;"></i>
            <p style="color: #fff; font-weight: 700; margin-bottom: 8px;">Could not generate study deck</p>
            <small style="color: var(--text-muted); display: block; margin-bottom: 12px;">${escapeHtml(data ? data.error : 'Unknown error')}</small>
            <button class="btn-primary btn-mini" id="btnRetryStudyDeck"><i class="fa-solid fa-rotate-right"></i> Try Again</button>
          </div>
        `;
        document.getElementById('btnRetryStudyDeck')?.addEventListener('click', () => fetchStudyDeck(mediaId, true));
      }
    } catch (err) {
      container.innerHTML = `
        <div style="padding: 30px 16px; text-align: center;">
          <i class="fa-solid fa-triangle-exclamation" style="font-size: 1.8rem; color: #f59e0b; margin-bottom: 8px;"></i>
          <p style="color: #fff; font-weight: 700; margin-bottom: 8px;">Network Error</p>
          <small style="color: var(--text-muted); display: block; margin-bottom: 12px;">${escapeHtml(err.message)}</small>
          <button class="btn-primary btn-mini" id="btnRetryStudyDeck"><i class="fa-solid fa-rotate-right"></i> Retry</button>
        </div>
      `;
      document.getElementById('btnRetryStudyDeck')?.addEventListener('click', () => fetchStudyDeck(mediaId, true));
    }
  }
  function renderStudyDeck(deck) {
    const container = document.getElementById('studyDeckContainer');
    if (!container || !deck) return;
    let html = `
      <div class="study-meta-banner">
        <div>
          <span style="font-size: 0.72rem; text-transform: uppercase; letter-spacing: 1px; color: var(--accent-cyan); font-weight: 800; display: block; margin-bottom: 2px;">
            📚 ${escapeHtml(deck.subject || 'General Study Deck')}
          </span>
          <strong style="color: #fff; font-size: 0.95rem;">${escapeHtml(deck.title || deck.videoTitle || 'Video Study Notes')}</strong>
        </div>
        <div style="display: flex; gap: 6px; align-items: center;">
          <span style="background: rgba(0,242,254,0.1); color: var(--accent-cyan); font-size: 0.72rem; font-weight: 700; padding: 2px 8px; border-radius: 6px;">
            ${escapeHtml(deck.difficulty || 'Intermediate')}
          </span>
          <span style="background: rgba(255,255,255,0.06); color: var(--text-muted); font-size: 0.72rem; font-weight: 600; padding: 2px 8px; border-radius: 6px;">
            ⏱️ ${deck.readTimeMinutes || 5}m
          </span>
        </div>
      </div>
    `;
    if (activeStudySubTab === 'takeaways') {
      html += `
        <div style="font-weight: 700; color: #fff; font-size: 0.85rem; margin-bottom: 6px; display: flex; align-items: center; gap: 6px;">
          <i class="fa-solid fa-align-left" style="color: var(--accent-cyan);"></i> Executive Summary
        </div>
        <div class="study-deck-summary-box">
          ${escapeHtml(deck.executiveSummary || 'No summary available.')}
        </div>
        <div style="font-weight: 700; color: #fff; font-size: 0.85rem; margin-bottom: 8px; display: flex; align-items: center; gap: 6px;">
          <i class="fa-solid fa-lightbulb" style="color: #f59e0b;"></i> Core Takeaways & Principles (${(deck.coreTakeaways || []).length})
        </div>
      `;
      (deck.coreTakeaways || []).forEach((t, idx) => {
        html += `
          <div class="takeaway-item">
            <div class="takeaway-title-row">
              <span><strong>${idx + 1}.</strong> ${escapeHtml(t.title)}</span>
              ${t.timestamp ? `<button class="citation-link citation-pill" data-time="${escapeHtml(t.timestamp)}"><i class="fa-solid fa-play"></i> ${escapeHtml(t.timestamp)}</button>` : ''}
            </div>
            <div style="color: var(--text-muted); font-size: 0.82rem; line-height: 1.5;">${escapeHtml(t.explanation)}</div>
          </div>
        `;
      });
    } else if (activeStudySubTab === 'flashcards') {
      const cards = deck.flashcards || [];
      if (cards.length === 0) {
        html += `<div style="text-align: center; color: var(--text-muted); padding: 30px;">No flashcards available.</div>`;
      } else {
        const curIndex = Math.min(currentFlashcardIndex, cards.length - 1);
        const card = cards[curIndex];
        const isMastered = flashcardsMastered.has(curIndex);
        html += `
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
            <span style="font-size: 0.78rem; font-weight: 700; color: var(--text-muted);">
              Card ${curIndex + 1} of ${cards.length}
            </span>
            <span style="font-size: 0.75rem; color: #34d399; font-weight: 600;">
              <i class="fa-solid fa-circle-check"></i> ${flashcardsMastered.size} Mastered
            </span>
          </div>
          <!-- 3D Flashcard Stage -->
          <div class="flashcard-stage" id="activeFlashcardStage">
            <div class="flashcard-card" id="activeFlashcardCard">
              <!-- Front Face -->
              <div class="flashcard-face flashcard-front">
                <div class="fc-category-badge">
                  <i class="fa-solid fa-brain"></i> ${escapeHtml(card.category || 'Recall Concept')}
                </div>
                <div style="font-size: 1.05rem; font-weight: 700; color: #fff; text-align: center; padding: 16px 8px; line-height: 1.5;">
                  ${escapeHtml(card.question)}
                </div>
                <div class="fc-flip-hint">
                  <i class="fa-solid fa-rotate"></i> Click anywhere to reveal answer
                </div>
              </div>
              <!-- Back Face -->
              <div class="flashcard-face flashcard-back">
                <div class="fc-category-badge" style="color: var(--accent-purple);">
                  <i class="fa-solid fa-circle-info"></i> Explanation & Key Rule
                </div>
                <div style="font-size: 0.92rem; color: #e2e8f0; padding: 12px 8px; line-height: 1.6; text-align: left;">
                  ${escapeHtml(card.answer)}
                </div>
                <div style="display: flex; justify-content: space-between; align-items: center;">
                  ${card.timestamp ? `<button class="citation-link citation-pill" data-time="${escapeHtml(card.timestamp)}"><i class="fa-solid fa-play"></i> Jump to ${escapeHtml(card.timestamp)}</button>` : '<span></span>'}
                  <div class="fc-flip-hint">
                    <i class="fa-solid fa-rotate"></i> Click to flip back
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- Nav & Mastery Controls -->
          <div class="fc-nav-controls">
            <button class="btn-subtle btn-mini" id="btnPrevFc" ${curIndex === 0 ? 'disabled' : ''}>
              <i class="fa-solid fa-chevron-left"></i> Prev
            </button>
            <button class="btn-subtle btn-mini" id="btnToggleMastered" style="color: ${isMastered ? '#34d399' : 'var(--text-muted)'}; border-color: ${isMastered ? '#10b981' : 'var(--border-color)'};">
              <i class="fa-solid fa-circle-check"></i> ${isMastered ? 'Mastered ✓' : 'Mark Mastered'}
            </button>
            <button class="btn-subtle btn-mini" id="btnNextFc" ${curIndex === cards.length - 1 ? 'disabled' : ''}>
              Next <i class="fa-solid fa-chevron-right"></i>
            </button>
          </div>
        `;
      }
    } else if (activeStudySubTab === 'glossary') {
      const terms = deck.glossary || [];
      html += `
        <div style="font-weight: 700; color: #fff; font-size: 0.85rem; margin-bottom: 10px; display: flex; align-items: center; justify-content: space-between;">
          <span><i class="fa-solid fa-book-bookmark" style="color: var(--accent-cyan);"></i> Key Terminology & Formulas (${terms.length})</span>
        </div>
      `;
      if (terms.length === 0) {
        html += `<div style="text-align: center; color: var(--text-muted); padding: 30px;">No glossary terms available.</div>`;
      } else {
        terms.forEach(g => {
          html += `
            <div class="takeaway-item" style="border-left: 3px solid var(--accent-cyan);">
              <div class="takeaway-title-row">
                <span style="color: var(--accent-cyan); font-weight: 700;">${escapeHtml(g.term)}</span>
                ${g.timestamp ? `<button class="citation-link citation-pill" data-time="${escapeHtml(g.timestamp)}"><i class="fa-solid fa-play"></i> ${escapeHtml(g.timestamp)}</button>` : ''}
              </div>
              <div style="color: var(--text-color); font-size: 0.82rem; line-height: 1.5;">${escapeHtml(g.definition)}</div>
            </div>
          `;
        });
      }
    } else if (activeStudySubTab === 'quiz') {
      const quizList = deck.quiz || [];
      html += `
        <div style="font-weight: 700; color: #fff; font-size: 0.85rem; margin-bottom: 12px; display: flex; align-items: center; justify-content: space-between;">
          <span><i class="fa-solid fa-circle-question" style="color: #10b981;"></i> Self-Assessment Knowledge Check</span>
          <span style="font-size: 0.75rem; color: var(--text-muted);">Instant Feedback</span>
        </div>
      `;
      if (quizList.length === 0) {
        html += `<div style="text-align: center; color: var(--text-muted); padding: 30px;">No quiz questions available.</div>`;
      } else {
        quizList.forEach((q, qIdx) => {
          const selectedChoice = quizAnswers[qIdx];
          const hasAnswered = selectedChoice !== undefined;
          html += `
            <div class="quiz-question-box">
              <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px;">
                <div style="font-weight: 700; font-size: 0.88rem; color: #fff; line-height: 1.4;">
                  ${qIdx + 1}. ${escapeHtml(q.question)}
                </div>
                ${q.timestamp ? `<button class="citation-link citation-pill" data-time="${escapeHtml(q.timestamp)}" style="margin-left: 8px;"><i class="fa-solid fa-play"></i> ${escapeHtml(q.timestamp)}</button>` : ''}
              </div>
              <div>
                ${(q.options || []).map((opt, oIdx) => {
                  let cls = 'quiz-option-choice';
                  if (hasAnswered) {
                    if (oIdx === q.correctIndex) cls += ' correct';
                    else if (oIdx === selectedChoice) cls += ' wrong';
                  }
                  return `
                    <button class="${cls}" data-q="${qIdx}" data-opt="${oIdx}" ${hasAnswered ? 'disabled' : ''}>
                      <span style="font-weight: 700; opacity: 0.8;">${String.fromCharCode(65 + oIdx)}.</span>
                      <span>${escapeHtml(opt)}</span>
                      ${hasAnswered && oIdx === q.correctIndex ? '<i class="fa-solid fa-check" style="margin-left: auto;"></i>' : ''}
                      ${hasAnswered && oIdx === selectedChoice && oIdx !== q.correctIndex ? '<i class="fa-solid fa-xmark" style="margin-left: auto;"></i>' : ''}
                    </button>
                  `;
                }).join('')}
              </div>
              ${hasAnswered ? `
                <div class="quiz-feedback-box">
                  <strong>${selectedChoice === q.correctIndex ? '🎉 Correct!' : '⚠️ Not quite.'}</strong>
                  <div style="margin-top: 4px; color: var(--text-muted);">${escapeHtml(q.explanation || '')}</div>
                </div>
              ` : ''}
            </div>
          `;
        });
      }
    }
    container.innerHTML = html;
    container.querySelectorAll('.citation-link').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const timeStr = btn.getAttribute('data-time');
        const seconds = parseTimeToSeconds(timeStr);
        if (typeof Player !== 'undefined' && typeof Player.seekTo === 'function') {
          Player.seekTo(seconds);
        }
      });
    });
    if (activeStudySubTab === 'flashcards') {
      const cardEl = document.getElementById('activeFlashcardCard');
      if (cardEl) {
        cardEl.addEventListener('click', () => {
          cardEl.classList.toggle('flipped');
        });
      }
      document.getElementById('btnPrevFc')?.addEventListener('click', (e) => {
        e.stopPropagation();
        if (currentFlashcardIndex > 0) {
          currentFlashcardIndex--;
          renderStudyDeck(currentStudyDeck);
        }
      });
      document.getElementById('btnNextFc')?.addEventListener('click', (e) => {
        e.stopPropagation();
        if (currentFlashcardIndex < (deck.flashcards || []).length - 1) {
          currentFlashcardIndex++;
          renderStudyDeck(currentStudyDeck);
        }
      });
      document.getElementById('btnToggleMastered')?.addEventListener('click', (e) => {
        e.stopPropagation();
        if (flashcardsMastered.has(currentFlashcardIndex)) {
          flashcardsMastered.delete(currentFlashcardIndex);
        } else {
          flashcardsMastered.add(currentFlashcardIndex);
        }
        renderStudyDeck(currentStudyDeck);
      });
    }
    if (activeStudySubTab === 'quiz') {
      container.querySelectorAll('.quiz-option-choice').forEach(btn => {
        btn.addEventListener('click', () => {
          const qIdx = parseInt(btn.getAttribute('data-q'), 10);
          const optIdx = parseInt(btn.getAttribute('data-opt'), 10);
          quizAnswers[qIdx] = optIdx;
          renderStudyDeck(currentStudyDeck);
        });
      });
    }
  }
  function bindStudyDeckControls() {
    document.querySelectorAll('.study-pill-btn').forEach(pill => {
      pill.addEventListener('click', () => {
        const tab = pill.getAttribute('data-tab');
        if (tab) {
          activeStudySubTab = tab;
          document.querySelectorAll('.study-pill-btn').forEach(p => p.classList.toggle('active', p === pill));
          if (currentStudyDeck) renderStudyDeck(currentStudyDeck);
        }
      });
    });
    document.getElementById('btnRefreshStudyDeck')?.addEventListener('click', () => {
      if (currentVideoItem) fetchStudyDeck(currentVideoItem.id, true);
      else if (typeof showNovaToast === 'function') showNovaToast('Please play a video first', 'fa-info');
    });
    document.getElementById('btnExportStudyDeckMd')?.addEventListener('click', () => {
      if (!currentVideoItem) {
        if (typeof showNovaToast === 'function') showNovaToast('Please play a video first', 'fa-info');
        return;
      }
      window.open(`/api/ai/study-deck/${encodeURIComponent(currentVideoItem.id)}/export?format=markdown`, '_blank');
      if (typeof showNovaToast === 'function') showNovaToast('Downloading Markdown Study Deck...', 'fa-file-arrow-down');
    });
    document.getElementById('btnExportStudyDeckPdf')?.addEventListener('click', () => {
      if (!currentVideoItem) {
        if (typeof showNovaToast === 'function') showNovaToast('Please play a video first', 'fa-info');
        return;
      }
      window.open(`/api/ai/study-deck/${encodeURIComponent(currentVideoItem.id)}/export?format=html`, '_blank');
    });
    document.getElementById('btnCopyStudyDeck')?.addEventListener('click', async () => {
      if (!currentStudyDeck) {
        if (typeof showNovaToast === 'function') showNovaToast('No Study Deck loaded to copy', 'fa-info');
        return;
      }
      try {
        const res = await fetch(`/api/ai/study-deck/${encodeURIComponent(currentStudyDeck.mediaId)}/export?format=markdown`);
        const md = await res.text();
        await navigator.clipboard.writeText(md);
        if (typeof showNovaToast === 'function') showNovaToast('Copied full study deck markdown to clipboard!', 'fa-copy');
      } catch (err) {
        alert('Could not copy to clipboard: ' + err.message);
      }
    });
  }
  return {
    init,
    fetchTranscriptForMedia,
    fetchStudyDeck,
    askQuestion,
    getTranscript: () => currentTranscript,
    getStudyDeck: () => currentStudyDeck
  };
})();
window.AiNotebook = AiNotebook;
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => AiNotebook.init());
} else {
  AiNotebook.init();
}