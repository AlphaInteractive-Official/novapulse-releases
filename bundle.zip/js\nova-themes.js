(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.NovaTheme = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  const COLOR_THEMES = [
    {
      no: 1,
      id: 'silver-black',
      name: 'Silver / Black',
      primary: '#E5E7EB',
      secondary: '#9CA3AF',
      dark: true,
      contrastText: '#06070A',
      description: 'Ultra-sleek titanium monochrome with polished silver accents.'
    },
    {
      no: 2,
      id: 'red-black',
      name: 'Red / Black',
      primary: '#FF3B30',
      secondary: '#B91C1C',
      dark: true,
      contrastText: '#FFFFFF',
      description: 'Fierce crimson dynamic sports styling with dark garnet undertones.'
    },
    {
      no: 3,
      id: 'electric-blue',
      name: 'Electric Blue',
      primary: '#00A8FF',
      secondary: '#2563EB',
      dark: true,
      contrastText: '#FFFFFF',
      description: 'High-voltage azure neon inspired by precision studio telemetry.'
    },
    {
      no: 4,
      id: 'emerald-green',
      name: 'Emerald Green',
      primary: '#00DFA2',
      secondary: '#22C55E',
      dark: true,
      contrastText: '#06070A',
      description: 'Luminous organic emerald green with crisp matrix highlights.'
    },
    {
      no: 5,
      id: 'purple-pink',
      name: 'Purple / Pink',
      primary: '#A855F7',
      secondary: '#EC4899',
      dark: true,
      contrastText: '#FFFFFF',
      description: 'Cyberpunk synthwave aesthetic blending radiant violet with hot pink.'
    },
    {
      no: 6,
      id: 'gold-black',
      name: 'Gold / Black',
      primary: '#FACC15',
      secondary: '#F59E0B',
      dark: true,
      contrastText: '#06070A',
      description: 'Regal 24-karat luxury gold with deep obsidian contrast.'
    },
    {
      no: 7,
      id: 'cyan-teal',
      name: 'Cyan / Teal',
      primary: '#00E5E5',
      secondary: '#00A6A6',
      dark: true,
      contrastText: '#06070A',
      description: 'Deep oceanic aquamarine and vibrant neon turquoise.'
    },
    {
      no: 8,
      id: 'white-silver',
      name: 'White / Silver',
      primary: '#F8FAFC',
      secondary: '#94A3B8',
      dark: true,
      contrastText: '#06070A',
      description: 'Clean architectural platinum frost with frosted slate accents.'
    },
    {
      no: 9,
      id: 'hot-pink',
      name: 'Hot Pink',
      primary: '#FF2D78',
      secondary: '#E11D48',
      dark: true,
      contrastText: '#FFFFFF',
      description: 'High-impact magenta laser styling with energetic rose gradients.'
    },
    {
      no: 10,
      id: 'orange-amber',
      name: 'Orange / Amber',
      primary: '#FF9A1F',
      secondary: '#F97316',
      dark: true,
      contrastText: '#06070A',
      description: 'Warm solar flare ignition with vibrant sunset amber accents.'
    },
    {
      no: 11,
      id: 'cyan-purple',
      name: 'Cyan / Purple',
      primary: '#00E5D4',
      secondary: '#A855F7',
      dark: true,
      contrastText: '#06070A',
      isDefault: true,
      description: 'The signature Nova Pulse brand identity: vibrant cyan-to-purple fusion.'
    },
    {
      no: 12,
      id: 'lime-green',
      name: 'Lime / Green',
      primary: '#A3E635',
      secondary: '#22C55E',
      dark: true,
      contrastText: '#06070A',
      description: 'Electric racing lime with hyper-vivid performance green accents.'
    },
    {
      no: 13,
      id: 'lavender-violet',
      name: 'Lavender / Violet',
      primary: '#D8B4FE',
      secondary: '#8B5CF6',
      dark: true,
      contrastText: '#06070A',
      description: 'Soft cosmic lavender paired with rich deep royal violet tones.'
    },
    {
      no: 14,
      id: 'cyan-blue',
      name: 'Cyan / Blue',
      primary: '#22D3EE',
      secondary: '#2563EB',
      dark: true,
      contrastText: '#06070A',
      description: 'Cool arctic cyan smoothly cascading into crystalline cobalt blue.'
    },
    {
      no: 15,
      id: 'champagne-gold',
      name: 'Champagne Gold',
      primary: '#D6B875',
      secondary: '#A98543',
      dark: true,
      contrastText: '#06070A',
      description: 'Sophisticated deep vintage champagne gold with dark metallic bronze accents.'
    }
  ];
  function hexToRgb(hex) {
    let c = hex.replace('#', '').trim();
    if (c.length === 3) c = c.split('').map(x => x + x).join('');
    const num = parseInt(c, 16);
    return {
      r: (num >> 16) & 255,
      g: (num >> 8) & 255,
      b: num & 255
    };
  }
  function getThemeByNo(themeNo) {
    const num = parseInt(themeNo, 10);
    return COLOR_THEMES.find(t => t.no === num) || COLOR_THEMES[10]; // Theme 11 is index 10
  }
  function getThemeById(themeId) {
    return COLOR_THEMES.find(t => t.id === themeId) || COLOR_THEMES[10];
  }
  const STORAGE_KEY = 'novapulse_color_theme';
  let activeThemeNumber = 11;
  let previewThemeNumber = null;
  function generateThemeTokens(theme) {
    const pRgb = hexToRgb(theme.primary);
    const sRgb = hexToRgb(theme.secondary);
    return {
      '--theme-primary': theme.primary,
      '--theme-secondary': theme.secondary,
      '--theme-primary-rgb': `${pRgb.r}, ${pRgb.g}, ${pRgb.b}`,
      '--theme-secondary-rgb': `${sRgb.r}, ${sRgb.g}, ${sRgb.b}`,
      '--theme-contrast-text': theme.contrastText || '#FFFFFF',
      '--theme-accent-gradient': `linear-gradient(135deg, ${theme.primary} 0%, ${theme.secondary} 100%)`,
      '--theme-accent-gradient-90': `linear-gradient(90deg, ${theme.primary} 0%, ${theme.secondary} 100%)`,
      '--theme-accent-soft': `rgba(${pRgb.r}, ${pRgb.g}, ${pRgb.b}, 0.14)`,
      '--theme-accent-hover': `rgba(${pRgb.r}, ${pRgb.g}, ${pRgb.b}, 0.22)`,
      '--theme-accent-active': `rgba(${pRgb.r}, ${pRgb.g}, ${pRgb.b}, 0.32)`,
      '--theme-focus-ring': `0 0 0 3px rgba(${pRgb.r}, ${pRgb.g}, ${pRgb.b}, 0.45)`,
      '--theme-selection': `rgba(${pRgb.r}, ${pRgb.g}, ${pRgb.b}, 0.35)`,
      '--theme-progress': theme.primary,
      '--theme-border-accent': `rgba(${pRgb.r}, ${pRgb.g}, ${pRgb.b}, 0.45)`,
      '--theme-glow': `0 0 16px rgba(${pRgb.r}, ${pRgb.g}, ${pRgb.b}, 0.4)`,
      '--theme-glow-strong': `0 0 24px rgba(${pRgb.r}, ${pRgb.g}, ${pRgb.b}, 0.65)`,
      '--primary': theme.primary,
      '--primary-2': theme.secondary,
      '--primary-glow': `rgba(${pRgb.r}, ${pRgb.g}, ${pRgb.b}, 0.5)`,
      '--accent-cyan': theme.primary,
      '--accent-purple': theme.secondary,
      '--border-glow': `rgba(${pRgb.r}, ${pRgb.g}, ${pRgb.b}, 0.55)`,
      '--grad-brand': `linear-gradient(135deg, ${theme.primary} 0%, ${theme.secondary} 100%)`,
      '--grad-tor': `linear-gradient(90deg, ${theme.secondary} 0%, ${theme.primary} 100%)`,
      '--shadow-tor': `0 0 16px rgba(${sRgb.r}, ${sRgb.g}, ${sRgb.b}, 0.85), 0 0 28px rgba(${pRgb.r}, ${pRgb.g}, ${pRgb.b}, 0.75)`,
      '--shadow-glow': `0 0 0 1px rgba(${pRgb.r}, ${pRgb.g}, ${pRgb.b}, 0.2), 0 16px 50px -16px rgba(${pRgb.r}, ${pRgb.g}, ${pRgb.b}, 0.45)`
    };
  }
  function applyTheme(themeNo, options = {}) {
    const theme = getThemeByNo(themeNo);
    if (!theme) return;
    const isPreview = !!options.preview;
    const tokens = generateThemeTokens(theme);
    const rootEl = document.documentElement;
    for (const [key, val] of Object.entries(tokens)) {
      rootEl.style.setProperty(key, val);
    }
    rootEl.setAttribute('data-theme-no', String(theme.no));
    rootEl.setAttribute('data-theme-id', theme.id);
    if (!isPreview) {
      activeThemeNumber = theme.no;
      previewThemeNumber = null;
      try {
        localStorage.setItem(STORAGE_KEY, String(theme.no));
      } catch (e) {
        console.warn('LocalStorage theme persistence unavailable:', e);
      }
      if (typeof fetch === 'function' && !options.skipServerSync) {
        fetch('/api/settings', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ colorTheme: theme.no })
        }).catch(err => console.debug('Server theme sync skipped:', err));
      }
      window.dispatchEvent(new CustomEvent('novathemechange', { detail: { theme } }));
    } else {
      previewThemeNumber = theme.no;
    }
    updateGalleryUI();
  }
  function previewTheme(themeNo) {
    applyTheme(themeNo, { preview: true });
  }
  function cancelPreview() {
    if (previewThemeNumber !== null) {
      applyTheme(activeThemeNumber);
    }
  }
  function resetToDefault() {
    applyTheme(11);
    if (typeof showNovaToast === 'function') {
      showNovaToast('Reset to default brand theme (Cyan / Purple)', 'fa-palette');
    }
  }
  function getActiveTheme() {
    return getThemeByNo(activeThemeNumber);
  }
  function initTheme() {
    let saved = null;
    try {
      saved = localStorage.getItem(STORAGE_KEY);
    } catch (e) {}
    const themeNo = saved ? parseInt(saved, 10) : 2;
    applyTheme(themeNo, { skipServerSync: true });
    if (typeof fetch === 'function') {
      fetch('/api/settings')
        .then(res => res.json())
        .then(data => {
          if (data && data.settings && data.settings.colorTheme) {
            const serverThemeNo = parseInt(data.settings.colorTheme, 10);
            if (serverThemeNo >= 1 && serverThemeNo <= 15 && serverThemeNo !== activeThemeNumber) {
              applyTheme(serverThemeNo, { skipServerSync: true });
            }
          }
        })
        .catch(() => {});
    }
  }
  function renderThemeGallery(containerId = 'novaThemeGalleryGrid') {
    const container = document.getElementById(containerId);
    if (!container) return;
    container.innerHTML = COLOR_THEMES.map(theme => {
      const isSelected = theme.no === activeThemeNumber;
      return `
        <div class="theme-card ${isSelected ? 'active' : ''}" data-theme-no="${theme.no}" onclick="NovaTheme.selectTheme(${theme.no})">
          <div class="theme-card-header">
            <span class="theme-number-badge">#${theme.no}</span>
            <div class="theme-card-title">${theme.name}</div>
            ${theme.isDefault ? '<span class="theme-default-pill">Default</span>' : ''}
            <div class="theme-check-indicator"><i class="fa-solid fa-check"></i></div>
          </div>
          <div class="theme-swatch-bar">
            <div class="theme-swatch primary" style="background: ${theme.primary};" title="Primary: ${theme.primary}"></div>
            <div class="theme-swatch secondary" style="background: ${theme.secondary};" title="Secondary: ${theme.secondary}"></div>
            <div class="theme-swatch gradient" style="background: linear-gradient(135deg, ${theme.primary} 0%, ${theme.secondary} 100%);" title="Gradient"></div>
          </div>
          <div class="theme-mini-preview">
            <div class="mini-app-mockup">
              <div class="mini-sidebar" style="border-right-color: rgba(${hexToRgb(theme.primary).r}, ${hexToRgb(theme.primary).g}, ${hexToRgb(theme.primary).b}, 0.25);">
                <div class="mini-dot active" style="background: ${theme.primary}; box-shadow: 0 0 6px ${theme.primary};"></div>
                <div class="mini-dot"></div>
                <div class="mini-dot"></div>
              </div>
              <div class="mini-content">
                <div class="mini-banner" style="background: linear-gradient(90deg, rgba(${hexToRgb(theme.primary).r}, ${hexToRgb(theme.primary).g}, ${hexToRgb(theme.primary).b}, 0.2), rgba(${hexToRgb(theme.secondary).r}, ${hexToRgb(theme.secondary).g}, ${hexToRgb(theme.secondary).b}, 0.15)); border-color: rgba(${hexToRgb(theme.primary).r}, ${hexToRgb(theme.primary).g}, ${hexToRgb(theme.primary).b}, 0.4);">
                  <div class="mini-btn" style="background: linear-gradient(135deg, ${theme.primary} 0%, ${theme.secondary} 100%); color: ${theme.contrastText};">Download</div>
                </div>
                <div class="mini-progress-track">
                  <div class="mini-progress-fill" style="width: 65%; background: linear-gradient(90deg, ${theme.primary}, ${theme.secondary});"></div>
                </div>
              </div>
            </div>
          </div>
          <div class="theme-card-actions">
            <button type="button" class="btn-theme-preview" onclick="event.stopPropagation(); NovaTheme.previewTheme(${theme.no})">
              <i class="fa-solid fa-eye"></i> Live Preview
            </button>
            <button type="button" class="btn-theme-apply" onclick="event.stopPropagation(); NovaTheme.selectTheme(${theme.no})">
              ${isSelected ? '<i class="fa-solid fa-check"></i> Active' : 'Apply'}
            </button>
          </div>
        </div>
      `;
    }).join('');
  }
  function updateGalleryUI() {
    const cards = document.querySelectorAll('.theme-card');
    cards.forEach(card => {
      const cardNo = parseInt(card.getAttribute('data-theme-no'), 10);
      const isSelected = cardNo === activeThemeNumber;
      if (isSelected) {
        card.classList.add('active');
        const applyBtn = card.querySelector('.btn-theme-apply');
        if (applyBtn) applyBtn.innerHTML = '<i class="fa-solid fa-check"></i> Active';
      } else {
        card.classList.remove('active');
        const applyBtn = card.querySelector('.btn-theme-apply');
        if (applyBtn) applyBtn.textContent = 'Apply';
      }
    });
    const activeThemeEl = document.getElementById('activeThemeSummaryName');
    if (activeThemeEl) {
      const curr = getActiveTheme();
      activeThemeEl.textContent = `${curr.name} (#${curr.no})`;
    }
  }
  function selectTheme(themeNo) {
    applyTheme(themeNo);
    const theme = getThemeByNo(themeNo);
    if (typeof showNovaToast === 'function') {
      showNovaToast(`Color Theme switched to ${theme.name}`, 'fa-palette');
    }
  }
  return {
    themes: COLOR_THEMES,
    getActiveTheme,
    getThemeByNo,
    getThemeById,
    applyTheme,
    selectTheme,
    previewTheme,
    cancelPreview,
    resetToDefault,
    initTheme,
    renderThemeGallery,
    updateGalleryUI
  };
});