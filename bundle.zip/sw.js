/**
 * NovaPulse Media Engine — Progressive Offline Service Worker
 * Alpha Interactive (c) 2026. All rights reserved.
 */
const CACHE_NAME = 'novapulse-app-v4.1.0';

const PRECACHE_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/css/nova.css',
  '/js/library.js?v=3.8',
  '/js/player.js?v=3.8',
  '/js/playlist.js?v=3.8',
  '/js/secure-vault.js?v=3.8',
  '/js/core-suite.js?v=3.8',
  '/js/studio-tools.js?v=3.8',
  '/js/notifications.js?v=3.8',
  '/js/app.js?v=3.8',
  '/js/nova-core.js?v=3.8',
  '/js/supported-sites.js?v=3.8',
  '/js/ai-notebook.js?v=3.8',
  '/js/power-trio.js?v=1.0',
  '/js/viral-shorts.js?v=1.0',
  '/js/channel-sync.js?v=1.0',
  '/js/browser-sniffer.js?v=1.0',
  '/js/ota-updater.js?v=4.1',
  '/js/nova-legal.js?v=1.0',
  '/js/nova-mediasession.js?v=1.0',
  '/assets/icons/favicon.ico',
  '/assets/icons/favicon-32x32.png',
  '/assets/icons/apple-touch-icon.png',
  '/assets/icons/android-chrome-192x192.png',
  '/assets/icons/android-chrome-512x512.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(PRECACHE_ASSETS).catch((err) => {
        console.warn('Some assets could not be pre-cached:', err);
      });
    }).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((name) => {
          if (name !== CACHE_NAME) {
            return caches.delete(name);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // For API calls or streaming endpoints, use network-only / network-first
  if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/videos/')) {
    event.respondWith(
      fetch(event.request).catch(async () => {
        const cached = await caches.match(event.request);
        if (cached) return cached;
        return new Response(JSON.stringify({ ok: false, offline: true, error: 'Network request failed (offline)' }), {
          status: 503,
          headers: { 'Content-Type': 'application/json' }
        });
      })
    );
    return;
  }

  // Cache-first strategy for static UI assets
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      if (cachedResponse) {
        // Fetch in background to update cache
        fetch(event.request).then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, networkResponse));
          }
        }).catch(() => {});
        return cachedResponse;
      }
      return fetch(event.request);
    }).catch(async () => {
      // Offline fallback
      if (event.request.mode === 'navigate') {
        const fallbackNav = await caches.match('/index.html');
        if (fallbackNav) return fallbackNav;
      }
      const cached = await caches.match(event.request);
      if (cached) return cached;
      return new Response('', { status: 408, statusText: 'Request Timeout' });
    })
  );
});
