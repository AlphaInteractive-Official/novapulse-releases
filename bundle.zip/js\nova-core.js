(function () {
  let currentView = 'home';
  window.showToast = function (msg, type = 'info') {
    let icon = 'fa-info-circle';
    if (type === 'success' || type === 'check') icon = 'fa-circle-check';
    else if (type === 'error' || type === 'warn') icon = 'fa-triangle-exclamation';
    else if (type === 'copy') icon = 'fa-copy';
    if (typeof window.showNovaToast === 'function') {
      window.showNovaToast(msg, icon);
    } else if (typeof showNovaToast === 'function') {
      showNovaToast(msg, icon);
    } else {
      console.log('[Toast]', msg);
    }
  };
  function recordActivePlaylistPlayback(playlist, trackIndex, trackItem) {
    if (!playlist) return;
    try {
      const state = {
        id: playlist.id,
        name: playlist.name,
        color: playlist.color || '#00F5FF',
        icon: playlist.icon || 'fa-music',
        trackIndex: Math.max(0, trackIndex || 0),
        trackName: trackItem ? trackItem.name : (playlist.items && playlist.items[trackIndex] ? playlist.items[trackIndex].name : ''),
        trackId: trackItem ? trackItem.id : (playlist.items && playlist.items[trackIndex] ? playlist.items[trackIndex].id : ''),
        timestamp: Date.now()
      };
      localStorage.setItem('novapulse_active_playlist', JSON.stringify(state));
      if (typeof renderResumePlaylistHero === 'function') {
        renderResumePlaylistHero();
      }
    } catch(e) {}
  }
  window.recordActivePlaylistPlayback = recordActivePlaylistPlayback;
  document.addEventListener('click', (e) => {
    const closeBtn = e.target.closest('.modal-close, .modal-cancel-btn, [data-close-modal]');
    if (closeBtn) {
      const backdrop = closeBtn.closest('.modal-backdrop');
      if (backdrop) {
        backdrop.style.display = 'none';
      }
    }
  });
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('.action-icon-btn');
    if (!btn) return;
    const title = (btn.getAttribute('title') || '').toLowerCase();
    if (title.includes('play')) {
      e.stopPropagation();
      switchView('player');
      if (typeof Player !== 'undefined' && Player.togglePlay) {
        Player.togglePlay();
      }
    } else if (title.includes('pause')) {
      e.stopPropagation();
      if (typeof Player !== 'undefined' && Player.pause) {
        Player.pause();
      }
    } else if (title.includes('folder')) {
      e.stopPropagation();
      fetch('/api/open-folder', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
      }).then(() => {
        window.showToast('Opened downloads directory in Windows Explorer', 'check');
      }).catch(() => {
        window.showToast('Could not open downloads directory', 'warn');
      });
    } else if (title.includes('more')) {
      e.stopPropagation();
      switchView('library');
    }
  });
  document.addEventListener('DOMContentLoaded', () => {
    if (window.NovaTheme && window.NovaTheme.initTheme) {
      window.NovaTheme.initTheme();
    }
    setupNovaNavigation();
    setupMiniPlayerSync();
    setupPlaylistsView();
    document.getElementById('btnCopyStoragePath')?.addEventListener('click', () => {
      const pathEl = document.getElementById('storagePathCode');
      const text = pathEl ? pathEl.textContent.trim() : '';
      if (text && navigator.clipboard) {
        navigator.clipboard.writeText(text).then(() => {
          if (typeof showNovaToast === 'function') {
            showNovaToast('Copied storage folder path!', 'fa-copy');
          }
        });
      }
    });
    document.querySelectorAll('#playlistIconCatTabs .icon-cat-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        document.querySelectorAll('#playlistIconCatTabs .icon-cat-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const cat = btn.getAttribute('data-cat');
        document.querySelectorAll('#playlistIconGrid .icon-choice').forEach(iconBtn => {
          if (cat === 'all' || iconBtn.getAttribute('data-cat') === cat) {
            iconBtn.style.display = 'flex';
          } else {
            iconBtn.style.display = 'none';
          }
        });
      });
    });
    let pendingDeleteMedia = null;
    let pendingDeleteCallback = null;
    window.openConfirmDeleteModal = function(item, onDeleted) {
      pendingDeleteMedia = item;
      pendingDeleteCallback = onDeleted;
      const modal = document.getElementById('novaConfirmDeleteModal');
      const titleEl = document.getElementById('deleteModalMediaTitle');
      const metaEl = document.getElementById('deleteModalMediaMeta');
      const thumbEl = document.getElementById('deleteModalThumb');
      if (!modal) return;
      if (titleEl) titleEl.textContent = item.name || item.filename || 'Untitled Media';
      if (metaEl) {
        const ext = (item.extension || '').toUpperCase().replace('.', '') || (item.type || 'VIDEO').toUpperCase();
        const size = formatBytes(item.size || 0);
        metaEl.textContent = `${ext} • ${size}`;
      }
      if (thumbEl) {
        const isVid = item.type === 'video';
        thumbEl.innerHTML = `<i class="fa-solid ${isVid ? 'fa-film' : 'fa-music'}"></i>`;
      }
      modal.style.display = 'flex';
    };
    const closeDeleteModal = () => {
      const modal = document.getElementById('novaConfirmDeleteModal');
      if (modal) modal.style.display = 'none';
      pendingDeleteMedia = null;
      pendingDeleteCallback = null;
    };
    document.getElementById('closeDeleteModalBtn')?.addEventListener('click', closeDeleteModal);
    document.getElementById('cancelDeleteModalBtn')?.addEventListener('click', closeDeleteModal);
    let isDeletingMedia = false;
    document.getElementById('confirmDeleteModalBtn')?.addEventListener('click', async () => {
      if (!pendingDeleteMedia || isDeletingMedia) return;
      const confirmBtn = document.getElementById('confirmDeleteModalBtn');
      const origText = confirmBtn ? confirmBtn.innerHTML : '';
      isDeletingMedia = true;
      if (confirmBtn) {
        confirmBtn.disabled = true;
        confirmBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Deleting...';
      }
      const item = pendingDeleteMedia;
      const cb = pendingDeleteCallback;
      try {
        const token = localStorage.getItem('novapulse_auth_token') || '';
        const res = await fetch(`/api/media-item/${item.id}`, {
          method: 'DELETE',
          headers: token ? { 'Authorization': `Bearer ${token}` } : {}
        });
        const data = await res.json();
        closeDeleteModal();
        if (data.ok) {
          if (typeof showNovaToast === 'function') {
            showNovaToast(`Permanently deleted "${item.name}"`, 'fa-trash-can');
          }
          if (cb) cb();
          try {
            window.dispatchEvent(new CustomEvent('novapulse:media-deleted', { detail: { id: item.id, item } }));
            if (typeof loadAndRenderPlaylists === 'function') {
              loadAndRenderPlaylists();
            }
            if (typeof activeDetailPlaylistId !== 'undefined' && activeDetailPlaylistId) {
              openPlaylistDetail(activeDetailPlaylistId);
            }
            if (typeof Playlist !== 'undefined' && typeof Playlist.getItems === 'function') {
              const qItems = Playlist.getItems() || [];
              const matchIdx = qItems.findIndex(q => q && q.id === item.id);
              if (matchIdx !== -1 && typeof Playlist.removeItem === 'function') {
                Playlist.removeItem(matchIdx);
              }
            }
            if (typeof refreshDashboard === 'function') {
              refreshDashboard();
            }
          } catch (syncErr) {
            console.warn('UI Deletion synchronization warning:', syncErr);
          }
        } else {
          const errMsg = data.error === 'Too many requests. Please slow down.'
            ? 'Action queued too quickly. Please try again in a moment.'
            : (data.error || 'Unable to delete media.');
          if (typeof showNovaToast === 'function') {
            showNovaToast(errMsg, 'fa-triangle-exclamation');
          } else {
            alert(errMsg);
          }
        }
      } catch (err) {
        closeDeleteModal();
        console.error('Delete media error:', err);
        if (typeof showNovaToast === 'function') {
          showNovaToast('Failed to delete media: Network error', 'fa-triangle-exclamation');
        } else {
          alert('Failed to delete media: ' + err.message);
        }
      } finally {
        isDeletingMedia = false;
        if (confirmBtn) {
          confirmBtn.disabled = false;
          confirmBtn.innerHTML = origText;
        }
      }
    });
    let pendingAddMedia = null;
    window.openAddToPlaylistModal = async function(item) {
      pendingAddMedia = item;
      const modal = document.getElementById('novaAddToPlaylistModal');
      const titleEl = document.getElementById('addToPlMediaTitle');
      const listEl = document.getElementById('addToPlList');
      if (!modal || !listEl) return;
      if (titleEl) titleEl.textContent = item.name || 'Selected Media';
      modal.style.display = 'flex';
      listEl.innerHTML = `
        <div style="padding: 16px; text-align: center; color: var(--text-muted); font-size: 0.85rem;">
          <i class="fa-solid fa-spinner fa-spin"></i> Loading playlists...
        </div>
      `;
      let playlists = [];
      try {
        playlists = await Playlist.fetchServerPlaylists();
      } catch (e) {
        console.error(e);
      }
      let html = `
        <!-- Option 1: Player Studio Queue -->
        <button class="add-to-pl-item-btn" id="addToQueueDirectBtn" style="display:flex; align-items:center; gap:12px; width:100%; padding:10px 14px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); border-radius:10px; color:#fff; cursor:pointer; text-align:left; transition:all 0.18s ease;">
          <div style="width:36px; height:36px; border-radius:8px; background:rgba(34,211,238,0.18); color:var(--accent-cyan); display:flex; align-items:center; justify-content:center; font-size:1rem; flex-shrink:0;">
            <i class="fa-solid fa-layer-group"></i>
          </div>
          <div style="flex:1; min-width:0;">
            <div style="font-weight:700; font-size:0.88rem; color:#fff;">Player Studio Queue</div>
            <div style="font-size:0.75rem; color:var(--text-muted);">Add directly to active playback queue</div>
          </div>
          <i class="fa-solid fa-plus" style="color:var(--accent-cyan);"></i>
        </button>
      `;
      if (playlists && playlists.length > 0) {
        playlists.forEach(pl => {
          const plColor = pl.color || '#00F5FF';
          const plIcon = pl.icon || 'fa-music';
          const count = pl.items ? pl.items.length : 0;
          html += `
            <button class="add-to-pl-item-btn" data-pl-id="${pl.id}" data-pl-name="${escapeHtml(pl.name)}" style="display:flex; align-items:center; gap:12px; width:100%; padding:10px 14px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); border-radius:10px; color:#fff; cursor:pointer; text-align:left; transition:all 0.18s ease;">
              <div style="width:36px; height:36px; border-radius:8px; background:${plColor}22; color:${plColor}; border:1px solid ${plColor}55; display:flex; align-items:center; justify-content:center; font-size:1rem; flex-shrink:0;">
                <i class="fa-solid ${plIcon}"></i>
              </div>
              <div style="flex:1; min-width:0;">
                <div style="font-weight:700; font-size:0.88rem; color:#fff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${escapeHtml(pl.name)}</div>
                <div style="font-size:0.75rem; color:var(--text-muted);">${count} item${count === 1 ? '' : 's'}</div>
              </div>
              <i class="fa-solid fa-folder-plus" style="color:${plColor};"></i>
            </button>
          `;
        });
      }
      listEl.innerHTML = html;
      document.getElementById('addToQueueDirectBtn')?.addEventListener('click', () => {
        Playlist.addItem(item, true);
        if (typeof showNovaToast === 'function') {
          showNovaToast(`Added "${item.name}" to Player Studio Queue`, 'fa-circle-check');
        }
        closeAddToPlModal();
      });
      listEl.querySelectorAll('[data-pl-id]').forEach(btn => {
        btn.addEventListener('click', async () => {
          const plId = btn.getAttribute('data-pl-id');
          const plName = btn.getAttribute('data-pl-name');
          await Playlist.addMediaToServerPlaylist(plId, item);
          if (typeof showNovaToast === 'function') {
            showNovaToast(`Added "${item.name}" to playlist "${plName}"`, 'fa-circle-check');
          }
          closeAddToPlModal();
        });
      });
    };
    const closeAddToPlModal = () => {
      const modal = document.getElementById('novaAddToPlaylistModal');
      if (modal) modal.style.display = 'none';
      pendingAddMedia = null;
    };
    document.getElementById('closeAddToPlModalBtn')?.addEventListener('click', closeAddToPlModal);
    document.getElementById('cancelAddToPlModalBtn')?.addEventListener('click', closeAddToPlModal);
    document.getElementById('btnQuickCreatePlFromAdd')?.addEventListener('click', () => {
      const itemToAdd = pendingAddMedia;
      closeAddToPlModal();
      switchView('playlists');
      const btn = document.getElementById('btnCreatePlaylistModal');
      if (btn) btn.click();
      if (itemToAdd) {
        setTimeout(() => {
          selectedMediaIds.add(itemToAdd.id);
          updateSelectedBadge();
          renderMediaChecklist();
        }, 150);
      }
    });
    window.recordActivePlaylistPlayback = function recordActivePlaylistPlayback(playlist, trackIndex, trackItem) {
      if (!playlist) return;
      const state = {
        id: playlist.id,
        name: playlist.name,
        color: playlist.color || '#00F5FF',
        icon: playlist.icon || 'fa-music',
        trackIndex: Math.max(0, trackIndex || 0),
        trackName: trackItem ? trackItem.name : (playlist.items && playlist.items[trackIndex] ? playlist.items[trackIndex].name : ''),
        trackId: trackItem ? trackItem.id : (playlist.items && playlist.items[trackIndex] ? playlist.items[trackIndex].id : ''),
        timestamp: Date.now()
      };
      localStorage.setItem('novapulse_active_playlist', JSON.stringify(state));
      renderResumePlaylistHero();
    }
    function renderResumePlaylistHero() {
      const container = document.getElementById('resumePlaylistHeroWrap');
      if (!container) return;
      const raw = localStorage.getItem('novapulse_active_playlist');
      if (!raw) {
        container.style.display = 'none';
        container.innerHTML = '';
        return;
      }
      let state;
      try {
        state = JSON.parse(raw);
      } catch (e) {
        container.style.display = 'none';
        return;
      }
      if (!state || !state.id || !state.name) {
        container.style.display = 'none';
        return;
      }
      const plColor = state.color || '#00F5FF';
      const plIcon = state.icon || 'fa-music';
      const trackIdx = (state.trackIndex || 0) + 1;
      const trackName = state.trackName || 'Resume playback';
      container.style.display = 'block';
      container.innerHTML = `
        <div class="resume-playlist-card" style="border-color: ${plColor}44; box-shadow: 0 14px 40px -15px ${plColor}33;">
          <div class="resume-pl-info">
            <div class="resume-pl-icon" style="background: ${plColor}22; color: ${plColor}; border-color: ${plColor}66; box-shadow: 0 0 15px ${plColor}44;">
              <i class="fa-solid ${plIcon}"></i>
            </div>
            <div class="resume-pl-text">
              <div class="resume-pl-label" style="color: ${plColor};">
                <i class="fa-solid fa-rotate-right"></i> Resume Playlist • Track ${trackIdx}
              </div>
              <div class="resume-pl-name">${escapeHtml(state.name)}</div>
              <div class="resume-pl-sub"><i class="fa-solid fa-play" style="font-size:0.7rem; margin-right:4px;"></i> ${escapeHtml(trackName)}</div>
            </div>
          </div>
          <div class="resume-pl-actions">
            <button class="btn-primary" id="btnResumePlaylistAction" style="background: ${plColor}; color: #000; font-weight: 800; border: none; box-shadow: 0 0 18px ${plColor}55;">
              <i class="fa-solid fa-play"></i> Resume Playlist
            </button>
            <button class="btn-ghost btn-mini" id="btnDismissResumePlaylist" title="Dismiss" style="color: var(--text-dim);">
              &times;
            </button>
          </div>
        </div>
      `;
      document.getElementById('btnDismissResumePlaylist')?.addEventListener('click', () => {
        localStorage.removeItem('novapulse_active_playlist');
        container.style.display = 'none';
      });
      document.getElementById('btnResumePlaylistAction')?.addEventListener('click', async () => {
        const pl = await Playlist.getServerPlaylist(state.id);
        if (!pl || !pl.items || !pl.items.length) {
          alert('Playlist could not be loaded or is empty.');
          return;
        }
        const resolvedItems = resolvePlaylistItems(pl.items);
        Playlist.clear();
        Playlist.addItems(resolvedItems);
        const targetIdx = Math.min(state.trackIndex || 0, resolvedItems.length - 1);
        Playlist.selectIndex(targetIdx, true);
        switchView('player');
        if (typeof showNovaToast === 'function') {
          showNovaToast(`Resumed "${pl.name}" at track ${targetIdx + 1}`, 'fa-play');
        }
      });
    }
    renderResumePlaylistHero();
    initDesktopContextMenu();
    refreshDashboard();
  });
  function setupNovaNavigation() {
    const navBtns = document.querySelectorAll('.nova-nav-btn');
    navBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const targetView = btn.getAttribute('data-view');
        if (targetView) switchView(targetView);
      });
    });
    const mobileMenuToggle = document.getElementById('mobileMenuToggle');
    const mobileSidebarBackdrop = document.getElementById('mobileSidebarBackdrop');
    const mobileMenuMoreBtn = document.getElementById('mobileMenuMoreBtn');
    const mobileDrawerCloseBtn = document.getElementById('mobileDrawerCloseBtn');
    if (mobileDrawerCloseBtn) {
      mobileDrawerCloseBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        document.body.classList.remove('mobile-sidebar-open');
      });
    }
    const sidebarElement = document.querySelector('.nova-sidebar');
    if (sidebarElement) {
      let touchStartX = 0;
      let touchStartY = 0;
      let touchCurrentX = 0;
      let isSwiping = false;
      sidebarElement.addEventListener('touchstart', (e) => {
        if (e.touches.length === 1) {
          touchStartX = e.touches[0].clientX;
          touchStartY = e.touches[0].clientY;
          touchCurrentX = touchStartX;
          isSwiping = true;
        }
      }, { passive: true });
      sidebarElement.addEventListener('touchmove', (e) => {
        if (!isSwiping || e.touches.length !== 1) return;
        touchCurrentX = e.touches[0].clientX;
        const diffX = touchCurrentX - touchStartX;
        const diffY = Math.abs(e.touches[0].clientY - touchStartY);
        if (diffX < 0 && Math.abs(diffX) > diffY) {
          sidebarElement.style.transform = `translateX(${diffX}px)`;
        }
      }, { passive: true });
      const endSwipe = (e) => {
        if (!isSwiping) return;
        isSwiping = false;
        const diffX = touchCurrentX - touchStartX;
        const diffY = Math.abs((e.changedTouches[0]?.clientY || touchStartY) - touchStartY);
        sidebarElement.style.transform = '';
        if (diffX < -50 && Math.abs(diffX) > diffY) {
          document.body.classList.remove('mobile-sidebar-open');
        }
        touchStartX = 0;
        touchCurrentX = 0;
      };
      sidebarElement.addEventListener('touchend', endSwipe, { passive: true });
      sidebarElement.addEventListener('touchcancel', endSwipe, { passive: true });
    }
    if (mobileMenuToggle) {
      mobileMenuToggle.addEventListener('click', (e) => {
        e.stopPropagation();
        document.body.classList.toggle('mobile-sidebar-open');
      });
    }
    if (mobileSidebarBackdrop) {
      mobileSidebarBackdrop.addEventListener('click', () => {
        document.body.classList.remove('mobile-sidebar-open');
      });
    }
    if (mobileMenuMoreBtn) {
      mobileMenuMoreBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        document.body.classList.toggle('mobile-sidebar-open');
      });
    }
    document.querySelectorAll('.nova-nav-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        if (window.innerWidth <= 900) {
          document.body.classList.remove('mobile-sidebar-open');
        }
      });
    });
    try {
      history.replaceState({ view: 'home' }, '', '#home');
      window.addEventListener('popstate', (e) => {
        const openModals = document.querySelectorAll(
          '#deviceSyncModal, #sitesModal, #videoFxModal, #eqModal, #playlistCreatorModal'
        );
        let closedModal = false;
        openModals.forEach(m => {
          if (m && (m.style.display === 'flex' || m.style.display === 'block')) {
            m.style.display = 'none';
            closedModal = true;
          }
        });
        if (closedModal) {
          history.pushState({ view: currentView }, '', '#' + currentView);
          return;
        }
        if (document.body.classList.contains('mobile-sidebar-open')) {
          document.body.classList.remove('mobile-sidebar-open');
          history.pushState({ view: currentView }, '', '#' + currentView);
          return;
        }
        const stateView = e.state?.view || 'home';
        if (stateView !== currentView) {
          switchView(stateView, false);
        }
      });
      document.addEventListener('backbutton', (e) => {
        e.preventDefault();
        window.dispatchEvent(new PopStateEvent('popstate'));
      }, false);
    } catch (e) {}
    const mobileNavItems = document.querySelectorAll('.mobile-nav-item[data-view]');
    mobileNavItems.forEach(btn => {
      btn.addEventListener('click', () => {
        const targetView = btn.getAttribute('data-view');
        if (targetView) switchView(targetView);
      });
    });
    const viewAllContinueBtn = document.getElementById('viewAllContinueBtn');
    if (viewAllContinueBtn) {
      viewAllContinueBtn.addEventListener('click', () => switchView('library'));
    }
    const viewAllRecentBtn = document.getElementById('viewAllRecentBtn');
    if (viewAllRecentBtn) {
      viewAllRecentBtn.addEventListener('click', () => switchView('library'));
    }
    const miniPlayerExpand = document.getElementById('miniPlayerExpand');
    const miniBtnExpand = document.getElementById('miniBtnExpand');
    const miniBtnClose = document.getElementById('miniBtnClose');
    if (miniPlayerExpand) {
      miniPlayerExpand.addEventListener('click', () => switchView('player'));
    }
    if (miniBtnExpand) {
      miniBtnExpand.addEventListener('click', (e) => {
        e.stopPropagation();
        switchView('player');
      });
    }
    if (miniBtnClose) {
      miniBtnClose.addEventListener('click', (e) => {
        e.stopPropagation();
        isMiniPlayerDismissed = true;
        const mini = document.getElementById('novaMiniPlayer');
        if (mini) mini.style.display = 'none';
        if (typeof Player !== 'undefined' && Player.pause) {
          Player.pause();
        }
      });
    }
    const sideStorageWidget = document.querySelector('.sidebar-storage-widget');
    if (sideStorageWidget) {
      sideStorageWidget.style.cursor = 'pointer';
      sideStorageWidget.addEventListener('click', () => switchView('storage'));
    }
    const btnPlayOnline = document.getElementById('btnPlayOnline');
    if (btnPlayOnline) {
      btnPlayOnline.addEventListener('click', () => playOnlineDirectly());
    }
    const globalSearchInput = document.getElementById('globalSearchInput');
    if (globalSearchInput) {
      globalSearchInput.addEventListener('input', (e) => {
        const q = e.target.value.trim();
        const libSearch = document.getElementById('libSearchInput');
        if (libSearch) {
          libSearch.value = q;
          if (typeof Library !== 'undefined') {
            Library.setFilter(q);
            if (typeof renderLibrary === 'function') renderLibrary();
          }
        }
        if (q.length > 1 && currentView !== 'library') {
          switchView('library');
        }
      });
    }
    const btnStorageOpenFolder = document.getElementById('btnStorageOpenFolder');
    if (btnStorageOpenFolder) {
      btnStorageOpenFolder.addEventListener('click', () => {
        if (typeof openFolder === 'function') openFolder();
      });
    }
    const openDownloadsFolderBtn = document.getElementById('openDownloadsFolderBtn');
    if (openDownloadsFolderBtn) {
      openDownloadsFolderBtn.addEventListener('click', () => {
        if (typeof openFolder === 'function') openFolder();
      });
    }
    const btnCheckUpdatesStorage = document.getElementById('btnCheckUpdatesStorage');
    const updaterBtn = document.getElementById('updaterBtn');
    if (btnCheckUpdatesStorage && updaterBtn) {
      btnCheckUpdatesStorage.addEventListener('click', () => updaterBtn.click());
    }
    const formatPills = document.querySelectorAll('.format-pill-card');
    formatPills.forEach(pill => {
      pill.addEventListener('click', () => {
        formatPills.forEach(p => p.classList.remove('active'));
        pill.classList.add('active');
        const fmt = pill.getAttribute('data-format');
        const urlInp = document.getElementById('urlInput');
        if (fmt === 'video') {
          if (urlInp) { urlInp.placeholder = 'Paste video link (YouTube, Vimeo, TikTok, MP4)...'; urlInp.focus(); }
        } else if (fmt === 'audio') {
          if (urlInp) { urlInp.placeholder = 'Paste link to extract MP3 audio (YouTube, Spotify, etc.)...'; urlInp.focus(); }
        } else if (fmt === 'images') {
          switchView('gallery-ripper');
        } else if (fmt === 'playlist') {
          switchView('playlists');
        } else if (fmt === 'livestream') {
          if (urlInp) { urlInp.placeholder = 'Paste live stream or .m3u8 manifest URL (Twitch, Kick, YouTube Live)...'; urlInp.focus(); }
        } else {
          if (urlInp) { urlInp.placeholder = 'Paste your link here...'; urlInp.focus(); }
        }
      });
    });
    const qaPopularWebsites = document.getElementById('qaPopularWebsites');
    if (qaPopularWebsites) {
      qaPopularWebsites.addEventListener('click', () => {
        const sitesModal = document.getElementById('sitesModal');
        if (sitesModal) sitesModal.style.display = 'flex';
        if (typeof window.initSitesDirectoryModal === 'function') {
          window.initSitesDirectoryModal();
        }
      });
    }
    const rightViewSitesBtn = document.getElementById('rightViewSitesBtn');
    if (rightViewSitesBtn) {
      rightViewSitesBtn.addEventListener('click', () => {
        const sitesModal = document.getElementById('sitesModal');
        if (sitesModal) sitesModal.style.display = 'flex';
        if (typeof window.initSitesDirectoryModal === 'function') {
          window.initSitesDirectoryModal();
        }
      });
    }
    const qaSupportedFormats = document.getElementById('qaSupportedFormats');
    const supportedFormatsModal = document.getElementById('supportedFormatsModal');
    const closeFormatsModal = document.getElementById('closeFormatsModal');
    const handleSupportedFormatsClick = () => {
      const formatPillsContainer = document.querySelector('.format-category-pills');
      if (formatPillsContainer) {
        formatPillsContainer.scrollIntoView({ behavior: 'smooth', block: 'center' });
        formatPillsContainer.classList.add('format-pill-pulse');
        setTimeout(() => formatPillsContainer.classList.remove('format-pill-pulse'), 1900);
      }
      if (supportedFormatsModal) {
        supportedFormatsModal.classList.add('active', 'open');
        supportedFormatsModal.style.display = 'flex';
      }
    };
    if (qaSupportedFormats) {
      qaSupportedFormats.addEventListener('click', handleSupportedFormatsClick);
    }
    if (closeFormatsModal && supportedFormatsModal) {
      closeFormatsModal.addEventListener('click', () => {
        supportedFormatsModal.classList.remove('active', 'open');
        supportedFormatsModal.style.display = 'none';
      });
      supportedFormatsModal.addEventListener('click', (e) => {
        if (e.target === supportedFormatsModal) {
          supportedFormatsModal.classList.remove('active', 'open');
          supportedFormatsModal.style.display = 'none';
        }
      });
    }
    const cookieDropdownWrap = document.getElementById('cookieDropdownWrap');
    const cookieDropdownBtn = document.getElementById('cookieDropdownBtn');
    const cookieDropdownMenu = document.getElementById('cookieDropdownMenu');
    const cookieDropdownSelectedText = document.getElementById('cookieDropdownSelectedText');
    const cookieBrowserSelect = document.getElementById('cookieBrowserSelect');
    if (cookieDropdownBtn && cookieDropdownMenu && cookieDropdownWrap) {
      cookieDropdownBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        cookieDropdownWrap.classList.toggle('open');
      });
      document.addEventListener('click', (e) => {
        if (!cookieDropdownWrap.contains(e.target)) {
          cookieDropdownWrap.classList.remove('open');
        }
      });
      const selectCookieBrowser = (val, itemEl, skipToast = false) => {
        if (cookieBrowserSelect) cookieBrowserSelect.value = val;
        try {
          localStorage.setItem('novapulse_cookie_browser', val);
        } catch (e) {}
        const leftContent = itemEl.querySelector('.custom-dropdown-item-left');
        if (cookieDropdownSelectedText) {
          cookieDropdownSelectedText.innerHTML = leftContent ? leftContent.innerHTML : itemEl.innerHTML;
        }
        cookieDropdownMenu.querySelectorAll('.custom-dropdown-item').forEach(it => it.classList.remove('active'));
        itemEl.classList.add('active');
        cookieDropdownWrap.classList.remove('open');
        if (!skipToast && typeof showNovaToast === 'function') {
          const browserName = (leftContent ? leftContent.innerText : itemEl.innerText).trim();
          if (val === 'none') {
            showNovaToast('Session Cookies: Public Only (Default)', 'fa-globe');
          } else {
            showNovaToast(`Session Cookies: ${browserName} connected`, 'fa-key');
          }
        }
      };
      cookieDropdownMenu.querySelectorAll('.custom-dropdown-item').forEach(item => {
        item.addEventListener('click', (e) => {
          e.stopPropagation();
          const val = item.getAttribute('data-val') || 'none';
          selectCookieBrowser(val, item, false);
        });
      });
      try {
        const savedVal = localStorage.getItem('novapulse_cookie_browser');
        if (savedVal && savedVal !== 'none') {
          const matchingItem = cookieDropdownMenu.querySelector(`.custom-dropdown-item[data-val="${savedVal}"]`);
          if (matchingItem) {
            selectCookieBrowser(savedVal, matchingItem, true);
          }
        }
      } catch (e) {}
      fetch('/api/cookies/browsers')
        .then(res => res.json())
        .then(data => {
          if (data && data.ok && Array.isArray(data.browsers)) {
            data.browsers.forEach(b => {
              const tagEl = document.getElementById(`tagBrowser${b.id.charAt(0).toUpperCase() + b.id.slice(1)}`);
              if (tagEl) {
                if (b.installed) {
                  tagEl.textContent = 'Detected';
                  tagEl.className = 'browser-status-tag detected';
                } else {
                  tagEl.textContent = 'Not Found';
                  tagEl.className = 'browser-status-tag missing';
                }
              }
            });
          }
        })
        .catch(() => {});
      document.addEventListener('click', (e) => {
        if (!cookieDropdownWrap.contains(e.target)) {
          cookieDropdownWrap.classList.remove('open');
        }
      });
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
          cookieDropdownWrap.classList.remove('open');
        }
      });
    }
    const libSortDropdownWrap = document.getElementById('libSortDropdownWrap');
    const libSortDropdownBtn = document.getElementById('libSortDropdownBtn');
    const libSortDropdownMenu = document.getElementById('libSortDropdownMenu');
    const libSortSelectedText = document.getElementById('libSortSelectedText');
    const libSortSelect = document.getElementById('libSortSelect');
    if (libSortDropdownBtn && libSortDropdownMenu && libSortDropdownWrap) {
      libSortDropdownBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        libSortDropdownWrap.classList.toggle('open');
      });
      document.addEventListener('click', (e) => {
        if (!libSortDropdownWrap.contains(e.target)) {
          libSortDropdownWrap.classList.remove('open');
        }
      });
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
          libSortDropdownWrap.classList.remove('open');
        }
      });
      libSortDropdownMenu.querySelectorAll('.custom-dropdown-item').forEach(item => {
        item.addEventListener('click', (e) => {
          e.stopPropagation();
          const val = item.getAttribute('data-val') || 'newest';
          if (libSortSelect) {
            libSortSelect.value = val;
            libSortSelect.dispatchEvent(new Event('change', { bubbles: true }));
          }
          if (libSortSelectedText) {
            libSortSelectedText.innerHTML = item.innerHTML;
          }
          libSortDropdownMenu.querySelectorAll('.custom-dropdown-item').forEach(it => it.classList.remove('active'));
          item.classList.add('active');
          libSortDropdownWrap.classList.remove('open');
          if (typeof Library !== 'undefined' && typeof Library.setSortMode === 'function') {
            Library.setSortMode(val);
            const libContainer = document.getElementById('libraryContainer');
            if (libContainer && typeof Library.renderList === 'function') {
              Library.renderList(libContainer);
            }
          }
        });
      });
    }
    const libChipsRow = document.querySelector('.lib-filter-chips-row');
    const libScrollThumb = document.getElementById('libScrollHintThumb');
    const updateScrollHint = () => {
      const row = document.querySelector('.lib-filter-chips-row');
      const thumb = document.getElementById('libScrollHintThumb');
      if (!row || !thumb) return;
      const scrollLeft = row.scrollLeft;
      const maxScroll = row.scrollWidth - row.clientWidth;
      if (maxScroll > 1) {
        const pct = Math.max(0, Math.min(100, (scrollLeft / maxScroll) * 100));
        const fillWidth = Math.min(100, Math.max(16, 16 + (pct * 0.84)));
        thumb.style.width = fillWidth + '%';
        thumb.style.transform = `translateX(${(pct * (90 - (90 * (fillWidth / 100)))) / 100}px)`;
      } else {
        thumb.style.width = '100%';
        thumb.style.transform = 'none';
      }
    };
    window.refreshLibScrollHint = updateScrollHint;
    if (libChipsRow) {
      libChipsRow.addEventListener('scroll', updateScrollHint, { passive: true });
      libChipsRow.addEventListener('touchmove', updateScrollHint, { passive: true });
      window.addEventListener('resize', updateScrollHint, { passive: true });
      setTimeout(updateScrollHint, 100);
      setTimeout(updateScrollHint, 400);
    }
    const playerSideTabs = document.querySelector('.player-side-column .side-tabs');
    const playerSideTabsThumb = document.getElementById('playerSideTabsScrollThumb');
    const updateSideTabsScrollHint = () => {
      const tabs = document.querySelector('.player-side-column .side-tabs');
      const thumb = document.getElementById('playerSideTabsScrollThumb');
      if (!tabs || !thumb) return;
      const scrollLeft = tabs.scrollLeft;
      const maxScroll = tabs.scrollWidth - tabs.clientWidth;
      if (maxScroll > 1) {
        const pct = Math.max(0, Math.min(100, (scrollLeft / maxScroll) * 100));
        const fillWidth = Math.min(100, Math.max(20, 20 + (pct * 0.80)));
        thumb.style.width = fillWidth + '%';
        thumb.style.transform = `translateX(${(pct * (90 - (90 * (fillWidth / 100)))) / 100}px)`;
      } else {
        thumb.style.width = '100%';
        thumb.style.transform = 'none';
      }
    };
    window.refreshSideTabsScrollHint = updateSideTabsScrollHint;
    if (playerSideTabs) {
      playerSideTabs.addEventListener('scroll', updateSideTabsScrollHint, { passive: true });
      playerSideTabs.addEventListener('touchmove', updateSideTabsScrollHint, { passive: true });
      window.addEventListener('resize', updateSideTabsScrollHint, { passive: true });
      setTimeout(updateSideTabsScrollHint, 200);
      setTimeout(updateSideTabsScrollHint, 500);
    }
    if (window.NotificationCenter && typeof window.NotificationCenter.init === 'function') {
      window.NotificationCenter.init();
    }
    const qaDownloadQueue = document.getElementById('qaDownloadQueue');
    if (qaDownloadQueue) {
      qaDownloadQueue.addEventListener('click', () => switchView('downloads'));
    }
    const qaMediaLibrary = document.getElementById('qaMediaLibrary');
    if (qaMediaLibrary) {
      qaMediaLibrary.addEventListener('click', () => switchView('library'));
    }
    const quickAccessViewAllBtn = document.getElementById('quickAccessViewAllBtn');
    if (quickAccessViewAllBtn) {
      quickAccessViewAllBtn.addEventListener('click', () => switchView('library'));
    }
    const recentViewAllBtn = document.getElementById('recentViewAllBtn');
    if (recentViewAllBtn) {
      recentViewAllBtn.addEventListener('click', () => switchView('library'));
    }
    document.querySelectorAll('.lib-quick-row').forEach(row => {
      row.addEventListener('click', () => {
        const filter = row.getAttribute('data-filter');
        if (filter === 'playlists') {
          switchView('playlists');
        } else {
          switchView('library');
          const chip = document.querySelector(`.chip-filter[data-type="${filter}"]`);
          if (chip) chip.click();
        }
      });
    });
    const headerSettingsGear = document.getElementById('headerSettingsGear');
    const navSettingsBtn = document.getElementById('navSettingsBtn');
    const rightStatusGear = document.getElementById('rightStatusGear');
    const openSettings = (e) => {
      if (e) e.stopPropagation();
      const modal = document.getElementById('settingsModal');
      if (modal) {
        modal.classList.add('active', 'open');
        modal.style.display = 'flex';
        const tabBtnGeneral = document.getElementById('tabBtnSettingsGeneral');
        const paneGeneral = document.getElementById('settingsTabGeneral');
        if (typeof window.switchSettingsTab === 'function' && tabBtnGeneral && paneGeneral) {
          window.switchSettingsTab(tabBtnGeneral, paneGeneral);
        } else if (tabBtnGeneral) {
          tabBtnGeneral.click();
        }
        const dInput = document.getElementById('downloadDirInput');
        if (dInput) {
          fetch('/api/settings').then(r => r.json()).then(st => {
            if (st && st.downloadDir) dInput.value = st.downloadDir;
          }).catch(() => {});
        }
        const sNight = document.getElementById('settingsNightShiftCheckbox');
        if (sNight && typeof currentNightShiftState !== 'undefined') {
          sNight.checked = currentNightShiftState;
        }
        if (window.NovaTheme && window.NovaTheme.renderThemeGallery) {
          window.NovaTheme.renderThemeGallery();
        }
      }
    };
    if (headerSettingsGear) headerSettingsGear.addEventListener('click', openSettings);
    if (navSettingsBtn) navSettingsBtn.addEventListener('click', openSettings);
    if (rightStatusGear) rightStatusGear.addEventListener('click', openSettings);
    const closeSettingsModal = document.getElementById('closeSettingsModal');
    if (closeSettingsModal) {
      closeSettingsModal.addEventListener('click', () => {
        const modal = document.getElementById('settingsModal');
        if (modal) {
          modal.classList.remove('active', 'open');
          modal.style.display = 'none';
        }
      });
    }
    document.querySelectorAll('.window-frame-btn').forEach((btn, idx) => {
      btn.addEventListener('click', () => {
        if (idx === 0) {
          if (window.electronAPI && typeof window.electronAPI.minimize === 'function') {
            window.electronAPI.minimize();
          } else {
            showToast('Running in Web Studio mode. Use browser minimize button.', 'info');
          }
        } else if (idx === 1) {
          if (window.electronAPI && typeof window.electronAPI.maximize === 'function') {
            window.electronAPI.maximize();
          } else if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen().catch(() => {});
          } else {
            document.exitFullscreen().catch(() => {});
          }
        } else if (idx === 2) {
          if (window.electronAPI && typeof window.electronAPI.close === 'function') {
            window.electronAPI.close();
          } else {
            try { window.close(); } catch (e) {}
            showToast('NovaPulse server is active. Close this tab or terminal to shut down.', 'info');
          }
        }
      });
    });
    const rightNpPlayPause = document.getElementById('rightNpPlayPause');
    const rightNpPrev = document.getElementById('rightNpPrev');
    const rightNpNext = document.getElementById('rightNpNext');
    const rightNpShuffle = document.getElementById('rightNpShuffle');
    const rightNpRepeat = document.getElementById('rightNpRepeat');
    const rightNpRange = document.getElementById('rightNpRange');
    const rightNpFill = document.getElementById('rightNpFill');
    const rightNpCurrent = document.getElementById('rightNpCurrent');
    const rightNpDuration = document.getElementById('rightNpDuration');
    const rightNpTitle = document.getElementById('rightNpTitle');
    const rightNpArtist = document.getElementById('rightNpArtist');
    const rightNpThumb = document.getElementById('rightNpThumb');
    function syncNowPlayingWidget() {
      const current = (typeof Playlist !== 'undefined' && Playlist.getCurrentItem) 
        ? Playlist.getCurrentItem() 
        : (typeof Player !== 'undefined' && Player.getCurrentItem ? Player.getCurrentItem() : null);
      if (current) {
        if (rightNpTitle) rightNpTitle.textContent = current.name || current.title || 'Now Playing';
        if (rightNpArtist) rightNpArtist.textContent = current.artist || (current.type === 'video' ? 'Video Track' : 'Audio Track');
        if (rightNpThumb && current.thumbnail) {
          rightNpThumb.src = current.thumbnail;
        }
      } else {
        if (rightNpTitle) rightNpTitle.textContent = 'No Active Playback';
        if (rightNpArtist) rightNpArtist.textContent = 'Player Idle';
        if (rightNpThumb) {
          rightNpThumb.src = 'assets/icons/novapulse.png';
        }
        if (rightNpFill) rightNpFill.style.width = '0%';
        if (rightNpRange) rightNpRange.value = 0;
        if (rightNpCurrent) rightNpCurrent.textContent = '0:00';
        if (rightNpDuration) rightNpDuration.textContent = '0:00';
        if (rightNpPlayPause) rightNpPlayPause.innerHTML = '<i class="fa-solid fa-play"></i>';
      }
      if (typeof Player !== 'undefined') {
        const isPaused = Player.isPaused();
        if (rightNpPlayPause) {
          rightNpPlayPause.innerHTML = isPaused ? '<i class="fa-solid fa-play"></i>' : '<i class="fa-solid fa-pause"></i>';
        }
        const cur = Player.getCurrentTime ? Player.getCurrentTime() : 0;
        const dur = Player.getDuration ? Player.getDuration() : 0;
        if (dur > 0) {
          const pct = Math.min(100, Math.max(0, (cur / dur) * 100));
          if (rightNpFill) rightNpFill.style.width = pct + '%';
          if (rightNpRange && document.activeElement !== rightNpRange) rightNpRange.value = pct;
          if (rightNpCurrent) rightNpCurrent.textContent = formatTime(cur);
          if (rightNpDuration) rightNpDuration.textContent = formatTime(dur);
        }
      }
      if (typeof Playlist !== 'undefined') {
        if (rightNpShuffle) {
          const isShuff = Playlist.getIsShuffle ? Playlist.getIsShuffle() : false;
          rightNpShuffle.style.color = isShuff ? '#ff1f3d' : '';
        }
        if (rightNpRepeat) {
          const repMode = Playlist.getRepeatMode ? Playlist.getRepeatMode() : 'off';
          rightNpRepeat.style.color = repMode !== 'off' ? '#ff1f3d' : '';
          rightNpRepeat.title = `Repeat: ${repMode.toUpperCase()}`;
        }
      }
    }
    if (rightNpPlayPause) {
      rightNpPlayPause.addEventListener('click', () => {
        if (typeof Player !== 'undefined' && Player.hasSource && Player.hasSource()) {
          Player.togglePlay();
          syncNowPlayingWidget();
        } else if (typeof Playlist !== 'undefined' && Playlist.getItems && Playlist.getItems().length > 0) {
          const item = Playlist.getCurrentItem() || Playlist.getItems()[0];
          if (item) {
            if (typeof window.playLibraryTrackWithQueue === 'function') {
              window.playLibraryTrackWithQueue(item);
            } else {
              Playlist.playNow(item);
            }
          }
        } else {
          window.showToast('No media loaded. Choose a track in Library or Player.', 'info');
        }
      });
    }
    if (rightNpPrev) {
      rightNpPrev.addEventListener('click', () => {
        if (typeof Playlist !== 'undefined') {
          const curTime = (typeof Player !== 'undefined' && Player.getCurrentTime) ? Player.getCurrentTime() : 0;
          Playlist.previous(curTime, true);
          syncNowPlayingWidget();
        }
      });
    }
    if (rightNpNext) {
      rightNpNext.addEventListener('click', () => {
        if (typeof Playlist !== 'undefined') {
          Playlist.next(true);
          syncNowPlayingWidget();
        }
      });
    }
    if (rightNpShuffle) {
      rightNpShuffle.addEventListener('click', () => {
        if (typeof Playlist !== 'undefined') {
          const newShuff = Playlist.toggleShuffle();
          rightNpShuffle.style.color = newShuff ? '#ff1f3d' : '';
          const bShuff = document.getElementById('btnShuffle');
          if (bShuff) bShuff.classList.toggle('active', newShuff);
          window.showToast(newShuff ? 'Shuffle mode enabled (Random playback)' : 'Shuffle mode disabled (Playing in sequential order: 1 → 2 → 3)', 'info');
        }
      });
    }
    if (rightNpRepeat) {
      rightNpRepeat.addEventListener('click', () => {
        if (typeof Playlist !== 'undefined') {
          const newMode = Playlist.cycleRepeatMode();
          rightNpRepeat.style.color = newMode !== 'off' ? '#ff1f3d' : '';
          window.showToast(`Repeat mode: ${newMode.toUpperCase()}`, 'info');
        }
      });
    }
    if (rightNpRange) {
      rightNpRange.addEventListener('input', (e) => {
        const val = parseFloat(e.target.value);
        if (rightNpFill) rightNpFill.style.width = val + '%';
        if (typeof Player !== 'undefined' && Player.getDuration) {
          const dur = Player.getDuration();
          if (dur > 0) {
            const seekSec = (val / 100) * dur;
            if (rightNpCurrent) rightNpCurrent.textContent = formatTime(seekSec);
          }
        }
      });
      rightNpRange.addEventListener('change', (e) => {
        const val = parseFloat(e.target.value);
        if (typeof Player !== 'undefined' && Player.getDuration && Player.seek) {
          const dur = Player.getDuration();
          if (dur > 0) {
            Player.seek((val / 100) * dur);
          }
        }
      });
    }
    if (typeof Player !== 'undefined') {
      if (typeof Player.onPlayStateChange === 'function') {
        Player.onPlayStateChange(() => syncNowPlayingWidget());
      }
      if (typeof Player.onTimeUpdate === 'function') {
        Player.onTimeUpdate(() => syncNowPlayingWidget());
      }
    }
    if (typeof Playlist !== 'undefined') {
      if (typeof Playlist.onItemChange === 'function') {
        Playlist.onItemChange(() => syncNowPlayingWidget());
      }
      if (typeof Playlist.onPlaylistChange === 'function') {
        Playlist.onPlaylistChange(() => syncNowPlayingWidget());
      }
    }
    setTimeout(syncNowPlayingWidget, 350);
  }
    function switchView(viewName, pushHistory = true) {
    const nightShiftBtn = document.getElementById('nightShiftToggle');
    if (nightShiftBtn) {
      if (viewName === 'player') {
        nightShiftBtn.classList.remove('view-hidden');
      } else {
        nightShiftBtn.classList.add('view-hidden');
      }
    }
    if (pushHistory && window.history && window.history.pushState) {
      if (viewName !== currentView) {
        window.history.pushState({ view: viewName }, '', '#' + viewName);
      }
    }
    currentView = viewName;
    document.querySelectorAll('.nova-view').forEach(v => v.classList.remove('active'));
    document.querySelectorAll('.nova-nav-btn').forEach(b => b.classList.remove('active'));
    const targetViewEl = document.getElementById('view-' + viewName);
    if (targetViewEl) targetViewEl.classList.add('active');
    if (viewName === 'library' && typeof window.refreshLibScrollHint === 'function') {
      setTimeout(window.refreshLibScrollHint, 80);
      setTimeout(window.refreshLibScrollHint, 300);
    }
    if (viewName === 'player' && typeof window.refreshSideTabsScrollHint === 'function') {
      setTimeout(window.refreshSideTabsScrollHint, 80);
      setTimeout(window.refreshSideTabsScrollHint, 300);
    }
    const mainViewport = document.querySelector('.nova-main-viewport');
    if (mainViewport) mainViewport.scrollTop = 0;
    window.scrollTo(0, 0);
    const activeNavBtn = document.querySelector(`.nova-nav-btn[data-view="${viewName}"]`);
    if (activeNavBtn) activeNavBtn.classList.add('active');
    document.querySelectorAll('.mobile-nav-item').forEach(btn => {
      if (btn.getAttribute('data-view') === viewName) {
        btn.classList.add('active');
      } else if (btn.getAttribute('data-view')) {
        btn.classList.remove('active');
      }
    });
    document.body.classList.remove('mobile-sidebar-open');
    updateMiniPlayerVisibility();
    if (viewName === 'home') refreshDashboard();
    else if (viewName === 'downloads') {
      if (typeof fetchDownloads === 'function') fetchDownloads();
    }
    else if (viewName === 'library') {
      if (typeof loadAndRenderLibrary === 'function') loadAndRenderLibrary();
    }
    else if (viewName === 'playlists') {
      if (typeof loadAndRenderPlaylists === 'function') loadAndRenderPlaylists();
    }
    else if (viewName === 'player') {
      if (typeof window.syncPlayerStudioUI === 'function') window.syncPlayerStudioUI();
      if (typeof window.renderPlaylistView === 'function') window.renderPlaylistView();
    }
    else if (viewName === 'history') {
      if (typeof loadAndRenderHistory === 'function') loadAndRenderHistory();
      else if (typeof window.loadAndRenderHistory === 'function') window.loadAndRenderHistory();
    }
    else if (viewName === 'storage') {
      fetchStorageStats();
      if (typeof fetchStatus === 'function') fetchStatus();
    }
    else if (viewName === 'supported-sites') {
      if (typeof window.loadAndRenderSupportedSites === 'function') window.loadAndRenderSupportedSites();
    }
    else if (viewName === 'secure-folder') {
      if (typeof window.loadAndRenderSecureFolder === 'function') window.loadAndRenderSecureFolder();
    }
    else if (viewName === 'gallery-ripper') {
    }
    else if (viewName === 'reclip-batch') {
    }
    else if (viewName === 'studio-tools') {
      if (window.NovaStudio && typeof window.NovaStudio.onOpen === 'function') {
        window.NovaStudio.onOpen();
      }
    }
    else if (viewName === 'viral-shorts') {
      if (window.ViralShorts && typeof window.ViralShorts.onOpen === 'function') {
        window.ViralShorts.onOpen();
      }
    }
    else if (viewName === 'channel-sync') {
      if (window.ChannelSync && typeof window.ChannelSync.onOpen === 'function') {
        window.ChannelSync.onOpen();
      }
    }
    else if (viewName === 'browser-sniffer') {
      if (window.BrowserSniffer && typeof window.BrowserSniffer.onOpen === 'function') {
        window.BrowserSniffer.onOpen();
      }
    }
  }
  let isMiniPlayerDismissed = false;
  function updateMiniPlayerVisibility() {
    const mini = document.getElementById('novaMiniPlayer');
    if (!mini) return;
    const playerViewEl = document.getElementById('playerView');
    const isPlayerActive = (currentView === 'player') || (playerViewEl && playerViewEl.classList.contains('active'));
    const currentItem = (typeof Playlist !== 'undefined' && Playlist.getCurrentItem && Playlist.getCurrentItem())
      || (typeof Player !== 'undefined' && Player.getCurrentItem && Player.getCurrentItem())
      || null;
    const miniTitle = document.getElementById('miniTitle');
    const miniThumb = document.getElementById('miniThumb');
    const miniSubtitle = document.getElementById('miniSubtitle');
    if (currentItem && (currentItem.name || currentItem.title)) {
      if (miniTitle) miniTitle.textContent = currentItem.name || currentItem.title;
      if (miniSubtitle) miniSubtitle.textContent = 'Tap to open full player';
      if (miniThumb) {
        if (currentItem.thumbnail && !currentItem.thumbnail.includes('#t=')) {
          miniThumb.src = currentItem.thumbnail;
        } else if (currentItem.type === 'video') {
          miniThumb.src = 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=200&auto=format&fit=crop&q=80';
        } else {
          miniThumb.src = 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=200&auto=format&fit=crop&q=80';
        }
      }
    }
    const isPlayable = currentItem && (currentItem.type === 'video' || currentItem.type === 'audio' || currentItem.url || currentItem.src || currentItem.name);
    if (!isPlayerActive && isPlayable && !isMiniPlayerDismissed) {
      mini.style.display = 'flex';
    } else {
      mini.style.display = 'none';
    }
  }
  window.addEventListener('novapulse-player-item', (e) => {
    isMiniPlayerDismissed = false;
    if (typeof updateMiniPlayerVisibility === 'function') {
      updateMiniPlayerVisibility();
    }
  });
window.updateMiniPlayerVisibility = updateMiniPlayerVisibility;
  async function playOnlineDirectly() {
    const inputEl = document.getElementById('urlInput');
    const inputVal = inputEl ? inputEl.value.trim() : '';
    const url = (typeof currentVideoInfo !== 'undefined' && currentVideoInfo && currentVideoInfo.webpage_url)
      ? currentVideoInfo.webpage_url
      : inputVal;
    if (!url) {
      alert('Please enter or paste a video URL first!');
      return;
    }
    const btn = document.getElementById('btnPlayOnline');
    const origHtml = btn ? btn.innerHTML : '';
    if (btn) {
      btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Loading Stream...';
      btn.disabled = true;
    }
    try {
      const res = await fetch('/api/resolve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url })
      });
      const data = await res.json();
      const resolution = data.ok ? data.resolution : null;
      const mainVideo = document.getElementById('mainVideoPlayer');
      const embedIframe = document.getElementById('onlineEmbedIframe');
      const placeholder = document.getElementById('videoPlaceholder');
      const nowPlayingTitle = document.getElementById('nowPlayingTitle');
      const nowPlayingExt = document.getElementById('nowPlayingExt');
      const trackTypeBadge = document.getElementById('trackTypeBadge');
      const videoTitle = (typeof currentVideoInfo !== 'undefined' && currentVideoInfo && currentVideoInfo.title)
        ? currentVideoInfo.title
        : 'Online Stream';
      const videoThumb = (typeof currentVideoInfo !== 'undefined' && currentVideoInfo && currentVideoInfo.thumbnail)
        ? currentVideoInfo.thumbnail
        : '';
      const videoDur = (typeof currentVideoInfo !== 'undefined' && currentVideoInfo && currentVideoInfo.duration)
        ? currentVideoInfo.duration
        : 0;
      if (resolution && resolution.playbackEngine === 'iframe-embed' && resolution.embedUrl) {
        if (mainVideo) {
          try {
            mainVideo.pause();
            mainVideo.removeAttribute('src');
            mainVideo.load();
          } catch (e) {}
          mainVideo.style.display = 'none';
        }
        const errBanner = document.getElementById('playerErrorBanner');
        if (errBanner) errBanner.style.display = 'none';
        if (embedIframe) {
          let finalEmbedUrl = resolution.embedUrl;
          if (!finalEmbedUrl.includes('enablejsapi=1')) {
            finalEmbedUrl += (finalEmbedUrl.includes('?') ? '&' : '?') + 'enablejsapi=1&origin=' + encodeURIComponent(window.location.origin);
          }
          embedIframe.src = finalEmbedUrl;
          embedIframe.style.display = 'block';
        }
        if (placeholder) {
          placeholder.style.display = 'none';
          placeholder.style.opacity = '0';
          placeholder.style.pointerEvents = 'none';
        }
        if (nowPlayingTitle) nowPlayingTitle.textContent = videoTitle;
        if (nowPlayingExt) nowPlayingExt.textContent = 'ONLINE';
        if (trackTypeBadge) {
          trackTypeBadge.textContent = 'EMBED STREAM';
          trackTypeBadge.className = 'track-type-badge type-video';
        }
        const onlineMediaItem = {
          id: 'online_' + Date.now(),
          name: videoTitle,
          url: url,
          webpage_url: url,
          type: 'video',
          extension: '.mp4',
          thumbnail: videoThumb,
          duration: videoDur
        };
        if (typeof Player !== 'undefined' && typeof Player.setEmbedMode === 'function') {
          Player.setEmbedMode(true, onlineMediaItem);
        }
        if (typeof window.syncPlayerStudioUI === 'function') {
          window.syncPlayerStudioUI();
        }
        switchView('player');
      } else if (resolution && resolution.canPlayOnline && resolution.url) {
        if (embedIframe) embedIframe.style.display = 'none';
        if (mainVideo) mainVideo.style.display = 'block';
        const mediaItem = {
          id: 'online_' + Date.now(),
          name: videoTitle,
          url: resolution.url,
          type: resolution.mediaKind || 'video',
          extension: resolution.type === 'hls' ? '.m3u8' : '.mp4',
          thumbnail: videoThumb,
          duration: videoDur
        };
        if (typeof Playlist !== 'undefined') {
          Playlist.addItem(mediaItem, true);
          Playlist.playNow(mediaItem);
        }
        switchView('player');
      } else {
        alert(resolution?.note || 'This platform source cannot be streamed directly without downloading. Please click "Download Max Quality" or inspect available formats below.');
      }
    } catch (err) {
      console.error('Failed to resolve online playback:', err);
      alert('Could not start direct online playback for this URL.');
    } finally {
      if (btn) {
        btn.innerHTML = origHtml;
        btn.disabled = false;
      }
    }
  }
  async function refreshDashboard() {
    let media = [];
    try {
      const libRes = await fetch('/api/library');
      const libData = await libRes.json();
      if (libData && libData.ok && Array.isArray(libData.library)) {
        media = libData.library;
      }
    } catch (e) {
      console.warn('[Nova] Library fetch caught:', e);
    }
    renderRecentDownloadedShelf(media);
    renderContinueWatchingShelf(media);
    let stats = null;
    try {
      const statsRes = await fetch('/api/storage/stats');
      const statsData = await statsRes.json();
      if (statsData && statsData.ok) stats = statsData.stats;
    } catch (e) {
      console.warn('[Nova] Storage stats fetch caught:', e);
    }
    let playlists = [];
    try {
      const plRes = await fetch('/api/playlists');
      const plData = await plRes.json();
      if (plData && plData.ok && Array.isArray(plData.playlists)) {
        playlists = plData.playlists;
      }
    } catch (e) {
      console.warn('[Nova] Playlists fetch caught:', e);
    }
    const videosCount = media.filter(m => m.type === 'video').length;
    const audioCount = media.filter(m => m.type === 'audio').length;
    const imagesCount = media.filter(m => m.type === 'image').length;
    const dashStatVideos = document.getElementById('dashStatVideos');
    const dashStatAudio = document.getElementById('dashStatAudio');
    const dashStatSize = document.getElementById('dashStatSize');
    const dashStatPlaylists = document.getElementById('dashStatPlaylists');
    const navLibCount = document.getElementById('navLibCount');
    const navPlaylistCount = document.getElementById('navPlaylistCount');
    if (dashStatVideos) dashStatVideos.textContent = videosCount;
    if (dashStatAudio) dashStatAudio.textContent = audioCount;
    if (dashStatSize && stats) dashStatSize.textContent = stats.totalSizeFormatted || '0 B';
    if (dashStatPlaylists) dashStatPlaylists.textContent = playlists.length;
    if (navLibCount) navLibCount.textContent = media.length;
    if (navPlaylistCount) navPlaylistCount.textContent = playlists.length;
    const rightStatVideos = document.getElementById('rightStatVideos');
    const rightStatAudio = document.getElementById('rightStatAudio');
    const rightStatImages = document.getElementById('rightStatImages');
    const rightStatPlaylists = document.getElementById('rightStatPlaylists');
    if (rightStatVideos) rightStatVideos.textContent = videosCount;
    if (rightStatAudio) rightStatAudio.textContent = audioCount;
    if (rightStatImages) rightStatImages.textContent = imagesCount;
    if (rightStatPlaylists) rightStatPlaylists.textContent = playlists.length;
    const rightExpVideos = document.getElementById('rightExpVideos');
    const rightExpAudio = document.getElementById('rightExpAudio');
    const rightExpImages = document.getElementById('rightExpImages');
    const rightExpPlaylists = document.getElementById('rightExpPlaylists');
    if (rightExpVideos) rightExpVideos.textContent = videosCount;
    if (rightExpAudio) rightExpAudio.textContent = audioCount;
    if (rightExpImages) rightExpImages.textContent = imagesCount;
    if (rightExpPlaylists) rightExpPlaylists.textContent = playlists.length;
    const sideStorageUsed = document.getElementById('sideStorageUsed');
    const sideStorageTotal = document.getElementById('sideStorageTotal');
    const sideStoragePct = document.getElementById('sideStoragePct');
    const sideStorageBar = document.getElementById('sideStorageBar');
    if (stats) {
      if (sideStorageUsed) sideStorageUsed.textContent = stats.totalSizeFormatted || '0 B';
      const updateClientStorageEstimate = async () => {
        let totalFree = stats.diskFreeFormatted || '32 GB';
        let usedBytes = stats.totalSizeBytes || 0;
        let freeBytes = stats.diskFreeBytes || 0;
        if (navigator.storage && navigator.storage.estimate) {
          try {
            const estimate = await navigator.storage.estimate();
            if (estimate.quota && estimate.quota > 0) {
              const deviceQuotaBytes = estimate.quota;
              const deviceUsedBytes = estimate.usage || usedBytes;
              const deviceFreeBytes = Math.max(0, deviceQuotaBytes - deviceUsedBytes);
              freeBytes = deviceFreeBytes;
              totalFree = formatClientBytes(deviceFreeBytes);
            }
          } catch (e) {}
        }
        if (sideStorageTotal) sideStorageTotal.textContent = totalFree + ' free';
        const totalPool = usedBytes + freeBytes;
        let pct = '0.0%';
        if (totalPool > 0) {
          pct = ((usedBytes / totalPool) * 100).toFixed(1) + '%';
        }
        if (sideStoragePct) sideStoragePct.textContent = pct;
        if (sideStorageBar) sideStorageBar.style.width = pct;
      };
      updateClientStorageEstimate();
    }
  }
  function formatClientBytes(bytes) {
    if (!bytes || bytes <= 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  }
  function renderContinueWatchingShelf(mediaList) {
    const container = document.getElementById('continueWatchingShelf');
    if (!container) return;
    let savedPositions = {};
    try {
      savedPositions = JSON.parse(localStorage.getItem('ultimatePlayer.mediaPositions') || '{}');
    } catch (e) {}
    mediaList.forEach(m => {
      if (savedPositions[m.id] && savedPositions[m.id].time > 1) {
        m.playbackPosition = savedPositions[m.id].time;
        if (savedPositions[m.id].duration) m.duration = savedPositions[m.id].duration;
      }
    });
    const inProgress = mediaList.filter(m => m.playbackPosition && m.playbackPosition > 1);
    inProgress.sort((a, b) => {
      const aTime = savedPositions[a.id]?.updatedAt || 0;
      const bTime = savedPositions[b.id]?.updatedAt || 0;
      return bTime - aTime;
    });
    const mostRecentInProgress = inProgress[0] || null;
    const items = inProgress.length ? inProgress.slice(0, 4) : mediaList.slice(0, 4);
    if (items.length === 0) {
      container.innerHTML = '<div style="grid-column: 1/-1; padding: 24px; text-align: center; color: var(--text-muted); background: var(--bg-surface); border-radius: var(--radius-md);">No media available yet. Download or import videos above!</div>';
      return;
    }
    const token = localStorage.getItem('novapulse_auth_token') || '';
    let heroHtml = '';
    if (mostRecentInProgress && mostRecentInProgress.playbackPosition > 5) {
      const curSecs = Math.floor(mostRecentInProgress.playbackPosition);
      const timeStr = `${Math.floor(curSecs / 60)}:${String(curSecs % 60).padStart(2, '0')}`;
      const durSecs = mostRecentInProgress.duration ? Math.floor(mostRecentInProgress.duration) : 0;
      const durStr = durSecs > 0 ? `${Math.floor(durSecs / 60)}:${String(durSecs % 60).padStart(2, '0')}` : '';
      const percent = durSecs > 0 ? Math.min(100, Math.round((curSecs / durSecs) * 100)) : 0;
      heroHtml = `
        <div class="resume-hero-banner" style="grid-column: 1/-1;">
          <div class="resume-hero-left">
            <div class="resume-hero-thumb">
              ${mostRecentInProgress.type === 'video'
                ? `<video src="${mostRecentInProgress.url}#t=${curSecs}" preload="metadata" muted playsinline style="width:100%; height:100%; object-fit:cover; pointer-events:none;"></video>`
                : `<div style="width:100%; height:100%; display:flex; align-items:center; justify-content:center; background:#1e1e2e; color:var(--accent-green);"><i class="fa-solid fa-music"></i></div>`
              }
            </div>
            <div style="min-width: 0;">
              <span class="pill pill-cyan" style="font-size: 0.72rem; padding: 2px 8px; margin-bottom: 4px; display: inline-block;">CONTINUE WATCHING • ${percent}%</span>
              <h4 class="resume-hero-title">${escapeHtml(mostRecentInProgress.name)}</h4>
              <div class="resume-hero-meta">
                <i class="fa-solid fa-clock-rotate-left"></i> Paused at ${timeStr} ${durStr ? `/ ${durStr}` : ''}
              </div>
            </div>
          </div>
          <button class="btn-resume-glow" id="btnHeroResume" data-id="${mostRecentInProgress.id}">
            <i class="fa-solid fa-play"></i> Resume at ${timeStr}
          </button>
        </div>
      `;
    }
    const cardsHtml = items.map(item => {
      let mediaSrc = item.url;
      if (token && mediaSrc && mediaSrc.startsWith('/api/')) {
        mediaSrc += (mediaSrc.includes('?') ? '&' : '?') + 'token=' + encodeURIComponent(token);
      }
      const isVid = item.type === 'video';
      const hasPos = item.playbackPosition && item.playbackPosition > 5;
      const curSecs = hasPos ? Math.floor(item.playbackPosition) : 0;
      const timeStr = `${Math.floor(curSecs / 60)}:${String(curSecs % 60).padStart(2, '0')}`;
      return `
      <div class="shelf-card" data-id="${item.id}">
        <div class="shelf-card-thumb">
          ${isVid 
            ? `<video src="${mediaSrc}#t=${hasPos ? curSecs : 1.0}" preload="metadata" muted playsinline style="width:100%; height:100%; object-fit:cover; pointer-events:none;" onerror="this.style.display='none'; if(this.nextElementSibling) this.nextElementSibling.style.display='flex';"></video>
               <div class="shelf-fallback-icon" style="display:none; width:100%; height:100%; align-items:center; justify-content:center; background:linear-gradient(135deg, rgba(99,102,241,0.15), rgba(168,85,247,0.15));"><i class="fa-solid fa-film" style="color:var(--accent-purple); font-size:1.6rem;"></i></div>` 
            : (item.thumbnail ? `<img src="${item.thumbnail}" alt="" style="width:100%; height:100%; object-fit:cover;" onerror="this.style.display='none'; if(this.nextElementSibling) this.nextElementSibling.style.display='flex';"><div class="shelf-fallback-icon" style="display:none; width:100%; height:100%; align-items:center; justify-content:center; background:linear-gradient(135deg, rgba(16,185,129,0.15), rgba(6,182,212,0.15));"><i class="fa-solid fa-music" style="color:var(--accent-green); font-size:1.6rem;"></i></div>` : `<div style="width:100%; height:100%; display:flex; align-items:center; justify-content:center; background:linear-gradient(135deg, rgba(16,185,129,0.15), rgba(6,182,212,0.15));"><i class="fa-solid fa-music" style="color:var(--accent-green); font-size:1.6rem;"></i></div>`)}
          ${item.duration ? `<span class="shelf-card-duration">${formatTime(item.duration)}</span>` : ''}
          ${hasPos ? `<div class="shelf-card-progress-bar" style="width: ${Math.min(100, (item.playbackPosition / (item.duration || 100)) * 100)}%;"></div>` : ''}
          ${hasPos ? `<span style="position: absolute; bottom: 8px; left: 8px; background: rgba(0,0,0,0.8); color: #6ee7b7; font-size: 0.7rem; font-weight: 700; padding: 2px 7px; border-radius: 4px; border: 1px solid rgba(52,211,153,0.3); font-family: var(--mono);"><i class="fa-solid fa-play" style="font-size:0.6rem;"></i> ${timeStr}</span>` : ''}
        </div>
        <div class="shelf-card-info">
          <div class="shelf-card-title" title="${item.name}">${item.name}</div>
          <div class="shelf-card-meta">
            <span>${item.type.toUpperCase()}</span>
            ${hasPos ? `<span style="color: var(--accent-green); font-weight: 700;"><i class="fa-solid fa-play"></i> Resume at ${timeStr}</span>` : `<span>${formatBytes(item.size)}</span>`}
          </div>
        </div>
      </div>
      `;
    }).join('');
    container.innerHTML = heroHtml + cardsHtml;
    const heroBtn = container.querySelector('#btnHeroResume');
    if (heroBtn) {
      heroBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        const id = heroBtn.getAttribute('data-id');
        const item = mediaList.find(m => m.id === id);
        if (item) {
          if (typeof window.playLibraryTrackWithQueue === 'function') {
            window.playLibraryTrackWithQueue(item);
          } else if (typeof Playlist !== 'undefined') {
            Playlist.addItem(item, true);
            Playlist.playNow(item);
            switchView('player');
          }
        }
      });
    }
    container.querySelectorAll('.shelf-card').forEach(card => {
      card.addEventListener('click', () => {
        const id = card.getAttribute('data-id');
        const item = mediaList.find(m => m.id === id);
        if (item) {
          if (typeof window.playLibraryTrackWithQueue === 'function') {
            window.playLibraryTrackWithQueue(item);
          } else if (typeof Playlist !== 'undefined') {
            Playlist.addItem(item, true);
            Playlist.playNow(item);
            switchView('player');
          }
        }
      });
    });
  }
  function renderRecentDownloadedShelf(mediaList) {
    const container = document.getElementById('homeRecentDownloadsList') || document.getElementById('recentDownloadedShelf');
    if (!container) return;
    const items = (mediaList || []).slice(0, 4);
    if (items.length === 0) {
      container.innerHTML = `
        <div style="padding: 28px 16px; text-align: center; background: var(--bg-surface); border: 1px dashed var(--border-color); border-radius: var(--radius-md); color: var(--text-muted);">
          <i class="fa-solid fa-cloud-arrow-down" style="font-size: 1.8rem; margin-bottom: 10px; color: var(--text-dim); display: block;"></i>
          <div style="font-size: 0.92rem; font-weight: 600; color: var(--text-main); margin-bottom: 4px;">No downloaded media yet</div>
          <div style="font-size: 0.8rem; margin-bottom: 14px;">Paste a video or music link above to download your first media file.</div>
          <button type="button" class="btn-subtle btn-mini" onclick="document.getElementById('urlInput')?.focus()"><i class="fa-solid fa-arrow-up"></i> Go to URL Bar</button>
        </div>
      `;
      return;
    }
    const token = localStorage.getItem('novapulse_auth_token') || '';
    container.innerHTML = items.map(item => {
      let mediaSrc = item.url;
      if (token && mediaSrc && mediaSrc.startsWith('/api/')) {
        mediaSrc += (mediaSrc.includes('?') ? '&' : '?') + 'token=' + encodeURIComponent(token);
      }
      const isVid = item.type === 'video';
      const ext = (item.extension || '').toUpperCase().replace('.', '') || (isVid ? 'MP4' : 'MP3');
      const rawName = item.name || item.filename || item.title || (item.url ? item.url.split('/').pop().split('?')[0] : 'Media File');
      const safeName = escapeHtml(rawName);
      const thumbHtml = isVid
        ? `<video src="${mediaSrc}#t=1.0" preload="metadata" muted playsinline style="width:100%; height:100%; object-fit:cover; pointer-events:none;" onerror="this.style.display='none'; if(this.nextElementSibling) this.nextElementSibling.style.display='flex';"></video>
           <div class="shelf-fallback-icon" style="display:none; width:100%; height:100%; align-items:center; justify-content:center; background:linear-gradient(135deg, rgba(99,102,241,0.15), rgba(168,85,247,0.15));"><i class="fa-solid fa-film" style="color:var(--accent-purple); font-size:1.1rem;"></i></div>`
        : (item.thumbnail
            ? `<img src="${item.thumbnail}" alt="" style="width:100%; height:100%; object-fit:cover;" onerror="this.style.display='none'; if(this.nextElementSibling) this.nextElementSibling.style.display='flex';"><div class="shelf-fallback-icon" style="display:none; width:100%; height:100%; align-items:center; justify-content:center; background:linear-gradient(135deg, rgba(16,185,129,0.15), rgba(6,182,212,0.15));"><i class="fa-solid fa-music" style="color:var(--accent-green); font-size:1.1rem;"></i></div>`
            : `<div style="width:100%; height:100%; display:flex; align-items:center; justify-content:center; background:linear-gradient(135deg, rgba(16,185,129,0.15), rgba(6,182,212,0.15));"><i class="fa-solid fa-music" style="color:var(--accent-green); font-size:1.1rem;"></i></div>`
          );
      return `
        <div class="recent-download-item" data-id="${item.id}">
          <div class="recent-top-row">
            <div class="recent-thumb-wrap">
              ${thumbHtml}
            </div>
            <div class="recent-main-info">
              <div class="recent-title" title="${safeName}">${safeName}</div>
              <div class="recent-meta-tags">
                <span class="recent-ext-tag">${ext}</span>
                <span>&bull;</span>
                <span>${formatBytes(item.size || 0)}</span>
                <span>&bull;</span>
                <span class="recent-status-text"><i class="fa-solid fa-circle-check" style="color:#10b981;"></i> Ready</span>
              </div>
            </div>
          </div>
          <div class="recent-actions-row">
            <button type="button" class="btn-recent-action btn-recent-play" title="Play Media">
              <i class="fa-solid fa-play"></i> <span>Play</span>
            </button>
            <button type="button" class="btn-recent-action btn-recent-folder" title="Browse / Open Folder">
              <i class="fa-regular fa-folder-open"></i> <span>Browse</span>
            </button>
            <button type="button" class="btn-recent-action btn-recent-more" title="More Options">
              <i class="fa-solid fa-ellipsis"></i>
            </button>
          </div>
        </div>
      `;
    }).join('');
    container.querySelectorAll('.recent-download-item').forEach(row => {
      const id = row.getAttribute('data-id');
      const item = mediaList.find(m => m.id === id);
      if (!item) return;
      const triggerPlay = () => {
        if (typeof window.playLibraryTrackWithQueue === 'function') {
          window.playLibraryTrackWithQueue(item);
        } else if (typeof Playlist !== 'undefined') {
          Playlist.addItem(item, true);
          Playlist.playNow(item);
          switchView('player');
        }
      };
      row.addEventListener('click', () => {
        triggerPlay();
      });
      const playBtn = row.querySelector('.btn-recent-play');
      if (playBtn) {
        playBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          triggerPlay();
        });
      }
      const folderBtn = row.querySelector('.btn-recent-folder');
      if (folderBtn) {
        folderBtn.addEventListener('click', async (e) => {
          e.stopPropagation();
          try {
            await fetch('/api/open-folder', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({})
            });
            window.showToast('Opened downloads directory in Windows Explorer', 'check');
          } catch (err) {
            window.showToast('Could not open downloads directory', 'warn');
          }
        });
      }
      const moreBtn = row.querySelector('.btn-recent-more');
      if (moreBtn) {
        moreBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          switchView('library');
        });
      }
    });
  }
  var activeDetailPlaylistId = null;
  var activePlCategoryFilter = 'all';
  function setupPlaylistsView() {
    const btnCreatePlaylistModal = document.getElementById('btnCreatePlaylistModal');
    const createPlaylistModal = document.getElementById('createPlaylistModal');
    const closeCreatePlaylistModal = document.getElementById('closeCreatePlaylistModal');
    const cancelCreatePlaylistBtn = document.getElementById('cancelCreatePlaylistBtn');
    const confirmCreatePlaylistBtn = document.getElementById('confirmCreatePlaylistBtn');
    const newPlaylistNameInput = document.getElementById('newPlaylistNameInput');
    const newPlaylistDescInput = document.getElementById('newPlaylistDescInput');
    const playlistMediaSearch = document.getElementById('playlistMediaFilterInput') || document.getElementById('playlistMediaSearch');
    const playlistSelectAllBtn = document.getElementById('btnSelectAllPlMedia') || document.getElementById('playlistSelectAllBtn');
    const playlistClearAllBtn = document.getElementById('btnClearSelectionPlMedia') || document.getElementById('playlistClearAllBtn');
    const playlistMediaCountBadge = document.getElementById('playlistMediaSelectedCount') || document.getElementById('playlistMediaCountBadge');
    const btnCreatePlCount = document.getElementById('btnCreatePlCount');
    const playlistMediaChecklist = document.getElementById('playlistMediaChecklist');
    let availableMedia = [];
    const selectedMediaIds = new Set();
    let currentModalTypeFilter = 'all';
    function updateSelectedBadge() {
      if (playlistMediaCountBadge) {
        playlistMediaCountBadge.textContent = `${selectedMediaIds.size} selected`;
      }
      if (btnCreatePlCount) {
        btnCreatePlCount.textContent = selectedMediaIds.size;
      }
    }
    function renderMediaChecklist(filterText = '') {
      if (!playlistMediaChecklist) return;
      const lowerFilter = filterText.trim().toLowerCase();
      let filtered = availableMedia;
      if (currentModalTypeFilter && currentModalTypeFilter !== 'all') {
        filtered = filtered.filter(m => {
          const type = (m.type || '').toLowerCase();
          if (currentModalTypeFilter === 'video') return type === 'video' || (!type && !m.extension?.match(/\.(mp3|wav|flac|aac|m4a|png|jpg|jpeg|webp|gif)$/i));
          if (currentModalTypeFilter === 'audio') return type === 'audio' || m.extension?.match(/\.(mp3|wav|flac|aac|m4a|ogg|opus)$/i);
          if (currentModalTypeFilter === 'image') return type === 'image' || m.extension?.match(/\.(png|jpg|jpeg|webp|gif|svg)$/i);
          return true;
        });
      }
      if (lowerFilter) {
        filtered = filtered.filter(m => (m.name || '').toLowerCase().includes(lowerFilter));
      }
      if (filtered.length === 0) {
        playlistMediaChecklist.innerHTML = `
          <div style="padding: 24px; text-align: center; color: var(--text-muted); font-size: 0.88rem;">
            ${availableMedia.length === 0 ? 'No media found in your library yet. Download or extract media first.' : 'No items match your filter.'}
          </div>
        `;
        return;
      }
      playlistMediaChecklist.innerHTML = filtered.map(item => {
        const isChecked = selectedMediaIds.has(item.id);
        const itemType = (item.type || '').toLowerCase();
        const isAud = itemType === 'audio' || item.extension?.match(/\.(mp3|wav|flac|aac|m4a|ogg|opus)$/i);
        const isImg = itemType === 'image' || item.extension?.match(/\.(png|jpg|jpeg|webp|gif|svg)$/i);
        const isVid = !isAud && !isImg;
        let iconClass = 'fa-film';
        let iconColor = 'var(--accent-purple)';
        let badgeType = 'VIDEO';
        if (isAud) {
          iconClass = 'fa-music';
          iconColor = 'var(--accent-green)';
          badgeType = 'AUDIO';
        } else if (isImg) {
          iconClass = 'fa-image';
          iconColor = '#ec4899';
          badgeType = 'IMAGE';
        }
        const safeName = (item.name || 'Untitled').replace(/"/g, '&quot;');
        return `
          <label style="display:flex; align-items:flex-start; gap:12px; padding:9px 12px; border-radius:var(--radius-sm); cursor:pointer; transition: background 0.15s ease; ${isChecked ? 'background: rgba(99, 102, 241, 0.12); border: 1px solid rgba(99, 102, 241, 0.3);' : 'border: 1px solid transparent;'}" class="playlist-media-item-label">
            <input type="checkbox" class="playlist-media-checkbox" data-id="${item.id}" ${isChecked ? 'checked' : ''} style="accent-color: var(--accent-purple); width:16px; height:16px; margin-top:3px; cursor:pointer;">
            <div style="width:32px; height:32px; border-radius:6px; background:var(--bg-card); display:flex; align-items:center; justify-content:center; flex-shrink:0; overflow:hidden;">
              ${isImg && item.url ? `<img src="${item.url}" style="width:100%; height:100%; object-fit:cover;" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';" /><div style="display:none; width:100%; height:100%; align-items:center; justify-content:center;"><i class="fa-solid ${iconClass}" style="color:${iconColor}; font-size:0.85rem;"></i></div>` : `<i class="fa-solid ${iconClass}" style="color:${iconColor}; font-size:0.85rem;"></i>`}
            </div>
            <div style="flex:1; min-width:0;">
              <div class="playlist-media-title-wrap" title="${safeName}">${safeName}</div>
              <div style="font-size:0.75rem; color:var(--text-muted); display:flex; gap:8px;">
                <span style="font-weight:600; color:${iconColor};">${badgeType}</span>
                <span>•</span>
                <span>${formatBytes(item.size || 0)}</span>
              </div>
            </div>
          </label>
        `;
      }).join('');
      playlistMediaChecklist.querySelectorAll('.playlist-media-checkbox').forEach(cb => {
        cb.addEventListener('change', (e) => {
          const id = cb.getAttribute('data-id');
          if (cb.checked) {
            selectedMediaIds.add(id);
          } else {
            selectedMediaIds.delete(id);
          }
          const label = cb.closest('label');
          if (label) {
            label.style.background = cb.checked ? 'rgba(99, 102, 241, 0.12)' : '';
            label.style.border = cb.checked ? '1px solid rgba(99, 102, 241, 0.3)' : '1px solid transparent';
          }
          updateSelectedBadge();
        });
      });
    }
    const mediaTypeTabBtns = document.querySelectorAll('#playlistMediaTypeTabs button[data-pl-filter-type]');
    mediaTypeTabBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        mediaTypeTabBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentModalTypeFilter = btn.getAttribute('data-pl-filter-type') || 'all';
        const filterVal = playlistMediaSearch ? playlistMediaSearch.value : '';
        renderMediaChecklist(filterVal);
      });
    });
    const playlistCatChoices = document.querySelectorAll('#playlistCatChoiceGrid .playlist-cat-choice');
    playlistCatChoices.forEach(btn => {
      btn.addEventListener('click', () => {
        playlistCatChoices.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const cat = btn.getAttribute('data-cat') || 'mixed';
        const catInput = document.getElementById('selectedPlaylistCategory');
        if (catInput) catInput.value = cat;
        const catPresets = {
          mixed: { color: '#00F5FF', icon: 'fa-box-archive' },
          video: { color: '#6366F1', icon: 'fa-film' },
          audio: { color: '#10B981', icon: 'fa-music' },
          image: { color: '#EC4899', icon: 'fa-images' },
          stream: { color: '#38BDF8', icon: 'fa-tower-broadcast' }
        };
        const preset = catPresets[cat];
        if (preset) {
          if (selectedColorInput) selectedColorInput.value = preset.color;
          if (customColorPicker) customColorPicker.value = preset.color;
          if (selectedIconInput) selectedIconInput.value = preset.icon;
          updatePreviewStyle(preset.color, preset.icon);
        }
        if (cat === 'video' || cat === 'audio' || cat === 'image') {
          const matchTab = document.querySelector(`#playlistMediaTypeTabs button[data-pl-filter-type="${cat}"]`);
          if (matchTab) matchTab.click();
        } else {
          const allTab = document.querySelector(`#playlistMediaTypeTabs button[data-pl-filter-type="all"]`);
          if (allTab) allTab.click();
        }
      });
    });
    if (playlistMediaSearch) {
      playlistMediaSearch.addEventListener('input', (e) => {
        renderMediaChecklist(e.target.value);
      });
    }
    if (playlistSelectAllBtn) {
      playlistSelectAllBtn.addEventListener('click', () => {
        const filterVal = playlistMediaSearch ? playlistMediaSearch.value : '';
        const lowerFilter = filterVal.trim().toLowerCase();
        let filtered = availableMedia;
        if (currentModalTypeFilter && currentModalTypeFilter !== 'all') {
          filtered = filtered.filter(m => (m.type || '').toLowerCase() === currentModalTypeFilter);
        }
        if (lowerFilter) {
          filtered = filtered.filter(m => (m.name || '').toLowerCase().includes(lowerFilter));
        }
        filtered.forEach(m => selectedMediaIds.add(m.id));
        renderMediaChecklist(filterVal);
        updateSelectedBadge();
      });
    }
    if (playlistClearAllBtn) {
      playlistClearAllBtn.addEventListener('click', () => {
        selectedMediaIds.clear();
        const filterVal = playlistMediaSearch ? playlistMediaSearch.value : '';
        renderMediaChecklist(filterVal);
        updateSelectedBadge();
      });
    }
    if (btnCreatePlaylistModal && createPlaylistModal) {
      btnCreatePlaylistModal.addEventListener('click', async () => {
        const editingPlaylistId = document.getElementById('editingPlaylistId');
        const playlistModalTitle = document.getElementById('playlistModalTitle');
        const confirmCreatePlaylistBtnText = document.getElementById('confirmCreatePlaylistBtnText');
        if (editingPlaylistId) editingPlaylistId.value = '';
        if (playlistModalTitle) playlistModalTitle.innerHTML = '<i class="fa-solid fa-folder-plus" style="color:var(--accent-purple);"></i> Create Custom Playlist';
        if (confirmCreatePlaylistBtnText) confirmCreatePlaylistBtnText.textContent = 'Create Playlist';
        if (newPlaylistNameInput) newPlaylistNameInput.value = '';
        if (newPlaylistDescInput) newPlaylistDescInput.value = '';
        if (playlistMediaSearch) playlistMediaSearch.value = '';
        selectedMediaIds.clear();
        updateSelectedBadge();
        const catInput = document.getElementById('selectedPlaylistCategory');
        if (catInput) catInput.value = 'mixed';
        playlistCatChoices.forEach(b => b.classList.toggle('active', b.getAttribute('data-cat') === 'mixed'));
        mediaTypeTabBtns.forEach(b => b.classList.toggle('active', b.getAttribute('data-pl-filter-type') === 'all'));
        currentModalTypeFilter = 'all';
        createPlaylistModal.style.display = 'flex';
        setTimeout(() => newPlaylistNameInput && newPlaylistNameInput.focus(), 50);
        if (playlistMediaChecklist) {
          playlistMediaChecklist.innerHTML = `
            <div style="padding: 24px; text-align: center; color: var(--text-muted); font-size: 0.88rem;">
              <i class="fa-solid fa-spinner fa-spin" style="font-size: 1.2rem; color: var(--accent-purple); margin-bottom: 8px;"></i>
              <div>Loading media library...</div>
            </div>
          `;
        }
        try {
          if (typeof Library !== 'undefined') {
            await Library.fetchLibrary();
            availableMedia = Library.getMediaList();
          }
          if (!availableMedia || availableMedia.length === 0) {
            const res = await fetch('/api/library');
            const data = await res.json();
            if (data && data.ok) availableMedia = data.library || [];
          }
        } catch (e) {
          console.error('Failed to load media for playlist modal:', e);
        }
        renderMediaChecklist();
      });
    }
    window.openEditPlaylistModal = async function(playlistId) {
      if (!createPlaylistModal) return;
      const pl = await Playlist.getServerPlaylist(playlistId);
      if (!pl) return alert('Could not find playlist to edit');
      const editingPlaylistId = document.getElementById('editingPlaylistId');
      const playlistModalTitle = document.getElementById('playlistModalTitle');
      const confirmCreatePlaylistBtnText = document.getElementById('confirmCreatePlaylistBtnText');
      if (editingPlaylistId) editingPlaylistId.value = playlistId;
      if (playlistModalTitle) playlistModalTitle.innerHTML = `<i class="fa-solid fa-pen-to-square" style="color:var(--accent-cyan);"></i> Edit Playlist`;
      if (confirmCreatePlaylistBtnText) confirmCreatePlaylistBtnText.textContent = 'Save Changes';
      if (newPlaylistNameInput) newPlaylistNameInput.value = pl.name || '';
      if (newPlaylistDescInput) newPlaylistDescInput.value = pl.description || '';
      if (playlistMediaSearch) playlistMediaSearch.value = '';
      const color = pl.color || '#00F5FF';
      const icon = pl.icon || 'fa-music';
      const category = pl.category || 'mixed';
      const catInput = document.getElementById('selectedPlaylistCategory');
      if (catInput) catInput.value = category;
      playlistCatChoices.forEach(b => b.classList.toggle('active', b.getAttribute('data-cat') === category));
      if (selectedColorInput) selectedColorInput.value = color;
      if (customColorPicker) customColorPicker.value = color;
      if (selectedIconInput) selectedIconInput.value = icon;
      updatePreviewStyle(color, icon);
      document.querySelectorAll('.color-swatch').forEach(s => {
        s.classList.toggle('active', s.getAttribute('data-color') === color);
      });
      document.querySelectorAll('.icon-choice').forEach(b => {
        b.classList.toggle('active', b.getAttribute('data-icon') === icon);
      });
      selectedMediaIds.clear();
      (pl.items || []).forEach(it => {
        const id = typeof it === 'string' ? it : (it ? it.id : null);
        if (id) selectedMediaIds.add(id);
      });
      updateSelectedBadge();
      mediaTypeTabBtns.forEach(b => b.classList.toggle('active', b.getAttribute('data-pl-filter-type') === 'all'));
      currentModalTypeFilter = 'all';
      createPlaylistModal.style.display = 'flex';
      setTimeout(() => newPlaylistNameInput && newPlaylistNameInput.focus(), 50);
      if (availableMedia.length === 0) {
        if (playlistMediaChecklist) {
          playlistMediaChecklist.innerHTML = `
            <div style="padding: 24px; text-align: center; color: var(--text-muted); font-size: 0.88rem;">
              <i class="fa-solid fa-spinner fa-spin" style="font-size: 1.2rem; color: var(--accent-purple); margin-bottom: 8px;"></i>
              <div>Loading media library...</div>
            </div>
          `;
        }
        try {
          if (typeof Library !== 'undefined') {
            await Library.fetchLibrary();
            availableMedia = Library.getMediaList();
          }
          if (!availableMedia || availableMedia.length === 0) {
            const res = await fetch('/api/library');
            const data = await res.json();
            if (data && data.ok) availableMedia = data.library || [];
          }
        } catch (e) {
          console.error(e);
        }
      }
      renderMediaChecklist();
    };
    const hideModal = () => {
      if (createPlaylistModal) createPlaylistModal.style.display = 'none';
      const editingPlaylistId = document.getElementById('editingPlaylistId');
      if (editingPlaylistId) editingPlaylistId.value = '';
    };
    if (closeCreatePlaylistModal) closeCreatePlaylistModal.addEventListener('click', hideModal);
    if (cancelCreatePlaylistBtn) cancelCreatePlaylistBtn.addEventListener('click', hideModal);
    const selectedColorInput = document.getElementById('selectedPlaylistColor');
    const customColorPicker = document.getElementById('playlistCustomColorPicker');
    const previewAvatar = document.getElementById('playlistPreviewAvatar');
    const previewIcon = document.getElementById('playlistPreviewIcon');
    const selectedIconInput = document.getElementById('selectedPlaylistIcon');
    function updatePreviewStyle(color, icon) {
      if (previewAvatar) {
        previewAvatar.style.background = `${color}25`;
        previewAvatar.style.color = color;
        previewAvatar.style.borderColor = color;
        previewAvatar.style.boxShadow = `0 0 14px ${color}55`;
      }
      if (previewIcon && icon) {
        previewIcon.className = `fa-solid ${icon}`;
      }
    }
    document.querySelectorAll('.color-swatch').forEach(swatch => {
      swatch.addEventListener('click', () => {
        document.querySelectorAll('.color-swatch').forEach(s => s.classList.remove('active'));
        swatch.classList.add('active');
        const color = swatch.getAttribute('data-color');
        if (selectedColorInput) selectedColorInput.value = color;
        if (customColorPicker) customColorPicker.value = color;
        const currentIcon = selectedIconInput ? selectedIconInput.value : 'fa-music';
        updatePreviewStyle(color, currentIcon);
      });
    });
    if (customColorPicker) {
      customColorPicker.addEventListener('input', (e) => {
        document.querySelectorAll('.color-swatch').forEach(s => s.classList.remove('active'));
        const color = e.target.value;
        if (selectedColorInput) selectedColorInput.value = color;
        const currentIcon = selectedIconInput ? selectedIconInput.value : 'fa-music';
        updatePreviewStyle(color, currentIcon);
      });
    }
    document.querySelectorAll('.icon-choice').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.icon-choice').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const icon = btn.getAttribute('data-icon');
        if (selectedIconInput) selectedIconInput.value = icon;
        const currentColor = selectedColorInput ? selectedColorInput.value : '#00F5FF';
        updatePreviewStyle(currentColor, icon);
      });
    });
    if (confirmCreatePlaylistBtn) {
      confirmCreatePlaylistBtn.addEventListener('click', async () => {
        const name = newPlaylistNameInput ? newPlaylistNameInput.value.trim() : '';
        const desc = newPlaylistDescInput ? newPlaylistDescInput.value.trim() : '';
        if (!name) return alert('Please enter a playlist title');
        const color = selectedColorInput ? selectedColorInput.value : '#00F5FF';
        const icon = selectedIconInput ? selectedIconInput.value : 'fa-music';
        const category = document.getElementById('selectedPlaylistCategory')?.value || 'mixed';
        const editingPlaylistId = document.getElementById('editingPlaylistId');
        const editId = editingPlaylistId ? editingPlaylistId.value : null;
        let existingItemsMap = new Map();
        if (editId) {
          try {
            const currentPl = await Playlist.getServerPlaylist(editId);
            if (currentPl && Array.isArray(currentPl.items)) {
              currentPl.items.forEach(it => {
                const itId = typeof it === 'string' ? it : (it ? it.id : null);
                if (itId) existingItemsMap.set(itId, it.repeatCount || 1);
              });
            }
          } catch(e) {}
        }
        const selectedItems = availableMedia
          .filter(m => selectedMediaIds.has(m.id))
          .map(m => ({
            ...m,
            repeatCount: existingItemsMap.has(m.id) ? existingItemsMap.get(m.id) : (m.repeatCount || 1)
          }));
        confirmCreatePlaylistBtn.disabled = true;
        if (editId) {
          await Playlist.updateServerPlaylist(editId, {
            name,
            description: desc,
            color,
            icon,
            category,
            items: selectedItems
          });
          if (typeof showNovaToast === 'function') {
            showNovaToast(`Updated playlist "${name}"!`, 'fa-circle-check');
          }
          if (activeDetailPlaylistId === editId) {
            openPlaylistDetail(editId);
          }
        } else {
          const pl = await Playlist.createServerPlaylist(name, desc, selectedItems, color, icon, category);
          if (typeof showNovaToast === 'function') {
            showNovaToast(`Created playlist "${name}"!`, 'fa-circle-check');
          }
        }
        confirmCreatePlaylistBtn.disabled = false;
        hideModal();
        loadAndRenderPlaylists();
      });
    }
  }
  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }
  function formatDurationTotal(items) {
    if (!Array.isArray(items) || items.length === 0) return '0 mins';
    const totalSecs = items.reduce((acc, it) => acc + (it.duration || 0), 0);
    if (totalSecs === 0) return `${items.length} track${items.length === 1 ? '' : 's'}`;
    const hrs = Math.floor(totalSecs / 3600);
    const mins = Math.floor((totalSecs % 3600) / 60);
    if (hrs > 0) return `${hrs} hr ${mins} min`;
    return `${mins} min`;
  }
  async function loadAndRenderPlaylists() {
    const grid = document.getElementById('playlistsGrid');
    if (!grid) return;
    const overviewSection = document.getElementById('playlistsOverviewSection');
    const detailSection = document.getElementById('playlistDetailSection');
    if (overviewSection && !activeDetailPlaylistId) {
      overviewSection.style.display = 'block';
    }
    const playlists = await Playlist.fetchServerPlaylists();
    const counts = { all: playlists.length, video: 0, audio: 0, image: 0, stream: 0, mixed: 0 };
    playlists.forEach(p => {
      const c = (p.category || 'mixed').toLowerCase();
      if (counts[c] !== undefined) counts[c]++;
      else counts.mixed++;
    });
    const countEls = {
      all: document.getElementById('plCountAll'),
      video: document.getElementById('plCountVideo'),
      audio: document.getElementById('plCountAudio'),
      image: document.getElementById('plCountImage'),
      stream: document.getElementById('plCountStream'),
      mixed: document.getElementById('plCountMixed')
    };
    for (const [k, el] of Object.entries(countEls)) {
      if (el) el.textContent = counts[k] || 0;
    }
    const catTabs = document.querySelectorAll('#playlistCategoryFilters .playlist-cat-tab');
    catTabs.forEach(tab => {
      tab.onclick = () => {
        catTabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        activePlCategoryFilter = tab.getAttribute('data-cat') || 'all';
        renderCards();
      };
    });
    const catMeta = {
      video: { icon: 'fa-film', label: 'Video', color: 'var(--accent-purple)' },
      audio: { icon: 'fa-music', label: 'Audio', color: 'var(--accent-green)' },
      image: { icon: 'fa-images', label: 'Images', color: '#ec4899' },
      stream: { icon: 'fa-tower-broadcast', label: 'Stream', color: '#38bdf8' },
      mixed: { icon: 'fa-box-archive', label: 'Mixed', color: '#f59e0b' }
    };
    function renderCards() {
      let filtered = playlists;
      if (activePlCategoryFilter && activePlCategoryFilter !== 'all') {
        filtered = playlists.filter(p => (p.category || 'mixed').toLowerCase() === activePlCategoryFilter);
      }
      if (filtered.length === 0) {
        grid.innerHTML = `
          <div style="grid-column: 1/-1; text-align: center; padding: 48px; background: var(--bg-surface); border: 1px dashed var(--border-strong); border-radius: var(--radius-lg);">
            <i class="fa-solid fa-folder-open" style="font-size: 2.5rem; color: var(--text-dim); margin-bottom: 12px;"></i>
            <h3>${playlists.length === 0 ? 'No Custom Playlists Yet' : 'No Playlists in this Category'}</h3>
            <p style="color: var(--text-muted); max-width: 400px; margin: 8px auto 20px;">
              ${playlists.length === 0 ? 'Organize and collect your favorite videos, audio tracks, and images into custom playlists.' : 'Create a new playlist in this category or switch category tabs above.'}
            </p>
            <button class="btn-primary" onclick="document.getElementById('btnCreatePlaylistModal').click()">
              <i class="fa-solid fa-plus"></i> Create Playlist
            </button>
          </div>
        `;
        return;
      }
      grid.innerHTML = filtered.map(pl => {
        const plColor = pl.color || '#00F5FF';
        const plIcon = pl.icon || 'fa-music';
        const catKey = (pl.category || 'mixed').toLowerCase();
        const catInfo = catMeta[catKey] || catMeta.mixed;
        const itemCount = pl.items ? pl.items.length : 0;
        return `
        <div class="playlist-card-item" data-pl-id="${pl.id}" style="--pl-accent: ${plColor}; border-top: 3px solid ${plColor};">
          <!-- Top Row: Icon/Thumbnail on Left, Title & Meta on Right -->
          <div class="playlist-card-top-row">
            <div class="playlist-card-icon" style="background: ${plColor}22; color: ${plColor}; border: 1px solid ${plColor}66; box-shadow: 0 0 12px ${plColor}33;">
              <i class="fa-solid ${plIcon}"></i>
            </div>
            <div class="playlist-card-info-col">
              <div class="playlist-card-header-line">
                <span class="playlist-category-pill pill-${catKey}" style="font-size:0.68rem; padding: 2px 8px; border-radius: 999px; background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.12); color: ${catInfo.color}; font-weight: 700; display: inline-flex; align-items: center; gap: 4px;">
                  <i class="fa-solid ${catInfo.icon}"></i> ${catInfo.label.toUpperCase()}
                </span>
                <span class="playlist-card-count-badge">${itemCount} item${itemCount === 1 ? '' : 's'}</span>
              </div>
              <div class="playlist-card-title">${escapeHtml(pl.name)}</div>
              <div class="playlist-card-desc">${escapeHtml(pl.description || 'Personal collection')}</div>
            </div>
          </div>
          <!-- Bottom Row: Centered Action Buttons (Open, Play All, Edit, Delete) -->
          <div class="playlist-card-bottom-actions">
            <button class="btn-primary btn-mini btn-open-pl" data-pl-id="${pl.id}" style="background: ${plColor}; color: #000; font-weight: 700; border: none;">
              <i class="fa-solid fa-folder-open"></i> Open
            </button>
            <button class="btn-subtle btn-mini btn-play-pl" data-pl-id="${pl.id}" title="Play All">
              <i class="fa-solid fa-play"></i> Play All
            </button>
            <button class="btn-ghost btn-mini btn-edit-playlist" data-pl-id="${pl.id}" title="Edit Playlist" style="color: var(--accent-cyan);">
              <i class="fa-solid fa-pen-to-square"></i> Edit
            </button>
            <button class="btn-ghost btn-mini btn-del-playlist" data-pl-id="${pl.id}" title="Delete Playlist" style="color: var(--accent-red);">
              <i class="fa-solid fa-trash-can"></i>
            </button>
          </div>
        </div>
        `;
      }).join('');
      grid.querySelectorAll('.btn-edit-playlist').forEach(btn => {
        btn.addEventListener('click', (e) => {
          e.stopPropagation();
          const id = btn.getAttribute('data-pl-id');
          if (typeof window.openEditPlaylistModal === 'function') {
            window.openEditPlaylistModal(id);
          }
        });
      });
      grid.querySelectorAll('.btn-del-playlist').forEach(btn => {
        btn.addEventListener('click', async (e) => {
          e.stopPropagation();
          const id = btn.getAttribute('data-pl-id');
          if (confirm('Are you sure you want to delete this playlist?')) {
            await Playlist.deleteServerPlaylist(id);
            loadAndRenderPlaylists();
          }
        });
      });
      grid.querySelectorAll('.btn-play-pl').forEach(btn => {
        btn.addEventListener('click', (e) => {
          e.stopPropagation();
          const id = btn.getAttribute('data-pl-id');
          const targetPl = playlists.find(p => p.id === id);
          if (targetPl && targetPl.items && targetPl.items.length) {
            const resolved = resolvePlaylistItems(targetPl.items);
            if (typeof Playlist !== 'undefined' && typeof Playlist.setQueue === 'function') {
              Playlist.setQueue(resolved, 0, true);
            } else if (typeof Playlist !== 'undefined') {
              Playlist.clear();
              Playlist.addItems(resolved);
              Playlist.selectIndex(0, true);
            }
            if (resolved[0]) recordActivePlaylistPlayback(targetPl, 0, resolved[0]);
            switchView('player');
          } else {
            alert('This playlist is empty. Open it to add items!');
          }
        });
      });
      grid.querySelectorAll('.playlist-card-item').forEach(card => {
        card.addEventListener('click', (e) => {
          if (e.target.closest('.btn-del-playlist') || e.target.closest('.btn-play-pl')) return;
          const id = card.getAttribute('data-pl-id');
          openPlaylistDetail(id);
        });
      });
    }
    renderCards();
  }
  function decodeMediaIdToUrl(id) {
    if (!id || typeof id !== 'string') return '';
    try {
      const b64 = id.replace(/^media_/, '').replace(/-/g, '+').replace(/_/g, '/');
      const relPath = decodeURIComponent(escape(atob(b64)));
      return '/api/media/' + relPath.replace(/\\/g, '/').split('/').map(seg => encodeURIComponent(seg)).join('/');
    } catch(e) {
      return '/api/media/' + encodeURIComponent(id.replace(/^media_/, ''));
    }
  }
  function resolvePlaylistItems(rawItems) {
    let allLibItems = [];
    if (typeof Library !== 'undefined' && typeof Library.getMediaList === 'function') {
      allLibItems = Library.getMediaList() || [];
    }
    const resolvedList = [];
    for (const it of (rawItems || [])) {
      if (!it) continue;
      let base = null;
      if (typeof it === 'string') {
        const found = allLibItems.find(libItem => libItem.id === it);
        if (found) {
          base = { ...found, repeatCount: 1 };
        } else if (it.startsWith('http://') || it.startsWith('https://')) {
          base = { id: it, name: 'Stream', type: 'stream', url: it, repeatCount: 1 };
        }
      } else if (it && typeof it === 'object') {
        const found = it.id ? allLibItems.find(libItem => libItem.id === it.id) : null;
        if (found) {
          base = { ...found, ...it };
        } else if (it.url && (it.url.startsWith('http://') || it.url.startsWith('https://'))) {
          base = { ...it };
        }
      }
      if (!base) continue; // Prune deleted local media from playlist playback
      if (!base.url && base.id) {
        base.url = decodeMediaIdToUrl(base.id);
      }
      let rc = base.repeatCount;
      if (rc === 'infinite' || rc === 'Infinity' || rc === '∞' || rc === 'inf' || rc === Infinity) {
        rc = 'infinite';
      } else {
        rc = Math.max(1, parseInt(rc, 10) || 1);
      }
      base.repeatCount = rc;
      resolvedList.push(base);
    }
    return resolvedList;
  }
  async function openPlaylistDetail(playlistId) {
    activeDetailPlaylistId = playlistId;
    const overviewSection = document.getElementById('playlistsOverviewSection');
    const detailSection = document.getElementById('playlistDetailSection');
    if (!detailSection) return;
    if (overviewSection) overviewSection.style.display = 'none';
    detailSection.style.display = 'block';
    const pl = await Playlist.getServerPlaylist(playlistId);
    if (!pl) {
      alert('Playlist could not be loaded.');
      if (overviewSection) overviewSection.style.display = 'block';
      detailSection.style.display = 'none';
      activeDetailPlaylistId = null;
      return;
    }
    pl.items = resolvePlaylistItems(pl.items);
    const titleEl = document.getElementById('playlistDetailTitle');
    const descEl = document.getElementById('playlistDetailDesc');
    const countEl = document.getElementById('playlistDetailItemCount');
    const durationEl = document.getElementById('playlistDetailDuration');
    const artIconEl = document.querySelector('.playlist-art-icon');
    const artBoxEl = document.querySelector('.playlist-detail-art');
    const catBadgeEl = document.getElementById('playlistDetailCategoryBadge');
    const plColor = pl.color || '#00F5FF';
    const plIcon = pl.icon || 'fa-compact-disc';
    const catKey = (pl.category || 'mixed').toLowerCase();
    const catMeta = {
      video: { icon: 'fa-film', label: 'Video' },
      audio: { icon: 'fa-music', label: 'Audio' },
      image: { icon: 'fa-images', label: 'Images' },
      stream: { icon: 'fa-tower-broadcast', label: 'Stream' },
      mixed: { icon: 'fa-box-archive', label: 'Mixed' }
    };
    const cInfo = catMeta[catKey] || catMeta.mixed;
    if (catBadgeEl) {
      catBadgeEl.className = `playlist-category-pill pill-${catKey}`;
      catBadgeEl.innerHTML = `<i class="fa-solid ${cInfo.icon}"></i> ${cInfo.label.toUpperCase()}`;
    }
    if (artIconEl) {
      artIconEl.className = `fa-solid ${plIcon} playlist-art-icon`;
    }
    if (artBoxEl) {
      artBoxEl.style.background = `linear-gradient(135deg, ${plColor}33, ${plColor}11)`;
      artBoxEl.style.border = `1px solid ${plColor}66`;
      artBoxEl.style.color = plColor;
      artBoxEl.style.boxShadow = `0 0 30px ${plColor}44`;
    }
    if (titleEl) titleEl.textContent = pl.name;
    if (descEl) descEl.textContent = pl.description || 'Personal Collection';
    const items = pl.items || [];
    if (countEl) countEl.innerHTML = `<i class="fa-solid ${cInfo.icon}"></i> ${items.length} items`;
    if (durationEl) durationEl.innerHTML = `<i class="fa-solid fa-clock"></i> ${formatDurationTotal(items)}`;
    const btnPlayCurrent = document.getElementById('btnPlayCurrentPlaylist');
    if (btnPlayCurrent) {
      btnPlayCurrent.onclick = () => {
        if (!pl.items || pl.items.length === 0) {
          return alert('This playlist has no items yet. Click "Add Videos" to include tracks!');
        }
        const resolved = resolvePlaylistItems(pl.items);
        if (typeof Playlist !== 'undefined' && typeof Playlist.setShuffle === 'function' && Playlist.getIsShuffle()) {
          Playlist.setShuffle(false);
          const bShuff = document.getElementById('btnShuffle');
          if (bShuff) bShuff.classList.remove('active');
          const rShuff = document.getElementById('rightNpShuffle');
          if (rShuff) rShuff.style.color = '';
        }
        if (typeof Playlist !== 'undefined' && typeof Playlist.setQueue === 'function') {
          Playlist.setQueue(resolved, 0, true);
        } else if (typeof Playlist !== 'undefined') {
          Playlist.clear();
          Playlist.addItems(resolved);
          Playlist.selectIndex(0, true);
        }
        if (resolved[0]) recordActivePlaylistPlayback(pl, 0, resolved[0]);
        switchView('player');
        if (typeof window.syncPlayerStudioUI === 'function') {
          window.syncPlayerStudioUI();
        }
      };
    }
    const btnAddVideos = document.getElementById('btnAddVideosToCurrentPlaylistBtn');
    if (btnAddVideos) {
      btnAddVideos.onclick = () => {
        openAddVideosToPlaylistModal(pl);
      };
    }
    const btnEditDetail = document.getElementById('btnEditDetailPlaylist');
    if (btnEditDetail) {
      btnEditDetail.onclick = () => {
        if (typeof window.openEditPlaylistModal === 'function') {
          window.openEditPlaylistModal(playlistId);
        }
      };
    }
    const btnBack = document.getElementById('btnBackToPlaylists');
    if (btnBack) {
      btnBack.onclick = () => {
        activeDetailPlaylistId = null;
        detailSection.style.display = 'none';
        if (overviewSection) overviewSection.style.display = 'block';
        loadAndRenderPlaylists();
      };
    }
    const btnSmart = document.getElementById('btnSmartArrangePlaylist');
    if (btnSmart) {
      btnSmart.onclick = async () => {
        if (!pl.items || pl.items.length <= 1) return;
        pl.items.sort((a, b) => {
          const nameA = (a.name || a.filename || '').trim();
          const nameB = (b.name || b.filename || '').trim();
          return nameA.localeCompare(nameB, undefined, { numeric: true, sensitivity: 'base' });
        });
        await Playlist.updateServerPlaylist(pl.id, { items: pl.items });
        renderDetailTracklist(pl);
        if (typeof showNovaToast === 'function') {
          showNovaToast('Playlist aligned smartly (Chapters & Episodes sorted)', 'fa-arrow-down-1-9');
        }
      };
    }
    renderDetailTracklist(pl);
  }
  function renderDetailTracklist(pl) {
    const container = document.getElementById('playlistDetailTracklist');
    if (!container) return;
    pl.items = resolvePlaylistItems(pl.items);
    const items = pl.items || [];
    if (items.length === 0) {
      container.innerHTML = `
        <div style="text-align: center; padding: 48px 24px; background: var(--bg-surface); border: 1px dashed var(--border-strong); border-radius: var(--radius-lg); margin-top: 10px;">
          <i class="fa-solid fa-film" style="font-size: 2.2rem; color: var(--text-dim); margin-bottom: 12px;"></i>
          <h3 style="margin: 0 0 6px;">No Media In This Playlist</h3>
          <p style="color: var(--text-muted); font-size: 0.9rem; margin: 0 0 16px;">Add songs and videos from your downloaded library.</p>
          <button class="btn-primary" onclick="document.getElementById('btnAddVideosToCurrentPlaylistBtn').click()">
            <i class="fa-solid fa-plus"></i> Add Videos From Library
          </button>
        </div>
      `;
      return;
    }
    container.innerHTML = items.map((item, idx) => {
      const itemType = (item.type || '').toLowerCase();
      const isAud = itemType === 'audio' || item.extension?.match(/\.(mp3|wav|flac|aac|m4a|ogg|opus)$/i);
      const isImg = itemType === 'image' || item.extension?.match(/\.(png|jpg|jpeg|webp|gif|svg)$/i);
      const isVid = !isAud && !isImg;
      let iconClass = 'fa-film';
      let iconColor = 'var(--accent-purple)';
      let badgeType = 'VIDEO';
      if (isAud) {
        iconClass = 'fa-music';
        iconColor = 'var(--accent-green)';
        badgeType = 'AUDIO';
      } else if (isImg) {
        iconClass = 'fa-image';
        iconColor = '#ec4899';
        badgeType = 'IMAGE';
      }
      const safeName = escapeHtml(item.name || 'Untitled');
      const isInf = item.repeatCount === 'infinite' || item.repeatCount === 'Infinity' || item.repeatCount === '∞' || item.repeatCount === 'inf' || item.repeatCount === Infinity;
      const displayVal = isInf ? '∞' : `${item.repeatCount || 1}x`;
      const mediaSrc = item.url ? (item.url + '#t=1.0') : '';
      let thumbHtml = '';
      if (isImg && item.url) {
        thumbHtml = `<img src="${item.url}" style="width:100%; height:100%; object-fit:cover; border-radius:4px;" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';" /><div style="display:none; width:100%; height:100%; align-items:center; justify-content:center; background:var(--bg-card);"><i class="fa-solid fa-image" style="color:#ec4899;"></i></div>`;
      } else if (isVid) {
        thumbHtml = `<video src="${mediaSrc}" preload="metadata" muted playsinline style="width:100%; height:100%; object-fit:cover; pointer-events:none;" onerror="this.style.display='none'; if(this.nextElementSibling) this.nextElementSibling.style.display='flex';"></video><div style="display:none; width:100%; height:100%; align-items:center; justify-content:center; background:var(--bg-card);"><i class="fa-solid ${iconClass}" style="color:${iconColor};"></i></div>`;
      } else {
        thumbHtml = `<div style="width:100%; height:100%; display:flex; align-items:center; justify-content:center; background:var(--bg-card);"><i class="fa-solid ${iconClass}" style="color:${iconColor}; font-size:1.1rem;"></i></div>`;
      }
      return `
        <div class="playlist-track-row pl-draggable-row" data-idx="${idx}" data-id="${item.id}" draggable="true">
          <span class="pl-track-drag-handle" title="Drag or hold to reorder"><i class="fa-solid fa-grip-vertical"></i></span>
          <span class="playlist-track-num">${idx + 1}</span>
          <div class="playlist-track-thumb-wrap" data-idx="${idx}" title="${isImg ? 'Click to view image' : 'Click to play'}">
            ${thumbHtml}
            <button class="playlist-track-play-btn btn-track-quickplay" data-idx="${idx}" title="${isImg ? 'View Image' : 'Play Track'}">
              <i class="fa-solid ${isImg ? 'fa-eye' : 'fa-play'}"></i>
            </button>
          </div>
          <div class="playlist-track-info" data-idx="${idx}" style="cursor: pointer;" title="Click to open this item">
            <div class="playlist-track-title" title="${safeName}">${safeName}</div>
            <div class="playlist-track-meta">
              <span style="font-weight:600; color:${iconColor};">${badgeType}</span>
              <span>•</span>
              <span>${(item.extension || '').toUpperCase().replace('.', '')}</span>
              <span>•</span>
              <span>${formatBytes(item.size || 0)}</span>
              ${item.duration ? `<span>•</span><span>${formatTime(item.duration)}</span>` : ''}
            </div>
          </div>
          <!-- Per-Track Custom Loop/Repeat Stepper & Direct Typing Input -->
          <div class="playlist-track-loop-widget" title="Set loop count (type 2, 3... or click ∞ for infinite loop)">
            <span class="track-loop-label"><i class="fa-solid fa-repeat"></i> Loop:</span>
            <button class="track-loop-btn btn-loop-minus" data-idx="${idx}" title="Decrease repeats"><i class="fa-solid fa-minus"></i></button>
            <input type="text" class="track-loop-input" id="trackLoopInput_${idx}" data-idx="${idx}" value="${displayVal}" title="Type number of loops (e.g. 2, 3) or inf / ∞" />
            <button class="track-loop-btn btn-loop-plus" data-idx="${idx}" title="Increase repeats"><i class="fa-solid fa-plus"></i></button>
            <button class="track-loop-btn btn-loop-inf ${isInf ? 'active' : ''}" data-idx="${idx}" title="${isInf ? 'Disable infinite loop' : 'Set infinite loop (∞)'}"><i class="fa-solid fa-infinity"></i></button>
          </div>
          <!-- Actions -->
          <div class="playlist-track-actions">
            <button class="btn-subtle btn-mini btn-track-quickplay" data-idx="${idx}" title="Play this video">
              <i class="fa-solid fa-play"></i> Play
            </button>
            ${idx > 0 ? `<button class="btn-ghost btn-mini btn-move-up" data-idx="${idx}" title="Move Up"><i class="fa-solid fa-arrow-up"></i></button>` : ''}
            ${idx < items.length - 1 ? `<button class="btn-ghost btn-mini btn-move-down" data-idx="${idx}" title="Move Down"><i class="fa-solid fa-arrow-down"></i></button>` : ''}
            <button class="btn-ghost btn-mini btn-del-track" data-id="${item.id}" title="Remove from playlist" style="color: var(--accent-red);">
              <i class="fa-solid fa-trash-can"></i>
            </button>
          </div>
        </div>
      `;
    }).join('');
    function playPlaylistTrack(idx) {
      if (idx < 0 || idx >= items.length) return;
      if (typeof Playlist !== 'undefined' && typeof Playlist.setShuffle === 'function' && Playlist.getIsShuffle()) {
        Playlist.setShuffle(false);
        const bShuff = document.getElementById('btnShuffle');
        if (bShuff) bShuff.classList.remove('active');
        const rShuff = document.getElementById('rightNpShuffle');
        if (rShuff) rShuff.style.color = '';
      }
      if (typeof Playlist !== 'undefined' && typeof Playlist.setQueue === 'function') {
        Playlist.setQueue(items, idx, true);
      } else if (typeof Playlist !== 'undefined') {
        Playlist.clear();
        Playlist.addItems(items);
        Playlist.selectIndex(idx, true);
      }
      try {
        recordActivePlaylistPlayback(pl, idx, items[idx]);
      } catch(e) {}
      switchView('player');
      if (typeof window.syncPlayerStudioUI === 'function') {
        window.syncPlayerStudioUI();
      }
      if (typeof Player !== 'undefined' && typeof Player.play === 'function') {
        setTimeout(() => { Player.play(); }, 50);
      }
    }
    async function applyLoopCount(idx, rawVal) {
      const item = items[idx];
      if (!item) return;
      const str = String(rawVal).trim().toLowerCase();
      const isInf = str === 'inf' || str === 'infinity' || str === '∞' || str === 'infinite' || str === 'loop' || str === 'forever';
      let cleanVal;
      if (isInf) {
        cleanVal = 'infinite';
        item.repeatCount = 'infinite';
      } else {
        const num = parseInt(str.replace(/[^0-9]/g, ''), 10);
        const count = isNaN(num) || num < 1 ? 1 : num;
        cleanVal = `${count}x`;
        item.repeatCount = count;
      }
      const inputEl = document.getElementById(`trackLoopInput_${idx}`);
      if (inputEl) inputEl.value = isInf ? '∞' : cleanVal;
      const infBtn = container.querySelector(`.btn-loop-inf[data-idx="${idx}"]`);
      if (infBtn) {
        if (isInf) {
          infBtn.classList.add('active');
          infBtn.title = 'Disable infinite loop';
        } else {
          infBtn.classList.remove('active');
          infBtn.title = 'Set infinite loop (∞)';
        }
      }
      if (typeof Playlist !== 'undefined') {
        Playlist.setItemRepeatCount(idx, item.repeatCount);
      }
      if (typeof showNovaToast === 'function') {
        if (isInf) {
          showNovaToast(`"${item.name || 'Track'}" set to loop infinitely (∞)`, 'fa-repeat');
        } else {
          showNovaToast(`"${item.name || 'Track'}" set to play ${item.repeatCount}x`, 'fa-repeat');
        }
      }
      await Playlist.updateServerPlaylist(pl.id, { items });
    }
    container.querySelectorAll('.btn-track-quickplay').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const idx = parseInt(btn.getAttribute('data-idx'), 10);
        playPlaylistTrack(idx);
      });
    });
    container.querySelectorAll('.playlist-track-thumb-wrap').forEach(thumb => {
      thumb.addEventListener('click', (e) => {
        e.stopPropagation();
        const idx = parseInt(thumb.getAttribute('data-idx'), 10);
        playPlaylistTrack(idx);
      });
    });
    container.querySelectorAll('.playlist-track-info').forEach(info => {
      info.addEventListener('click', (e) => {
        e.stopPropagation();
        const idx = parseInt(info.getAttribute('data-idx'), 10);
        playPlaylistTrack(idx);
      });
    });
    container.querySelectorAll('.pl-draggable-row').forEach(row => {
      row.addEventListener('click', (e) => {
        if (e.target.closest('button, input, select, .pl-track-drag-handle, .playlist-track-loop-widget')) return;
        const idx = parseInt(row.getAttribute('data-idx'), 10);
        playPlaylistTrack(idx);
      });
    });
    container.querySelectorAll('.track-loop-input').forEach(input => {
      input.addEventListener('click', (e) => e.stopPropagation());
      input.addEventListener('change', async (e) => {
        e.stopPropagation();
        const idx = parseInt(input.getAttribute('data-idx'), 10);
        await applyLoopCount(idx, input.value);
      });
      input.addEventListener('keydown', async (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          input.blur();
        }
      });
    });
    container.querySelectorAll('.btn-loop-plus').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const idx = parseInt(btn.getAttribute('data-idx'), 10);
        const item = items[idx];
        if (!item) return;
        const isInf = item.repeatCount === 'infinite' || item.repeatCount === 'Infinity' || item.repeatCount === '∞' || item.repeatCount === Infinity;
        if (isInf) {
          await applyLoopCount(idx, 2);
        } else {
          const nextCount = (parseInt(item.repeatCount, 10) || 1) + 1;
          await applyLoopCount(idx, nextCount);
        }
      });
    });
    container.querySelectorAll('.btn-loop-minus').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const idx = parseInt(btn.getAttribute('data-idx'), 10);
        const item = items[idx];
        if (!item) return;
        const isInf = item.repeatCount === 'infinite' || item.repeatCount === 'Infinity' || item.repeatCount === '∞' || item.repeatCount === Infinity;
        if (isInf) {
          await applyLoopCount(idx, 1);
        } else {
          const nextCount = Math.max(1, (parseInt(item.repeatCount, 10) || 1) - 1);
          await applyLoopCount(idx, nextCount);
        }
      });
    });
    container.querySelectorAll('.btn-loop-inf').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const idx = parseInt(btn.getAttribute('data-idx'), 10);
        const item = items[idx];
        if (!item) return;
        const isInf = item.repeatCount === 'infinite' || item.repeatCount === 'Infinity' || item.repeatCount === '∞' || item.repeatCount === Infinity;
        if (isInf) {
          await applyLoopCount(idx, 1);
        } else {
          await applyLoopCount(idx, 'infinite');
        }
      });
    });
    let plDragSrcIdx = null;
    container.querySelectorAll('.pl-draggable-row').forEach(row => {
      row.addEventListener('dragstart', (e) => {
        plDragSrcIdx = parseInt(row.getAttribute('data-idx'), 10);
        row.classList.add('is-dragging');
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', plDragSrcIdx.toString());
      });
      row.addEventListener('dragend', () => {
        row.classList.remove('is-dragging');
        container.querySelectorAll('.pl-draggable-row').forEach(r => r.classList.remove('drag-over-target'));
      });
      row.addEventListener('dragover', (e) => {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        container.querySelectorAll('.pl-draggable-row').forEach(r => r.classList.remove('drag-over-target'));
        row.classList.add('drag-over-target');
      });
      row.addEventListener('dragleave', () => {
        row.classList.remove('drag-over-target');
      });
      row.addEventListener('drop', async (e) => {
        e.preventDefault();
        row.classList.remove('drag-over-target');
        const toIdx = parseInt(row.getAttribute('data-idx'), 10);
        if (plDragSrcIdx !== null && plDragSrcIdx !== toIdx) {
          const [moved] = items.splice(plDragSrcIdx, 1);
          items.splice(toIdx, 0, moved);
          await Playlist.updateServerPlaylist(pl.id, { items });
          renderDetailTracklist(pl);
          if (typeof showNovaToast === 'function') {
            showNovaToast(`Moved "${moved.name || 'Video'}" to position #${toIdx + 1}`, 'fa-arrow-up-down');
          }
        }
        plDragSrcIdx = null;
      });
    });
    container.querySelectorAll('.btn-move-up').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const idx = parseInt(btn.getAttribute('data-idx'), 10);
        if (idx > 0) {
          const temp = items[idx];
          items[idx] = items[idx - 1];
          items[idx - 1] = temp;
          await Playlist.updateServerPlaylist(pl.id, { items });
          renderDetailTracklist(pl);
        }
      });
    });
    container.querySelectorAll('.btn-move-down').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const idx = parseInt(btn.getAttribute('data-idx'), 10);
        if (idx < items.length - 1) {
          const temp = items[idx];
          items[idx] = items[idx + 1];
          items[idx + 1] = temp;
          await Playlist.updateServerPlaylist(pl.id, { items });
          renderDetailTracklist(pl);
        }
      });
    });
    container.querySelectorAll('.btn-del-track').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const mediaId = btn.getAttribute('data-id');
        pl.items = items.filter(it => it.id !== mediaId);
        await Playlist.updateServerPlaylist(pl.id, { items: pl.items });
        const countEl = document.getElementById('playlistDetailItemCount');
        const durationEl = document.getElementById('playlistDetailDuration');
        if (countEl) countEl.innerHTML = `<i class="fa-solid fa-film"></i> ${pl.items.length} items`;
        if (durationEl) durationEl.innerHTML = `<i class="fa-solid fa-clock"></i> ${formatDurationTotal(pl.items)}`;
        renderDetailTracklist(pl);
        if (typeof showNovaToast === 'function') {
          showNovaToast('Track removed from playlist', 'fa-trash-can');
        }
      });
    });
  }
  async function openAddVideosToPlaylistModal(pl) {
    const modal = document.getElementById('addVideosToPlaylistModal');
    const checklist = document.getElementById('addVideosChecklist');
    const searchInput = document.getElementById('addVideosSearchInput');
    const badge = document.getElementById('addVideosSelectedBadge');
    const confirmBtn = document.getElementById('confirmAddVideosBtn');
    const cancelBtn = document.getElementById('cancelAddVideosBtn');
    const closeBtn = document.getElementById('closeAddVideosModal');
    const selectAllBtn = document.getElementById('addVideosSelectAllBtn');
    const clearAllBtn = document.getElementById('addVideosClearAllBtn');
    if (!modal || !checklist) return;
    modal.style.display = 'flex';
    if (searchInput) searchInput.value = '';
    const selectedIds = new Set();
    let addModalTypeFilter = (pl.category && pl.category !== 'mixed') ? pl.category : 'all';
    function updateModalBadge() {
      if (badge) badge.textContent = `${selectedIds.size} selected`;
    }
    updateModalBadge();
    const addTypeTabBtns = document.querySelectorAll('#addMediaTypeTabs button[data-add-filter-type]');
    addTypeTabBtns.forEach(btn => {
      const type = btn.getAttribute('data-add-filter-type') || 'all';
      btn.classList.toggle('active', type === addModalTypeFilter);
      btn.onclick = () => {
        addTypeTabBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        addModalTypeFilter = type;
        renderChecklist(searchInput ? searchInput.value : '');
      };
    });
    let mediaList = [];
    if (typeof Library !== 'undefined' && Library.getMediaList().length > 0) {
      mediaList = Library.getMediaList();
    } else {
      try {
        const res = await fetch('/api/library');
        const data = await res.json();
        if (data.ok) mediaList = data.library || [];
      } catch (e) {
        console.error('Failed to load library:', e);
      }
    }
    const existingIds = new Set((pl.items || []).map(it => it.id));
    const candidateList = mediaList.filter(m => !existingIds.has(m.id));
    function renderChecklist(query = '') {
      const q = query.trim().toLowerCase();
      let filtered = candidateList;
      if (addModalTypeFilter && addModalTypeFilter !== 'all') {
        filtered = filtered.filter(m => {
          const type = (m.type || '').toLowerCase();
          if (addModalTypeFilter === 'video') return type === 'video' || (!type && !m.extension?.match(/\.(mp3|wav|flac|aac|m4a|png|jpg|jpeg|webp|gif)$/i));
          if (addModalTypeFilter === 'audio') return type === 'audio' || m.extension?.match(/\.(mp3|wav|flac|aac|m4a|ogg|opus)$/i);
          if (addModalTypeFilter === 'image') return type === 'image' || m.extension?.match(/\.(png|jpg|jpeg|webp|gif|svg)$/i);
          return true;
        });
      }
      if (q) {
        filtered = filtered.filter(m => (m.name || '').toLowerCase().includes(q));
      }
      if (filtered.length === 0) {
        checklist.innerHTML = `
          <div style="padding: 24px; text-align: center; color: var(--text-muted); font-size: 0.85rem;">
            ${candidateList.length === 0 ? 'All library media items are already in this playlist!' : 'No matching items found.'}
          </div>
        `;
        return;
      }
      checklist.innerHTML = filtered.map(item => {
        const isChecked = selectedIds.has(item.id);
        const itemType = (item.type || '').toLowerCase();
        const isAud = itemType === 'audio' || item.extension?.match(/\.(mp3|wav|flac|aac|m4a|ogg|opus)$/i);
        const isImg = itemType === 'image' || item.extension?.match(/\.(png|jpg|jpeg|webp|gif|svg)$/i);
        const isVid = !isAud && !isImg;
        let iconClass = 'fa-film';
        let iconColor = 'var(--accent-purple)';
        let badgeType = 'VIDEO';
        if (isAud) {
          iconClass = 'fa-music';
          iconColor = 'var(--accent-green)';
          badgeType = 'AUDIO';
        } else if (isImg) {
          iconClass = 'fa-image';
          iconColor = '#ec4899';
          badgeType = 'IMAGE';
        }
        const safeName = escapeHtml(item.name || 'Untitled');
        return `
          <label style="display:flex; align-items:flex-start; gap:10px; padding:9px 12px; border-radius:var(--radius-sm); cursor:pointer; transition: background 0.15s ease; ${isChecked ? 'background: rgba(99, 102, 241, 0.12); border: 1px solid rgba(99, 102, 241, 0.3);' : 'border: 1px solid transparent;'}" class="add-videos-label">
            <input type="checkbox" class="add-videos-checkbox" data-id="${item.id}" ${isChecked ? 'checked' : ''} style="accent-color: var(--accent-purple); width:16px; height:16px; margin-top:3px;">
            <div style="width:30px; height:30px; border-radius:6px; background:var(--bg-card); display:flex; align-items:center; justify-content:center; flex-shrink:0; overflow:hidden;">
              ${isImg && item.url ? `<img src="${item.url}" style="width:100%; height:100%; object-fit:cover;" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';" /><div style="display:none; width:100%; height:100%; align-items:center; justify-content:center;"><i class="fa-solid ${iconClass}" style="color:${iconColor}; font-size:0.8rem;"></i></div>` : `<i class="fa-solid ${iconClass}" style="color:${iconColor}; font-size:0.8rem;"></i>`}
            </div>
            <div style="flex:1; min-width:0;">
              <div class="playlist-media-title-wrap" title="${safeName}">${safeName}</div>
              <div style="font-size:0.75rem; color:var(--text-muted); display:flex; gap:8px;">
                <span style="font-weight:600; color:${iconColor};">${badgeType}</span>
                <span>•</span>
                <span>${formatBytes(item.size || 0)}</span>
              </div>
            </div>
          </label>
        `;
      }).join('');
      checklist.querySelectorAll('.add-videos-checkbox').forEach(cb => {
        cb.addEventListener('change', () => {
          const id = cb.getAttribute('data-id');
          if (cb.checked) selectedIds.add(id);
          else selectedIds.delete(id);
          const label = cb.closest('label');
          if (label) {
            label.style.background = cb.checked ? 'rgba(99, 102, 241, 0.12)' : '';
            label.style.border = cb.checked ? '1px solid rgba(99, 102, 241, 0.3)' : '1px solid transparent';
          }
          updateModalBadge();
        });
      });
    }
    renderChecklist();
    if (searchInput) {
      searchInput.oninput = (e) => renderChecklist(e.target.value);
    }
    if (selectAllBtn) {
      selectAllBtn.onclick = () => {
        const q = searchInput ? searchInput.value : '';
        const lowerQ = q.trim().toLowerCase();
        let filtered = candidateList;
        if (addModalTypeFilter && addModalTypeFilter !== 'all') {
          filtered = filtered.filter(m => (m.type || '').toLowerCase() === addModalTypeFilter);
        }
        if (lowerQ) {
          filtered = filtered.filter(m => (m.name || '').toLowerCase().includes(lowerQ));
        }
        filtered.forEach(m => selectedIds.add(m.id));
        renderChecklist(q);
        updateModalBadge();
      };
    }
    if (clearAllBtn) {
      clearAllBtn.onclick = () => {
        selectedIds.clear();
        const q = searchInput ? searchInput.value : '';
        renderChecklist(q);
        updateModalBadge();
      };
    }
    const hideAddModal = () => { modal.style.display = 'none'; };
    if (closeBtn) closeBtn.onclick = hideAddModal;
    if (cancelBtn) cancelBtn.onclick = hideAddModal;
    if (confirmBtn) {
      confirmBtn.onclick = async () => {
        if (selectedIds.size === 0) return alert('Please select at least one item to add.');
        const itemsToAdd = candidateList.filter(m => selectedIds.has(m.id));
        pl.items = pl.items || [];
        itemsToAdd.forEach(it => {
          pl.items.push({ ...it, repeatCount: 1 });
        });
        confirmBtn.disabled = true;
        await Playlist.updateServerPlaylist(pl.id, { items: pl.items });
        confirmBtn.disabled = false;
        hideAddModal();
        openPlaylistDetail(pl.id);
        if (typeof showNovaToast === 'function') {
          showNovaToast(`Added ${itemsToAdd.length} media item(s) to playlist`, 'fa-circle-check');
        }
      };
    }
  }
  async function fetchStorageStats() {
    try {
      const res = await fetch('/api/storage/stats');
      const data = await res.json();
      if (data.ok) {
        const stats = data.stats;
        const storageTotalUsage = document.getElementById('storageTotalUsage');
        const storagePathCode = document.getElementById('storagePathCode');
        const storageVideoFilesCount = document.getElementById('storageVideoFilesCount');
        const storageAudioFilesCount = document.getElementById('storageAudioFilesCount');
        if (storageTotalUsage) storageTotalUsage.textContent = stats.totalSizeFormatted;
        if (storagePathCode) storagePathCode.textContent = stats.downloadDir;
        if (storageVideoFilesCount) storageVideoFilesCount.textContent = stats.videoCount;
        if (storageAudioFilesCount) storageAudioFilesCount.textContent = stats.audioCount;
      }
    } catch (err) {
      console.error('Failed to load storage statistics:', err);
    }
  }
  function setupMiniPlayerSync() {
    const miniBtnPlay = document.getElementById('miniBtnPlay');
    const miniPlayIcon = document.getElementById('miniPlayIcon');
    const miniBtnPrev = document.getElementById('miniBtnPrev');
    const miniBtnNext = document.getElementById('miniBtnNext');
    const miniBtnMute = document.getElementById('miniBtnMute');
    const miniVolumeIcon = document.getElementById('miniVolumeIcon');
    const miniVolumeSlider = document.getElementById('miniVolumeSlider');
    const miniSeekSlider = document.getElementById('miniSeekSlider');
    const miniSeekProgress = document.getElementById('miniSeekProgress');
    const miniThumb = document.getElementById('miniThumb');
    const miniTitle = document.getElementById('miniTitle');
    const miniTimeCurrent = document.getElementById('miniTimeCurrent');
    const miniTimeDuration = document.getElementById('miniTimeDuration');
    if (miniBtnPlay) {
      miniBtnPlay.addEventListener('click', () => {
        if (typeof Player !== 'undefined') Player.togglePlay();
      });
    }
    if (miniBtnPrev) {
      miniBtnPrev.addEventListener('click', () => {
        if (typeof Playlist !== 'undefined') Playlist.previous();
      });
    }
    if (miniBtnNext) {
      miniBtnNext.addEventListener('click', () => {
        if (typeof Playlist !== 'undefined') Playlist.next();
      });
    }
    if (miniBtnMute) {
      miniBtnMute.addEventListener('click', () => {
        if (typeof Player !== 'undefined') {
          const isMuted = Player.toggleMute();
          if (miniVolumeIcon) {
            miniVolumeIcon.className = isMuted ? 'fa-solid fa-volume-xmark' : 'fa-solid fa-volume-high';
          }
        }
      });
    }
    if (miniVolumeSlider) {
      miniVolumeSlider.addEventListener('input', () => {
        const val = parseFloat(miniVolumeSlider.value);
        if (typeof Player !== 'undefined') {
          if (val > 1.0) Player.setAmplification(val);
          else Player.setVolume(val);
        }
      });
    }
    if (miniSeekSlider) {
      miniSeekSlider.addEventListener('input', () => {
        const pct = parseFloat(miniSeekSlider.value);
        if (typeof Player !== 'undefined') {
          const dur = Player.getDuration();
          if (dur && !isNaN(dur)) Player.seek((pct / 100) * dur);
        }
      });
    }
    if (typeof Player !== 'undefined') {
      let miniShowRemaining = false;
      if (miniTimeDuration) {
        miniTimeDuration.style.cursor = 'pointer';
        miniTimeDuration.title = 'Click to toggle remaining time';
        miniTimeDuration.addEventListener('click', () => {
          miniShowRemaining = !miniShowRemaining;
          const current = typeof Player !== 'undefined' ? Player.getCurrentTime() : 0;
          const duration = typeof Player !== 'undefined' ? Player.getDuration() : 0;
          const hasHours = (duration >= 3600) || (current >= 3600);
          if (miniShowRemaining && duration > 0) {
            miniTimeDuration.textContent = '-' + formatTime(Math.max(0, duration - current), hasHours);
          } else {
            miniTimeDuration.textContent = formatTime(duration, hasHours);
          }
        });
      }
      Player.onPlayStateChange((isPlaying) => {
        if (miniPlayIcon) {
          miniPlayIcon.className = isPlaying ? 'fa-solid fa-pause' : 'fa-solid fa-play';
        }
      });
      Player.onTimeUpdate((current, duration) => {
        const hasHours = (duration >= 3600) || (current >= 3600);
        if (miniTimeCurrent) miniTimeCurrent.textContent = formatTime(current, hasHours);
        if (miniTimeDuration) {
          if (miniShowRemaining && duration > 0) {
            miniTimeDuration.textContent = '-' + formatTime(Math.max(0, duration - current), hasHours);
          } else {
            miniTimeDuration.textContent = formatTime(duration, hasHours);
          }
        }
        if (duration && !isNaN(duration) && duration > 0) {
          const pct = (current / duration) * 100;
          if (miniSeekSlider) miniSeekSlider.value = pct;
          if (miniSeekProgress) miniSeekProgress.style.width = pct + '%';
        }
      });
    }
    if (typeof Playlist !== 'undefined') {
      Playlist.onItemChange((item) => {
        isMiniPlayerDismissed = false;
        if (item) {
          if (miniTitle) miniTitle.textContent = item.name;
          if (miniThumb) {
            if (item.thumbnail && !item.thumbnail.includes('#t=')) {
              miniThumb.src = item.thumbnail;
            } else if (item.type === 'video') {
              miniThumb.src = 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=200&auto=format&fit=crop&q=80';
            } else {
              miniThumb.src = 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=200&auto=format&fit=crop&q=80';
            }
          }
        }
        updateMiniPlayerVisibility();
        if (typeof window.syncPlayerStudioUI === 'function') {
          window.syncPlayerStudioUI();
        }
      });
      Playlist.onPlaylistChange(() => {
        if (typeof window.renderPlaylistView === 'function') {
          window.renderPlaylistView();
        }
      });
    }
  }
  function formatTime(sec, forceHours = false) {
    if (isNaN(sec) || sec === null || sec < 0) return forceHours ? '0:00:00' : '00:00';
    const totalSecs = Math.floor(sec);
    const hrs = Math.floor(totalSecs / 3600);
    const mins = Math.floor((totalSecs % 3600) / 60);
    const secs = totalSecs % 60;
    const pad = n => (n < 10 ? '0' + n : n);
    if (hrs > 0 || forceHours) return `${hrs}:${pad(mins)}:${pad(secs)}`;
    return `${pad(mins)}:${pad(secs)}`;
  }
  function formatBytes(bytes) {
    if (!bytes || bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }
  function initDesktopContextMenu() {
    const menu = document.getElementById('novaContextMenu');
    if (!menu) return;
    window.addEventListener('contextmenu', (e) => {
      const tag = e.target.tagName ? e.target.tagName.toLowerCase() : '';
      if ((tag === 'input' && e.target.type === 'text') || tag === 'textarea') {
        if (window.getSelection && window.getSelection().toString().length > 0) {
          return;
        }
      }
      e.preventDefault();
      const isPaused = typeof Player !== 'undefined' && Player.isPaused ? Player.isPaused() : true;
      const playPauseItem = document.getElementById('ctxPlayPause');
      if (playPauseItem) {
        playPauseItem.innerHTML = isPaused
          ? `<i class="fa-solid fa-play"></i><span>Play</span><span class="context-menu-shortcut">Space</span>`
          : `<i class="fa-solid fa-pause"></i><span>Pause</span><span class="context-menu-shortcut">Space</span>`;
      }
      const isMuted = typeof Player !== 'undefined' && Player.isMuted ? Player.isMuted() : false;
      const muteItem = document.getElementById('ctxMute');
      if (muteItem) {
        muteItem.innerHTML = isMuted
          ? `<i class="fa-solid fa-volume-high"></i><span>Unmute</span><span class="context-menu-shortcut">M</span>`
          : `<i class="fa-solid fa-volume-xmark"></i><span>Mute</span><span class="context-menu-shortcut">M</span>`;
      }
      menu.style.display = 'block';
      menu.style.visibility = 'hidden';
      const menuWidth = menu.offsetWidth || 240;
      const menuHeight = menu.offsetHeight || 320;
      let x = e.clientX;
      let y = e.clientY;
      if (x + menuWidth > window.innerWidth) {
        x = window.innerWidth - menuWidth - 8;
      }
      if (y + menuHeight > window.innerHeight) {
        y = window.innerHeight - menuHeight - 8;
      }
      menu.style.left = `${Math.max(8, x)}px`;
      menu.style.top = `${Math.max(8, y)}px`;
      menu.style.visibility = 'visible';
    });
    window.addEventListener('click', (e) => {
      if (menu && menu.style.display !== 'none' && !menu.contains(e.target)) {
        menu.style.display = 'none';
      }
    });
    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && menu && menu.style.display !== 'none') {
        menu.style.display = 'none';
      }
    });
    const bindCtxClick = (id, fn) => {
      const el = document.getElementById(id);
      if (el) {
        el.addEventListener('click', (e) => {
          e.stopPropagation();
          menu.style.display = 'none';
          try { fn(); } catch(err) { console.warn(err); }
        });
      }
    };
    bindCtxClick('ctxPlayPause', () => {
      if (typeof Player !== 'undefined' && Player.togglePlay) Player.togglePlay();
    });
    bindCtxClick('ctxNextTrack', () => {
      if (typeof Playlist !== 'undefined' && Playlist.next) Playlist.next();
    });
    bindCtxClick('ctxPrevTrack', () => {
      if (typeof Playlist !== 'undefined' && Playlist.previous) Playlist.previous();
    });
    bindCtxClick('ctxMute', () => {
      if (typeof Player !== 'undefined' && Player.toggleMute) Player.toggleMute();
    });
    bindCtxClick('ctxBoostVolume', () => {
      if (typeof Player !== 'undefined' && Player.setVolume) {
        Player.setVolume(1.0);
        if (typeof showNovaToast === 'function') {
          showNovaToast('Super Volume Boost enabled (Max 150%)', 'fa-gauge-high');
        }
      }
    });
    bindCtxClick('ctxFullscreen', () => {
      if (typeof Player !== 'undefined' && Player.toggleFullscreen) Player.toggleFullscreen();
    });
    bindCtxClick('ctxNavHome', () => switchView('home'));
    bindCtxClick('ctxNavLibrary', () => switchView('library'));
    bindCtxClick('ctxNavPlayer', () => switchView('player'));
    bindCtxClick('ctxNavPlaylists', () => switchView('playlists'));
    bindCtxClick('ctxNavDownloads', () => switchView('downloads'));
    bindCtxClick('ctxCopyUrl', () => {
      let copyText = window.location.href;
      if (typeof Player !== 'undefined' && Player.getCurrentItem) {
        const item = Player.getCurrentItem();
        if (item && item.url) copyText = item.url;
      }
      navigator.clipboard.writeText(copyText).then(() => {
        if (typeof showNovaToast === 'function') {
          showNovaToast('Copied media URL to clipboard!', 'fa-link');
        }
      });
    });
    bindCtxClick('ctxReloadApp', () => {
      window.location.reload();
    });
  }
  window.loadAndRenderHistory = function() {
    const container = document.getElementById('historyTimelineContainer');
    const badge = document.getElementById('navHistoryCount');
    const statHistoryTotal = document.getElementById('statHistoryTotal');
    const statHistoryResumes = document.getElementById('statHistoryResumes');
    const statHistoryTime = document.getElementById('statHistoryTime');
    if (!container) return;
    let list = [];
    try {
      const raw = localStorage.getItem('novapulse_watch_history');
      if (raw) list = JSON.parse(raw);
    } catch(e) { list = []; }
    const activeItem = (typeof Playlist !== 'undefined' && Playlist.getCurrentItem) 
      ? Playlist.getCurrentItem() 
      : ((typeof Player !== 'undefined' && Player.getCurrentItem) ? Player.getCurrentItem() : null);
    if (activeItem && activeItem.id) {
      const curTime = (typeof Player !== 'undefined' && Player.getCurrentTime) ? Player.getCurrentTime() : 0;
      const curDur = (typeof Player !== 'undefined' && Player.getDuration && Player.getDuration() > 0) ? Player.getDuration() : (activeItem.duration || 0);
      const curPct = (curDur > 0 && curTime > 0) ? Math.min(100, Math.round((curTime / curDur) * 100)) : 0;
      const existingIdx = list.findIndex(it => it && it.id === activeItem.id);
      const activeEntry = {
        id: activeItem.id,
        name: activeItem.name || 'Untitled Media',
        url: activeItem.url || '',
        thumbnail: activeItem.thumbnail || '',
        type: activeItem.type || 'video',
        extension: activeItem.extension || 'mp4',
        size: activeItem.size || 0,
        duration: curDur,
        currentTime: curTime,
        percent: curPct,
        watchedAt: Date.now()
      };
      if (existingIdx !== -1) {
        list.splice(existingIdx, 1);
      }
      list.unshift(activeEntry);
      try {
        localStorage.setItem('novapulse_watch_history', JSON.stringify(list));
      } catch(e) {}
    }
    if (badge) badge.textContent = list.length;
    if (statHistoryTotal) statHistoryTotal.textContent = list.length;
    let activeResumes = 0;
    let totalSecs = 0;
    list.forEach(item => {
      if (item && item.percent > 0 && item.percent < 98) activeResumes++;
      const watched = typeof item.totalWatchedSeconds === 'number' && item.totalWatchedSeconds > 0
        ? item.totalWatchedSeconds
        : (item && item.currentTime ? item.currentTime : 0);
      totalSecs += watched;
    });
    if (statHistoryResumes) statHistoryResumes.textContent = activeResumes;
    if (statHistoryTime) {
      const mins = Math.round(totalSecs / 60);
      statHistoryTime.textContent = mins > 60 ? `${Math.floor(mins / 60)}h ${mins % 60}m` : `${mins}m`;
    }
    if (!list || list.length === 0) {
      container.innerHTML = `
        <div class="empty-history-box" id="emptyHistoryBox">
          <i class="fa-solid fa-clock-rotate-left"></i>
          <h3>No Watch History Yet</h3>
          <p>Videos and audio tracks you play in Player Studio will automatically appear here on your personal timeline.</p>
          <button class="btn-primary" onclick="Nova.switchView('library')">
            <i class="fa-solid fa-layer-group"></i> Browse Library &amp; Watch
          </button>
        </div>`;
      return;
    }
    let html = `<div class="history-list" style="display: flex; flex-direction: column; gap: 12px; margin-top: 16px;">`;
    list.forEach((item, idx) => {
      const isCurrentlyWatching = activeItem && activeItem.id === item.id;
      const dateStr = isCurrentlyWatching ? 'Watching Now' : (item.watchedAt ? new Date(item.watchedAt).toLocaleString() : 'Recently watched');
      const curFormatted = formatTime(item.currentTime || 0);
      const durFormatted = formatTime(item.duration || 0);
      const thumb = item.thumbnail || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=200&auto=format&fit=crop&q=80';
      const pct = item.percent || 0;
      const cardBorder = isCurrentlyWatching
        ? 'border: 1px solid var(--theme-border-accent); box-shadow: var(--theme-glow);'
        : 'border: 1px solid var(--border-color);';
      const tagBadge = isCurrentlyWatching
        ? `<span style="background: rgba(16, 185, 129, 0.2); color: #10b981; border: 1px solid rgba(16, 185, 129, 0.4); font-size: 0.68rem; font-weight: 700; padding: 2px 8px; border-radius: 4px; display: inline-flex; align-items: center; gap: 4px;"><i class="fa-solid fa-play fa-fade"></i> WATCHING NOW</span>`
        : `<span style="background: var(--theme-accent-soft); color: var(--theme-primary); border: 1px solid var(--theme-border-accent); font-size: 0.68rem; font-weight: 700; padding: 2px 6px; border-radius: 4px; text-transform: uppercase;">${item.type || 'VIDEO'}</span>`;
      const playBtnText = isCurrentlyWatching
        ? `<i class="fa-solid fa-headphones"></i> <span>Playing</span>`
        : `<i class="fa-solid fa-play"></i> <span>Resume</span>`;
      html += `
        <div class="history-card-item library-item" data-id="${item.id}" style="display: flex; flex-direction: column; gap: 10px; background: rgba(14, 18, 27, 0.92); ${cardBorder} border-radius: 14px; padding: 12px 14px; width: 100%; box-sizing: border-box; margin-bottom: 10px; transition: border-color .2s ease;">
          <div class="lib-card-top-row" style="display: flex; flex-direction: row; align-items: flex-start; gap: 12px; width: 100%;">
            <div class="lib-thumb-col" style="width: 72px; min-width: 72px; max-width: 72px; height: 52px; border-radius: 8px; overflow: hidden; background: #090b10; border: 1px solid rgba(255, 255, 255, 0.1); flex-shrink: 0; position: relative;">
              <img src="${thumb}" alt="thumb" style="width: 100%; height: 100%; object-fit: cover;" onerror="this.src='https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=200&auto=format&fit=crop&q=80';" />
              <span class="lib-thumb-duration" style="position: absolute; bottom: 3px; right: 3px; background: rgba(0,0,0,0.85); font-size: 0.65rem; padding: 1px 4px; border-radius: 4px; font-family: var(--mono); color: #fff; line-height: 1;">${durFormatted}</span>
              <div style="position: absolute; bottom: 0; left: 0; right: 0; height: 3px; background: rgba(255,255,255,0.2);">
                <div style="height: 100%; width: ${pct}%; background: var(--theme-accent-gradient);"></div>
              </div>
            </div>
            <div class="lib-info-col" style="display: flex; flex-direction: column; gap: 4px; flex: 1 1 auto; min-width: 0;">
              <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 2px;">
                ${tagBadge}
                <span style="font-size: 0.72rem; color: var(--text-muted);"><i class="fa-regular fa-clock"></i> ${dateStr}</span>
              </div>
              <div class="lib-title" title="${item.name}" style="font-size: 0.9rem; font-weight: 700; color: #ffffff; line-height: 1.35; word-break: break-word; overflow: hidden; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; white-space: normal;">${item.name}</div>
              <div class="lib-sub" style="display: flex; flex-wrap: wrap; align-items: center; gap: 6px; font-size: 0.74rem; color: #94a3b8; font-family: var(--mono); margin-top: 2px;">
                <span>Progress: <b style="color: #fff;">${curFormatted}</b> / ${durFormatted} (${pct}%)</span>
              </div>
            </div>
          </div>
          <div class="lib-actions-col" style="display: flex; flex-direction: row; align-items: center; justify-content: flex-start; gap: 8px; width: 100%; padding-top: 8px; border-top: 1px solid rgba(255, 255, 255, 0.06);">
            <button class="btn-lib-action btn-history-play" data-idx="${idx}" title="Resume Playback" style="display: inline-flex; align-items: center; justify-content: center; gap: 6px; padding: 6px 14px; border-radius: 8px; font-size: 0.8rem; font-weight: 600; cursor: pointer; background: var(--theme-accent-gradient); color: var(--theme-contrast-text); border: none; box-shadow: var(--theme-glow);">
              ${playBtnText}
            </button>
            <button class="btn-lib-action btn-subtle btn-history-del" data-id="${item.id}" title="Remove from History" style="display: inline-flex; align-items: center; justify-content: center; gap: 6px; padding: 6px 12px; border-radius: 8px; font-size: 0.8rem; font-weight: 600; cursor: pointer; background: rgba(239, 68, 68, 0.12); color: #ef4444; border: 1px solid rgba(239, 68, 68, 0.25);">
              <i class="fa-solid fa-trash-can"></i> <span>Delete</span>
            </button>
          </div>
        </div>`;
    });
    html += `</div>`;
    container.innerHTML = html;
    container.querySelectorAll('.btn-history-play').forEach(btn => {
      btn.addEventListener('click', () => {
        const idx = parseInt(btn.getAttribute('data-idx'), 10);
        const target = list[idx];
        if (!target) return;
        if (typeof Playlist !== 'undefined' && Playlist.playNow) {
          Playlist.playNow(target);
          if (target.currentTime && typeof Player !== 'undefined' && Player.seek) {
            setTimeout(() => {
              try { Player.seek(target.currentTime); } catch(e){}
            }, 300);
          }
        } else if (typeof Player !== 'undefined' && Player.loadItem) {
          Player.loadItem(target, true, target.currentTime || 0);
        }
        if (typeof switchView === 'function') {
          switchView('player');
        } else if (typeof Nova !== 'undefined' && Nova.switchView) {
          Nova.switchView('player');
        }
      });
    });
    container.querySelectorAll('.btn-history-del').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const id = btn.getAttribute('data-id');
        let updated = list.filter(it => it && it.id !== id);
        localStorage.setItem('novapulse_watch_history', JSON.stringify(updated));
        window.loadAndRenderHistory();
      });
    });
  };
  window.playMediaFile = function(url, name) {
    const item = { url, name, id: 'media_' + btoa(encodeURIComponent(url || name)) };
    if (typeof Playlist !== 'undefined' && Playlist.playNow) {
      Playlist.playNow(item);
    } else if (typeof Player !== 'undefined' && Player.loadItem) {
      Player.loadItem(item, true);
    }
    if (typeof switchView === 'function') switchView('player');
    else if (typeof Nova !== 'undefined' && Nova.switchView) Nova.switchView('player');
  };
  const btnClearWatchHistory = document.getElementById('btnClearWatchHistory');
  if (btnClearWatchHistory) {
    btnClearWatchHistory.addEventListener('click', () => {
      if (confirm('Clear all watch history?')) {
        localStorage.removeItem('novapulse_watch_history');
        try {
          fetch('/api/history', { method: 'DELETE' }).catch(() => {});
        } catch (e) {}
        window.loadAndRenderHistory();
      }
    });
  }
  const btnResumeLastWatched = document.getElementById('btnResumeLastWatched');
  if (btnResumeLastWatched) {
    btnResumeLastWatched.addEventListener('click', () => {
      try {
        const raw = localStorage.getItem('novapulse_watch_history');
        const list = raw ? JSON.parse(raw) : [];
        if (list && list.length > 0) {
          const first = list[0];
          if (typeof Playlist !== 'undefined' && Playlist.playNow) {
            Playlist.playNow(first);
            if (first.currentTime && typeof Player !== 'undefined' && Player.seek) {
              setTimeout(() => { try { Player.seek(first.currentTime); } catch(e){} }, 300);
            }
          } else if (typeof Player !== 'undefined' && Player.loadItem) {
            Player.loadItem(first, true, first.currentTime || 0);
          }
          if (typeof switchView === 'function') switchView('player');
          else if (typeof Nova !== 'undefined' && Nova.switchView) Nova.switchView('player');
        } else {
          if (typeof showNovaToast === 'function') {
            showNovaToast('No watch history to resume', 'fa-clock-rotate-left');
          } else {
            alert('No watch history to resume!');
          }
        }
      } catch(e) {}
    });
  }
  const historySearchInput = document.getElementById('historySearchInput');
  if (historySearchInput) {
    historySearchInput.addEventListener('input', () => {
      const q = historySearchInput.value.toLowerCase().trim();
      const cards = document.querySelectorAll('.history-card-item');
      cards.forEach(card => {
        const text = card.textContent.toLowerCase();
        card.style.display = text.includes(q) ? 'flex' : 'none';
      });
    });
  }
  window.initSitesDirectoryModal = async function() {
    const sitesBadgeGrid = document.getElementById('sitesBadgeGrid');
    const filteredSitesCount = document.getElementById('filteredSitesCount');
    const sitesSearchInput = document.getElementById('sitesSearchInput');
    const sitesModal = document.getElementById('sitesModal');
    if (!sitesBadgeGrid) return;
    if (!window._novaCachedSites || window._novaCachedSites.length === 0) {
      try {
        const res = await fetch('/api/supported-sites');
        const data = await res.json();
        if (data && data.sites && Array.isArray(data.sites)) {
          window._novaCachedSites = data.sites;
        } else {
          window._novaCachedSites = ['YouTube', 'YouTube Music', 'TikTok', 'Instagram', 'Twitter / X', 'Facebook', 'Twitch', 'Reddit', 'Vimeo', 'SoundCloud', 'Bilibili', 'Dailymotion', 'VK', 'Pinterest', 'Bandcamp', 'Telegram', 'Kick', 'Loom', 'Rumble', 'Pornhub', 'Threads', 'Bluesky', 'Mastodon'];
        }
      } catch (e) {
        window._novaCachedSites = ['YouTube', 'YouTube Music', 'TikTok', 'Instagram', 'Twitter / X', 'Facebook', 'Twitch', 'Reddit', 'Vimeo', 'SoundCloud', 'Bilibili', 'Dailymotion', 'VK', 'Pinterest', 'Bandcamp', 'Telegram', 'Kick', 'Loom', 'Rumble'];
      }
    }
    function renderSites(list) {
      if (filteredSitesCount) filteredSitesCount.textContent = list.length;
      sitesBadgeGrid.innerHTML = '';
      list.slice(0, 150).forEach(site => {
        const badge = document.createElement('span');
        badge.className = 'site-badge';
        badge.textContent = site;
        badge.title = 'Click to paste sample into URL input';
        badge.addEventListener('click', () => {
          const urlInput = document.getElementById('urlInput');
          if (urlInput) {
            urlInput.value = `https://${site.toLowerCase().replace(/[^a-z0-9]/g, '')}.com`;
            urlInput.focus();
          }
          if (sitesModal) sitesModal.style.display = 'none';
        });
        sitesBadgeGrid.appendChild(badge);
      });
    }
    renderSites(window._novaCachedSites);
    if (sitesSearchInput) {
      sitesSearchInput.oninput = () => {
        const q = sitesSearchInput.value.toLowerCase().trim();
        const filtered = window._novaCachedSites.filter(s => s.toLowerCase().includes(q));
        renderSites(filtered);
      };
    }
  };
  window.Nova = {
    switchView,
    refreshDashboard,
    loadAndRenderPlaylists
  };
  window.switchView = switchView;
    const headerNotifBtn = document.getElementById('headerNotifBtn');
    const novaNotifPopover = document.getElementById('novaNotifPopover');
    const btnClearNotifs = document.getElementById('btnClearNotifs');
    const notifSubCount = document.getElementById('notifSubCount');
    const notifRedDot = document.querySelector('.notif-red-dot');
    if (headerNotifBtn && novaNotifPopover) {
      headerNotifBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        const isOpen = novaNotifPopover.style.display === 'flex' || novaNotifPopover.style.display === 'block';
        novaNotifPopover.style.display = isOpen ? 'none' : 'flex';
      });
      document.addEventListener('click', (e) => {
        if (!novaNotifPopover.contains(e.target) && !headerNotifBtn.contains(e.target)) {
          novaNotifPopover.style.display = 'none';
        }
      });
    }
    if (btnClearNotifs && novaNotifPopover) {
      btnClearNotifs.addEventListener('click', (e) => {
        e.stopPropagation();
        const list = document.getElementById('notifPopoverList');
        if (list) {
          list.innerHTML = '<div style="text-align: center; padding: 30px 10px; color: var(--text-muted); font-size: 0.85rem;"><i class="fa-regular fa-bell" style="font-size: 1.8rem; margin-bottom: 8px; color: var(--text-dim); display: block;"></i>All caught up! No notifications.</div>';
        }
        if (notifSubCount) notifSubCount.textContent = '0 unread notifications';
        if (notifRedDot) notifRedDot.style.display = 'none';
      });
    }
    document.addEventListener('click', (e) => {
      const dismissBtn = e.target.closest('.notif-card-dismiss');
      if (dismissBtn) {
        e.stopPropagation();
        const card = dismissBtn.closest('.notif-item');
        if (card) {
          card.style.opacity = '0';
          card.style.transform = 'translateX(20px)';
          setTimeout(() => {
            card.remove();
            const list = document.getElementById('notifPopoverList');
            const remaining = list ? list.querySelectorAll('.notif-item').length : 0;
            if (notifSubCount) notifSubCount.textContent = remaining + ' unread notifications';
            if (remaining === 0) {
              if (notifRedDot) notifRedDot.style.display = 'none';
              if (list) list.innerHTML = '<div style="text-align: center; padding: 30px 10px; color: var(--text-muted); font-size: 0.85rem;"><i class="fa-regular fa-bell" style="font-size: 1.8rem; margin-bottom: 8px; color: var(--text-dim); display: block;"></i>All caught up! No notifications.</div>';
            }
          }, 180);
        }
      }
    });
    const formatPills = document.querySelectorAll('.format-pill-card');
    const urlInputEl = document.getElementById('urlInput');
    formatPills.forEach(pill => {
      pill.addEventListener('click', (e) => {
        formatPills.forEach(p => p.classList.remove('active'));
        pill.classList.add('active');
        const formatType = pill.getAttribute('data-format');
        if (urlInputEl) {
          if (formatType === 'video') {
            urlInputEl.placeholder = 'Paste video link (YouTube, Vimeo, Twitter, etc.)...';
          } else if (formatType === 'audio') {
            urlInputEl.placeholder = 'Paste audio / music link (SoundCloud, Spotify, MP3)...';
          } else if (formatType === 'images') {
            urlInputEl.placeholder = 'Paste image, gallery, Pinterest or Reddit link...';
          } else if (formatType === 'playlist') {
            urlInputEl.placeholder = 'Paste YouTube, Spotify or custom playlist link...';
          } else if (formatType === 'livestream') {
            urlInputEl.placeholder = 'Paste live stream link (Twitch, Kick, YouTube Live)...';
          } else {
            urlInputEl.placeholder = 'Paste your link here...';
          }
          urlInputEl.focus();
        }
        const formatNames = {
          all: 'All Formats (Auto Detect)',
          video: 'Video (MP4 / MKV)',
          audio: 'Audio (MP3 / M4A)',
          images: 'Images & Galleries',
          playlist: 'Playlist Pipeline',
          livestream: 'Live Stream Pipeline'
        };
        if (typeof window.showNovaToast === 'function') {
          window.showNovaToast('Format Preset: ' + (formatNames[formatType] || formatType), 'fa-filter');
        }
      });
    });
    const qaPopularWebsitesBtn = document.getElementById('qaPopularWebsites');
    if (qaPopularWebsitesBtn) {
      qaPopularWebsitesBtn.addEventListener('click', () => switchView('supported-sites'));
    }
    const rightViewSitesBtnEl = document.getElementById('rightViewSitesBtn');
    if (rightViewSitesBtnEl) {
      rightViewSitesBtnEl.addEventListener('click', () => switchView('supported-sites'));
    }
    const qaSupportedFormatsBtn = document.getElementById('qaSupportedFormats');
    if (qaSupportedFormatsBtn) {
      qaSupportedFormatsBtn.addEventListener('click', () => {
        const modal = document.getElementById('supportedFormatsModal');
        if (modal) modal.style.display = 'flex';
      });
    }
    const headerNotifBtnEl = document.getElementById('headerNotifBtn');
    const notifBackdropEl = document.getElementById('novaNotifBackdrop');
    const closeNotifPopoverBtn = document.getElementById('closeNotifPopoverBtn');
    if (closeNotifPopoverBtn && notifBackdropEl) {
      closeNotifPopoverBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        notifBackdropEl.classList.remove('active', 'open');
        notifBackdropEl.style.display = 'none';
      });
    }
    if (notifBackdropEl) {
      notifBackdropEl.addEventListener('click', (e) => {
        if (e.target === notifBackdropEl) {
          notifBackdropEl.classList.remove('active', 'open');
          notifBackdropEl.style.display = 'none';
        }
      });
    }
})();