(function () {
  let vaultItems = [];
  let currentTargetItem = null;
  async function fetchVaultList() {
    try {
      const res = await fetch('/api/secure-vault/list');
      if (res.ok) {
        const data = await res.json();
        if (data.ok) {
          vaultItems = data.items || [];
          updateVaultBadge(vaultItems.length);
          return vaultItems;
        }
      }
    } catch (e) {
      console.warn('Failed to load secure vault list:', e);
    }
    return [];
  }
  function updateVaultBadge(count) {
    const badge = document.getElementById('navSecureCount');
    if (badge) {
      badge.textContent = count > 0 ? `${count} 🔒` : '🔒';
    }
    const statEl = document.getElementById('vaultStatTotal');
    if (statEl) statEl.textContent = count;
  }
  async function loadAndRenderSecureFolder() {
    await fetchVaultList();
    renderVaultGrid(vaultItems);
  }
  function renderVaultGrid(items) {
    const grid = document.getElementById('vaultCardsGrid');
    const emptyState = document.getElementById('vaultEmptyState');
    if (!grid) return;
    grid.innerHTML = '';
    if (!items || items.length === 0) {
      if (emptyState) emptyState.style.display = 'block';
      return;
    }
    if (emptyState) emptyState.style.display = 'none';
    items.forEach(item => {
      const card = document.createElement('div');
      card.className = 'vault-card glassmorphism';
      card.innerHTML = `
        <div class="vault-card-badge">
          <i class="fa-solid fa-shield-halved"></i> AES-256 LOCKED
        </div>
        <div class="vault-card-preview">
          <div class="vault-lock-orb">
            <i class="fa-solid fa-lock"></i>
          </div>
          <span class="vault-format-pill">${escapeHtml(item.format || '1080p')}</span>
        </div>
        <div class="vault-card-content">
          <h4 class="vault-card-title" title="${escapeHtml(item.title)}">${escapeHtml(item.title)}</h4>
          <div class="vault-card-meta">
            <span><i class="fa-solid fa-file-shield"></i> ${formatBytes(item.size)}</span>
            <span><i class="fa-solid fa-clock"></i> ${formatDate(item.createdAt)}</span>
          </div>
          <div class="vault-encryption-indicator">
            <i class="fa-solid fa-key"></i> <b>Encrypted on Disk:</b> <code>${escapeHtml(item.id)}.nvsec</code>
          </div>
          <div class="vault-card-actions">
            <button class="btn-primary btn-mini btn-vault-play" data-id="${item.id}" title="Unlock and Stream Video">
              <i class="fa-solid fa-play"></i> Unlock &amp; Play
            </button>
            <button class="btn-subtle btn-mini btn-vault-export" data-id="${item.id}" title="Decrypt back to standard library">
              <i class="fa-solid fa-arrow-up-from-bracket"></i> Export
            </button>
            <button class="btn-danger-subtle btn-mini btn-vault-delete" data-id="${item.id}" title="Delete Video (Password or Master Key required)">
              <i class="fa-solid fa-trash"></i> Delete
            </button>
          </div>
        </div>
      `;
      card.querySelector('.btn-vault-play').addEventListener('click', () => {
        openUnlockModal(item);
      });
      card.querySelector('.btn-vault-export').addEventListener('click', () => {
        openExportModal(item);
      });
      card.querySelector('.btn-vault-delete').addEventListener('click', () => {
        openDeleteModal(item);
      });
      grid.appendChild(card);
    });
  }
  function openUnlockModal(item) {
    currentTargetItem = item;
    const modal = document.getElementById('vaultUnlockModal');
    const titleEl = document.getElementById('vaultUnlockTitle');
    const pwdInput = document.getElementById('vaultUnlockPassword');
    const errorEl = document.getElementById('vaultUnlockError');
    if (!modal) return;
    if (titleEl) titleEl.textContent = item.title;
    if (pwdInput) {
      pwdInput.value = '';
      setTimeout(() => pwdInput.focus(), 150);
    }
    if (errorEl) errorEl.style.display = 'none';
    modal.style.display = 'flex';
  }
  function openDeleteModal(item) {
    currentTargetItem = item;
    const modal = document.getElementById('vaultDeleteModal');
    const titleEl = document.getElementById('vaultDeleteTitle');
    const pwdInput = document.getElementById('vaultDeletePassword');
    const errorEl = document.getElementById('vaultDeleteError');
    if (!modal) return;
    if (titleEl) titleEl.textContent = item.title;
    if (pwdInput) {
      pwdInput.value = '';
      setTimeout(() => pwdInput.focus(), 150);
    }
    if (errorEl) errorEl.style.display = 'none';
    modal.style.display = 'flex';
  }
  function openExportModal(item) {
    currentTargetItem = item;
    const modal = document.getElementById('vaultExportModal');
    const titleEl = document.getElementById('vaultExportTitle');
    const pwdInput = document.getElementById('vaultExportPassword');
    const errorEl = document.getElementById('vaultExportError');
    if (!modal) return;
    if (titleEl) titleEl.textContent = item.title;
    if (pwdInput) {
      pwdInput.value = '';
      setTimeout(() => pwdInput.focus(), 150);
    }
    if (errorEl) errorEl.style.display = 'none';
    modal.style.display = 'flex';
  }
  function setupModals() {
    const unlockModal = document.getElementById('vaultUnlockModal');
    const unlockConfirmBtn = document.getElementById('btnConfirmVaultUnlock');
    const unlockPwdInput = document.getElementById('vaultUnlockPassword');
    const unlockErrorEl = document.getElementById('vaultUnlockError');
    if (unlockConfirmBtn && unlockPwdInput) {
      const handleUnlock = async () => {
        const password = unlockPwdInput.value.trim();
        if (!password) {
          if (unlockErrorEl) {
            unlockErrorEl.textContent = 'Please enter the password for this secret video.';
            unlockErrorEl.style.display = 'block';
          }
          return;
        }
        unlockConfirmBtn.disabled = true;
        unlockConfirmBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Decrypting...';
        if (unlockErrorEl) unlockErrorEl.style.display = 'none';
        try {
          const res = await fetch('/api/secure-vault/unlock', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: currentTargetItem.id, password })
          });
          const data = await res.json();
          if (!data.ok) {
            throw new Error(data.error || 'Incorrect security password.');
          }
          unlockModal.style.display = 'none';
          if (typeof showNovaToast === 'function') {
            showNovaToast('Decrypted stream session ready. Playing in Player Studio!', 'fa-shield-halved');
          }
          if (typeof switchView === 'function') switchView('player');
          else if (typeof Nova !== 'undefined' && Nova.switchView) Nova.switchView('player');
          if (typeof Player !== 'undefined' && Player.loadItem) {
            Player.loadItem({
              id: 'sec_' + data.token,
              title: data.title || currentTargetItem.title,
              name: data.title || currentTargetItem.title,
              url: data.streamUrl,
              type: 'video',
              isSecret: true,
              isVault: true
            });
            setTimeout(() => {
              if (Player.play) Player.play();
            }, 300);
          }
        } catch (err) {
          if (unlockErrorEl) {
            unlockErrorEl.textContent = err.message;
            unlockErrorEl.style.display = 'block';
          }
        } finally {
          unlockConfirmBtn.disabled = false;
          unlockConfirmBtn.innerHTML = '<i class="fa-solid fa-unlock"></i> Unlock &amp; Play';
        }
      };
      unlockConfirmBtn.addEventListener('click', handleUnlock);
      unlockPwdInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') handleUnlock();
      });
    }
    const deleteModal = document.getElementById('vaultDeleteModal');
    const deleteConfirmBtn = document.getElementById('btnConfirmVaultDelete');
    const deletePwdInput = document.getElementById('vaultDeletePassword');
    const deleteErrorEl = document.getElementById('vaultDeleteError');
    if (deleteConfirmBtn && deletePwdInput) {
      const handleDelete = async () => {
        const password = deletePwdInput.value.trim();
        if (!password) {
          if (deleteErrorEl) {
            deleteErrorEl.textContent = 'Enter the video password or Master Key to confirm deletion.';
            deleteErrorEl.style.display = 'block';
          }
          return;
        }
        deleteConfirmBtn.disabled = true;
        deleteConfirmBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Shredding...';
        if (deleteErrorEl) deleteErrorEl.style.display = 'none';
        try {
          const res = await fetch('/api/secure-vault/delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: currentTargetItem.id, password })
          });
          const data = await res.json();
          if (!data.ok) {
            throw new Error(data.error || 'Access Denied: Invalid password or master deletion key.');
          }
          deleteModal.style.display = 'none';
          if (typeof showNovaToast === 'function') {
            showNovaToast('Secret video permanently shredded and removed from disk.', 'fa-trash');
          }
          loadAndRenderSecureFolder();
        } catch (err) {
          if (deleteErrorEl) {
            deleteErrorEl.textContent = err.message;
            deleteErrorEl.style.display = 'block';
          }
        } finally {
          deleteConfirmBtn.disabled = false;
          deleteConfirmBtn.innerHTML = '<i class="fa-solid fa-trash"></i> Permanently Delete';
        }
      };
      deleteConfirmBtn.addEventListener('click', handleDelete);
      deletePwdInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') handleDelete();
      });
    }
    const exportModal = document.getElementById('vaultExportModal');
    const exportConfirmBtn = document.getElementById('btnConfirmVaultExport');
    const exportPwdInput = document.getElementById('vaultExportPassword');
    const exportErrorEl = document.getElementById('vaultExportError');
    if (exportConfirmBtn && exportPwdInput) {
      const handleExport = async () => {
        const password = exportPwdInput.value.trim();
        if (!password) {
          if (exportErrorEl) {
            exportErrorEl.textContent = 'Please enter the password to decrypt this video.';
            exportErrorEl.style.display = 'block';
          }
          return;
        }
        exportConfirmBtn.disabled = true;
        exportConfirmBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Decrypting to Library...';
        if (exportErrorEl) exportErrorEl.style.display = 'none';
        try {
          const res = await fetch('/api/secure-vault/export', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: currentTargetItem.id, password })
          });
          const data = await res.json();
          if (!data.ok) {
            throw new Error(data.error || 'Incorrect security password.');
          }
          exportModal.style.display = 'none';
          if (typeof showNovaToast === 'function') {
            showNovaToast('Video decrypted and restored to normal Downloads Library!', 'fa-circle-check');
          }
          loadAndRenderSecureFolder();
        } catch (err) {
          if (exportErrorEl) {
            exportErrorEl.textContent = err.message;
            exportErrorEl.style.display = 'block';
          }
        } finally {
          exportConfirmBtn.disabled = false;
          exportConfirmBtn.innerHTML = '<i class="fa-solid fa-arrow-up-from-bracket"></i> Decrypt &amp; Restore';
        }
      };
      exportConfirmBtn.addEventListener('click', handleExport);
      exportPwdInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') handleExport();
      });
    }
    const lockAllBtn = document.getElementById('btnLockVaultAll');
    if (lockAllBtn) {
      lockAllBtn.addEventListener('click', async () => {
        try {
          await fetch('/api/secure-vault/lock', { method: 'POST' });
          if (typeof showNovaToast === 'function') {
            showNovaToast('Secure Folder locked! All decrypted memory pipes terminated.', 'fa-shield-halved');
          }
        } catch (e) {}
      });
    }
    document.querySelectorAll('.modal-close, .modal-cancel-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const parentModal = e.target.closest('.modal-backdrop');
        if (parentModal) parentModal.style.display = 'none';
      });
    });
  }
  function promptSecretDownload(payload, onConfirmed) {
    const modal = document.getElementById('novaSecretDownloadModal');
    if (!modal) {
      return onConfirmed({ ...payload, isSecretConfirmed: true });
    }
    const titleEl = document.getElementById('secretPromptVideoTitle');
    const formatEl = document.getElementById('secretPromptFormat');
    const secretToggle = document.getElementById('secretToggleCheckbox');
    const pwdFieldsWrap = document.getElementById('secretPasswordFieldsWrap');
    const pwdInput = document.getElementById('secretDownloadPassword');
    const pwdConfirmInput = document.getElementById('secretDownloadPasswordConfirm');
    const errorEl = document.getElementById('secretPromptError');
    const confirmBtn = document.getElementById('btnConfirmDownloadSecret');
    const cancelBtn = document.getElementById('btnCancelDownloadSecret');
    if (titleEl) titleEl.textContent = payload.titleHint || 'Video Download';
    if (formatEl) formatEl.textContent = `Mode: ${payload.mode.toUpperCase()} ${payload.quality ? `(${payload.quality}p)` : ''}`;
    const isSecretMode = !!(payload.forceSecret || payload.isSecret);
    if (secretToggle) secretToggle.checked = isSecretMode;
    if (pwdFieldsWrap) pwdFieldsWrap.style.display = isSecretMode ? 'block' : 'none';
    if (pwdInput) {
      pwdInput.value = '';
      if (isSecretMode) setTimeout(() => pwdInput.focus(), 150);
    }
    if (pwdConfirmInput) pwdConfirmInput.value = '';
    if (errorEl) errorEl.style.display = 'none';
    if (confirmBtn) {
      if (isSecretMode) {
        confirmBtn.innerHTML = '<i class="fa-solid fa-lock"></i> Download &amp; Lock in Secure Folder';
        confirmBtn.className = 'btn-primary btn-gold-glow';
      } else {
        confirmBtn.innerHTML = '<i class="fa-solid fa-download"></i> Start Normal Download';
        confirmBtn.className = 'btn-primary';
      }
    }
    const strengthContainer = document.getElementById('pwdStrengthContainer');
    const matchBadge = document.getElementById('pwdMatchBadge');
    const btnGenPass = document.getElementById('btnGenSecretPass');
    if (strengthContainer) strengthContainer.style.display = 'none';
    if (matchBadge) matchBadge.style.display = 'none';
    if (pwdConfirmInput) pwdConfirmInput.style.borderColor = '';
    const updateStrengthAndMatch = () => {
      const val = pwdInput ? pwdInput.value : '';
      const confVal = pwdConfirmInput ? pwdConfirmInput.value : '';
      if (!val) {
        if (strengthContainer) strengthContainer.style.display = 'none';
      } else {
        if (strengthContainer) strengthContainer.style.display = 'flex';
        let score = 0;
        if (val.length >= 4) score++;
        if (val.length >= 7) score++;
        if (/[A-Z]/.test(val) && /[a-z]/.test(val)) score++;
        if (/[0-9]/.test(val) && /[^A-Za-z0-9]/.test(val)) score++;
        if (score === 0) score = 1;
        const segs = [
          document.getElementById('pwdStrSeg1'),
          document.getElementById('pwdStrSeg2'),
          document.getElementById('pwdStrSeg3'),
          document.getElementById('pwdStrSeg4')
        ];
        const textEl = document.getElementById('pwdStrengthText');
        const colors = ['#ef4444', '#f97316', '#eab308', '#10b981'];
        const labels = ['Weak', 'Fair', 'Good', 'Strong'];
        segs.forEach((seg, idx) => {
          if (!seg) return;
          if (idx < score) {
            seg.style.background = colors[score - 1];
            seg.style.boxShadow = `0 0 8px ${colors[score - 1]}88`;
          } else {
            seg.style.background = 'rgba(255, 255, 255, 0.08)';
            seg.style.boxShadow = 'none';
          }
        });
        if (textEl) {
          textEl.textContent = labels[score - 1];
          textEl.style.color = colors[score - 1];
        }
      }
      if (!confVal) {
        if (matchBadge) matchBadge.style.display = 'none';
        if (pwdConfirmInput) pwdConfirmInput.style.borderColor = '';
      } else if (val === confVal) {
        if (matchBadge) {
          matchBadge.style.display = 'flex';
          matchBadge.innerHTML = '<i class="fa-solid fa-circle-check" style="color:#10b981;"></i> <span style="color:#10b981;">Passwords match perfectly</span>';
        }
        if (pwdConfirmInput) pwdConfirmInput.style.borderColor = 'rgba(16, 185, 129, 0.8)';
      } else {
        if (matchBadge) {
          matchBadge.style.display = 'flex';
          matchBadge.innerHTML = '<i class="fa-solid fa-circle-xmark" style="color:#ef4444;"></i> <span style="color:#ef4444;">Passwords do not match</span>';
        }
        if (pwdConfirmInput) pwdConfirmInput.style.borderColor = 'rgba(239, 68, 68, 0.8)';
      }
    };
    if (pwdInput) pwdInput.oninput = updateStrengthAndMatch;
    if (pwdConfirmInput) pwdConfirmInput.oninput = updateStrengthAndMatch;
    if (btnGenPass) {
      btnGenPass.onclick = () => {
        const randPIN = String(Math.floor(100000 + Math.random() * 900000));
        if (pwdInput) {
          pwdInput.value = randPIN;
          pwdInput.type = 'text';
        }
        if (pwdConfirmInput) {
          pwdConfirmInput.value = randPIN;
          pwdConfirmInput.type = 'text';
        }
        modal.querySelectorAll('.pwd-toggle-eye').forEach(btn => {
          btn.innerHTML = '<i class="fa-solid fa-eye-slash"></i>';
        });
        updateStrengthAndMatch();
        if (typeof showNovaToast === 'function') {
          showNovaToast(`Generated 6-digit Secret PIN: ${randPIN}`, 'fa-key');
        }
      };
    }
    if (secretToggle) {
      secretToggle.onchange = () => {
        if (secretToggle.checked) {
          pwdFieldsWrap.style.display = 'block';
          pwdInput.focus();
          confirmBtn.innerHTML = '<i class="fa-solid fa-lock"></i> Download &amp; Lock in Secure Folder';
          confirmBtn.className = 'btn-primary btn-gold-glow';
        } else {
          pwdFieldsWrap.style.display = 'none';
          confirmBtn.innerHTML = '<i class="fa-solid fa-download"></i> Start Normal Download';
          confirmBtn.className = 'btn-primary';
          if (errorEl) errorEl.style.display = 'none';
        }
      };
    }
    const submitHandler = () => {
      if (secretToggle && secretToggle.checked) {
        const pwd = pwdInput ? pwdInput.value.trim() : '';
        const pwdConf = pwdConfirmInput ? pwdConfirmInput.value.trim() : '';
        if (!pwd || pwd.length < 3) {
          if (errorEl) {
            errorEl.textContent = 'Please enter a password (minimum 3 characters) to secure this video.';
            errorEl.style.display = 'block';
          }
          return;
        }
        if (pwd !== pwdConf) {
          if (errorEl) {
            errorEl.textContent = 'Passwords do not match. Please re-enter identical passwords.';
            errorEl.style.display = 'block';
          }
          return;
        }
        modal.style.display = 'none';
        cleanup();
        onConfirmed({
          ...payload,
          isSecret: true,
          secretPassword: pwd,
          isSecretConfirmed: true
        });
      } else {
        modal.style.display = 'none';
        cleanup();
        onConfirmed({
          ...payload,
          isSecret: false,
          isSecretConfirmed: true
        });
      }
    };
    const cancelHandler = () => {
      modal.style.display = 'none';
      cleanup();
    };
    function cleanup() {
      if (confirmBtn) confirmBtn.onclick = null;
      if (cancelBtn) cancelBtn.onclick = null;
    }
    if (confirmBtn) confirmBtn.onclick = submitHandler;
    if (cancelBtn) cancelBtn.onclick = cancelHandler;
    modal.style.display = 'flex';
  }
  function formatBytes(bytes) {
    if (!bytes || bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }
  function formatDate(isoStr) {
    if (!isoStr) return '';
    try {
      const d = new Date(isoStr);
      return d.toLocaleDateString() + ' ' + d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch (e) {
      return isoStr;
    }
  }
  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }
  function setupEyeToggles() {
    document.querySelectorAll('.pwd-toggle-eye').forEach(btn => {
      btn.addEventListener('click', () => {
        const targetId = btn.getAttribute('data-target');
        const input = document.getElementById(targetId);
        if (input) {
          if (input.type === 'password') {
            input.type = 'text';
            btn.innerHTML = '<i class="fa-solid fa-eye-slash"></i>';
          } else {
            input.type = 'password';
            btn.innerHTML = '<i class="fa-solid fa-eye"></i>';
          }
        }
      });
    });
  }
  document.addEventListener('DOMContentLoaded', () => {
    setupModals();
    setupEyeToggles();
    fetchVaultList();
  });
  window.SecureVault = {
    init: setupModals,
    loadAndRender: loadAndRenderSecureFolder,
    promptSecretDownload
  };
  window.loadAndRenderSecureFolder = loadAndRenderSecureFolder;
})();