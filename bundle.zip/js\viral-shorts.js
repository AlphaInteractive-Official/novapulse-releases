(function () {
  'use strict';
  let currentMedia = null;
  let detectedMoments = [];
  let selectedMoment = null;
  let activeLayout = 'blurred_stack';
  let isAnalyzing = false;
  let renderPollTimer = null;
  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }
  function formatTime(seconds) {
    if (isNaN(seconds) || seconds < 0) seconds = 0;
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }
  function formatBytes(bytes) {
    if (!bytes || bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  }
  async function populateVideoSources() {
    const select = document.getElementById('shortsSourceSelect');
    if (!select) return;
    let list = [];
    if (typeof window.Library !== 'undefined' && typeof window.Library.getMediaList === 'function') {
      list = window.Library.getMediaList() || [];
    }
    if (list.length === 0 && typeof window.Library !== 'undefined' && typeof window.Library.fetchLibrary === 'function') {
      list = await window.Library.fetchLibrary();
    }
    const videos = list.filter(i => i.type === 'video');
    select.innerHTML = '<option value="">-- Choose a video to turn into viral Shorts --</option>';
    videos.forEach(v => {
      const opt = document.createElement('option');
      opt.value = v.id;
      opt.textContent = `${v.name} (${v.resolution || 'HD'})`;
      opt.dataset.mediaPath = v.path || '';
      opt.dataset.mediaUrl = v.url || '';
      opt.dataset.mediaName = v.name || '';
      opt.dataset.duration = v.duration || 0;
      select.appendChild(opt);
    });
    if (currentMedia && select.querySelector(`option[value="${currentMedia.id}"]`)) {
      select.value = currentMedia.id;
    }
  }
  async function analyzeViralHooks() {
    const select = document.getElementById('shortsSourceSelect');
    const btn = document.getElementById('btnAnalyzeViralHooks');
    const container = document.getElementById('shortsMomentsContainer');
    const countBadge = document.getElementById('shortsMomentsCountBadge');
    if (!select || !select.value) {
      alert('Please select a video from the dropdown first!');
      return;
    }
    const selectedOpt = select.options[select.selectedIndex];
    const mediaId = select.value;
    const videoTitle = selectedOpt ? selectedOpt.dataset.mediaName : 'Video';
    const mediaUrl = selectedOpt ? selectedOpt.dataset.mediaUrl : '';
    currentMedia = {
      id: mediaId,
      name: videoTitle,
      url: mediaUrl,
      duration: parseFloat(selectedOpt?.dataset?.duration) || 0
    };
    if (btn) {
      btn.disabled = true;
      btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Scanning transcript for viral hooks...';
    }
    if (container) {
      container.innerHTML = `
        <div style="text-align: center; padding: 32px 16px; color: #94a3b8;">
          <i class="fa-solid fa-brain fa-bounce" style="font-size: 2.4rem; color: #ff1f3d; margin-bottom: 12px; display: inline-block;"></i>
          <div style="font-weight: 800; color: #fff; font-size: 1.05rem;">AI Neural Hook Scanner Active</div>
          <p style="font-size: 0.82rem; margin: 6px 0 0; color: #cbd5e1;">Evaluating speech retention velocity, contrarian hooks, emotional peaks &amp; punchlines...</p>
        </div>
      `;
    }
    try {
      const res = await fetch('/api/shorts/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mediaId,
          videoTitle,
          customDuration: currentMedia.duration
        })
      });
      const data = await res.json();
      if (!data.ok || !Array.isArray(data.moments) || data.moments.length === 0) {
        if (container) {
          container.innerHTML = `
            <div style="padding: 24px; text-align: center; color: #f87171;">
              <i class="fa-solid fa-triangle-exclamation" style="font-size: 1.8rem; margin-bottom: 8px;"></i>
              <div>Failed to detect moments: ${escapeHtml(data.error || 'No transcript speech found')}</div>
            </div>
          `;
        }
        return;
      }
      detectedMoments = data.moments;
      if (countBadge) {
        countBadge.style.display = 'inline-block';
        countBadge.textContent = `${detectedMoments.length} viral clips`;
      }
      renderMomentsList(detectedMoments);
      if (detectedMoments.length > 0) {
        selectMoment(detectedMoments[0]);
      }
      if (typeof window.showNovaToast === 'function') {
        window.showNovaToast(`AI Hook Scanner: ${detectedMoments.length} viral 9:16 clips identified!`, 'fa-bolt');
      }
    } catch (err) {
      if (container) {
        container.innerHTML = `
          <div style="padding: 24px; text-align: center; color: #f87171;">
            <i class="fa-solid fa-triangle-exclamation" style="font-size: 1.8rem; margin-bottom: 8px;"></i>
            <div>Analysis failed: ${escapeHtml(err.message)}</div>
          </div>
        `;
      }
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-wand-magic-sparkles"></i> <span>Re-Analyze Viral Hooks</span>';
      }
    }
  }
  function renderMomentsList(moments) {
    const container = document.getElementById('shortsMomentsContainer');
    if (!container) return;
    container.innerHTML = '';
    moments.forEach((m, idx) => {
      const card = document.createElement('div');
      card.className = `shorts-moment-card ${idx === 0 ? 'active' : ''}`;
      card.id = `momentCard_${m.id}`;
      card.innerHTML = `
        <div class="shorts-moment-top">
          <span class="shorts-virality-badge">
            <i class="fa-solid fa-fire"></i> ${m.viralityScore}% Viral Potential
          </span>
          <span class="shorts-time-badge">
            <i class="fa-regular fa-clock"></i> ${formatTime(m.start)} &rarr; ${formatTime(m.end)} (${m.duration}s)
          </span>
        </div>
        <div style="font-weight: 800; color: #fff; font-size: 0.9rem; margin-bottom: 4px;">
          ${escapeHtml(m.title)}
        </div>
        <div class="shorts-quote-text">
          "${escapeHtml(m.quote || m.reason || 'High engagement moment')}"
        </div>
        <div class="shorts-reason-text">
          <i class="fa-solid fa-bullseye" style="color: #ff4d6d;"></i>
          <span>${escapeHtml(m.category || 'High Retention')} &bull; ${escapeHtml(m.reason || '')}</span>
        </div>
      `;
      card.addEventListener('click', () => {
        document.querySelectorAll('.shorts-moment-card').forEach(c => c.classList.remove('active'));
        card.classList.add('active');
        selectMoment(m);
      });
      container.appendChild(card);
    });
  }
  function selectMoment(moment) {
    selectedMoment = moment;
    const banner = document.getElementById('phoneHookBanner');
    const hookInput = document.getElementById('shortsHookTitleInput');
    const headline = moment.hookHeadline || '🔥 MUST WATCH';
    if (banner) banner.textContent = headline;
    if (hookInput) hookInput.value = headline;
    const subPreview = document.getElementById('phoneSubPreview');
    if (subPreview) {
      subPreview.textContent = moment.quote ? `"${moment.quote}"` : 'Subtitle Preview';
    }
    const video = document.getElementById('shortsPreviewVideo');
    const placeholder = document.getElementById('phonePreviewPlaceholder');
    if (video && currentMedia && currentMedia.url) {
      if (placeholder) placeholder.style.display = 'none';
      video.src = currentMedia.url;
      video.currentTime = moment.start;
      video.muted = true; // Avoid sudden loud audio during preview
      const p = video.play();
      if (p && typeof p.catch === 'function') p.catch(() => {});
      video.ontimeupdate = () => {
        if (video.currentTime >= moment.end) {
          video.currentTime = moment.start;
        }
      };
    }
  }
  async function exportShort() {
    if (!currentMedia) {
      alert('Please choose a video from your library first!');
      return;
    }
    if (!selectedMoment) {
      alert('Please click on an AI-detected viral moment from the shelf first!');
      return;
    }
    const btn = document.getElementById('btnExportShort');
    const progressBox = document.getElementById('shortsRenderProgressBox');
    const progressBar = document.getElementById('shortsProgressBar');
    const pctText = document.getElementById('shortsRenderPctText');
    const statusText = document.getElementById('shortsRenderStatusText');
    const hookInput = document.getElementById('shortsHookTitleInput');
    const subSelect = document.getElementById('shortsSubStyleSelect');
    const hookTitle = hookInput ? hookInput.value.trim() : '🔥 THE REAL TRUTH';
    const subStyle = subSelect ? subSelect.value : 'yellow_bold';
    if (btn) {
      btn.disabled = true;
      btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Rendering 9:16 Short...';
    }
    if (progressBox) progressBox.style.display = 'block';
    if (progressBar) progressBar.style.width = '5%';
    if (pctText) pctText.textContent = '5%';
    if (statusText) statusText.textContent = 'Initializing 1080x1920 filtergraph & subtitles...';
    try {
      const res = await fetch('/api/shorts/render', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mediaId: currentMedia.id,
          start: selectedMoment.start,
          end: selectedMoment.end,
          layout: activeLayout,
          burnSubtitles: subStyle !== 'none',
          subtitleStyle: subStyle,
          hookTitle
        })
      });
      const data = await res.json();
      if (!data.ok) {
        throw new Error(data.error || 'Server rejected rendering request');
      }
      const jobId = data.jobId;
      clearInterval(renderPollTimer);
      renderPollTimer = setInterval(async () => {
        try {
          const sRes = await fetch(`/api/shorts/status/${jobId}`);
          const sData = await sRes.json();
          if (sData.ok && sData.job) {
            const job = sData.job;
            const progress = job.progress || 0;
            if (progressBar) progressBar.style.width = `${progress}%`;
            if (pctText) pctText.textContent = `${progress}%`;
            if (job.status === 'completed') {
              clearInterval(renderPollTimer);
              if (statusText) statusText.textContent = 'Rendering Complete!';
              if (progressBar) progressBar.style.width = '100%';
              if (pctText) pctText.textContent = '100%';
              if (typeof window.showNovaToast === 'function') {
                window.showNovaToast('Viral 9:16 Short Rendered Successfully!', 'fa-circle-check');
              }
              if (btn) {
                btn.disabled = false;
                btn.innerHTML = '<i class="fa-solid fa-circle-check" style="color:#4ade80;"></i> Export Complete! Render Another';
              }
              loadShortsGallery();
            } else if (job.status === 'error') {
              clearInterval(renderPollTimer);
              throw new Error(job.error || 'Rendering job failed');
            }
          }
        } catch (pollErr) {
          console.warn('Status poll warning:', pollErr);
        }
      }, 600);
    } catch (err) {
      clearInterval(renderPollTimer);
      alert('Failed to render short: ' + err.message);
      if (btn) {
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-bolt"></i> Export 9:16 Viral Short (Instant Render)';
      }
      if (statusText) statusText.textContent = 'Render failed: ' + err.message;
    }
  }
  async function loadShortsGallery() {
    const grid = document.getElementById('shortsGalleryGrid');
    if (!grid) return;
    try {
      const res = await fetch('/api/shorts/list');
      const data = await res.json();
      if (!data.ok || !data.shorts || data.shorts.length === 0) {
        grid.innerHTML = `
          <div style="grid-column: 1 / -1; text-align: center; padding: 24px; color: #64748b;">
            <i class="fa-solid fa-film" style="font-size: 2rem; margin-bottom: 8px; opacity: 0.4;"></i>
            <div>No 9:16 Shorts exported yet. Select a moment above and click Export!</div>
          </div>
        `;
        return;
      }
      grid.innerHTML = '';
      data.shorts.forEach(s => {
        const card = document.createElement('div');
        card.className = 'shorts-gallery-card';
        card.innerHTML = `
          <video src="${escapeHtml(s.url)}" preload="metadata" muted playsinline></video>
          <div class="shorts-gallery-overlay">
            <div class="shorts-gallery-title" title="${escapeHtml(s.filename)}">${escapeHtml(s.filename)}</div>
            <div class="shorts-gallery-actions">
              <span style="font-size: 0.7rem; color: #94a3b8; font-weight: 600;">${formatBytes(s.size)}</span>
              <div style="display: flex; gap: 6px;">
                <button class="btn-primary" style="padding: 4px 10px; font-size: 0.75rem;" title="Play in Player Studio" onclick="if(window.playLibraryTrackWithQueue) window.playLibraryTrackWithQueue({ id: 'short_${btoa(s.filename)}', name: '${escapeHtml(s.filename)}', url: '${escapeHtml(s.url)}', type: 'video' })">
                  <i class="fa-solid fa-play"></i> Play
                </button>
                <a href="${escapeHtml(s.url)}" download="${escapeHtml(s.filename)}" class="btn-subtle" style="padding: 4px 8px; font-size: 0.75rem;" title="Download to Device">
                  <i class="fa-solid fa-download"></i>
                </a>
              </div>
            </div>
          </div>
        `;
        const vid = card.querySelector('video');
        if (vid) {
          card.addEventListener('mouseenter', () => vid.play().catch(() => {}));
          card.addEventListener('mouseleave', () => { vid.pause(); vid.currentTime = 0; });
        }
        grid.appendChild(card);
      });
    } catch (e) {
      console.warn('Could not load shorts gallery:', e);
    }
  }
  function setupShortsEvents() {
    document.querySelectorAll('.shorts-layout-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        document.querySelectorAll('.shorts-layout-chip').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        activeLayout = chip.dataset.layout;
        const videoWrap = document.getElementById('phoneVideoWrap');
        if (videoWrap) {
          if (activeLayout === 'center_crop') {
            videoWrap.style.transform = 'scale(1)';
            videoWrap.style.filter = 'none';
          } else if (activeLayout === 'smart_fit') {
            videoWrap.style.transform = 'scale(0.95)';
          }
        }
      });
    });
    const hookInput = document.getElementById('shortsHookTitleInput');
    const hookBanner = document.getElementById('phoneHookBanner');
    if (hookInput && hookBanner) {
      hookInput.addEventListener('input', () => {
        hookBanner.textContent = hookInput.value.toUpperCase() || '🔥 THE REAL TRUTH';
      });
    }
    const subSelect = document.getElementById('shortsSubStyleSelect');
    const subPreview = document.getElementById('phoneSubPreview');
    if (subSelect && subPreview) {
      subSelect.addEventListener('change', () => {
        const val = subSelect.value;
        if (val === 'yellow_bold') {
          subPreview.style.display = 'block';
          subPreview.style.color = '#ffff00';
        } else if (val === 'cyan_cyber') {
          subPreview.style.display = 'block';
          subPreview.style.color = '#00F5FF';
        } else if (val === 'white_clean') {
          subPreview.style.display = 'block';
          subPreview.style.color = '#ffffff';
        } else if (val === 'none') {
          subPreview.style.display = 'none';
        }
      });
    }
    const sourceSelect = document.getElementById('shortsSourceSelect');
    if (sourceSelect) {
      sourceSelect.addEventListener('change', () => {
        if (sourceSelect.value) {
          analyzeViralHooks();
        }
      });
    }
    const btnAnalyze = document.getElementById('btnAnalyzeViralHooks');
    if (btnAnalyze) btnAnalyze.addEventListener('click', analyzeViralHooks);
    const btnExport = document.getElementById('btnExportShort');
    if (btnExport) btnExport.addEventListener('click', exportShort);
    const btnRefresh = document.getElementById('btnRefreshShortsLibrary');
    if (btnRefresh) btnRefresh.addEventListener('click', loadShortsGallery);
    const btnOpenFolder = document.getElementById('btnShortsOpenFolder');
    if (btnOpenFolder) {
      btnOpenFolder.addEventListener('click', () => {
        if (typeof window.openFolder === 'function') {
          window.openFolder('Videos\\Shorts');
        } else {
          fetch('/api/open-folder', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ subfolder: 'Videos/Shorts' })
          });
        }
      });
    }
    const btnPlayerLaunchShorts = document.getElementById('btnPlayerLaunchShorts');
    if (btnPlayerLaunchShorts) {
      btnPlayerLaunchShorts.addEventListener('click', () => {
        let playerItem = null;
        if (typeof window.Playlist !== 'undefined' && typeof window.Playlist.getCurrentItem === 'function') {
          playerItem = window.Playlist.getCurrentItem();
        }
        if (playerItem) {
          openFromPlayer(playerItem);
        } else {
          if (typeof window.switchView === 'function') window.switchView('viral-shorts');
        }
      });
    }
  }
  function openFromPlayer(mediaItem) {
    if (typeof window.switchView === 'function') {
      window.switchView('viral-shorts');
    }
    setTimeout(async () => {
      await populateVideoSources();
      const select = document.getElementById('shortsSourceSelect');
      if (select && mediaItem) {
        for (let i = 0; i < select.options.length; i++) {
          if (select.options[i].value === mediaItem.id || (mediaItem.name && select.options[i].textContent.includes(mediaItem.name.slice(0, 20)))) {
            select.selectedIndex = i;
            break;
          }
        }
        analyzeViralHooks();
      }
    }, 200);
  }
  function onOpen() {
    populateVideoSources();
    loadShortsGallery();
  }
  function init() {
    setupShortsEvents();
    populateVideoSources();
    loadShortsGallery();
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
  window.ViralShorts = {
    onOpen,
    openFromPlayer,
    analyzeViralHooks,
    exportShort
  };
})();