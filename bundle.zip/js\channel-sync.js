const ChannelSync = (function () {
  let subscriptions = [];
  let filter = 'all'; // all | active | paused
  let isResolving = false;
  let isAdding = false;
  function init() {
    bindControls();
    loadSubscriptions();
  }
  function getAuthToken() {
    return localStorage.getItem('novapulse_auth_token') || 'DEFAULT0725';
  }
  function bindControls() {
    const btnSyncAll = document.getElementById('btnSyncAllChannels');
    if (btnSyncAll) {
      btnSyncAll.addEventListener('click', async () => {
        btnSyncAll.disabled = true;
        btnSyncAll.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Syncing Feeds...';
        try {
          const res = await fetch('/api/subscriptions/sync-all', {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${getAuthToken()}` }
          });
          const data = await res.json();
          if (data && data.ok) {
            if (typeof showNovaToast === 'function') {
              showNovaToast(`Synced ${data.count} channel feeds!`, 'fa-rotate');
            }
            loadSubscriptions();
          }
        } catch (err) {
          alert('Sync all error: ' + err.message);
        } finally {
          btnSyncAll.disabled = false;
          btnSyncAll.innerHTML = '<i class="fa-solid fa-arrows-rotate"></i> Sync All Channels Now';
        }
      });
    }
    const btnOpenAddModal = document.getElementById('btnOpenAddSubModal');
    const modal = document.getElementById('modalAddSubscription');
    const btnCloseModal = document.getElementById('btnCloseSubModal');
    const btnCancelModal = document.getElementById('btnCancelSubModal');
    if (btnOpenAddModal && modal) {
      btnOpenAddModal.addEventListener('click', () => {
        modal.style.display = 'flex';
        document.getElementById('inputSubUrl')?.focus();
      });
    }
    const closeModal = () => { if (modal) modal.style.display = 'none'; };
    if (btnCloseModal) btnCloseModal.addEventListener('click', closeModal);
    if (btnCancelModal) btnCancelModal.addEventListener('click', closeModal);
    const btnInspect = document.getElementById('btnInspectSubUrl');
    const inputUrl = document.getElementById('inputSubUrl');
    if (btnInspect && inputUrl) {
      btnInspect.addEventListener('click', async () => {
        const url = inputUrl.value.trim();
        if (!url) return;
        btnInspect.disabled = true;
        btnInspect.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';
        try {
          const res = await fetch('/api/subscriptions/resolve', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${getAuthToken()}`
            },
            body: JSON.stringify({ url })
          });
          const data = await res.json();
          if (data && data.ok && data.info) {
            const previewEl = document.getElementById('subPreviewBox');
            if (previewEl) {
              previewEl.style.display = 'flex';
              const nameEl = document.getElementById('subPreviewName');
              if (nameEl) nameEl.textContent = data.info.channelName;
              const countEl = document.getElementById('subPreviewCount');
              if (countEl) countEl.textContent = `${data.info.recentVideoCount} recent uploads detected`;
              const avatarEl = document.getElementById('subPreviewAvatar');
              if (avatarEl && data.info.avatar) avatarEl.src = data.info.avatar;
            }
            const nameInput = document.getElementById('inputSubName');
            if (nameInput && !nameInput.value) {
              nameInput.value = data.info.channelName;
            }
          }
        } catch (err) {
          console.warn('Inspect channel error:', err.message);
        } finally {
          btnInspect.disabled = false;
          btnInspect.innerHTML = 'Inspect';
        }
      });
    }
    const btnSubmitAdd = document.getElementById('btnSubmitAddSub');
    if (btnSubmitAdd) {
      btnSubmitAdd.addEventListener('click', async () => {
        const url = document.getElementById('inputSubUrl')?.value.trim();
        const customName = document.getElementById('inputSubName')?.value.trim();
        const quality = document.getElementById('selectSubQuality')?.value || '1080p';
        const format = document.getElementById('selectSubFormat')?.value || 'video';
        const maxItems = parseInt(document.getElementById('selectSubMaxItems')?.value, 10) || 5;
        const plexNaming = document.getElementById('checkSubPlex')?.checked !== false;
        if (!url) {
          alert('Please enter a channel or playlist link');
          return;
        }
        btnSubmitAdd.disabled = true;
        btnSubmitAdd.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Subscribing...';
        try {
          const res = await fetch('/api/subscriptions/add', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${getAuthToken()}`
            },
            body: JSON.stringify({
              url,
              customName,
              quality,
              format,
              maxItems,
              plexNaming,
              autoSync: true
            })
          });
          const data = await res.json();
          if (data && data.ok) {
            if (typeof showNovaToast === 'function') {
              showNovaToast(`Subscribed to ${data.subscription.channelName}! Initial sync queued.`, 'fa-circle-check');
            }
            closeModal();
            if (inputUrl) inputUrl.value = '';
            document.getElementById('subPreviewBox').style.display = 'none';
            loadSubscriptions();
          } else {
            alert('Could not add subscription: ' + (data.error || 'Unknown error'));
          }
        } catch (err) {
          alert('Network error: ' + err.message);
        } finally {
          btnSubmitAdd.disabled = false;
          btnSubmitAdd.innerHTML = '<i class="fa-solid fa-satellite-dish"></i> Subscribe &amp; Start Sync';
        }
      });
    }
    document.querySelectorAll('.sub-filter-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        filter = chip.getAttribute('data-filter') || 'all';
        document.querySelectorAll('.sub-filter-chip').forEach(c => c.classList.toggle('active', c === chip));
        renderList();
      });
    });
  }
  async function loadSubscriptions() {
    const grid = document.getElementById('channelSubscriptionsGrid');
    if (!grid) return;
    try {
      const res = await fetch('/api/subscriptions', {
        headers: { 'Authorization': `Bearer ${getAuthToken()}` }
      });
      const data = await res.json();
      if (data && data.ok) {
        subscriptions = Array.isArray(data.subscriptions) ? data.subscriptions : [];
        const countBadge = document.getElementById('subCountBadge');
        if (countBadge) countBadge.textContent = subscriptions.length;
        renderList();
      }
    } catch (err) {
      console.warn('Could not load subscriptions:', err);
    }
  }
  function renderList() {
    const grid = document.getElementById('channelSubscriptionsGrid');
    if (!grid) return;
    let filtered = subscriptions;
    if (filter === 'active') filtered = subscriptions.filter(s => s.autoSync);
    else if (filter === 'paused') filtered = subscriptions.filter(s => !s.autoSync);
    if (filtered.length === 0) {
      grid.innerHTML = `
        <div style="grid-column: 1 / -1; text-align: center; padding: 60px 20px; background: rgba(14,18,28,0.5); border: 1px dashed rgba(255,255,255,0.1); border-radius: 16px;">
          <div style="width: 64px; height: 64px; border-radius: 50%; background: rgba(0,242,254,0.1); color: var(--accent-cyan); display: flex; align-items: center; justify-content: center; font-size: 1.8rem; margin: 0 auto 16px;">
            <i class="fa-solid fa-satellite-dish"></i>
          </div>
          <h3 style="font-size: 1.2rem; font-weight: 700; color: #fff; margin: 0 0 8px;">No Channel Subscriptions Active</h3>
          <p style="color: var(--text-muted); max-width: 440px; margin: 0 auto 20px; font-size: 0.9rem; line-height: 1.5;">
            Subscribe to YouTube channels, podcasts, or video feeds. NovaPulse will check for new uploads in the background and organize them into Plex/Jellyfin TV Show directories automatically.
          </p>
          <button class="btn-primary" onclick="document.getElementById('btnOpenAddSubModal').click()">
            <i class="fa-solid fa-plus"></i> Add Channel / Playlist
          </button>
        </div>
      `;
      return;
    }
    grid.innerHTML = filtered.map(sub => {
      const isSyncing = sub.status === 'syncing';
      const lastSyncStr = sub.lastSync ? new Date(sub.lastSync).toLocaleString() : 'Never';
      const avatarSrc = sub.avatar || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=100&auto=format&fit=crop&q=80';
      return `
        <div class="sub-card" data-id="${sub.id}">
          <div class="sub-card-header">
            <img src="${avatarSrc}" class="sub-channel-avatar" alt="Avatar" onerror="this.src='https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=100&auto=format&fit=crop&q=80'" />
            <div style="flex: 1; min-width: 0;">
              <h4 class="sub-channel-title" title="${escapeHtml(sub.channelName)}">${escapeHtml(sub.channelName)}</h4>
              <a href="${escapeHtml(sub.url)}" target="_blank" class="sub-channel-url">
                <i class="fa-solid fa-arrow-up-right-from-square"></i> Channel Feed
              </a>
            </div>
            <span class="sub-status-indicator ${sub.autoSync ? 'active' : 'paused'}">
              ${sub.autoSync ? '● Auto-Sync' : '○ Paused'}
            </span>
          </div>
          <div class="sub-card-body">
            <div class="sub-badges-row">
              <span class="sub-pill"><i class="fa-solid fa-film"></i> ${escapeHtml(sub.quality)}</span>
              <span class="sub-pill"><i class="fa-solid fa-clock-rotate-left"></i> Latest ${sub.maxItems}</span>
              ${sub.plexNaming ? `<span class="sub-pill" style="border-color: rgba(245,158,11,0.3); color: #f59e0b;"><i class="fa-solid fa-server"></i> Plex / .nfo</span>` : ''}
            </div>
            <div class="sub-stat-row">
              <span style="color: var(--text-muted); font-size: 0.82rem;">Downloaded Episodes:</span>
              <strong style="color: #fff; font-size: 0.88rem;">${sub.totalDownloaded || 0} videos</strong>
            </div>
            <div class="sub-stat-row" style="margin-top: 4px;">
              <span style="color: var(--text-muted); font-size: 0.82rem;">Last Sync Check:</span>
              <span style="color: var(--text-muted); font-size: 0.8rem;">${lastSyncStr}</span>
            </div>
          </div>
          <div class="sub-card-footer">
            <button class="btn-subtle btn-mini btn-sub-toggle" data-id="${sub.id}" title="${sub.autoSync ? 'Pause background sync' : 'Resume background sync'}">
              <i class="fa-solid ${sub.autoSync ? 'fa-pause' : 'fa-play'}"></i> ${sub.autoSync ? 'Pause' : 'Resume'}
            </button>
            <button class="btn-primary btn-mini btn-sub-sync" data-id="${sub.id}" ${isSyncing ? 'disabled' : ''}>
              <i class="fa-solid ${isSyncing ? 'fa-spinner fa-spin' : 'fa-rotate'}"></i> ${isSyncing ? 'Syncing...' : 'Sync Now'}
            </button>
            <button class="btn-subtle btn-mini btn-sub-delete" data-id="${sub.id}" title="Remove subscription" style="color: #ef4444;">
              <i class="fa-solid fa-trash-can"></i>
            </button>
          </div>
        </div>
      `;
    }).join('');
    grid.querySelectorAll('.btn-sub-sync').forEach(btn => {
      btn.addEventListener('click', async () => {
        const id = btn.getAttribute('data-id');
        btn.disabled = true;
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Checking...';
        try {
          const res = await fetch(`/api/subscriptions/${encodeURIComponent(id)}/sync`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${getAuthToken()}` }
          });
          const data = await res.json();
          if (data && data.ok) {
            const count = data.result?.newCount || 0;
            if (typeof showNovaToast === 'function') {
              showNovaToast(`Sync complete! ${count} new uploads queued.`, 'fa-circle-check');
            }
            loadSubscriptions();
          } else {
            alert('Sync failed: ' + (data.error || 'Unknown error'));
          }
        } catch (err) {
          alert('Sync error: ' + err.message);
        } finally {
          btn.disabled = false;
          btn.innerHTML = '<i class="fa-solid fa-rotate"></i> Sync Now';
        }
      });
    });
    grid.querySelectorAll('.btn-sub-toggle').forEach(btn => {
      btn.addEventListener('click', async () => {
        const id = btn.getAttribute('data-id');
        try {
          const res = await fetch(`/api/subscriptions/${encodeURIComponent(id)}/toggle`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${getAuthToken()}` }
          });
          const data = await res.json();
          if (data && data.ok) {
            loadSubscriptions();
          }
        } catch (err) {
          console.warn('Toggle error:', err);
        }
      });
    });
    grid.querySelectorAll('.btn-sub-delete').forEach(btn => {
      btn.addEventListener('click', async () => {
        const id = btn.getAttribute('data-id');
        if (!confirm('Are you sure you want to unsubscribe from this channel? (Previously downloaded files will remain safe).')) return;
        try {
          const res = await fetch(`/api/subscriptions/${encodeURIComponent(id)}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${getAuthToken()}` }
          });
          const data = await res.json();
          if (data && data.ok) {
            if (typeof showNovaToast === 'function') showNovaToast('Unsubscribed successfully', 'fa-trash-can');
            loadSubscriptions();
          }
        } catch (err) {
          alert('Delete error: ' + err.message);
        }
      });
    });
  }
  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }
  return {
    init,
    loadSubscriptions,
    onOpen: () => loadSubscriptions()
  };
})();
window.ChannelSync = ChannelSync;
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => ChannelSync.init());
} else {
  ChannelSync.init();
}