/**
 * NovaPulse — Master Presentation Layer Manager
 * Alpha Interactive (c) 2026. All rights reserved.
 * 
 * Coordinates the 3 independent presentation layers (Desktop, Tablet, Mobile)
 * on top of the shared core application ecosystem.
 */

(function () {
  'use strict';

  window.NovaPulse = window.NovaPulse || {};

  var presentation = {
    getDevice: function () {
      return (window.NovaPulseDevice && window.NovaPulseDevice.getDevice()) || 'desktop';
    },

    isDesktop: function () {
      return this.getDevice() === 'desktop';
    },

    isTablet: function () {
      return this.getDevice() === 'tablet';
    },

    isMobile: function () {
      return this.getDevice() === 'mobile';
    },

    getOrientation: function () {
      return (window.NovaPulseDevice && window.NovaPulseDevice.getOrientation()) || 'landscape';
    },

    setDeviceOverride: function (mode) {
      if (window.NovaPulseDevice) {
        window.NovaPulseDevice.setOverride(mode);
      }
    },

    getDeviceOverride: function () {
      return (window.NovaPulseDevice && window.NovaPulseDevice.getOverride()) || 'auto';
    },

    onDeviceChange: function (fn) {
      if (window.NovaPulseDevice) {
        window.NovaPulseDevice.onDeviceChange(fn);
      }
    },

    init: function () {
      var device = this.getDevice();
      console.log('[NovaPulse] Master presentation manager initialized. Active layer: ' + device.toUpperCase());

      // Trigger initialization of the active layer
      if (device === 'desktop' && window.NovaPulseDesktop) {
        window.NovaPulseDesktop.init();
      } else if (device === 'tablet' && window.NovaPulseTablet) {
        window.NovaPulseTablet.init();
      } else if (device === 'mobile' && window.NovaPulseMobile) {
        window.NovaPulseMobile.init();
      }
    }
  };

  window.NovaPulse.presentation = presentation;

  window.addEventListener('nova:device-changed', function (e) {
    var dev = e.detail && e.detail.device;
    if (dev === 'desktop' && window.NovaPulseDesktop) {
      window.NovaPulseDesktop.init();
    } else if (dev === 'tablet' && window.NovaPulseTablet) {
      window.NovaPulseTablet.init();
    } else if (dev === 'mobile' && window.NovaPulseMobile) {
      window.NovaPulseMobile.init();
    }
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      presentation.init();
    });
  } else {
    presentation.init();
  }

})();
