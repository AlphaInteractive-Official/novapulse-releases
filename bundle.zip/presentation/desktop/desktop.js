/**
 * NovaPulse — Desktop Presentation Controller
 * Alpha Interactive (c) 2026. All rights reserved.
 * 
 * Specialized keyboard shortcuts, mouse hover interactions, and desktop UX enhancements.
 */

(function () {
  'use strict';

  var isInitialized = false;

  function initDesktopPresentation() {
    if (isInitialized) return;
    isInitialized = true;

    // Desktop Global Keyboard Shortcuts
    window.addEventListener('keydown', function (e) {
      // Ignore if user is currently typing in an input, textarea, or contenteditable
      var tag = e.target.tagName.toLowerCase();
      var isInput = tag === 'input' || tag === 'textarea' || tag === 'select' || e.target.isContentEditable;

      // Esc always dismisses open modals
      if (e.key === 'Escape') {
        var openModal = document.querySelector('.modal-backdrop:not([style*="display: none"])');
        if (openModal) {
          e.preventDefault();
          var closeBtn = openModal.querySelector('.modal-close, .modal-cancel-btn');
          if (closeBtn) closeBtn.click();
          return;
        }
      }

      if (isInput) return;

      var player = document.getElementById('mainVideoPlayer');

      // Space / 'k' -> Play/Pause
      if (e.key === ' ' || e.key === 'k' || e.key === 'K') {
        e.preventDefault();
        var playBtn = document.getElementById('btnPlayPause');
        if (playBtn) playBtn.click();
      }

      // 'f' / 'F' -> Fullscreen Toggle
      else if (e.key === 'f' || e.key === 'F') {
        e.preventDefault();
        var fsBtn = document.getElementById('btnFullscreen');
        if (fsBtn) fsBtn.click();
      }

      // 'm' / 'M' -> Mute Toggle
      else if (e.key === 'm' || e.key === 'M') {
        e.preventDefault();
        var muteBtn = document.getElementById('btnMute');
        if (muteBtn) muteBtn.click();
      }

      // ArrowLeft / 'j' -> Seek backward 5s
      else if (e.key === 'ArrowLeft' || e.key === 'j' || e.key === 'J') {
        e.preventDefault();
        if (player && !isNaN(player.currentTime)) {
          player.currentTime = Math.max(0, player.currentTime - 5);
        }
      }

      // ArrowRight / 'l' -> Seek forward 5s
      else if (e.key === 'ArrowRight' || e.key === 'l' || e.key === 'L') {
        e.preventDefault();
        if (player && !isNaN(player.currentTime) && !isNaN(player.duration)) {
          player.currentTime = Math.min(player.duration, player.currentTime + 5);
        }
      }

      // ArrowUp -> Volume + 10%
      else if (e.key === 'ArrowUp') {
        e.preventDefault();
        if (player) {
          player.volume = Math.min(1, player.volume + 0.1);
          var slider = document.getElementById('volumeSlider');
          if (slider) slider.value = player.volume;
        }
      }

      // ArrowDown -> Volume - 10%
      else if (e.key === 'ArrowDown') {
        e.preventDefault();
        if (player) {
          player.volume = Math.max(0, player.volume - 0.1);
          var slider = document.getElementById('volumeSlider');
          if (slider) slider.value = player.volume;
        }
      }
    });

    console.log('[NovaPulse] Desktop presentation layer active.');
  }

  // Auto-init when desktop is detected
  if (document.documentElement.getAttribute('data-device') === 'desktop') {
    initDesktopPresentation();
  }

  window.addEventListener('nova:device-changed', function (e) {
    if (e.detail && e.detail.device === 'desktop') {
      initDesktopPresentation();
    }
  });

  window.NovaPulseDesktop = {
    init: initDesktopPresentation
  };

})();
