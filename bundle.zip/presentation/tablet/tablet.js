/**
 * NovaPulse — Tablet Presentation Controller
 * Alpha Interactive (c) 2026. All rights reserved.
 * 
 * Adaptive navigation rail behavior, orientation shifts, and tablet gestures.
 */

(function () {
  'use strict';

  var isInitialized = false;

  function initTabletPresentation() {
    if (isInitialized) return;
    isInitialized = true;

    var sidebar = document.querySelector('.nova-sidebar');
    var isExpanded = false;

    // Optional expandable rail on tablet
    if (sidebar) {
      var brandStrip = sidebar.querySelector('.sidebar-brand-strip');
      if (brandStrip) {
        brandStrip.style.cursor = 'pointer';
        brandStrip.setAttribute('title', 'Tap to expand/collapse navigation labels');
        brandStrip.addEventListener('click', function (e) {
          e.stopPropagation();
          isExpanded = !isExpanded;
          if (isExpanded) {
            sidebar.style.width = '200px';
            sidebar.style.minWidth = '200px';
            sidebar.style.maxWidth = '200px';
            sidebar.querySelectorAll('.nova-nav-btn').forEach(function (btn) {
              btn.style.flexDirection = 'row';
              btn.style.width = '100%';
              btn.style.justifyContent = 'flex-start';
              btn.style.padding = '10px 14px';
              btn.style.gap = '12px';
            });
            sidebar.querySelectorAll('.nova-nav-btn span').forEach(function (s) {
              s.style.fontSize = '0.85rem';
              s.style.maxWidth = 'none';
            });
          } else {
            sidebar.style.width = '76px';
            sidebar.style.minWidth = '76px';
            sidebar.style.maxWidth = '76px';
            sidebar.querySelectorAll('.nova-nav-btn').forEach(function (btn) {
              btn.style.flexDirection = 'column';
              btn.style.width = '56px';
              btn.style.justifyContent = 'center';
              btn.style.padding = '6px 2px';
              btn.style.gap = '4px';
            });
            sidebar.querySelectorAll('.nova-nav-btn span').forEach(function (s) {
              s.style.fontSize = '0.65rem';
              s.style.maxWidth = '52px';
            });
          }
        });
      }
    }

    // Orientation change listener
    window.addEventListener('nova:device-changed', function (e) {
      if (e.detail && e.detail.device === 'tablet') {
        console.log('[NovaPulse] Tablet orientation:', e.detail.orientation);
      }
    });

    console.log('[NovaPulse] Tablet presentation layer active.');
  }

  // Auto-init when tablet is detected
  if (document.documentElement.getAttribute('data-device') === 'tablet') {
    initTabletPresentation();
  }

  window.addEventListener('nova:device-changed', function (e) {
    if (e.detail && e.detail.device === 'tablet') {
      initTabletPresentation();
    }
  });

  window.NovaPulseTablet = {
    init: initTabletPresentation
  };

})();
