/**
 * NovaPulse — Mobile Presentation Controller
 * Alpha Interactive (c) 2026. All rights reserved.
 * 
 * Touch interactions, slide-over navigation drawer, and smartphone UX polish.
 */

(function () {
  'use strict';

  var isInitialized = false;

  function initMobilePresentation() {
    if (isInitialized) return;
    isInitialized = true;

    var menuToggle = document.getElementById('mobileMenuToggle');
    var sidebar = document.querySelector('.nova-sidebar');
    var backdrop = document.getElementById('mobileSidebarBackdrop');

    if (!backdrop) {
      backdrop = document.createElement('div');
      backdrop.id = 'mobileSidebarBackdrop';
      document.body.appendChild(backdrop);
    }

        function openDrawer() {
      if (sidebar) sidebar.classList.add('mobile-sidebar-open');
      document.body.classList.add('mobile-sidebar-open');
      if (backdrop) backdrop.classList.add('active');
      document.body.style.overflow = 'hidden';
    }

    function closeDrawer() {
      if (sidebar) sidebar.classList.remove('mobile-sidebar-open');
      document.body.classList.remove('mobile-sidebar-open');
      if (backdrop) backdrop.classList.remove('active');
      document.body.style.overflow = '';
    }

    if (menuToggle) {
      menuToggle.addEventListener('click', function (e) {
        e.stopPropagation();
        if (sidebar && sidebar.classList.contains('mobile-sidebar-open')) {
          closeDrawer();
        } else {
          openDrawer();
        }
      });
    }

    if (backdrop) {
      backdrop.addEventListener('click', function () {
        closeDrawer();
      });
    }

    // Auto-close drawer when any navigation link is tapped on mobile
    if (sidebar) {
      sidebar.querySelectorAll('.nova-nav-btn, .nav-item').forEach(function (btn) {
        btn.addEventListener('click', function () {
          closeDrawer();
        });
      });
    }

    // Swipe-to-dismiss gesture for the mobile drawer
    var touchStartX = 0;
    var touchStartY = 0;

    if (sidebar) {
      sidebar.addEventListener('touchstart', function (e) {
        touchStartX = e.touches[0].clientX;
        touchStartY = e.touches[0].clientY;
      }, { passive: true });

      sidebar.addEventListener('touchend', function (e) {
        var touchEndX = e.changedTouches[0].clientX;
        var touchEndY = e.changedTouches[0].clientY;
        var diffX = touchEndX - touchStartX;
        var diffY = Math.abs(touchEndY - touchStartY);

        // If swiped left by at least 60px and mostly horizontal
        if (diffX < -60 && diffY < 100) {
          closeDrawer();
        }
      }, { passive: true });
    }

    console.log('[NovaPulse] Mobile presentation layer active.');
  }

  // Auto-init when mobile is detected
  if (document.documentElement.getAttribute('data-device') === 'mobile') {
    initMobilePresentation();
  }

  window.addEventListener('nova:device-changed', function (e) {
    if (e.detail && e.detail.device === 'mobile') {
      initMobilePresentation();
    }
  });

  window.NovaPulseMobile = {
    init: initMobilePresentation
  };

})();
