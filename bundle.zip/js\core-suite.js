(function () {
  'use strict';
  window.NovaCoreSuite = {
    init() {
      this.initYtdlnisPowerBar();
      this.initGalleryRipper();
      this.initReclipStudio();
      this.initLyricsEngine();
      this.initLibraryImageLightbox();
    },
    initYtdlnisPowerBar() {
      const inputContainer = document.querySelector('.input-card');
      if (!inputContainer) return;
      if (document.getElementById('ytdlnisPowerBar')) return;
      const powerBar = document.createElement('div');
      powerBar.id = 'ytdlnisPowerBar';
      powerBar.className = 'ytdlnis-power-bar';
      powerBar.innerHTML = `
        <div class="power-bar-header">
          <span><i class="fa-solid fa-wand-magic-sparkles" style="color: var(--accent-cyan);"></i> <b>Power Tools</b> (GhostDrive Turbo • Live DVR • Stream Splitter)</span>
          <button type="button" class="btn-link-mini" id="togglePowerDetailsBtn"><i class="fa-solid fa-sliders"></i> Customize Options</button>
        </div>
        <div class="power-quick-chips">
          <label class="power-chip" title="GhostDrive 16x multi-connection acceleration">
            <input type="checkbox" id="chkAria2Turbo" checked />
            <span><i class="fa-solid fa-bolt" style="color: #f59e0b;"></i> GhostDrive 16x Turbo</span>
          </label>
          <label class="power-chip" title="Automatically remove sponsors, intros, and self-promotion (SponsorBlock)">
            <input type="checkbox" id="chkSponsorBlock" />
            <span><i class="fa-solid fa-shield-halved" style="color: #10b981;"></i> SponsorBlock</span>
          </label>
          <label class="power-chip" title="Download and embed all available subtitles">
            <input type="checkbox" id="chkEmbedSubs" />
            <span><i class="fa-solid fa-closed-captioning" style="color: #38bdf8;"></i> Embed Subtitles</span>
          </label>
          <label class="power-chip" title="Embed original high-res cover art thumbnail">
            <input type="checkbox" id="chkEmbedThumb" checked />
            <span><i class="fa-solid fa-image" style="color: #ec4899;"></i> Embed Artwork</span>
          </label>
          <label class="power-chip" title="Detect & record live stream from start (Twitch, Kick, YouTube Live)">
            <input type="checkbox" id="chkLiveDvr" />
            <span><i class="fa-solid fa-satellite-dish" style="color: #ef4444;"></i> Live DVR</span>
          </label>
          <button type="button" class="power-chip btn-chip" id="btnToggleTrimmer">
            <i class="fa-solid fa-scissors" style="color: #a855f7;"></i> Trim Video
          </button>
        </div>
        <!-- Trimmer Inputs Drawer -->
        <div class="trimmer-drawer" id="trimmerDrawer" style="display: none;">
          <div class="trimmer-row">
            <i class="fa-solid fa-clock"></i>
            <span>Cut Range:</span>
            <input type="text" id="trimStartTime" placeholder="Start (e.g. 00:01:15)" />
            <span>to</span>
            <input type="text" id="trimEndTime" placeholder="End (e.g. 00:03:40)" />
            <button type="button" class="btn-subtle btn-mini" id="btnClearTrim">Clear</button>
          </div>
        </div>
      `;
      const toolbar = inputContainer.querySelector('.universal-toolbar');
      if (toolbar) {
        toolbar.insertAdjacentElement('afterend', powerBar);
      } else {
        inputContainer.prepend(powerBar);
      }
      const btnToggleTrimmer = document.getElementById('btnToggleTrimmer');
      const trimmerDrawer = document.getElementById('trimmerDrawer');
      if (btnToggleTrimmer && trimmerDrawer) {
        btnToggleTrimmer.addEventListener('click', () => {
          const isHidden = trimmerDrawer.style.display === 'none';
          trimmerDrawer.style.display = isHidden ? 'block' : 'none';
          btnToggleTrimmer.classList.toggle('active', isHidden);
        });
      }
      const btnClearTrim = document.getElementById('btnClearTrim');
      if (btnClearTrim) {
        btnClearTrim.addEventListener('click', () => {
          document.getElementById('trimStartTime').value = '';
          document.getElementById('trimEndTime').value = '';
        });
      }
    },
    getPowerOptions() {
      const chkAria2 = document.getElementById('chkAria2Turbo');
      const chkSponsor = document.getElementById('chkSponsorBlock');
      const chkSubs = document.getElementById('chkEmbedSubs');
      const chkThumb = document.getElementById('chkEmbedThumb');
      const chkLive = document.getElementById('chkLiveDvr');
      const trimStart = document.getElementById('trimStartTime');
      const trimEnd = document.getElementById('trimEndTime');
      const options = {
        useAria2: chkAria2 ? chkAria2.checked : true,
        sponsorblock: chkSponsor ? chkSponsor.checked : false,
        embedSubs: chkSubs ? chkSubs.checked : false,
        embedThumbnail: chkThumb ? chkThumb.checked : true,
        isLiveStream: chkLive ? chkLive.checked : false
      };
      if (trimStart && trimEnd && (trimStart.value.trim() || trimEnd.value.trim())) {
        options.timeRange = {
          start: trimStart.value.trim(),
          end: trimEnd.value.trim()
        };
      }
      return options;
    },
    initGalleryRipper() {
      const view = document.getElementById('view-gallery-ripper');
      if (!view) return;
      const urlInput = document.getElementById('galleryUrlInput');
      const analyzeBtn = document.getElementById('galleryAnalyzeBtn');
      const previewArea = document.getElementById('galleryPreviewArea');
      const grid = document.getElementById('galleryGrid');
      const countBadge = document.getElementById('galleryItemCount');
      const downloadAllBtn = document.getElementById('galleryDownloadAllBtn');
      const selectAllBtn = document.getElementById('gallerySelectAllBtn');
      const progressWrap = document.getElementById('galleryProgressWrap');
      const progressBar = document.getElementById('galleryProgressBar');
      const progressText = document.getElementById('galleryProgressText');
      let currentGalleryData = null;
      if (analyzeBtn && urlInput) {
        analyzeBtn.addEventListener('click', async () => {
          const url = urlInput.value.trim();
          if (!url) {
            alert('Please paste an image, album, or gallery URL.');
            return;
          }
          analyzeBtn.disabled = true;
          analyzeBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Extracting Gallery...';
          previewArea.style.display = 'none';
          try {
            const resp = await fetch('/api/gallery/info', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'X-Nova-Auth': localStorage.getItem('nova_auth_token') || '0725'
              },
              body: JSON.stringify({ url })
            });
            const data = await resp.json();
            analyzeBtn.disabled = false;
            analyzeBtn.innerHTML = '<i class="fa-solid fa-images"></i> Analyze Gallery';
            if (!data.ok || !data.items || data.items.length === 0) {
              alert(data.error || 'No images found at this URL.');
              return;
            }
            currentGalleryData = data;
            countBadge.textContent = `${data.items.length} Images Found (${data.engine})`;
            previewArea.style.display = 'block';
            grid.innerHTML = data.items.map((it, idx) => `
              <div class="gallery-card" data-idx="${idx}">
                <div class="gallery-thumb-box">
                  <img src="${it.thumbnail || it.url}" alt="${it.filename}" loading="lazy" onerror="this.src='/favicon.ico'" />
                  <label class="gallery-chk-overlay">
                    <input type="checkbox" class="chk-gallery-img" data-idx="${idx}" checked />
                  </label>
                </div>
                <div class="gallery-card-info">
                  <div class="gallery-fname" title="${it.filename}">${it.filename}</div>
                  <div class="gallery-meta">
                    <span>${it.extension ? it.extension.toUpperCase() : 'IMG'}</span>
                    ${it.width ? `<span>${it.width}x${it.height}</span>` : ''}
                  </div>
                </div>
              </div>
            `).join('');
          } catch (err) {
            analyzeBtn.disabled = false;
            analyzeBtn.innerHTML = '<i class="fa-solid fa-images"></i> Analyze Gallery';
            alert('Error extracting gallery: ' + err.message);
          }
        });
      }
      if (selectAllBtn) {
        selectAllBtn.addEventListener('click', () => {
          const chks = grid.querySelectorAll('.chk-gallery-img');
          const allChecked = Array.from(chks).every(c => c.checked);
          chks.forEach(c => c.checked = !allChecked);
          selectAllBtn.textContent = allChecked ? 'Select All' : 'Deselect All';
        });
      }
      if (downloadAllBtn) {
        downloadAllBtn.addEventListener('click', async () => {
          if (!currentGalleryData) return;
          const url = urlInput.value.trim();
          downloadAllBtn.disabled = true;
          downloadAllBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Ripping Album...';
          progressWrap.style.display = 'block';
          progressBar.style.width = '5%';
          progressText.textContent = 'Initiating download of album images...';
          try {
            const resp = await fetch('/api/gallery/download', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'X-Nova-Auth': localStorage.getItem('nova_auth_token') || '0725'
              },
              body: JSON.stringify({ url })
            });
            const res = await resp.json();
            if (!res.ok) {
              alert('Failed to start download: ' + res.error);
              downloadAllBtn.disabled = false;
              downloadAllBtn.innerHTML = '<i class="fa-solid fa-download"></i> Download Album';
              return;
            }
            const taskId = res.taskId;
            const poller = setInterval(async () => {
              try {
                const tResp = await fetch('/api/gallery/tasks', {
                  headers: { 'X-Nova-Auth': localStorage.getItem('nova_auth_token') || '0725' }
                });
                const tData = await tResp.json();
                const task = (tData.tasks || []).find(t => t.id === taskId);
                if (task) {
                  progressBar.style.width = `${task.percent}%`;
                  progressText.textContent = `Downloaded ${task.downloaded} of ${task.total} images (${task.percent}%)`;
                  if (task.status === 'completed') {
                    clearInterval(poller);
                    progressBar.style.width = '100%';
                    progressText.textContent = `Album downloaded successfully! Stored in ${task.destDir}`;
                    downloadAllBtn.disabled = false;
                    downloadAllBtn.innerHTML = '<i class="fa-solid fa-check"></i> Album Downloaded!';
                    if (typeof window.fetchLibrary === 'function') window.fetchLibrary();
                  } else if (task.status === 'failed') {
                    clearInterval(poller);
                    progressText.textContent = 'Album download encountered an error.';
                    downloadAllBtn.disabled = false;
                  }
                }
              } catch (e) {}
            }, 1000);
          } catch (err) {
            downloadAllBtn.disabled = false;
            downloadAllBtn.innerHTML = '<i class="fa-solid fa-download"></i> Download Album';
            alert('Download failed: ' + err.message);
          }
        });
      }
    },
    initReclipStudio() {
      const view = document.getElementById('view-reclip-batch');
      if (!view) return;
      const textarea = document.getElementById('reclipUrlsTextarea');
      const counterBadge = document.getElementById('reclipCountBadge');
      const parseBtn = document.getElementById('reclipFetchBtn');
      const formatSelect = document.getElementById('reclipGlobalFormat');
      const resultsContainer = document.getElementById('reclipCardsContainer');
      const batchDownloadAllBtn = document.getElementById('reclipBatchDownloadAllBtn');
      let parsedUrls = [];
      let resolvedItems = [];
      if (textarea && counterBadge) {
        textarea.addEventListener('input', () => {
          const lines = textarea.value.split(/[\r\n\s]+/);
          const urls = lines.filter(l => /^https?:\/\//i.test(l.trim()));
          const unique = new Set(urls);
          parsedUrls = Array.from(unique);
          counterBadge.textContent = `${parsedUrls.length} unique URLs detected`;
        });
      }
      if (parseBtn) {
        parseBtn.addEventListener('click', async () => {
          if (!parsedUrls || parsedUrls.length === 0) {
            alert('Please paste at least one valid video URL.');
            return;
          }
          parseBtn.disabled = true;
          parseBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Fetching Previews...';
          resultsContainer.innerHTML = '<div class="reclip-loading"><i class="fa-solid fa-spinner fa-spin"></i> Analyzing URLs concurrently...</div>';
          try {
            const resp = await fetch('/api/reclip/batch-info', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'X-Nova-Auth': localStorage.getItem('nova_auth_token') || '0725'
              },
              body: JSON.stringify({ urls: parsedUrls })
            });
            const data = await resp.json();
            parseBtn.disabled = false;
            parseBtn.innerHTML = '<i class="fa-solid fa-layer-group"></i> Fetch All Previews';
            if (!data.ok || !data.items) {
              resultsContainer.innerHTML = '<div class="alert alert-danger">Failed to resolve URLs.</div>';
              return;
            }
            resolvedItems = data.items;
            batchDownloadAllBtn.style.display = 'inline-flex';
            resultsContainer.innerHTML = data.items.map((it, idx) => {
              if (it.status === 'error') {
                return `
                  <div class="reclip-item-card error">
                    <div class="reclip-err-badge"><i class="fa-solid fa-triangle-exclamation"></i> Error</div>
                    <div class="reclip-url-txt">${it.url}</div>
                    <div class="reclip-err-msg">${it.error}</div>
                  </div>
                `;
              }
              const info = it.info || {};
              return `
                <div class="reclip-item-card" data-idx="${idx}">
                  <div class="reclip-card-thumb">
                    <img src="${info.thumbnail || '/favicon.ico'}" alt="${info.title}" />
                    <span class="reclip-duration">${info.duration_string || ''}</span>
                  </div>
                  <div class="reclip-card-body">
                    <h4 class="reclip-title">${info.title || 'Video ' + (idx + 1)}</h4>
                    <div class="reclip-uploader">${info.uploader || 'Web Media'}</div>
                    <div class="reclip-controls">
                      <select class="reclip-item-mode" data-idx="${idx}">
                        <option value="max">Max Quality (MP4)</option>
                        <option value="custom-quality-1080">1080p FHD</option>
                        <option value="custom-quality-720">720p HD</option>
                        <option value="audio">MP3 Audio Only</option>
                      </select>
                      <button class="btn-primary btn-mini btn-reclip-single-dl" data-idx="${idx}">
                        <i class="fa-solid fa-download"></i> Download
                      </button>
                    </div>
                  </div>
                </div>
              `;
            }).join('');
            resultsContainer.querySelectorAll('.btn-reclip-single-dl').forEach(btn => {
              btn.addEventListener('click', (e) => {
                const idx = parseInt(btn.dataset.idx, 10);
                const item = resolvedItems[idx];
                const modeSelect = resultsContainer.querySelector(`.reclip-item-mode[data-idx="${idx}"]`);
                const modeVal = modeSelect ? modeSelect.value : 'max';
                let mode = 'max';
                let quality = null;
                if (modeVal.startsWith('custom-quality-')) {
                  mode = 'custom-quality';
                  quality = modeVal.replace('custom-quality-', '');
                } else if (modeVal === 'audio') {
                  mode = 'audio';
                }
                btn.disabled = true;
                btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Queued';
                if (typeof window.triggerDownload === 'function') {
                  window.triggerDownload({
                    url: item.url,
                    mode,
                    quality,
                    titleHint: (item.info || {}).title
                  });
                }
              });
            });
          } catch (err) {
            parseBtn.disabled = false;
            parseBtn.innerHTML = '<i class="fa-solid fa-layer-group"></i> Fetch All Previews';
            resultsContainer.innerHTML = `<div class="alert alert-danger">Batch error: ${err.message}</div>`;
          }
        });
      }
      if (batchDownloadAllBtn) {
        batchDownloadAllBtn.addEventListener('click', () => {
          if (!resolvedItems || resolvedItems.length === 0) return;
          const globalModeVal = formatSelect ? formatSelect.value : 'max';
          let mode = 'max';
          let quality = null;
          if (globalModeVal.startsWith('custom-quality-')) {
            mode = 'custom-quality';
            quality = globalModeVal.replace('custom-quality-', '');
          } else if (globalModeVal === 'audio') {
            mode = 'audio';
          }
          let queued = 0;
          resolvedItems.forEach((it, idx) => {
            if (it.status === 'resolved' && it.url) {
              setTimeout(() => {
                if (typeof window.triggerDownload === 'function') {
                  window.triggerDownload({
                    url: it.url,
                    mode,
                    quality,
                    titleHint: (it.info || {}).title
                  });
                }
              }, idx * 300);
              queued++;
            }
          });
          batchDownloadAllBtn.innerHTML = `<i class="fa-solid fa-check"></i> Queued ${queued} Downloads!`;
          setTimeout(() => {
            batchDownloadAllBtn.innerHTML = '<i class="fa-solid fa-cloud-arrow-down"></i> Download All Videos';
          }, 4000);
        });
      }
    },
    initLyricsEngine() {
      window.fetchSongLyrics = async function (trackName, artistName) {
        try {
          const q = `${artistName || ''} ${trackName || ''}`.trim();
          const resp = await fetch(`/api/lyrics?q=${encodeURIComponent(q)}&title=${encodeURIComponent(trackName || '')}&artist=${encodeURIComponent(artistName || '')}`, {
            headers: { 'X-Nova-Auth': localStorage.getItem('nova_auth_token') || '0725' }
          });
          const data = await resp.json();
          return data;
        } catch (err) {
          return { ok: false, error: err.message };
        }
      };
    },
    initLibraryImageLightbox() {
      if (!document.getElementById('novaImageLightboxModal')) {
        const modal = document.createElement('div');
        modal.id = 'novaImageLightboxModal';
        modal.className = 'nova-modal lightbox-modal';
        modal.style.display = 'none';
        modal.innerHTML = `
          <div class="lightbox-overlay" onclick="document.getElementById('novaImageLightboxModal').style.display='none'"></div>
          <div class="lightbox-content">
            <button class="lightbox-close-btn" onclick="document.getElementById('novaImageLightboxModal').style.display='none'">&times;</button>
            <img id="lightboxImg" src="" alt="Full view" />
            <div class="lightbox-caption" id="lightboxCaption"></div>
          </div>
        `;
        document.body.appendChild(modal);
      }
      window.openImageLightbox = function (imgUrl, caption) {
        const modal = document.getElementById('novaImageLightboxModal');
        const img = document.getElementById('lightboxImg');
        const cap = document.getElementById('lightboxCaption');
        if (modal && img) {
          img.src = imgUrl;
          if (cap) cap.textContent = caption || '';
          modal.style.display = 'flex';
        }
      };
    }
  };
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => window.NovaCoreSuite.init());
  } else {
    window.NovaCoreSuite.init();
  }
})();