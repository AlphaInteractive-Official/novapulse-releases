const Library = (function () {
  let mediaList = [];
  let filterText = '';
  let activeTab = 'all'; // 'all' | 'video' | 'audio' | 'favorites' | 'recent'
  let sortMode = 'newest'; // 'newest' | 'oldest' | 'name-asc' | 'name-desc' | 'largest' | 'smallest'
  let favorites = new Set();
  let recentlyPlayed = [];
  const FAVORITES_KEY = 'ultimatePlayer.favorites';
  const RECENT_KEY = 'ultimatePlayer.recentlyPlayed';
  const MAX_RECENT = 20;
  let onAddToPlaylistCb = null;
  let onPlayNowCb = null;
  let onRowClickCb = null;
  let activeId = null;
  let lastRowClick = { id: null, time: 0 };
  function initPersisted() {
    try {
      const raw = localStorage.getItem(FAVORITES_KEY);
      if (raw) {
        const arr = JSON.parse(raw);
        if (Array.isArray(arr)) favorites = new Set(arr);
      }
    } catch (e) {
      console.warn('Library: could not restore favorites:', e);
      favorites = new Set();
    }
    try {
      const raw = localStorage.getItem(RECENT_KEY);
      if (raw) {
        const arr = JSON.parse(raw);
        if (Array.isArray(arr)) recentlyPlayed = arr;
      }
    } catch (e) {
      console.warn('Library: could not restore recently played:', e);
      recentlyPlayed = [];
    }
  }
  initPersisted();
  async function fetchLibrary() {
    try {
      const res = await fetch('/api/library');
      const data = await res.json();
      if (data.ok) {
        mediaList = data.library || [];
        return mediaList;
      } else {
        console.error('Failed to load library:', data.error);
        return [];
      }
    } catch (err) {
      console.error('Error fetching library:', err);
      return [];
    }
  }
  function getMediaList() {
    return mediaList;
  }
  function getFilteredMedia() {
    let list = mediaList;
    if (activeTab === 'favorites') {
      list = list.filter(item => favorites.has(item.id));
    } else if (activeTab === 'recent') {
      const mediaById = new Map(mediaList.map(m => [m.id, m]));
      return recentlyPlayed
        .map(r => mediaById.get(r.id))
        .filter(Boolean);
    } else if (activeTab !== 'all') {
      list = list.filter(item => item.type === activeTab);
    }
    if (filterText) {
      const q = filterText.toLowerCase();
      list = list.filter(item =>
        item.name.toLowerCase().includes(q) ||
        (item.filename || '').toLowerCase().includes(q)
      );
    }
    list = [...list]; // shallow copy before sort
    switch (sortMode) {
      case 'name-asc':
        list.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case 'name-desc':
        list.sort((a, b) => b.name.localeCompare(a.name));
        break;
      case 'newest':
        list.sort((a, b) => (b.mtime || 0) - (a.mtime || 0));
        break;
      case 'oldest':
        list.sort((a, b) => (a.mtime || 0) - (b.mtime || 0));
        break;
      case 'largest':
        list.sort((a, b) => (b.size || 0) - (a.size || 0));
        break;
      case 'smallest':
        list.sort((a, b) => (a.size || 0) - (b.size || 0));
        break;
    }
    return list;
  }
  function setFilter(text) {
    filterText = text || '';
  }
  function setActiveTab(type) {
    activeTab = type || 'all';
  }
  function setSortMode(mode) {
    sortMode = mode;
  }
  function getSortMode() {
    return sortMode;
  }
  function isFavorite(itemId) {
    return favorites.has(itemId);
  }
  function toggleFavorite(itemId) {
    if (favorites.has(itemId)) {
      favorites.delete(itemId);
    } else {
      favorites.add(itemId);
    }
    saveFavorites();
    return favorites.has(itemId);
  }
  function saveFavorites() {
    try {
      localStorage.setItem(FAVORITES_KEY, JSON.stringify([...favorites]));
    } catch (e) {
      console.warn('Library: could not save favorites:', e);
    }
  }
  function recordRecentlyPlayed(item) {
    if (!item || !item.id) return;
    recentlyPlayed = recentlyPlayed.filter(r => r.id !== item.id);
    recentlyPlayed.unshift({
      id: item.id,
      name: item.name,
      type: item.type,
      extension: item.extension,
      url: item.url,
      relativePath: item.relativePath,
      size: item.size,
      timestamp: Date.now()
    });
    if (recentlyPlayed.length > MAX_RECENT) {
      recentlyPlayed = recentlyPlayed.slice(0, MAX_RECENT);
    }
    try {
      localStorage.setItem(RECENT_KEY, JSON.stringify(recentlyPlayed));
    } catch (e) {
      console.warn('Library: could not save recently played:', e);
    }
  }
  function getRecentlyPlayed() {
    return recentlyPlayed;
  }
  function renderList(containerEl, customList = null) {
    if (!containerEl) return;
    const filtered = customList || getFilteredMedia();
    if (filtered.length === 0) {
      let msg = 'No media files found in your download folder.';
      let hint = 'Downloaded videos & extracted audio will show up here automatically.';
      if (activeTab === 'favorites') {
        msg = 'No favorites yet.';
        hint = 'Click the ★ button on any track to mark it as a favorite.';
      } else if (activeTab === 'recent') {
        msg = 'Nothing played yet.';
        hint = 'Your recently played tracks will appear here.';
      }
      containerEl.innerHTML = `
        <div class="empty-library">
          <i class="fa-solid fa-folder-open"></i>
          <p>${escapeHtml(msg)}</p>
          <small>${escapeHtml(hint)}</small>
        </div>
      `;
      return;
    }
    containerEl.innerHTML = '';
    filtered.forEach(item => {
      const el = document.createElement('div');
      const isActive = activeId !== null && item.id === activeId;
      el.className = `library-item${isActive ? ' active' : ''}`;
      el.dataset.id = item.id;
      el.title = 'Click to play this file';
      const iconClass = item.type === 'video' ? 'fa-solid fa-film' : (item.type === 'image' ? 'fa-solid fa-image' : 'fa-solid fa-music');
      const sizeStr = formatBytes(item.size);
      const isFav = favorites.has(item.id);
      const favClass = isFav ? 'btn-lib-action btn-favorite active' : 'btn-lib-action btn-favorite';
      const favTitle = isFav ? 'Remove from Favorites' : 'Add to Favorites';
      let thumbUrl = item.thumbnail || '';
      if (!thumbUrl || thumbUrl.endsWith('#t=1.0')) {
        const ytMatch = (item.name || item.filename || '').match(/\[([a-zA-Z0-9_-]{11})\]/);
        if (ytMatch) thumbUrl = `https://i.ytimg.com/vi/${ytMatch[1]}/mqdefault.jpg`;
      }
      const durationBadge = item.type === 'image' ? 'IMAGE' : (item.duration ? formatDuration(item.duration) : (item.type === 'video' ? (item.extension || 'MP4').toUpperCase().replace('.', '') : 'AUDIO'));
      el.innerHTML = `
        <div class="lib-card-top-row">
          <div class="lib-thumb-col">
            ${thumbUrl ? `
              <img class="lib-thumb-img" src="${escapeHtml(thumbUrl)}" alt="${escapeHtml(item.name)}" loading="lazy" onerror="this.style.display='none'; if(this.nextElementSibling) this.nextElementSibling.style.display='flex';" />
              <div class="lib-thumb-fallback" style="display:none;"><i class="${iconClass}"></i></div>
            ` : `
              <div class="lib-thumb-fallback"><i class="${iconClass}"></i></div>
            `}
            <span class="lib-thumb-duration">${durationBadge}</span>
            <div class="lib-thumb-play-overlay">
              <i class="fa-solid fa-play"></i>
            </div>
          </div>
          <div class="lib-info-col">
            <div class="lib-title" title="${escapeHtml(item.name)}">${escapeHtml(item.name)}</div>
            <div class="lib-sub">
              <span class="lib-tag ${item.type}"><i class="${iconClass}"></i> ${(item.extension || '').toUpperCase().replace('.', '')}</span>
              <span>&bull;</span>
              <span>${sizeStr}</span>
              <span>&bull;</span>
              <span class="lib-relpath"><i class="fa-regular fa-folder"></i> ${escapeHtml(item.relativePath)}</span>
            </div>
          </div>
        </div>
        <div class="lib-actions-col">
          <button class="btn-lib-action btn-play-now" title="Play Now">
            <i class="fa-solid fa-play"></i> <span>Play</span>
          </button>
          <button class="${favClass}" title="${favTitle}" data-id="${escapeHtml(item.id)}">
            <i class="fa-${isFav ? 'solid' : 'regular'} fa-star"></i> <span>Favorite</span>
          </button>
          <button class="btn-lib-action btn-add-custom-pl" title="Add to Playlist or Queue">
            <i class="fa-solid fa-plus"></i> <span>Playlist</span>
          </button>
          <button class="btn-lib-action btn-del-media" title="Delete File">
            <i class="fa-solid fa-trash-can"></i> <span>Delete</span>
          </button>
        </div>
      `;
      el.querySelector('.btn-favorite').addEventListener('click', (e) => {
        e.stopPropagation();
        const nowFav = toggleFavorite(item.id);
        const btn = e.currentTarget;
        btn.classList.toggle('active', nowFav);
        btn.title = nowFav ? 'Remove from Favorites' : 'Add to Favorites';
        const icon = btn.querySelector('i');
        icon.className = `fa-${nowFav ? 'solid' : 'regular'} fa-star`;
        if (activeTab === 'favorites') renderList(containerEl);
      });
      el.querySelector('.btn-play-now').addEventListener('click', (e) => {
        e.stopPropagation();
        if (item.type === 'image') {
          if (typeof window.openImageLightbox === 'function') window.openImageLightbox(item.url, item.name);
          return;
        }
        if (onPlayNowCb) {
          onPlayNowCb(item);
        } else if (typeof window.playLibraryTrackWithQueue === 'function') {
          window.playLibraryTrackWithQueue(item);
        } else if (typeof Playlist !== 'undefined') {
          Playlist.playNow(item);
          if (typeof window.switchView === 'function') window.switchView('player');
          else if (typeof Nova !== 'undefined' && typeof Nova.switchView === 'function') Nova.switchView('player');
        }
      });
      const btnCustomPl = el.querySelector('.btn-add-custom-pl');
      if (btnCustomPl) {
        btnCustomPl.addEventListener('click', (e) => {
          e.stopPropagation();
          if (typeof window.openAddToPlaylistModal === 'function') {
            window.openAddToPlaylistModal(item);
          } else if (onAddToPlaylistCb) {
            onAddToPlaylistCb(item);
          }
        });
      }
      const btnDelMedia = el.querySelector('.btn-del-media');
      if (btnDelMedia) {
        btnDelMedia.addEventListener('click', (e) => {
          e.stopPropagation();
          if (typeof window.openConfirmDeleteModal === 'function') {
            window.openConfirmDeleteModal(item, () => {
              mediaList = mediaList.filter(m => m.id !== item.id);
              renderList(containerEl);
              const countEl = document.getElementById('libCount');
              const navLibCount = document.getElementById('navLibCount');
              if (countEl) countEl.textContent = mediaList.length;
              if (navLibCount) navLibCount.textContent = mediaList.length;
              if (typeof Nova !== 'undefined' && Nova.refreshDashboard) Nova.refreshDashboard();
            });
          } else {
            if (!confirm(`Are you sure you want to permanently delete "${item.name}" from storage?`)) return;
            fetch(`/api/media-item/${item.id}`, { method: 'DELETE' }).then(() => {
              mediaList = mediaList.filter(m => m.id !== item.id);
              renderList(containerEl);
            });
          }
        });
      }
      el.addEventListener('click', (e) => {
        if (e.target.closest('.btn-lib-action')) return;
        const now = Date.now();
        if (lastRowClick.id === item.id && (now - lastRowClick.time) < 350) return;
        lastRowClick = { id: item.id, time: now };
        setActiveId(item.id);
        markActiveInDom(containerEl, item.id);
        if (item.type === 'image') {
          if (typeof window.openImageLightbox === 'function') window.openImageLightbox(item.url, item.name);
          return;
        }
        if (onRowClickCb) {
          onRowClickCb(item);
        } else if (onPlayNowCb) {
          onPlayNowCb(item);
        } else if (typeof window.playLibraryTrackWithQueue === 'function') {
          window.playLibraryTrackWithQueue(item);
        } else if (typeof Playlist !== 'undefined') {
          Playlist.playNow(item);
          if (typeof window.switchView === 'function') window.switchView('player');
          else if (typeof Nova !== 'undefined' && typeof Nova.switchView === 'function') Nova.switchView('player');
        }
      });
      containerEl.appendChild(el);
    });
  }
  function setActiveId(id) {
    activeId = id || null;
  }
  function getActiveId() {
    return activeId;
  }
  function markActiveInDom(containerEl, id) {
    const targetId = id === undefined ? activeId : (id || null);
    const root = containerEl || document.getElementById('libraryContainer');
    if (!root) return;
    root.querySelectorAll('.library-item').forEach(el => {
      el.classList.toggle('active', el.dataset.id === targetId);
    });
  }
  function formatBytes(bytes) {
    if (!bytes || bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  }
  function formatDuration(sec) {
    if (!sec || isNaN(sec)) return '';
    const s = Math.floor(sec);
    const hrs = Math.floor(s / 3600);
    const mins = Math.floor((s % 3600) / 60);
    const secs = s % 60;
    if (hrs > 0) {
      return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  }
  function escapeHtml(str) {
    return (str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }
  return {
    fetchLibrary,
    getMediaList,
    getFilteredMedia,
    setFilter,
    setActiveTab,
    setSortMode,
    getSortMode,
    renderList,
    isFavorite,
    toggleFavorite,
    recordRecentlyPlayed,
    getRecentlyPlayed,
    setActiveId,
    getActiveId,
    markActiveInDom,
    onAddToPlaylist: (cb) => { onAddToPlaylistCb = cb; },
    onPlayNow: (cb) => { onPlayNowCb = cb; },
    onRowClick: (cb) => { onRowClickCb = cb; }
  };
})();