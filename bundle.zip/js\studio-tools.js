(function () {
  'use strict';
  window.NovaStudio = {
    currentJobId: null,
    libraryMedia: [],
    init() {
      this.initTabs();
      this.initVideoToAudio();
      this.initTranscoder();
      this.initStems();
      this.initLoudness();
      this.initDuplicates();
      this.initSpeedAndNightShift();
      this.bindGlobalActions();
    },
    onOpen() {
      this.loadLibraryPicker();
    },
    initTabs() {
      const tabBtns = document.querySelectorAll('.studio-tab-btn');
      tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
          const tab = btn.getAttribute('data-studio-tab');
          tabBtns.forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
          document.querySelectorAll('.studio-panel').forEach(p => p.style.display = 'none');
          const activePanel = document.getElementById(`studioPanel${tab.charAt(0).toUpperCase() + tab.slice(1)}`);
          if (activePanel) {
            activePanel.style.display = 'block';
          }
          if (tab === 'duplicates') {
            const hasScanned = document.getElementById('dupStatClusters').textContent !== '--';
            if (!hasScanned) this.scanDuplicates();
          }
        });
      });
    },
    bindGlobalActions() {
      const refreshBtn = document.getElementById('btnStudioRefreshLibrary');
      if (refreshBtn) {
        refreshBtn.addEventListener('click', async () => {
          refreshBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Refreshing...';
          await this.loadLibraryPicker(true);
          refreshBtn.innerHTML = '<i class="fa-solid fa-arrows-rotate"></i> Refresh Files';
          if (typeof showNovaToast === 'function') {
            showNovaToast('Media library picker refreshed', 'fa-check');
          }
        });
      }
      const openFolderBtn = document.getElementById('btnStudioOpenFolder');
      if (openFolderBtn) {
        openFolderBtn.addEventListener('click', () => {
          if (typeof openFolder === 'function') openFolder();
        });
      }
    },
    async loadLibraryPicker(forceRefresh = false) {
      try {
        const res = await fetch('/api/library');
        const data = await res.json();
        if (data && (data.media || data.library)) {
          this.libraryMedia = data.library || data.media || [];
          this.populateSelects();
          this.populateVideoToAudio();
        }
      } catch (e) {
        console.error('Failed to load library items for studio picker:', e);
      }
    },
    populateSelects() {
      const transcodeSelect = document.getElementById('transcodeSourceSelect');
      const stemSelect = document.getElementById('stemSourceSelect');
      const loudnessSelect = document.getElementById('loudnessSourceSelect');
      const videoAndAudio = this.libraryMedia.filter(m => m.type === 'video' || m.type === 'audio');
      const populate = (sel) => {
        if (!sel) return;
        const currentVal = sel.value;
        sel.innerHTML = '<option value="">-- Choose file from library --</option>';
        videoAndAudio.forEach(m => {
          const opt = document.createElement('option');
          opt.value = m.fullPath;
          const durationStr = m.duration ? ` [${m.duration}]` : '';
          const typeIcon = m.type === 'video' ? '🎬' : '🎵';
          opt.textContent = `${typeIcon} ${m.name}${durationStr}`;
          sel.appendChild(opt);
        });
        if (currentVal) sel.value = currentVal;
      };
      populate(transcodeSelect);
      populate(stemSelect);
      populate(loudnessSelect);
    },
    populateVideoToAudio() {
      const v2aSelect = document.getElementById('v2aSourceSelect');
      const bulkChecklist = document.getElementById('v2aBulkChecklist');
      const videos = (this.libraryMedia || []).filter(m => m.type === 'video');
      if (v2aSelect) {
        const currentVal = v2aSelect.value;
        v2aSelect.innerHTML = '<option value="">-- Choose video file from library --</option>';
        videos.forEach(v => {
          const opt = document.createElement('option');
          opt.value = v.fullPath;
          const durationStr = v.duration ? ` [${v.duration}]` : '';
          opt.textContent = `🎬 ${v.name}${durationStr}`;
          v2aSelect.appendChild(opt);
        });
        if (currentVal) v2aSelect.value = currentVal;
      }
      if (bulkChecklist) {
        if (videos.length === 0) {
          bulkChecklist.innerHTML = `
            <div style="padding: 24px; text-align: center; color: var(--text-muted); font-size: 0.85rem;">
              No video files found in library. Download or add videos first!
            </div>
          `;
          return;
        }
        const filterInput = document.getElementById('v2aBulkFilterInput');
        const query = filterInput ? filterInput.value.trim().toLowerCase() : '';
        const filtered = query ? videos.filter(v => (v.name || '').toLowerCase().includes(query)) : videos;
        bulkChecklist.innerHTML = filtered.map(v => {
          const durationStr = v.duration ? v.duration : '';
          const sizeStr = v.size ? NovaStudio.formatBytes(v.size) : '';
          const safeName = (v.name || 'Untitled Video').replace(/"/g, '&quot;');
          return `
            <label style="display: flex; align-items: center; gap: 10px; padding: 8px 10px; border-radius: var(--radius-sm); cursor: pointer; transition: background 0.15s ease; border: 1px solid transparent;" class="v2a-bulk-row">
              <input type="checkbox" class="v2a-bulk-cb" value="${v.fullPath.replace(/"/g, '&quot;')}" data-name="${safeName}" style="accent-color: var(--accent-purple); width: 16px; height: 16px;">
              <div style="width: 28px; height: 28px; border-radius: 6px; background: rgba(168, 85, 247, 0.12); display: flex; align-items: center; justify-content: center; flex-shrink: 0; color: #c084fc;">
                <i class="fa-solid fa-film"></i>
              </div>
              <div style="flex: 1; min-width: 0;">
                <div style="font-size: 0.85rem; font-weight: 600; color: #fff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${safeName}">${safeName}</div>
                <div style="font-size: 0.73rem; color: var(--text-muted); display: flex; gap: 8px;">
                  ${durationStr ? `<span>${durationStr}</span>•` : ''}
                  <span>${sizeStr}</span>
                </div>
              </div>
            </label>
          `;
        }).join('');
        this.bindBulkCheckboxEvents();
      }
    },
    bindBulkCheckboxEvents() {
      const checklist = document.getElementById('v2aBulkChecklist');
      if (!checklist) return;
      const cbs = checklist.querySelectorAll('.v2a-bulk-cb');
      const badgeCount = document.getElementById('v2aBulkBadgeCount');
      const selectedBadge = document.getElementById('v2aBulkSelectedCountBadge');
      const btnCount = document.getElementById('btnStartV2aBulkCount');
      const updateCount = () => {
        let count = 0;
        cbs.forEach(cb => {
          if (cb.checked) count++;
          const row = cb.closest('.v2a-bulk-row');
          if (row) {
            row.style.background = cb.checked ? 'rgba(168, 85, 247, 0.12)' : '';
            row.style.borderColor = cb.checked ? 'rgba(168, 85, 247, 0.3)' : 'transparent';
          }
        });
        if (badgeCount) badgeCount.textContent = count;
        if (selectedBadge) selectedBadge.textContent = `${count} selected`;
        if (btnCount) btnCount.textContent = count;
      };
      cbs.forEach(cb => cb.addEventListener('change', updateCount));
      updateCount();
    },
    initVideoToAudio() {
      const singleBtn = document.getElementById('v2aModeSingleBtn');
      const bulkBtn = document.getElementById('v2aModeBulkBtn');
      const singleContainer = document.getElementById('v2aSingleModeContainer');
      const bulkContainer = document.getElementById('v2aBulkModeContainer');
      if (singleBtn && bulkBtn) {
        singleBtn.addEventListener('click', () => {
          singleBtn.classList.add('active');
          singleBtn.style.background = 'rgba(168, 85, 247, 0.2)';
          singleBtn.style.borderColor = 'rgba(168, 85, 247, 0.4)';
          singleBtn.style.color = '#fff';
          bulkBtn.classList.remove('active');
          bulkBtn.style.background = 'transparent';
          bulkBtn.style.borderColor = 'transparent';
          bulkBtn.style.color = 'var(--text-muted)';
          if (singleContainer) singleContainer.style.display = 'block';
          if (bulkContainer) bulkContainer.style.display = 'none';
        });
        bulkBtn.addEventListener('click', () => {
          bulkBtn.classList.add('active');
          bulkBtn.style.background = 'rgba(168, 85, 247, 0.2)';
          bulkBtn.style.borderColor = 'rgba(168, 85, 247, 0.4)';
          bulkBtn.style.color = '#fff';
          singleBtn.classList.remove('active');
          singleBtn.style.background = 'transparent';
          singleBtn.style.borderColor = 'transparent';
          singleBtn.style.color = 'var(--text-muted)';
          if (singleContainer) singleContainer.style.display = 'none';
          if (bulkContainer) bulkContainer.style.display = 'block';
        });
      }
      const singlePresetChips = document.querySelectorAll('#studioPanelVideoToAudio .studio-preset-chip[data-v2a-preset]');
      singlePresetChips.forEach(chip => {
        chip.addEventListener('click', () => {
          singlePresetChips.forEach(c => c.classList.remove('active'));
          chip.classList.add('active');
          const radio = chip.querySelector('input[type="radio"]');
          if (radio) radio.checked = true;
        });
      });
      const bulkPresetChips = document.querySelectorAll('#studioPanelVideoToAudio .studio-preset-chip[data-v2a-bulk-preset]');
      bulkPresetChips.forEach(chip => {
        chip.addEventListener('click', () => {
          bulkPresetChips.forEach(c => c.classList.remove('active'));
          chip.classList.add('active');
          const radio = chip.querySelector('input[type="radio"]');
          if (radio) radio.checked = true;
        });
      });
      const sourceSelect = document.getElementById('v2aSourceSelect');
      const customInput = document.getElementById('v2aCustomInput');
      const probeBadge = document.getElementById('v2aProbeBadge');
      const probeDetails = document.getElementById('v2aProbeDetails');
      const probeDuration = document.getElementById('v2aProbeDuration');
      const triggerProbe = async (filePath) => {
        if (!filePath) {
          if (probeBadge) probeBadge.style.display = 'none';
          return;
        }
        try {
          const res = await fetch('/api/studio/probe', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ inputPath: filePath })
          });
          const data = await res.json();
          if (data.ok && data.probe) {
            const p = data.probe;
            const aStream = (p.streams || []).find(s => s.codec_type === 'audio');
            const vStream = (p.streams || []).find(s => s.codec_type === 'video');
            const dur = p.format?.duration ? parseFloat(p.format.duration) : 0;
            const hrs = Math.floor(dur / 3600).toString().padStart(2, '0');
            const mins = Math.floor((dur % 3600) / 60).toString().padStart(2, '0');
            const secs = Math.floor(dur % 60).toString().padStart(2, '0');
            if (probeDuration) probeDuration.textContent = `${hrs}:${mins}:${secs}`;
            if (probeDetails) {
              const aCodec = aStream ? `${(aStream.codec_name || '').toUpperCase()} (${aStream.sample_rate || '44100'}Hz, ${aStream.channels || 2}ch)` : 'No audio track detected';
              const vCodec = vStream ? `${(vStream.codec_name || '').toUpperCase()} ${vStream.width || ''}x${vStream.height || ''}` : 'No video';
              probeDetails.innerHTML = `
                <div><i class="fa-solid fa-film" style="color:#c084fc;"></i> Video: <b>${vCodec}</b></div>
                <div><i class="fa-solid fa-music" style="color:var(--accent-green);"></i> Source Audio: <b>${aCodec}</b></div>
              `;
            }
            if (probeBadge) probeBadge.style.display = 'block';
          }
        } catch (e) {
          console.warn('V2A probe failed:', e);
        }
      };
      if (sourceSelect) {
        sourceSelect.addEventListener('change', () => {
          if (sourceSelect.value) {
            if (customInput) customInput.value = '';
            triggerProbe(sourceSelect.value);
          }
        });
      }
      if (customInput) {
        customInput.addEventListener('change', () => {
          if (customInput.value.trim()) {
            if (sourceSelect) sourceSelect.value = '';
            triggerProbe(customInput.value.trim());
          }
        });
      }
      const btnStartSingle = document.getElementById('btnStartV2aSingle');
      if (btnStartSingle) {
        btnStartSingle.addEventListener('click', async () => {
          const inputPath = (sourceSelect && sourceSelect.value) ? sourceSelect.value : (customInput ? customInput.value.trim() : '');
          if (!inputPath) {
            return alert('Please select a video from the dropdown or paste a local file path');
          }
          const selectedRadio = document.querySelector('input[name="v2aPreset"]:checked');
          const preset = selectedRadio ? selectedRadio.value : 'audio_mp3';
          const normalizeAudio = document.getElementById('v2aNormalizeAudio')?.checked ?? true;
          const vocalBoost = document.getElementById('v2aVocalBoost')?.checked ?? false;
          const trimStart = document.getElementById('v2aTrimStart')?.value?.trim();
          const trimEnd = document.getElementById('v2aTrimEnd')?.value?.trim();
          const progressBox = document.getElementById('v2aSingleProgressBox');
          const progressBar = document.getElementById('v2aSingleProgressBar');
          const progressPercent = document.getElementById('v2aSingleProgressPercent');
          const statusBadge = document.getElementById('v2aSingleStatusBadge');
          const resultContainer = document.getElementById('v2aSingleResultContainer');
          btnStartSingle.disabled = true;
          btnStartSingle.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Extracting Audio...';
          if (progressBox) progressBox.style.display = 'block';
          if (progressBar) progressBar.style.width = '15%';
          if (progressPercent) progressPercent.textContent = 'Extracting...';
          if (statusBadge) {
            statusBadge.style.display = 'inline-block';
            statusBadge.textContent = 'Processing';
            statusBadge.className = 'task-status-pill downloading';
          }
          if (resultContainer) {
            resultContainer.innerHTML = `
              <div style="padding: 24px; text-align: center;">
                <i class="fa-solid fa-compact-disc fa-spin" style="font-size: 2.8rem; color: #a855f7; margin-bottom: 14px;"></i>
                <h4 style="color: #fff; margin-bottom: 6px;">Extracting Audio from Video</h4>
                <p style="font-size: 0.85rem; color: var(--text-muted);">Demuxing stream &amp; encoding to <b>${preset.toUpperCase().replace('AUDIO_', '')}</b> with studio mastering...</p>
              </div>
            `;
          }
          try {
            const timeRange = (trimStart || trimEnd) ? { start: trimStart, end: trimEnd } : null;
            const res = await fetch('/api/studio/transcode', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                inputPath,
                preset,
                normalizeAudio,
                vocalBoost,
                timeRange
              })
            });
            const data = await res.json();
            if (data.ok) {
              if (progressBar) progressBar.style.width = '100%';
              if (progressPercent) progressPercent.textContent = '100%';
              if (statusBadge) {
                statusBadge.textContent = 'Completed';
                statusBadge.className = 'task-status-pill completed';
              }
              const escapedOutput = (data.outputPath || '').replace(/\\/g, '\\\\');
              const folderPath = (data.outputPath || '').split(/[\\\/]/).slice(0, -1).join('\\').replace(/\\/g, '\\\\');
              if (resultContainer) {
                resultContainer.innerHTML = `
                  <div style="width: 100%; text-align: left; padding: 18px; background: rgba(168, 85, 247, 0.08); border: 1px solid rgba(168, 85, 247, 0.25); border-radius: var(--radius-sm);">
                    <div style="display: flex; align-items: center; gap: 8px; color: #c084fc; font-weight: 700; margin-bottom: 8px;">
                      <i class="fa-solid fa-circle-check"></i> Audio Extracted Successfully!
                    </div>
                    <h4 style="color: #fff; margin-bottom: 6px; word-break: break-all;">${data.fileName}</h4>
                    <div style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 14px;">
                      Format: <b>${preset.toUpperCase().replace('AUDIO_', '')}</b> • Size: <b>${NovaStudio.formatBytes(data.fileSize)}</b>
                    </div>
                    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                      <button class="btn-primary" style="padding: 8px 14px; font-size: 0.85rem; background: linear-gradient(135deg, #a855f7, #6366f1);" onclick="NovaStudio.playFile('${escapedOutput}')">
                        <i class="fa-solid fa-play"></i> Play in Player Studio
                      </button>
                      <button class="btn-subtle" style="padding: 8px 14px; font-size: 0.85rem;" onclick="NovaStudio.addExtractedToPlaylist('${escapedOutput}', '${(data.fileName || '').replace(/'/g, "\\'")}')">
                        <i class="fa-solid fa-plus"></i> Add to Playlist
                      </button>
                      <button class="btn-subtle" style="padding: 8px 14px; font-size: 0.85rem;" onclick="openFolder('${folderPath}')">
                        <i class="fa-solid fa-folder-open"></i> Storage Folder
                      </button>
                    </div>
                  </div>
                `;
              }
              if (typeof showNovaToast === 'function') {
                showNovaToast(`Audio extracted: ${data.fileName}`, 'fa-music');
              }
              if (typeof Library !== 'undefined' && typeof Library.fetchLibrary === 'function') {
                Library.fetchLibrary();
              }
            } else {
              throw new Error(data.error || 'Audio extraction failed');
            }
          } catch (err) {
            if (statusBadge) {
              statusBadge.textContent = 'Error';
              statusBadge.className = 'task-status-pill error';
            }
            if (resultContainer) {
              resultContainer.innerHTML = `
                <div style="color: var(--accent-red); padding: 20px; text-align: center;">
                  <i class="fa-solid fa-triangle-exclamation" style="font-size: 2.2rem; margin-bottom: 10px;"></i>
                  <h4>Extraction Failed</h4>
                  <p style="font-size: 0.85rem;">${err.message}</p>
                </div>
              `;
            }
          } finally {
            btnStartSingle.disabled = false;
            btnStartSingle.innerHTML = '<i class="fa-solid fa-wand-magic-sparkles"></i> Extract Audio from Video';
          }
        });
      }
      const bulkFilterInput = document.getElementById('v2aBulkFilterInput');
      if (bulkFilterInput) {
        bulkFilterInput.addEventListener('input', () => {
          this.populateVideoToAudio();
        });
      }
      const bulkSelectAll = document.getElementById('v2aBulkSelectAllBtn');
      if (bulkSelectAll) {
        bulkSelectAll.addEventListener('click', () => {
          const cbs = document.querySelectorAll('#v2aBulkChecklist .v2a-bulk-cb');
          cbs.forEach(cb => cb.checked = true);
          this.bindBulkCheckboxEvents();
        });
      }
      const bulkClearAll = document.getElementById('v2aBulkClearAllBtn');
      if (bulkClearAll) {
        bulkClearAll.addEventListener('click', () => {
          const cbs = document.querySelectorAll('#v2aBulkChecklist .v2a-bulk-cb');
          cbs.forEach(cb => cb.checked = false);
          this.bindBulkCheckboxEvents();
        });
      }
      const btnStartBulk = document.getElementById('btnStartV2aBulk');
      if (btnStartBulk) {
        btnStartBulk.addEventListener('click', async () => {
          const checkedCbs = Array.from(document.querySelectorAll('#v2aBulkChecklist .v2a-bulk-cb:checked'));
          if (checkedCbs.length === 0) {
            return alert('Please select at least one video from the list for bulk extraction');
          }
          const selectedRadio = document.querySelector('input[name="v2aBulkPreset"]:checked');
          const preset = selectedRadio ? selectedRadio.value : 'audio_mp3';
          const normalizeAudio = document.getElementById('v2aBulkNormalize')?.checked ?? true;
          const progressBox = document.getElementById('v2aBulkProgressBox');
          const progressBar = document.getElementById('v2aBulkProgressBar');
          const statusText = document.getElementById('v2aBulkStatusText');
          const percentLabel = document.getElementById('v2aBulkPercent');
          const currentItemLabel = document.getElementById('v2aBulkCurrentItemLabel');
          const completedList = document.getElementById('v2aBulkCompletedList');
          if (progressBox) progressBox.style.display = 'block';
          if (completedList) completedList.innerHTML = '';
          btnStartBulk.disabled = true;
          const total = checkedCbs.length;
          if (typeof showNovaToast === 'function') {
            showNovaToast(`Starting bulk extraction for ${total} videos...`, 'fa-bolt');
          }
          let successCount = 0;
          for (let i = 0; i < total; i++) {
            const cb = checkedCbs[i];
            const inputPath = cb.value;
            const name = cb.getAttribute('data-name') || inputPath.split(/[\\\/]/).pop();
            const overallPct = Math.round((i / total) * 100);
            if (progressBar) progressBar.style.width = `${overallPct}%`;
            if (percentLabel) percentLabel.textContent = `${overallPct}%`;
            if (statusText) statusText.textContent = `Converting ${i + 1} of ${total} files...`;
            if (currentItemLabel) currentItemLabel.textContent = `Processing: ${name}`;
            try {
              const res = await fetch('/api/studio/transcode', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  inputPath,
                  preset,
                  normalizeAudio
                })
              });
              const data = await res.json();
              if (data.ok) {
                successCount++;
                const escOut = (data.outputPath || '').replace(/\\/g, '\\\\');
                if (completedList) {
                  const itemEl = document.createElement('div');
                  itemEl.style.cssText = 'padding: 8px 12px; background: rgba(34, 211, 238, 0.05); border: 1px solid rgba(34, 211, 238, 0.2); border-radius: 6px; display: flex; justify-content: space-between; align-items: center; gap: 8px; font-size: 0.8rem;';
                  itemEl.innerHTML = `
                    <div style="flex: 1; min-width: 0;">
                      <div style="color: #fff; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${data.fileName}</div>
                      <div style="color: var(--text-muted); font-size: 0.72rem;">${NovaStudio.formatBytes(data.fileSize)} • ${preset.toUpperCase().replace('AUDIO_', '')}</div>
                    </div>
                    <button class="btn-subtle btn-mini" onclick="NovaStudio.playFile('${escOut}')" title="Play Track">
                      <i class="fa-solid fa-play"></i> Play
                    </button>
                  `;
                  completedList.appendChild(itemEl);
                }
              }
            } catch (err) {
              console.error('Failed to extract:', inputPath, err);
            }
          }
          if (progressBar) progressBar.style.width = '100%';
          if (percentLabel) percentLabel.textContent = '100%';
          if (statusText) statusText.textContent = `Batch Completed: ${successCount} of ${total} audios extracted!`;
          if (currentItemLabel) currentItemLabel.textContent = 'All conversions finished successfully.';
          btnStartBulk.disabled = false;
          if (typeof showNovaToast === 'function') {
            showNovaToast(`Bulk audio extraction finished! ${successCount} audios ready.`, 'fa-circle-check');
          }
          if (typeof Library !== 'undefined' && typeof Library.fetchLibrary === 'function') {
            Library.fetchLibrary();
          }
        });
      }
    },
    addExtractedToPlaylist(filePath, fileName) {
      if (typeof window.openAddToPlaylistModal === 'function') {
        const item = {
          id: 'media_' + btoa(unescape(encodeURIComponent(filePath.replace(/\\/g, '/')))),
          name: fileName,
          fullPath: filePath,
          type: 'audio'
        };
        window.openAddToPlaylistModal(item);
      } else {
        if (typeof showNovaToast === 'function') {
          showNovaToast('Audio added to library. Open Playlists tab to add to playlist.', 'fa-music');
        }
      }
    },
    initTranscoder() {
      const sourceSelect = document.getElementById('transcodeSourceSelect');
      const customInput = document.getElementById('transcodeInputPath');
      const probeBadge = document.getElementById('transcodeProbeBadge');
      const probeDetails = document.getElementById('probeDetails');
      const probeDurationBadge = document.getElementById('probeDurationBadge');
      const btnStart = document.getElementById('btnStartTranscode');
      const presetChips = document.querySelectorAll('#studioPanelTranscode .studio-preset-chip');
      presetChips.forEach(chip => {
        chip.addEventListener('click', () => {
          presetChips.forEach(c => c.classList.remove('active'));
          chip.classList.add('active');
          const radio = chip.querySelector('input[type="radio"]');
          if (radio) radio.checked = true;
        });
      });
      const deckSettingsBtn = document.getElementById('btnStudioDeckSettings');
      const deckMonitorBtn = document.getElementById('btnStudioDeckMonitor');
      const studioGrid = document.querySelector('#studioPanelTranscode .studio-grid');
      if (deckSettingsBtn && deckMonitorBtn && studioGrid) {
        deckSettingsBtn.addEventListener('click', () => {
          studioGrid.scrollTo({ left: 0, behavior: 'smooth' });
          deckSettingsBtn.classList.add('active');
          deckMonitorBtn.classList.remove('active');
        });
        deckMonitorBtn.addEventListener('click', () => {
          studioGrid.scrollTo({ left: studioGrid.scrollWidth, behavior: 'smooth' });
          deckMonitorBtn.classList.add('active');
          deckSettingsBtn.classList.remove('active');
        });
        studioGrid.addEventListener('scroll', () => {
          if (studioGrid.scrollLeft > studioGrid.clientWidth / 2) {
            deckMonitorBtn.classList.add('active');
            deckSettingsBtn.classList.remove('active');
          } else {
            deckSettingsBtn.classList.add('active');
            deckMonitorBtn.classList.remove('active');
          }
        }, { passive: true });
      }
      const handleSourceChange = async (filePath) => {
        if (!filePath) {
          probeBadge.style.display = 'none';
          return;
        }
        customInput.value = filePath;
        try {
          const res = await fetch('/api/studio/probe', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ inputPath: filePath })
          });
          const data = await res.json();
          if (data.ok && data.probe) {
            probeBadge.style.display = 'block';
            const fmt = data.probe.format || {};
            const vStream = (data.probe.streams || []).find(s => s.codec_type === 'video') || {};
            const aStream = (data.probe.streams || []).find(s => s.codec_type === 'audio') || {};
            probeDurationBadge.textContent = fmt.duration ? `${Math.round(fmt.duration)}s` : 'Unknown';
            probeDetails.innerHTML = `
              <div><b>Video:</b> ${vStream.codec_name ? vStream.codec_name.toUpperCase() : 'N/A'} ${vStream.width ? `(${vStream.width}x${vStream.height})` : ''}</div>
              <div><b>Audio:</b> ${aStream.codec_name ? aStream.codec_name.toUpperCase() : 'N/A'} ${aStream.sample_rate ? `• ${aStream.sample_rate}Hz` : ''}</div>
              <div><b>Bitrate:</b> ${fmt.bit_rate ? `${Math.round(fmt.bit_rate / 1000)} kbps` : 'Variable'} • <b>Size:</b> ${this.formatBytes(fmt.size || 0)}</div>
            `;
          }
        } catch (e) {
          console.warn('Probe preview error:', e);
        }
      };
      if (sourceSelect) {
        sourceSelect.addEventListener('change', (e) => handleSourceChange(e.target.value));
      }
      if (customInput) {
        customInput.addEventListener('blur', (e) => handleSourceChange(e.target.value));
        customInput.addEventListener('keydown', (e) => {
          if (e.key === 'Enter') handleSourceChange(e.target.value);
        });
      }
      if (btnStart) {
        btnStart.addEventListener('click', async () => {
          const inputPath = customInput.value.trim() || sourceSelect.value;
          if (!inputPath) {
            if (typeof showNovaToast === 'function') showNovaToast('Please select a file to transcode', 'fa-triangle-exclamation');
            return;
          }
          const selectedRadio = document.querySelector('input[name="transcodePreset"]:checked');
          const preset = selectedRadio ? selectedRadio.value : 'hevc';
          const normalizeAudio = document.getElementById('chkTranscodeNormalize')?.checked || false;
          const vocalBoost = document.getElementById('chkTranscodeVocalBoost')?.checked || false;
          const trimStart = document.getElementById('transcodeTrimStart')?.value.trim();
          const trimEnd = document.getElementById('transcodeTrimEnd')?.value.trim();
          const progressBox = document.getElementById('transcodeProgressBox');
          const progressBar = document.getElementById('transcodeProgressBar');
          const progressPercent = document.getElementById('transcodeProgressPercent');
          const statusBadge = document.getElementById('transcodeStatusBadge');
          const resultContainer = document.getElementById('transcodeResultContainer');
          btnStart.disabled = true;
          btnStart.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Transcoding Active...';
          progressBox.style.display = 'block';
          progressBar.style.width = '10%';
          progressPercent.textContent = 'Starting...';
          statusBadge.style.display = 'inline-block';
          statusBadge.textContent = 'Transcoding';
          statusBadge.className = 'task-status-pill downloading';
          if (studioGrid && window.innerWidth <= 900) {
            studioGrid.scrollTo({ left: studioGrid.scrollWidth, behavior: 'smooth' });
            if (deckMonitorBtn && deckSettingsBtn) {
              deckMonitorBtn.classList.add('active');
              deckSettingsBtn.classList.remove('active');
            }
          }
          resultContainer.innerHTML = `
            <div style="padding: 24px;">
              <i class="fa-solid fa-gears fa-spin" style="font-size: 2.8rem; color: var(--accent-cyan); margin-bottom: 14px;"></i>
              <h4 style="color: var(--text-main); margin-bottom: 6px;">Transcoding in Progress</h4>
              <p style="font-size: 0.85rem; color: var(--text-muted);">Encoding with preset <b>${preset.toUpperCase()}</b>. This may take a few moments depending on duration.</p>
            </div>
          `;
          try {
            const timeRange = (trimStart || trimEnd) ? { start: trimStart, end: trimEnd } : null;
            const res = await fetch('/api/studio/transcode', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                inputPath,
                preset,
                normalizeAudio,
                vocalBoost,
                timeRange
              })
            });
            const data = await res.json();
            if (data.ok) {
              progressBar.style.width = '100%';
              progressPercent.textContent = '100%';
              statusBadge.textContent = 'Completed';
              statusBadge.className = 'task-status-pill completed';
              const escapedOutput = (data.outputPath || '').replace(/\\/g, '\\\\');
              const folderPath = (data.outputPath || '').split(/[\\\/]/).slice(0, -1).join('\\').replace(/\\/g, '\\\\');
              resultContainer.innerHTML = `
                <div style="width: 100%; text-align: left; padding: 18px; background: rgba(34, 211, 238, 0.05); border: 1px solid rgba(34, 211, 238, 0.2); border-radius: var(--radius-sm);">
                  <div style="display: flex; align-items: center; gap: 8px; color: var(--accent-cyan); font-weight: 700; margin-bottom: 8px;">
                    <i class="fa-solid fa-circle-check"></i> Transcode Successful!
                  </div>
                  <h4 style="color: #fff; margin-bottom: 6px; word-break: break-all;">${data.fileName}</h4>
                  <div style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 14px;">
                    Size: <b>${this.formatBytes(data.fileSize)}</b> • Preset: <b>${preset.toUpperCase()}</b>
                  </div>
                  <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                    <button class="btn-primary" style="padding: 8px 14px; font-size: 0.85rem;" onclick="NovaStudio.playFile('${escapedOutput}')">
                      <i class="fa-solid fa-play"></i> Play in Studio
                    </button>
                    <button class="btn-subtle" style="padding: 8px 14px; font-size: 0.85rem;" onclick="openFolder('${folderPath}')">
                      <i class="fa-solid fa-folder-open"></i> Open Folder
                    </button>
                  </div>
                </div>
              `;
              if (typeof showNovaToast === 'function') {
                showNovaToast(`Transcode finished: ${data.fileName}`, 'fa-check');
              }
            } else {
              throw new Error(data.error || 'Transcode failed');
            }
          } catch (err) {
            statusBadge.textContent = 'Error';
            statusBadge.className = 'task-status-pill error';
            resultContainer.innerHTML = `
              <div style="color: var(--accent-red); padding: 20px;">
                <i class="fa-solid fa-triangle-exclamation" style="font-size: 2.2rem; margin-bottom: 10px;"></i>
                <h4>Transcoding Failed</h4>
                <p style="font-size: 0.85rem;">${err.message}</p>
              </div>
            `;
          } finally {
            btnStart.disabled = false;
            btnStart.innerHTML = '<i class="fa-solid fa-play"></i> Start Hardware Transcode';
          }
        });
      }
    },
    initStems() {
      const stemSelect = document.getElementById('stemSourceSelect');
      const btnStart = document.getElementById('btnStartStemSeparation');
      const resultContainer = document.getElementById('stemsResultContainer');
      const modeChips = document.querySelectorAll('#studioPanelStems .studio-preset-chip');
      modeChips.forEach(chip => {
        chip.addEventListener('click', () => {
          modeChips.forEach(c => c.classList.remove('active'));
          chip.classList.add('active');
          const radio = chip.querySelector('input[type="radio"]');
          if (radio) radio.checked = true;
        });
      });
      if (btnStart) {
        btnStart.addEventListener('click', async () => {
          const inputPath = stemSelect.value;
          if (!inputPath) {
            if (typeof showNovaToast === 'function') showNovaToast('Please pick an audio or video track first', 'fa-triangle-exclamation');
            return;
          }
          const selectedRadio = document.querySelector('input[name="stemMode"]:checked');
          const mode = selectedRadio ? selectedRadio.value : 'both';
          btnStart.disabled = true;
          btnStart.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Isolating Stems...';
          resultContainer.innerHTML = `
            <div style="padding: 24px;">
              <i class="fa-solid fa-waveform fa-beat" style="font-size: 3rem; color: #ec4899; margin-bottom: 14px;"></i>
              <h4 style="color: var(--text-main); margin-bottom: 6px;">Stereo Phase Demixing Active</h4>
              <p style="font-size: 0.85rem; color: var(--text-muted);">Inverting center-channel audio spectrum to extract Acapella and Karaoke stems...</p>
            </div>
          `;
          try {
            const res = await fetch('/api/studio/separate-stems', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ inputPath, mode })
            });
            const data = await res.json();
            if (data.ok && data.stems) {
              let stemsHtml = `<div style="width: 100%; display: flex; flex-direction: column; gap: 14px; text-align: left;">`;
              if (data.stems.instrumental) {
                const inst = data.stems.instrumental;
                const escPath = inst.path.replace(/\\/g, '\\\\');
                stemsHtml += `
                  <div style="background: rgba(56, 189, 248, 0.08); border: 1px solid rgba(56, 189, 248, 0.25); border-radius: var(--radius-sm); padding: 14px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                      <span style="font-weight: 700; color: #38bdf8; font-size: 0.9rem;"><i class="fa-solid fa-guitar"></i> Karaoke Instrumental</span>
                      <span style="font-size: 0.78rem; color: var(--text-muted);">${NovaStudio.formatBytes(inst.size)}</span>
                    </div>
                    <div style="font-size: 0.82rem; color: #fff; margin-bottom: 10px; word-break: break-all;">${inst.fileName}</div>
                    <audio controls style="width: 100%; height: 36px; margin-bottom: 8px;" src="/api/media/stream?path=${encodeURIComponent(inst.path)}"></audio>
                    <button class="btn-subtle" style="font-size: 0.8rem; padding: 6px 12px;" onclick="NovaStudio.playFile('${escPath}')">
                      <i class="fa-solid fa-play"></i> Play in Player Studio
                    </button>
                  </div>
                `;
              }
              if (data.stems.vocals) {
                const voc = data.stems.vocals;
                const escPath = voc.path.replace(/\\/g, '\\\\');
                stemsHtml += `
                  <div style="background: rgba(236, 72, 153, 0.08); border: 1px solid rgba(236, 72, 153, 0.25); border-radius: var(--radius-sm); padding: 14px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                      <span style="font-weight: 700; color: #ec4899; font-size: 0.9rem;"><i class="fa-solid fa-microphone"></i> Acapella Vocals</span>
                      <span style="font-size: 0.78rem; color: var(--text-muted);">${NovaStudio.formatBytes(voc.size)}</span>
                    </div>
                    <div style="font-size: 0.82rem; color: #fff; margin-bottom: 10px; word-break: break-all;">${voc.fileName}</div>
                    <audio controls style="width: 100%; height: 36px; margin-bottom: 8px;" src="/api/media/stream?path=${encodeURIComponent(voc.path)}"></audio>
                    <button class="btn-subtle" style="font-size: 0.8rem; padding: 6px 12px;" onclick="NovaStudio.playFile('${escPath}')">
                      <i class="fa-solid fa-play"></i> Play in Player Studio
                    </button>
                  </div>
                `;
              }
              stemsHtml += `</div>`;
              resultContainer.innerHTML = stemsHtml;
              if (typeof showNovaToast === 'function') {
                showNovaToast('Stems extracted & added to library!', 'fa-wand-magic-sparkles');
              }
            } else {
              throw new Error(data.error || 'Failed to separate stems');
            }
          } catch (err) {
            resultContainer.innerHTML = `
              <div style="color: var(--accent-red); padding: 20px;">
                <i class="fa-solid fa-triangle-exclamation" style="font-size: 2.2rem; margin-bottom: 10px;"></i>
                <h4>Stem Demixing Failed</h4>
                <p style="font-size: 0.85rem;">${err.message}</p>
              </div>
            `;
          } finally {
            btnStart.disabled = false;
            btnStart.innerHTML = '<i class="fa-solid fa-scissors"></i> Isolate Stems (Karaoke &amp; Vocals)';
          }
        });
      }
    },
    initLoudness() {
      const loudnessSelect = document.getElementById('loudnessSourceSelect');
      const formatSelect = document.getElementById('loudnessFormatSelect');
      const vocalBoostChk = document.getElementById('chkLoudnessVocalBoost');
      const btnStart = document.getElementById('btnStartLoudnessMastering');
      const resultContainer = document.getElementById('loudnessResultContainer');
      if (btnStart) {
        btnStart.addEventListener('click', async () => {
          const inputPath = loudnessSelect.value;
          if (!inputPath) {
            if (typeof showNovaToast === 'function') showNovaToast('Please select a track to master', 'fa-triangle-exclamation');
            return;
          }
          const outputPreset = formatSelect ? formatSelect.value : 'audio_mp3';
          const vocalBoost = vocalBoostChk ? vocalBoostChk.checked : true;
          btnStart.disabled = true;
          btnStart.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Mastering Audio...';
          resultContainer.innerHTML = `
            <div style="padding: 24px;">
              <i class="fa-solid fa-sliders fa-beat" style="font-size: 3rem; color: #f59e0b; margin-bottom: 14px;"></i>
              <h4 style="color: var(--text-main); margin-bottom: 6px;">Applying Broadcast Loudness Engine</h4>
              <p style="font-size: 0.85rem; color: var(--text-muted);">Calibrating integrated loudness to -16 LUFS &amp; contouring 3 kHz presence boost...</p>
            </div>
          `;
          try {
            const res = await fetch('/api/studio/loudness-boost', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ inputPath, vocalBoost, outputPreset })
            });
            const data = await res.json();
            if (data.ok) {
              const escPath = (data.outputPath || '').replace(/\\/g, '\\\\');
              resultContainer.innerHTML = `
                <div style="width: 100%; text-align: left; padding: 18px; background: rgba(245, 158, 11, 0.08); border: 1px solid rgba(245, 158, 11, 0.25); border-radius: var(--radius-sm);">
                  <div style="display: flex; align-items: center; gap: 8px; color: #f59e0b; font-weight: 700; margin-bottom: 8px;">
                    <i class="fa-solid fa-circle-check"></i> Mastering Complete!
                  </div>
                  <h4 style="color: #fff; margin-bottom: 6px; word-break: break-all;">${data.fileName}</h4>
                  <div style="font-size: 0.82rem; color: var(--text-muted); margin-bottom: 12px;">
                    Target: <b>-16 LUFS Integrated</b> • True Peak: <b>-1.5 dBTP</b> • Vocal EQ: <b>${vocalBoost ? 'Active (+4dB @ 3kHz)' : 'Off'}</b>
                  </div>
                  <audio controls style="width: 100%; height: 36px; margin-bottom: 12px;" src="/api/media/stream?path=${encodeURIComponent(data.outputPath)}"></audio>
                  <button class="btn-primary" style="padding: 8px 14px; font-size: 0.85rem; background: linear-gradient(115deg, #f59e0b 0%, #d97706 100%);" onclick="NovaStudio.playFile('${escPath}')">
                    <i class="fa-solid fa-play"></i> Play in Player Studio
                  </button>
                </div>
              `;
              if (typeof showNovaToast === 'function') {
                showNovaToast('EBU R128 audio mastering complete!', 'fa-volume-high');
              }
            } else {
              throw new Error(data.error || 'Failed to normalize audio');
            }
          } catch (err) {
            resultContainer.innerHTML = `
              <div style="color: var(--accent-red); padding: 20px;">
                <i class="fa-solid fa-triangle-exclamation" style="font-size: 2.2rem; margin-bottom: 10px;"></i>
                <h4>Audio Mastering Failed</h4>
                <p style="font-size: 0.85rem;">${err.message}</p>
              </div>
            `;
          } finally {
            btnStart.disabled = false;
            btnStart.innerHTML = '<i class="fa-solid fa-volume-high"></i> Master &amp; Normalize Audio';
          }
        });
      }
    },
    initDuplicates() {
      const btnScan = document.getElementById('btnScanDuplicatesNow');
      if (btnScan) {
        btnScan.addEventListener('click', () => this.scanDuplicates());
      }
    },
    async scanDuplicates() {
      const btnScan = document.getElementById('btnScanDuplicatesNow');
      const clustersContainer = document.getElementById('duplicateClustersContainer');
      const statClusters = document.getElementById('dupStatClusters');
      const statRedundant = document.getElementById('dupStatRedundant');
      const statReclaimable = document.getElementById('dupStatReclaimable');
      if (btnScan) {
        btnScan.disabled = true;
        btnScan.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Analyzing Library...';
      }
      clustersContainer.innerHTML = `
        <div class="card glass-card" style="text-align: center; padding: 36px 20px; color: var(--text-muted);">
          <i class="fa-solid fa-microchip fa-spin" style="font-size: 2.6rem; color: #10b981; margin-bottom: 12px;"></i>
          <h4 style="color: var(--text-main); margin-bottom: 6px;">Scanning Local Disks</h4>
          <p style="font-size: 0.88rem;">Normalizing media titles, matching durations, and identifying multi-resolution duplicate clusters...</p>
        </div>
      `;
      try {
        const res = await fetch('/api/studio/duplicates');
        const data = await res.json();
        if (data.ok) {
          statClusters.textContent = data.duplicateClusterCount || 0;
          statRedundant.textContent = data.redundantFileCount || 0;
          statReclaimable.textContent = data.totalReclaimableFormatted || '0 B';
          if (!data.clusters || data.clusters.length === 0) {
            clustersContainer.innerHTML = `
              <div class="card glass-card" style="text-align: center; padding: 40px 20px; color: var(--text-muted);">
                <i class="fa-solid fa-shield-check" style="font-size: 3rem; color: #10b981; margin-bottom: 12px;"></i>
                <h4 style="color: var(--text-main); margin-bottom: 6px;">Library is Clean &amp; Optimized</h4>
                <p style="font-size: 0.88rem; max-width: 400px; margin: 0 auto;">No redundant duplicates or unnecessary resolution copies found in your media library!</p>
              </div>
            `;
          } else {
            let html = '';
            data.clusters.forEach(cluster => {
              const best = cluster.canonicalItem;
              html += `
                <div class="card glass-card duplicate-cluster-card" id="cluster_${cluster.clusterId}" style="border: 1px solid rgba(16, 185, 129, 0.2); margin-bottom: 16px;">
                  <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 12px; margin-bottom: 14px;">
                    <div>
                      <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 4px;">
                        <span class="nav-badge-count" style="background: rgba(16, 185, 129, 0.2); color: #34d399; font-weight: 700; font-size: 0.75rem;">
                          ${cluster.totalItems} Copies Found
                        </span>
                        <h4 style="font-size: 1.05rem; font-weight: 700; margin: 0; color: #fff;">${cluster.clusterTitle}</h4>
                      </div>
                      <div style="font-size: 0.82rem; color: var(--text-muted);">
                        Potential Space Recovery: <b style="color: #34d399;">${cluster.potentialSavingsFormatted}</b>
                      </div>
                    </div>
                    <button class="btn-subtle" style="color: #fb7185; border-color: rgba(251, 113, 133, 0.3);" onclick="NovaStudio.cleanCluster('${cluster.clusterId}')">
                      <i class="fa-solid fa-trash-can"></i> Clean Redundant Copies (${cluster.redundantItems.length})
                    </button>
                  </div>
                  <!-- Canonical Master Item -->
                  <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.06); border-radius: var(--radius-sm); padding: 12px 14px; margin-bottom: 10px;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                      <div>
                        <span style="font-size: 0.72rem; color: #34d399; font-weight: 700; text-transform: uppercase;">
                          <i class="fa-solid fa-star"></i> Master Copy (Keep)
                        </span>
                        <div style="font-weight: 600; font-size: 0.9rem; color: #fff; margin: 2px 0;">${best.name}</div>
                        <div style="font-size: 0.75rem; color: var(--text-muted); font-family: var(--mono);">${best.folder}</div>
                      </div>
                      <div style="text-align: right;">
                        <span style="font-weight: 700; color: #fff; font-size: 0.88rem;">${best.sizeFormatted}</span>
                      </div>
                    </div>
                  </div>
                  <!-- Redundant Items List -->
                  <div style="display: flex; flex-direction: column; gap: 8px;">
                    ${cluster.redundantItems.map(item => `
                      <div style="background: rgba(251, 113, 133, 0.05); border: 1px dashed rgba(251, 113, 133, 0.2); border-radius: var(--radius-sm); padding: 10px 14px; display: flex; justify-content: space-between; align-items: center;">
                        <div>
                          <span style="font-size: 0.72rem; color: #fb7185; font-weight: 700; text-transform: uppercase;">
                            <i class="fa-solid fa-copy"></i> Redundant Copy
                          </span>
                          <div style="font-weight: 500; font-size: 0.85rem; color: #e2e8f0; margin: 2px 0;">${item.name}</div>
                          <div style="font-size: 0.75rem; color: var(--text-muted); font-family: var(--mono);">${item.folder}</div>
                        </div>
                        <div style="display: flex; align-items: center; gap: 12px;">
                          <span style="font-weight: 600; color: #fb7185; font-size: 0.85rem;">${item.sizeFormatted}</span>
                        </div>
                      </div>
                    `).join('')}
                  </div>
                </div>
              `;
            });
            clustersContainer.innerHTML = html;
          }
        }
      } catch (e) {
        clustersContainer.innerHTML = `
          <div style="color: var(--accent-red); padding: 20px; text-align: center;">
            <i class="fa-solid fa-triangle-exclamation" style="font-size: 2.2rem; margin-bottom: 10px;"></i>
            <h4>Scan Failed</h4>
            <p style="font-size: 0.85rem;">${e.message}</p>
          </div>
        `;
      } finally {
        if (btnScan) {
          btnScan.disabled = false;
          btnScan.innerHTML = '<i class="fa-solid fa-magnifying-glass"></i> Scan Library for Duplicates';
        }
      }
    },
    async cleanCluster(clusterId) {
      if (!confirm('Are you sure you want to permanently delete redundant copies in this cluster? The highest quality master copy will be preserved.')) {
        return;
      }
      const clusterEl = document.getElementById(`cluster_${clusterId}`);
      if (clusterEl) {
        clusterEl.style.opacity = '0.5';
      }
      try {
        const res = await fetch('/api/studio/duplicates/clean', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ clusterId })
        });
        const data = await res.json();
        if (data.ok) {
          if (typeof showNovaToast === 'function') {
            showNovaToast(`Cleaned ${data.deletedCount} redundant files!`, 'fa-trash-can');
          }
          if (clusterEl) clusterEl.remove();
          this.scanDuplicates();
        } else {
          throw new Error(data.error || 'Clean failed');
        }
      } catch (e) {
        if (typeof showNovaToast === 'function') {
          showNovaToast(`Error cleaning duplicate: ${e.message}`, 'fa-triangle-exclamation');
        }
        if (clusterEl) clusterEl.style.opacity = '1';
      }
    },
    async initSpeedAndNightShift() {
      const speedSelect = document.getElementById('topbarSpeedLimitSelect');
      const nightShiftBtn = document.getElementById('topbarNightShiftBtn');
      const nightShiftIcon = document.getElementById('topbarNightShiftIcon');
      const nightShiftLabel = document.getElementById('topbarNightShiftLabel');
      try {
        const res = await fetch('/api/settings');
        const data = await res.json();
        if (data && data.settings) {
          const s = data.settings;
          if (speedSelect && s.downloadSpeedLimit) {
            speedSelect.value = s.downloadSpeedLimit;
          }
          this.updateNightShiftUI(s.nightShiftEnabled);
        }
      } catch (e) {
        console.warn('Could not load initial speed settings:', e);
      }
      if (speedSelect) {
        speedSelect.addEventListener('change', async (e) => {
          const limit = e.target.value;
          try {
            await fetch('/api/settings/speed-limit', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ speedLimit: limit })
            });
            if (typeof showNovaToast === 'function') {
              showNovaToast(`Bandwidth throttled to ${limit === 'unlimited' ? 'Unlimited' : limit}`, 'fa-gauge-high');
            }
          } catch (err) {
            console.error('Failed to update speed limit:', err);
          }
        });
      }
      if (nightShiftBtn) {
        nightShiftBtn.addEventListener('click', () => {
          if (typeof toggleNightShiftGlobal === 'function') {
            toggleNightShiftGlobal();
          }
        });
      }
    },
    updateNightShiftUI(enabled) {
      const nightShiftIcon = document.getElementById('topbarNightShiftIcon');
      const nightShiftLabel = document.getElementById('topbarNightShiftLabel');
      const nightShiftBtn = document.getElementById('topbarNightShiftBtn');
      if (enabled) {
        if (nightShiftIcon) nightShiftIcon.style.color = '#fbbf24';
        if (nightShiftLabel) nightShiftLabel.textContent = '';
        if (nightShiftBtn) nightShiftBtn.style.borderColor = 'rgba(251, 191, 36, 0.4)';
      } else {
        if (nightShiftIcon) nightShiftIcon.style.color = '#94a3b8';
        if (nightShiftLabel) nightShiftLabel.textContent = '';
        if (nightShiftBtn) nightShiftBtn.style.borderColor = 'transparent';
      }
    },
    playFile(filePath) {
      if (typeof window.playItemDirectly === 'function') {
        window.playItemDirectly(filePath);
      } else if (typeof window.playMediaItem === 'function') {
        window.playMediaItem({ fullPath: filePath, name: filePath.split(/[\\\/]/).pop() });
      } else {
        window.location.hash = '#player';
      }
    },
    formatBytes(bytes) {
      if (!bytes || bytes === 0) return '0 B';
      const k = 1024;
      const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
      const i = Math.floor(Math.log(bytes) / Math.log(k));
      return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
  };
  document.addEventListener('DOMContentLoaded', () => {
    window.NovaStudio.init();
  });
})();