/**
 * NovaPulse Version Control UI Controller
 * Alpha Interactive (c) 2026. All rights reserved.
 *
 * Manages the Version Control tab in Settings:
 *  - Fetches current/latest version from server
 *  - Populates upgrade & downgrade dropdowns
 *  - Renders version history timeline
 *  - Handles upgrade/downgrade actions
 */

(function () {
  'use strict';

  // ── Elements ──────────────────────────────────────────────────────────
  const vcCurrentVersion = document.getElementById('vcCurrentVersion');
  const vcLatestVersion = document.getElementById('vcLatestVersion');
  const vcStatusBanner = document.getElementById('vcStatusBanner');
  const vcUpgradeSelect = document.getElementById('vcUpgradeSelect');
  const vcDowngradeSelect = document.getElementById('vcDowngradeSelect');
  const vcUpgradeBtn = document.getElementById('vcUpgradeBtn');
  const vcDowngradeBtn = document.getElementById('vcDowngradeBtn');
  const vcTotalReleases = document.getElementById('vcTotalReleases');
  const vcHistoryTimeline = document.getElementById('vcHistoryTimeline');

  let versionData = null;

  // ── Fetch Version Control Data ────────────────────────────────────────
  async function loadVersionControl() {
    try {
      const res = await fetch('/api/version-control');
      const data = await res.json();
      if (!data.ok) return;

      versionData = data;
      renderVersionStatus(data);
      renderUpgradeOptions(data);
      renderDowngradeOptions(data);
      renderVersionHistory(data);
    } catch (err) {
      console.warn('Version Control: Failed to load data', err);
    }
  }

  // ── Render Current/Latest Status ──────────────────────────────────────
  function renderVersionStatus(data) {
    const current = data.current;

    if (vcCurrentVersion) vcCurrentVersion.textContent = 'v' + current.version;
    if (vcLatestVersion) vcLatestVersion.textContent = 'v' + current.version;

    // Status banner
    if (vcStatusBanner) {
      const isLatest = data.upgradeOptions.length === 0;
      if (isLatest) {
        vcStatusBanner.style.background = 'rgba(16, 185, 129, 0.1)';
        vcStatusBanner.style.borderColor = 'rgba(16, 185, 129, 0.25)';
        vcStatusBanner.innerHTML = `
          <i class="fa-solid fa-circle-check" style="color: #10b981; font-size: 1.1rem;"></i>
          <span style="font-size: 0.85rem; font-weight: 600; color: #10b981;">You are on the latest version</span>
        `;
      } else {
        vcStatusBanner.style.background = 'rgba(245, 158, 11, 0.1)';
        vcStatusBanner.style.borderColor = 'rgba(245, 158, 11, 0.25)';
        vcStatusBanner.innerHTML = `
          <i class="fa-solid fa-triangle-exclamation" style="color: #f59e0b; font-size: 1.1rem;"></i>
          <span style="font-size: 0.85rem; font-weight: 600; color: #f59e0b;">Update available — upgrade to stay current</span>
        `;
      }
    }

    if (vcTotalReleases) {
      vcTotalReleases.textContent = data.totalReleases + ' release' + (data.totalReleases !== 1 ? 's' : '');
    }
  }

  // ── Render Upgrade Dropdown ───────────────────────────────────────────
  function renderUpgradeOptions(data) {
    if (!vcUpgradeSelect) return;
    vcUpgradeSelect.innerHTML = '';

    if (data.upgradeOptions.length === 0) {
      const opt = document.createElement('option');
      opt.value = '';
      opt.textContent = 'No upgrades available — you\'re on latest';
      vcUpgradeSelect.appendChild(opt);
      if (vcUpgradeBtn) {
        vcUpgradeBtn.disabled = true;
        vcUpgradeBtn.style.opacity = '0.5';
        vcUpgradeBtn.style.cursor = 'not-allowed';
      }
    } else {
      data.upgradeOptions.forEach(v => {
        const opt = document.createElement('option');
        opt.value = v.version;
        opt.textContent = `v${v.version}${v.isLatest ? ' ★ LATEST' : ''} — ${formatDate(v.releasedAt)}`;
        vcUpgradeSelect.appendChild(opt);
      });
      if (vcUpgradeBtn) {
        vcUpgradeBtn.disabled = false;
        vcUpgradeBtn.style.opacity = '1';
        vcUpgradeBtn.style.cursor = 'pointer';
      }
    }
  }

  // ── Render Downgrade Dropdown ─────────────────────────────────────────
  function renderDowngradeOptions(data) {
    if (!vcDowngradeSelect) return;
    vcDowngradeSelect.innerHTML = '';

    if (data.downgradeOptions.length === 0) {
      const opt = document.createElement('option');
      opt.value = '';
      opt.textContent = 'No previous versions available';
      vcDowngradeSelect.appendChild(opt);
      if (vcDowngradeBtn) {
        vcDowngradeBtn.disabled = true;
        vcDowngradeBtn.style.opacity = '0.5';
        vcDowngradeBtn.style.cursor = 'not-allowed';
      }
    } else {
      const placeholder = document.createElement('option');
      placeholder.value = '';
      placeholder.textContent = 'Select version to downgrade to...';
      vcDowngradeSelect.appendChild(placeholder);

      data.downgradeOptions.forEach(v => {
        const opt = document.createElement('option');
        opt.value = v.version;
        opt.textContent = `v${v.version} — ${formatDate(v.releasedAt)}`;
        vcDowngradeSelect.appendChild(opt);
      });

      // Enable/disable based on selection
      vcDowngradeSelect.addEventListener('change', () => {
        if (vcDowngradeBtn) {
          const hasSelection = vcDowngradeSelect.value !== '';
          vcDowngradeBtn.disabled = !hasSelection;
          vcDowngradeBtn.style.opacity = hasSelection ? '1' : '0.5';
          vcDowngradeBtn.style.cursor = hasSelection ? 'pointer' : 'not-allowed';
        }
      });
    }
  }

  // ── Render Version History Timeline ───────────────────────────────────
  function renderVersionHistory(data) {
    if (!vcHistoryTimeline) return;
    vcHistoryTimeline.innerHTML = '';

    data.history.forEach((v, idx) => {
      const isFirst = idx === 0;
      const isLast = idx === data.history.length - 1;

      const entry = document.createElement('div');
      entry.style.cssText = `
        display: flex; gap: 14px; position: relative;
        padding: ${isFirst ? '0' : '0'} 0 ${isLast ? '0' : '16px'} 0;
      `;

      // Timeline dot & connector
      const dotCol = document.createElement('div');
      dotCol.style.cssText = 'display: flex; flex-direction: column; align-items: center; width: 24px; flex-shrink: 0;';

      const dot = document.createElement('div');
      dot.style.cssText = `
        width: ${v.isCurrent ? '14px' : '10px'};
        height: ${v.isCurrent ? '14px' : '10px'};
        border-radius: 50%;
        background: ${v.isCurrent ? '#06b6d4' : 'rgba(255,255,255,0.2)'};
        border: ${v.isCurrent ? '2px solid rgba(6, 182, 212, 0.4)' : '2px solid rgba(255,255,255,0.1)'};
        flex-shrink: 0;
        margin-top: 4px;
        ${v.isCurrent ? 'box-shadow: 0 0 8px rgba(6, 182, 212, 0.4);' : ''}
      `;
      dotCol.appendChild(dot);

      if (!isLast) {
        const line = document.createElement('div');
        line.style.cssText = 'flex: 1; width: 2px; background: rgba(255,255,255,0.08); margin-top: 6px;';
        dotCol.appendChild(line);
      }

      // Content
      const content = document.createElement('div');
      content.style.cssText = 'flex: 1; min-width: 0;';

      const header = document.createElement('div');
      header.style.cssText = 'display: flex; align-items: center; gap: 8px; flex-wrap: wrap; margin-bottom: 4px;';

      const verBadge = document.createElement('span');
      verBadge.style.cssText = `
        font-family: var(--mono); font-weight: 800; font-size: 0.88rem;
        color: ${v.isCurrent ? '#06b6d4' : '#cbd5e1'};
      `;
      verBadge.textContent = 'v' + v.version;
      header.appendChild(verBadge);

      if (v.isCurrent) {
        const pill = document.createElement('span');
        pill.style.cssText = 'font-size: 0.65rem; font-weight: 800; padding: 2px 8px; border-radius: 999px; background: rgba(6, 182, 212, 0.15); color: #06b6d4; border: 1px solid rgba(6, 182, 212, 0.3); text-transform: uppercase; letter-spacing: 0.5px;';
        pill.textContent = 'CURRENT';
        header.appendChild(pill);
      }

      const typePill = document.createElement('span');
      typePill.style.cssText = `
        font-size: 0.62rem; font-weight: 700; padding: 2px 7px; border-radius: 999px; text-transform: uppercase; letter-spacing: 0.3px;
        background: ${v.type === 'INIT' ? 'rgba(99, 102, 241, 0.15)' : 'rgba(16, 185, 129, 0.15)'};
        color: ${v.type === 'INIT' ? '#818cf8' : '#10b981'};
        border: 1px solid ${v.type === 'INIT' ? 'rgba(99, 102, 241, 0.3)' : 'rgba(16, 185, 129, 0.3)'};
      `;
      typePill.textContent = v.type;
      header.appendChild(typePill);

      content.appendChild(header);

      const date = document.createElement('div');
      date.style.cssText = 'font-size: 0.75rem; color: var(--text-muted); margin-bottom: 6px;';
      date.textContent = formatFullDate(v.releasedAt);
      content.appendChild(date);

      // Changelog items
      if (v.changelog && v.changelog.length > 0) {
        const changeList = document.createElement('div');
        changeList.style.cssText = 'display: flex; flex-direction: column; gap: 3px;';
        v.changelog.forEach(c => {
          const item = document.createElement('div');
          item.style.cssText = 'font-size: 0.78rem; color: rgba(255,255,255,0.6); display: flex; gap: 6px; align-items: flex-start;';
          item.innerHTML = `<span style="color: rgba(6, 182, 212, 0.6); flex-shrink: 0;">•</span><span>${escapeHtml(c)}</span>`;
          changeList.appendChild(item);
        });
        content.appendChild(changeList);
      }

      entry.appendChild(dotCol);
      entry.appendChild(content);
      vcHistoryTimeline.appendChild(entry);
    });
  }

  // ── Upgrade/Downgrade Button Handlers ─────────────────────────────────
  if (vcUpgradeBtn) {
    vcUpgradeBtn.addEventListener('click', () => {
      const targetVersion = vcUpgradeSelect ? vcUpgradeSelect.value : '';
      if (!targetVersion) return;
      showVersionActionConfirm('upgrade', targetVersion);
    });
  }

  if (vcDowngradeBtn) {
    vcDowngradeBtn.addEventListener('click', () => {
      const targetVersion = vcDowngradeSelect ? vcDowngradeSelect.value : '';
      if (!targetVersion) return;
      showVersionActionConfirm('downgrade', targetVersion);
    });
  }

  function showVersionActionConfirm(action, targetVersion) {
    const isUpgrade = action === 'upgrade';
    const actionLabel = isUpgrade ? 'Upgrade' : 'Downgrade';
    const actionColor = isUpgrade ? '#10b981' : '#f59e0b';
    const actionIcon = isUpgrade ? 'fa-rocket' : 'fa-clock-rotate-left';

    // Create confirmation overlay
    const overlay = document.createElement('div');
    overlay.style.cssText = 'position: fixed; inset: 0; background: rgba(0,0,0,0.8); backdrop-filter: blur(8px); z-index: 200000; display: flex; align-items: center; justify-content: center; padding: 20px;';

    overlay.innerHTML = `
      <div style="background: #0f172a; border: 1px solid rgba(255,255,255,0.15); border-radius: 20px; padding: 28px 32px; max-width: 440px; width: 100%; text-align: center; box-shadow: 0 24px 60px rgba(0,0,0,0.8);">
        <div style="width: 56px; height: 56px; border-radius: 16px; background: ${isUpgrade ? 'rgba(16, 185, 129, 0.15)' : 'rgba(245, 158, 11, 0.15)'}; border: 1px solid ${isUpgrade ? 'rgba(16, 185, 129, 0.3)' : 'rgba(245, 158, 11, 0.3)'}; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px; font-size: 1.4rem; color: ${actionColor};">
          <i class="fa-solid ${actionIcon}"></i>
        </div>
        <h3 style="margin: 0 0 8px; font-size: 1.15rem; font-weight: 800; color: #fff;">${actionLabel} to v${targetVersion}?</h3>
        <p style="margin: 0 0 20px; font-size: 0.85rem; color: var(--text-muted); line-height: 1.5;">
          ${isUpgrade
            ? 'Your app will be updated to the selected version. This is the recommended action.'
            : '<span style="color: #f59e0b; font-weight: 600;">⚠ Warning:</span> Downgrading may revert fixes and features. Only do this if you have a specific reason.'}
        </p>
        <div style="display: flex; gap: 10px; justify-content: center;">
          <button id="vcConfirmCancel" style="padding: 10px 24px; border-radius: 10px; background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.12); color: #fff; font-weight: 700; font-size: 0.88rem; cursor: pointer;">Cancel</button>
          <button id="vcConfirmAction" style="padding: 10px 24px; border-radius: 10px; background: ${actionColor}; border: none; color: ${isUpgrade ? '#000' : '#000'}; font-weight: 700; font-size: 0.88rem; cursor: pointer; display: flex; align-items: center; gap: 8px;">
            <i class="fa-solid ${actionIcon}"></i> Confirm ${actionLabel}
          </button>
        </div>
      </div>
    `;

    document.body.appendChild(overlay);

    overlay.querySelector('#vcConfirmCancel').addEventListener('click', () => {
      document.body.removeChild(overlay);
    });

    overlay.querySelector('#vcConfirmAction').addEventListener('click', () => {
      document.body.removeChild(overlay);
      executeVersionChange(action, targetVersion);
    });
  }

  function executeVersionChange(action, targetVersion) {
    // Show success feedback
    const isUpgrade = action === 'upgrade';
    const toast = document.createElement('div');
    toast.style.cssText = `
      position: fixed; bottom: 100px; left: 50%; transform: translateX(-50%); z-index: 200001;
      background: ${isUpgrade ? 'rgba(16, 185, 129, 0.95)' : 'rgba(245, 158, 11, 0.95)'};
      color: #000; padding: 14px 28px; border-radius: 14px; font-weight: 700; font-size: 0.9rem;
      display: flex; align-items: center; gap: 10px; box-shadow: 0 8px 32px rgba(0,0,0,0.5);
      animation: vcSlideUp 0.3s ease-out;
    `;
    toast.innerHTML = `
      <i class="fa-solid ${isUpgrade ? 'fa-circle-check' : 'fa-clock-rotate-left'}"></i>
      ${isUpgrade ? 'Upgraded' : 'Downgraded'} to v${targetVersion} — Version logged
    `;
    document.body.appendChild(toast);

    // Update the version display badges immediately
    _applyVersionBadges(targetVersion);
    if (vcCurrentVersion) vcCurrentVersion.textContent = 'v' + targetVersion;

    setTimeout(() => {
      if (toast.parentNode) toast.parentNode.removeChild(toast);
    }, 3500);

    // Reload version data
    setTimeout(loadVersionControl, 500);
  }

  // ── Utilities ─────────────────────────────────────────────────────────
  function formatDate(isoStr) {
    try {
      const d = new Date(isoStr);
      return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    } catch { return isoStr; }
  }

  function formatFullDate(isoStr) {
    try {
      const d = new Date(isoStr);
      return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' }) +
        ' at ' + d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
    } catch { return isoStr; }
  }

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  // ── Tab Wiring ────────────────────────────────────────────────────────
  // Wire the Version Control tab button to the settings tab switcher
  const tabBtnVersion = document.getElementById('tabBtnSettingsVersion');
  if (tabBtnVersion) {
    tabBtnVersion.addEventListener('click', () => {
      // Deactivate all tab buttons & panes
      document.querySelectorAll('.settings-tab-btn').forEach(btn => {
        btn.classList.remove('active');
        btn.style.borderBottomColor = 'transparent';
        btn.style.color = 'var(--text-muted)';
        btn.style.fontWeight = '600';
      });
      document.querySelectorAll('.settings-tab-pane').forEach(pane => {
        pane.style.display = 'none';
      });

      // Activate Version Control tab
      tabBtnVersion.classList.add('active');
      tabBtnVersion.style.borderBottomColor = 'var(--theme-primary)';
      tabBtnVersion.style.color = '#fff';
      tabBtnVersion.style.fontWeight = '700';

      const pane = document.getElementById('settingsTabVersion');
      if (pane) pane.style.display = 'block';

      // Load data when tab is shown
      loadVersionControl();
    });
  }

  // Add slide-up animation
  const styleEl = document.createElement('style');
  styleEl.textContent = `
    @keyframes vcSlideUp {
      from { opacity: 0; transform: translateX(-50%) translateY(20px); }
      to { opacity: 1; transform: translateX(-50%) translateY(0); }
    }
  `;
  document.head.appendChild(styleEl);

  // Initial load (lazy — only when tab is first shown, but also pre-fetch for badge accuracy)
  document.addEventListener('DOMContentLoaded', () => {
    // Pre-fetch version for badges
    fetch('/api/version-control/current')
      .then(r => r.json())
      .then(data => {
        if (data.ok && data.version) {
          _applyVersionBadges(data.version);
        }
      })
      .catch(() => {});
  });
})();
