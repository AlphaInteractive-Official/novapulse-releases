// Ultimate Video Downloader Client Application
let currentVideoInfo = null;
let selectedQuality = null;
let selectedVideoFormatId = null;
let selectedAudioFormatId = null;
let activeTasksMap = new Map();

// Elements
const urlInput = document.getElementById('urlInput');
const inspectBtn = document.getElementById('inspectBtn');
const pasteBtn = document.getElementById('pasteBtn');
const previewCard = document.getElementById('previewCard');
const tasksContainer = document.getElementById('tasksContainer');
const emptyTasks = document.getElementById('emptyTasks');
const displayStoragePath = document.getElementById('displayStoragePath');
const openBaseFolderBtn = document.getElementById('openBaseFolderBtn');
const ytdlpVerBadge = document.getElementById('ytdlpVerBadge');

// Batch elements
const toggleBatchBtn = document.getElementById('toggleBatchBtn');
const batchBox = document.getElementById('batchBox');
const batchTextarea = document.getElementById('batchTextarea');
const batchModeSelect = document.getElementById('batchModeSelect');
const startBatchBtn = document.getElementById('startBatchBtn');
const batchToggleText = document.getElementById('batchToggleText');

// Preview Elements
const prevThumb = document.getElementById('prevThumb');
const prevDuration = document.getElementById('prevDuration');
const prevTitle = document.getElementById('prevTitle');
const prevChannel = document.getElementById('prevChannel');
const maxResBadge = document.getElementById('maxResBadge');
const qualityGrid = document.getElementById('qualityGrid');
const btnDownloadMax = document.getElementById('btnDownloadMax');
const btnDownloadCustomQuality = document.getElementById('btnDownloadCustomQuality');
const btnDownloadAudio = document.getElementById('btnDownloadAudio');
const btnDownloadCustomStream = document.getElementById('btnDownloadCustomStream');
const selectedStreamCode = document.getElementById('selectedStreamCode');

// Modals
const settingsModal = document.getElementById('settingsModal');
const settingsBtn = document.getElementById('settingsBtn');
const closeSettingsModal = document.getElementById('closeSettingsModal');
const downloadDirInput = document.getElementById('downloadDirInput');
const btnSaveDir = document.getElementById('btnSaveDir');

const updaterModal = document.getElementById('updaterModal');
const updaterBtn = document.getElementById('updaterBtn');
const closeUpdaterModal = document.getElementById('closeUpdaterModal');
const modalCurrentVer = document.getElementById('modalCurrentVer');
const runUpdateBtn = document.getElementById('runUpdateBtn');
const updateLogBox = document.getElementById('updateLogBox');

// Security PIN Token Storage
let authToken = localStorage.getItem('novapulse_auth_token') || '';

// Global fetch interceptor to attach security token if present
const originalFetch = window.fetch;
window.fetch = async function (url, options = {}) {
  options.headers = options.headers || {};
  if (authToken) {
    if (options.headers instanceof Headers) {
      options.headers.set('x-access-token', authToken);
    } else {
      options.headers['x-access-token'] = authToken;
    }
  }
  return await originalFetch(url, options);
};

function showAuthModal() {
  // Authentication disabled for direct local access
}

function hideAuthModal() {
  const modal = document.getElementById('authModal');
  if (modal) modal.style.display = 'none';
}

// Night Shift Global State & Synchronization
let currentNightShiftState = false;

function syncNightShiftUI(enabled) {
  currentNightShiftState = !!enabled;

  // 1. Settings Checkbox
  const chk = document.getElementById('settingsNightShiftCheckbox');
  if (chk) chk.checked = currentNightShiftState;

  // 2. Download View Button
  const dlBtn = null;
  const dlIcon = document.getElementById('iconNightShiftDownloads');
  const dlLabel = document.getElementById('labelNightShiftDownloads');
  if (dlBtn && dlLabel) {
    if (currentNightShiftState) {
      dlBtn.style.borderColor = 'rgba(251, 191, 36, 0.5)';
      dlBtn.style.background = 'rgba(251, 191, 36, 0.08)';
      if (dlIcon) dlIcon.style.color = '#fbbf24';
      dlLabel.textContent = '🌙 Night Shift: ON (Queued)';
      dlLabel.style.color = '#fbbf24';
    } else {
      dlBtn.style.borderColor = 'rgba(255, 255, 255, 0.12)';
      dlBtn.style.background = 'transparent';
      if (dlIcon) dlIcon.style.color = '#94a3b8';
      dlLabel.textContent = '⚡ Direct Download: ON';
      dlLabel.style.color = '#fff';
    }
  }

  // 3. Topbar Button
  const topBtn = null;
  const topIcon = document.getElementById('topbarNightShiftIcon');
  const topLabel = document.getElementById('topbarNightShiftLabel');
  if (topBtn) {
    if (currentNightShiftState) {
      topBtn.style.borderColor = 'rgba(251, 191, 36, 0.5)';
      topBtn.style.background = 'rgba(251, 191, 36, 0.12)';
      if (topIcon) topIcon.style.color = '#fbbf24';
      if (topLabel) {
        topLabel.textContent = '';
        topLabel.style.color = '#fbbf24';
      }
    } else {
      topBtn.style.borderColor = 'transparent';
      topBtn.style.background = 'transparent';
      if (topIcon) topIcon.style.color = '#94a3b8';
      if (topLabel) {
        topLabel.textContent = '';
        topLabel.style.color = 'var(--text-muted)';
      }
    }
  }
}

async function setNightShiftGlobal(newState) {
  try {
    syncNightShiftUI(newState);
    await fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nightShiftEnabled: newState })
    });
    if (typeof showNovaToast === 'function') {
      showNovaToast(
        newState 
          ? 'Night Shift ON: Downloads will wait for off-peak (1 AM - 7 AM)' 
          : 'Night Shift OFF: Direct Download mode active (Instant)',
        newState ? 'fa-moon' : 'fa-bolt'
      );
    }
  } catch (err) {
    console.error('Failed to update nightShiftEnabled setting:', err);
  }
}

function toggleNightShiftGlobal() {
  setNightShiftGlobal(!currentNightShiftState);
}

// Initialize
function initApp() {
  try { hideAuthModal(); } catch (e) { console.warn('hideAuthModal error:', e); }
  try { setupSSE(); } catch (e) { console.warn('setupSSE error:', e); }
  try { fetchStatus(); } catch (e) { console.warn('fetchStatus error:', e); }
  try { fetchDownloads(); } catch (e) { console.warn('fetchDownloads error:', e); }
  if (window.NovaPulseAndroid) {
    setInterval(() => {
      try { fetchDownloads(); } catch (e) {}
    }, 2000);
  }
  try { setupEventListeners(); } catch (e) { console.error('setupEventListeners error:', e); }
  try { initMediaStudio(); } catch (e) { console.error('initMediaStudio error:', e); }
  try { loadAndRenderLibrary(); } catch (e) { console.error('loadAndRenderLibrary error:', e); }
  try { setupAuthHandling(); } catch (e) { console.error('setupAuthHandling error:', e); }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initApp);
} else {
  initApp();
}

function setupAuthHandling() {
  // Authentication bypassed for seamless personal use

  const btnSubmitPin = document.getElementById('btnSubmitPin');
  if (btnSubmitPin) {
    btnSubmitPin.addEventListener('click', (e) => {
      e.preventDefault();
      if (authForm) authForm.dispatchEvent(new Event('submit', { cancelable: true }));
    });
  }

  if (authForm) {
    authForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const pin = authPinInput.value.trim();
      if (!pin) return;

      try {
        const res = await originalFetch('/api/auth/verify', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ password: pin })
        });
        const data = await res.json();
        if (data.ok) {
          authToken = data.token;
          localStorage.setItem('novapulse_auth_token', authToken);
          authErrorMsg.style.display = 'none';
          authPinInput.value = '';
          hideAuthModal();
          // Reconnect SSE with token
          setupSSE();
          // Refresh status, downloads, and library
          fetchStatus();
          fetchDownloads();
          if (typeof loadAndRenderLibrary === 'function') loadAndRenderLibrary();
        } else {
          authErrorMsg.textContent = data.error || 'Incorrect security access PIN.';
          authErrorMsg.style.display = 'block';
        }
      } catch (err) {
        authErrorMsg.textContent = 'Server verification failed: ' + err.message;
        authErrorMsg.style.display = 'block';
      }
    });
  }
}

// SSE Connection for Live Progress
let liveSseSource = null;
function setupSSE() {
  if (liveSseSource) {
    liveSseSource.close();
    liveSseSource = null;
  }
  const token = authToken || localStorage.getItem('novapulse_auth_token') || '';
  const streamUrl = '/api/progress/stream' + (token ? '?token=' + encodeURIComponent(token) : '');
  liveSseSource = new EventSource(streamUrl);

  liveSseSource.onmessage = (event) => {
    try {
      const data = JSON.parse(event.data);
      handleProgressEvent(data);
    } catch (e) {
      console.error('Error parsing SSE event', e);
    }
  };

  liveSseSource.onerror = () => {
    // Reconnection is automatic by browser EventSource
  };
}


function handleProgressEvent(data) {
  if (data.type === 'task_started' || data.type === 'task_added') {
    createOrUpdateTaskUI(data.task);
  } else if (data.type === 'task_progress') {
    updateTaskProgress(data);
  } else if (data.type === 'task_status') {
    const task = activeTasksMap.get(data.taskId);
    if (task) {
      task.status = data.status;
      if (data.speed !== undefined) task.speed = data.speed;
      if (data.eta !== undefined) task.eta = data.eta;
      if (task.status === 'paused') {
        task.isPaused = true;
        task.speed = 'Paused';
        task.eta = '--:--';
      } else if (task.status === 'downloading' || task.status === 'starting') {
        task.isPaused = false;
      }
      renderTask(task);
      if (window.AlphaDeviceBridge && typeof window.AlphaDeviceBridge.updateDownloadProgress === 'function') {
        const pctNum = parseInt(task.percent, 10) || 0;
        window.AlphaDeviceBridge.updateDownloadProgress(task.title || 'Media Download', pctNum, task.speed || '', task.eta || '');
      }
    }
  } else if (data.type === 'task_finished') {
    const task = activeTasksMap.get(data.taskId);
    if (task) {
      task.status = data.status;
      task.savedFile = data.savedFile;
      task.outputDir = data.outputDir;
      task.percent = data.status === 'completed' ? '100%' : task.percent;
      renderTask(task);
      if (window.AlphaDeviceBridge && typeof window.AlphaDeviceBridge.dismissDownloadNotification === 'function') {
        window.AlphaDeviceBridge.dismissDownloadNotification();
      }
      if (data.status === 'completed') {
        if (typeof NotificationCenter !== 'undefined') {
          NotificationCenter.pushDownloadCompleted({
            title: task.title || 'Media Download',
            savedFile: data.savedFile,
            outputDir: data.outputDir,
            total: task.total
          });
        }
        if (typeof Library !== 'undefined') {
          loadAndRenderLibrary();
        }
      } else if (data.status === 'failed') {
        if (typeof NotificationCenter !== 'undefined') {
          NotificationCenter.pushDownloadFailed({
            taskId: data.taskId,
            title: task.title || 'Media Download',
            error: data.error || 'Download interrupted'
          });
        }
      }
    }
  }
}

// Initial status & settings
async function fetchStatus() {
  try {
    const res = await fetch('/api/status');
    const data = await res.json();
    if (data.ok) {
      if (data.settings && data.settings.downloadDir) {
        if (displayStoragePath) displayStoragePath.textContent = data.settings.downloadDir;
        if (downloadDirInput) downloadDirInput.value = data.settings.downloadDir;
      }
      if (data.settings && typeof data.settings.nightShiftEnabled !== 'undefined') {
        syncNightShiftUI(data.settings.nightShiftEnabled);
      }

      // Update engine badges dynamically
      const ytdlpOk = data.tools?.ytdlp?.exists;
      const ffmpegOk = data.tools?.ffmpeg?.exists;

      const ytdlpBadge = document.getElementById('ytdlpStatusBadge');
      const ffmpegBadge = document.getElementById('ffmpegStatusBadge');
      const storageYt = document.getElementById('storageYtdlpBadge');
      const storageFf = document.getElementById('storageFfmpegBadge');

      if (ytdlpBadge) {
        ytdlpBadge.className = `status-badge ${ytdlpOk ? 'ok' : 'error'}`;
        ytdlpBadge.textContent = ytdlpOk ? 'Verified' : 'Missing';
      }
      if (ffmpegBadge) {
        ffmpegBadge.className = `status-badge ${ffmpegOk ? 'ok' : 'error'}`;
        ffmpegBadge.textContent = ffmpegOk ? 'Verified' : 'Missing';
      }
      if (storageYt) {
        storageYt.className = `status-badge ${ytdlpOk ? 'ok' : 'error'}`;
        storageYt.textContent = ytdlpOk ? 'Verified' : 'Missing';
      }
      if (storageFf) {
        storageFf.className = `status-badge ${ffmpegOk ? 'ok' : 'error'}`;
        storageFf.textContent = ffmpegOk ? 'Verified' : 'Missing';
      }
    }
    // Fetch version
    const verRes = await fetch('/api/updater/version');
    const verData = await verRes.json();
    if (verData.ok) {
      if (ytdlpVerBadge) ytdlpVerBadge.textContent = 'Alpha Engine v' + verData.version;
      if (modalCurrentVer) modalCurrentVer.textContent = verData.version;
    }
  } catch (err) {
    console.error('Failed to fetch status:', err);
  }
}

// Fetch active downloads and history
async function fetchDownloads() {
  try {
    const res = await fetch('/api/downloads');
    const data = await res.json();
    if (data.ok) {
      activeTasksMap.clear();
      if (Array.isArray(data.active)) {
        data.active.forEach(t => activeTasksMap.set(t.id, t));
      }
      renderAllTasks();
    }
  } catch (err) {
    console.error('Failed to fetch downloads:', err);
  }
}


function setupEventListeners() {
  // Dynamic link presence animator & state observer
  const updateInputLinkState = () => {
    const val = (urlInput ? urlInput.value : '').trim();
    const capsule = urlInput ? urlInput.closest('.hero-input-capsule') : null;
    if (!capsule) return;
    if (val.length > 0) {
      capsule.classList.add('has-link');
    } else {
      capsule.classList.remove('has-link');
    }
  };

  window.updateNovaInputLinkState = updateInputLinkState;
  urlInput.addEventListener('input', updateInputLinkState);
  urlInput.addEventListener('change', updateInputLinkState);
  urlInput.addEventListener('keyup', updateInputLinkState);

  // Inspect button
  inspectBtn.addEventListener('click', () => {
    const url = urlInput.value.trim();
    if (!url) return showNovaToast('Please enter a video URL first!', 'fa-circle-exclamation');
    inspectVideo(url);
  });

  urlInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      inspectBtn.click();
    }
  });

  // Auto-inspect when user directly pastes with Ctrl+V or right-click
  function isCandidateUrl(val) {
    if (!val) return false;
    const s = val.trim();
    return s.startsWith('http://') || s.startsWith('https://') || s.startsWith('magnet:?') ||
           /^[a-fA-F0-9]{40}$/.test(s) || /^[a-zA-Z2-7]{32}$/.test(s);
  }

  urlInput.addEventListener('paste', () => {
    setTimeout(() => {
      updateInputLinkState();
      const val = urlInput.value.trim();
      if (isCandidateUrl(val)) {
        inspectVideo(val);
      }
    }, 50);
  });

  // Paste button
  if (pasteBtn) {
    pasteBtn.addEventListener('click', async () => {
      try {
        const text = await navigator.clipboard.readText();
        urlInput.value = text;
        updateInputLinkState();
        if (isCandidateUrl(text)) {
          inspectVideo(text.trim());
        }
      } catch (e) {
        console.error(e);
      }
    });
  }

  // Batch toggle
  if (toggleBatchBtn) {
    toggleBatchBtn.addEventListener('click', () => {
      if (!batchBox) return;
      const isHidden = batchBox.style.display === 'none';
      batchBox.style.display = isHidden ? 'flex' : 'none';
      if (batchToggleText) batchToggleText.textContent = isHidden ? 'Switch to Single URL Mode' : 'Switch to Batch Queue Mode';
    });
  }

  if (startBatchBtn) {
    startBatchBtn.addEventListener('click', startBatchDownload);
  }

  // Mode Tabs switching (delegated + direct)
  document.addEventListener('click', (e) => {
    const tab = e.target.closest('.mode-tab');
    if (!tab) return;
    document.querySelectorAll('.mode-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.mode-panel').forEach(p => p.classList.remove('active'));

    tab.classList.add('active');
    const mode = tab.dataset.mode;
    const panel = document.getElementById(`panel-${mode}`);
    if (panel) panel.classList.add('active');
  });

  // Sites Directory Modal
  const sitesDirBtn = document.getElementById('sitesDirBtn');
  const sitesModal = document.getElementById('sitesModal');
  const closeSitesModal = document.getElementById('closeSitesModal');
  const sitesSearchInput = document.getElementById('sitesSearchInput');
  const sitesBadgeGrid = document.getElementById('sitesBadgeGrid');
  const filteredSitesCount = document.getElementById('filteredSitesCount');
  let cachedSites = [
    'YouTube', 'YouTube Music', 'TikTok', 'Instagram', 'Twitter / X', 'Facebook', 'Twitch', 'Reddit', 
    'Vimeo', 'SoundCloud', 'Bilibili', 'Dailymotion', 'VK', 'Pinterest', 'Bandcamp', 'Telegram', 
    'Kick', 'Loom', 'Rumble', 'Pornhub', 'Threads', 'Bluesky', 'Mastodon', 'Apple Podcasts',
    'Mixcloud', 'Deezer', 'TwitCasting', 'Weibo', 'Youku', 'iQiyi', 'Steam', 'Dropbox', 'Google Drive'
  ];

  async function loadCachedSites() {
    try {
      const res = await fetch('/api/supported-sites');
      const data = await res.json();
      if (data && data.sites && Array.isArray(data.sites) && data.sites.length > 0) {
        cachedSites = data.sites;
      }
    } catch(e) {}
    renderSitesList(cachedSites);
  }
  loadCachedSites();

  if (sitesDirBtn) {
    sitesDirBtn.addEventListener('click', () => {
      if (typeof Nova !== 'undefined' && Nova.switchView) {
        Nova.switchView('supported-sites');
      } else if (typeof switchView === 'function') {
        switchView('supported-sites');
      }
      if (sitesModal) sitesModal.style.display = 'none';
    });
  }

  if (closeSitesModal) {
    closeSitesModal.addEventListener('click', () => sitesModal.style.display = 'none');
  }

  if (sitesSearchInput) {
    sitesSearchInput.addEventListener('input', () => {
      const q = sitesSearchInput.value.toLowerCase().trim();
      const filtered = cachedSites.filter(s => s.toLowerCase().includes(q));
      renderSitesList(filtered);
    });
  }

  function renderSitesList(list) {
    filteredSitesCount.textContent = list.length;
    sitesBadgeGrid.innerHTML = '';
    list.slice(0, 150).forEach(site => {
      const badge = document.createElement('span');
      badge.className = 'site-badge';
      badge.textContent = site;
      badge.title = 'Click to paste into URL bar as example/domain search';
      badge.addEventListener('click', () => {
        urlInput.value = `https://${site.toLowerCase().replace(/[^a-z0-9]/g, '')}.com`;
        sitesModal.style.display = 'none';
        urlInput.focus();
      });
      sitesBadgeGrid.appendChild(badge);
    });
  }

  // Action Download buttons
  if (btnDownloadMax) {
    btnDownloadMax.addEventListener('click', () => {
      const meta = getActiveDownloadUrlAndMeta();
      if (!meta.url) return showNovaToast('Please enter or paste a valid video URL first!', 'fa-circle-exclamation');
      triggerDownload({
        url: meta.url,
        mode: 'max',
        browserCookies: meta.browserCookies,
        titleHint: meta.titleHint,
        thumbnail: meta.thumbnail
      }, btnDownloadMax);
    });
  }

  const btnQuickDownloadMax = document.getElementById('btnQuickDownloadMax');
  if (btnQuickDownloadMax) {
    btnQuickDownloadMax.addEventListener('click', () => {
      const meta = getActiveDownloadUrlAndMeta();
      if (!meta.url) return showNovaToast('Please enter or paste a valid video URL first!', 'fa-circle-exclamation');
      triggerDownload({
        url: meta.url,
        mode: 'max',
        browserCookies: meta.browserCookies,
        titleHint: meta.titleHint,
        thumbnail: meta.thumbnail
      }, btnQuickDownloadMax);
    });
  }

  if (btnDownloadCustomQuality) {
    btnDownloadCustomQuality.addEventListener('click', () => {
      if (!selectedQuality) return showNovaToast('Please select a resolution preset above (e.g. 1080p, 720p).', 'fa-circle-exclamation');
      const meta = getActiveDownloadUrlAndMeta();
      if (!meta.url) return showNovaToast('Please enter or paste a valid video URL first!', 'fa-circle-exclamation');
      triggerDownload({
        url: meta.url,
        mode: 'custom-quality',
        quality: selectedQuality,
        browserCookies: meta.browserCookies,
        titleHint: `${meta.titleHint} (${selectedQuality}p)`,
        thumbnail: meta.thumbnail
      }, btnDownloadCustomQuality);
    });
  }

  if (btnDownloadAudio) {
    btnDownloadAudio.addEventListener('click', () => {
      const meta = getActiveDownloadUrlAndMeta();
      if (!meta.url) return showNovaToast('Please enter or paste a valid video URL first!', 'fa-circle-exclamation');
      triggerDownload({
        url: meta.url,
        mode: 'audio',
        browserCookies: meta.browserCookies,
        titleHint: `${meta.titleHint} [MP3]`,
        thumbnail: meta.thumbnail
      }, btnDownloadAudio);
    });
  }

  if (btnDownloadCustomStream) {
    btnDownloadCustomStream.addEventListener('click', () => {
      if (!selectedVideoFormatId && !selectedAudioFormatId) {
        return showNovaToast('Please select at least one stream from the table above.', 'fa-circle-exclamation');
      }
      const meta = getActiveDownloadUrlAndMeta();
      if (!meta.url) return showNovaToast('Please enter or paste a valid video URL first!', 'fa-circle-exclamation');
      triggerDownload({
        url: meta.url,
        mode: 'custom-stream',
        customVideoId: selectedVideoFormatId,
        customAudioId: selectedAudioFormatId,
        browserCookies: meta.browserCookies,
        titleHint: `${meta.titleHint} [Custom ${selectedVideoFormatId || ''}+${selectedAudioFormatId || ''}]`,
        thumbnail: meta.thumbnail
      }, btnDownloadCustomStream);
    });
  }

  // Secret Download buttons
  const onSecretDownload = (btn) => {
    const meta = getActiveDownloadUrlAndMeta();
    if (!meta.url) return showNovaToast('Please enter or paste a valid video URL first!', 'fa-circle-exclamation');
    triggerDownload({
      url: meta.url,
      mode: 'max',
      isSecret: true,
      browserCookies: meta.browserCookies,
      titleHint: meta.titleHint,
      thumbnail: meta.thumbnail
    }, btn);
  };

  const btnSecretDownloadDirect = document.getElementById('btnSecretDownloadDirect');
  if (btnSecretDownloadDirect) {
    btnSecretDownloadDirect.addEventListener('click', () => onSecretDownload(btnSecretDownloadDirect));
  }

  const btnSecretDownloadMax = document.getElementById('btnSecretDownloadMax');
  if (btnSecretDownloadMax) {
    btnSecretDownloadMax.addEventListener('click', () => onSecretDownload(btnSecretDownloadMax));
  }

  const btnDownloadSecretMode = document.getElementById('btnDownloadSecretMode');
  if (btnDownloadSecretMode) {
    btnDownloadSecretMode.addEventListener('click', () => onSecretDownload(btnDownloadSecretMode));
  }

  // Explorer open
  if (openBaseFolderBtn) {
    openBaseFolderBtn.addEventListener('click', () => {
      openFolder();
    });
  }

  // Clear completed
  const clearCompletedBtn = document.getElementById('clearCompletedBtn');
  if (clearCompletedBtn) {
    clearCompletedBtn.addEventListener('click', async () => {
      activeTasksMap.forEach((task, id) => {
        if (task.status === 'completed' || task.status === 'failed' || task.status === 'cancelled') {
          activeTasksMap.delete(id);
        }
      });
      renderAllTasks();
      try {
        await fetch('/api/downloads/clear', { method: 'POST' });
        if (typeof showNovaToast === 'function') {
          showNovaToast('Finished downloads cleared', 'fa-trash-can');
        }
      } catch (e) {
        console.error('Failed to clear finished downloads:', e);
      }
    });
  }

  // Settings modal
  if (settingsBtn && settingsModal) {
    settingsBtn.addEventListener('click', () => {
      settingsModal.style.display = 'flex';
      const tabBtnGeneral = document.getElementById('tabBtnSettingsGeneral');
      if (tabBtnGeneral) tabBtnGeneral.click();
      if (window.NovaTheme && window.NovaTheme.renderThemeGallery) {
        window.NovaTheme.renderThemeGallery();
      }
    });
  }
  if (closeSettingsModal && settingsModal) {
    closeSettingsModal.addEventListener('click', () => settingsModal.style.display = 'none');
  }

  // Settings Tabs Switcher (General, Appearance, Engine, Legal)
  const setupSettingsTabs = () => {
    const tabBtnGeneral = document.getElementById('tabBtnSettingsGeneral');
    const tabBtnAppearance = document.getElementById('tabBtnSettingsAppearance');
    const tabBtnEngine = document.getElementById('tabBtnSettingsEngine');
    const tabBtnLegal = document.getElementById('tabBtnSettingsLegal');
    const paneGeneral = document.getElementById('settingsTabGeneral');
    const paneAppearance = document.getElementById('settingsTabAppearance');
    const paneEngine = document.getElementById('settingsTabEngine');
    const paneLegal = document.getElementById('settingsTabLegal');
    const btnBackToGeneral = document.getElementById('btnBackToGeneralSettings');

    const switchTab = (activeBtn, activePane) => {
      [tabBtnGeneral, tabBtnAppearance, tabBtnEngine, tabBtnLegal].forEach(b => {
        if (b) {
          b.classList.remove('active');
          b.style.borderBottomColor = 'transparent';
          b.style.color = 'var(--text-muted)';
        }
      });
      [paneGeneral, paneAppearance, paneEngine, paneLegal].forEach(p => {
        if (p) p.style.display = 'none';
      });

      if (activeBtn) {
        activeBtn.classList.add('active');
        activeBtn.style.borderBottomColor = 'var(--theme-primary)';
        activeBtn.style.color = '#fff';
      }
      if (activePane) activePane.style.display = 'block';

      if (activePane === paneAppearance && window.NovaTheme) {
        window.NovaTheme.renderThemeGallery();
      }
      if (activePane === paneGeneral) {
        const dInput = document.getElementById('downloadDirInput');
        if (dInput && !dInput.value) {
          fetch('/api/settings').then(r => r.json()).then(st => {
            if (st && st.downloadDir) dInput.value = st.downloadDir;
          }).catch(() => {});
        }
        const sNight = document.getElementById('settingsNightShiftCheckbox');
        if (sNight) sNight.checked = currentNightShiftState;
      }
    };

    if (tabBtnGeneral) tabBtnGeneral.addEventListener('click', () => switchTab(tabBtnGeneral, paneGeneral));
    if (tabBtnAppearance) tabBtnAppearance.addEventListener('click', () => switchTab(tabBtnAppearance, paneAppearance));
    if (tabBtnEngine) tabBtnEngine.addEventListener('click', () => switchTab(tabBtnEngine, paneEngine));
    if (tabBtnLegal) tabBtnLegal.addEventListener('click', () => switchTab(tabBtnLegal, paneLegal));
    if (btnBackToGeneral) btnBackToGeneral.addEventListener('click', () => switchTab(tabBtnGeneral, paneGeneral));

    // Expose switchTab globally for nova-core & modal opening resets
    window.switchSettingsTab = switchTab;
  };
  setupSettingsTabs();
  if (btnSaveDir && downloadDirInput) {
    btnSaveDir.addEventListener('click', async () => {
      const downloadDir = downloadDirInput.value.trim();
      if (!downloadDir) return;
      await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ downloadDir })
      });
      if (displayStoragePath) displayStoragePath.textContent = downloadDir;
      if (settingsModal) settingsModal.style.display = 'none';
    });
  }

  // Night Shift Settings & Controls Wiring
  const settingsNightShiftCheckbox = document.getElementById('settingsNightShiftCheckbox');
  if (settingsNightShiftCheckbox) {
    settingsNightShiftCheckbox.addEventListener('change', (e) => {
      setNightShiftGlobal(e.target.checked);
    });
  }

  const btnToggleNightShiftDownloads = document.getElementById('btnToggleNightShiftDownloads');
  if (btnToggleNightShiftDownloads) {
    btnToggleNightShiftDownloads.addEventListener('click', () => {
      toggleNightShiftGlobal();
    });
  }

  const btnStartAllScheduled = document.getElementById('btnStartAllScheduled');
  if (btnStartAllScheduled) {
    btnStartAllScheduled.addEventListener('click', async () => {
      const scheduledTasks = Array.from(activeTasksMap.values()).filter(t => t.status === 'scheduled');
      if (scheduledTasks.length === 0) return;
      btnStartAllScheduled.disabled = true;
      btnStartAllScheduled.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Starting All...';
      try {
        for (const st of scheduledTasks) {
          await fetch('/api/download/run-scheduled', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ taskId: st.id })
          });
        }
        if (typeof showNovaToast === 'function') {
          showNovaToast(`Launched ${scheduledTasks.length} queued download(s)!`, 'fa-bolt');
        }
      } catch (err) {
        console.error('Error starting scheduled downloads:', err);
      } finally {
        btnStartAllScheduled.disabled = false;
        btnStartAllScheduled.innerHTML = '<i class="fa-solid fa-forward"></i> Start All Scheduled';
      }
    });
  }

  // Updater modal
  if (updaterBtn && updaterModal) {
    updaterBtn.addEventListener('click', () => updaterModal.style.display = 'flex');
  }
  if (closeUpdaterModal && updaterModal) {
    closeUpdaterModal.addEventListener('click', () => updaterModal.style.display = 'none');
  }
  if (runUpdateBtn) {
    runUpdateBtn.addEventListener('click', async () => {
      runUpdateBtn.disabled = true;
      if (updateLogBox) updateLogBox.textContent = 'Checking Alpha Core Engine updates...\n';
      try {
        const res = await fetch('/api/updater/run', { method: 'POST' });
        const data = await res.json();
        if (updateLogBox) updateLogBox.textContent = data.output || 'Update completed.';
        fetchStatus();
      } catch (e) {
        if (updateLogBox) updateLogBox.textContent = 'Update error: ' + e.message;
      } finally {
        runUpdateBtn.disabled = false;
      }
    });
  }
}

// 1. Inspect Video
async function inspectVideo(url) {
  // Pre-unwrap if Google Images or search redirect
  try {
    const parsed = new URL(url);
    if (parsed.hostname.includes('google.') && parsed.searchParams.has('imgurl')) {
      const direct = parsed.searchParams.get('imgurl');
      if (direct && (direct.startsWith('http://') || direct.startsWith('https://'))) {
        url = direct;
        if (urlInput) urlInput.value = direct;
        if (typeof showNovaToast === 'function') {
          showNovaToast('Extracted direct image link from Google Search!', 'fa-wand-magic-sparkles');
        }
      }
    }
  } catch (e) {}

  inspectBtn.querySelector('.btn-text').style.display = 'none';
  inspectBtn.querySelector('.btn-loader').style.display = 'inline-flex';
  inspectBtn.disabled = true;

  const browserCookies = document.getElementById('cookieBrowserSelect') ? document.getElementById('cookieBrowserSelect').value : 'none';

  try {
    let data;
    if (window.NovaPulseAndroid && !window.location.origin.includes(':4980')) {
      // Standalone Android execution: live metadata resolution with YouTube oEmbed & direct stream fallback
      let cleanTitle = 'Media Stream';
      let channelName = 'Verified Source';
      let thumbUrl = 'assets/icons/novapulse.png';
      let estDuration = 0;
      let hostname = '';

      try {
        const u = new URL(url);
        hostname = u.hostname;
        const ytMatch = url.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?(?:.*&)?v=|(?:embed|v|shorts)\/))([\w-]{11})/i);
        if (ytMatch && ytMatch[1]) {
          const ytId = ytMatch[1];
          thumbUrl = 'https://i.ytimg.com/vi/' + ytId + '/hqdefault.jpg';
          cleanTitle = 'YouTube Video (' + ytId + ')';
          channelName = 'YouTube Channel';
          try {
            const oembedUrl = 'https://www.youtube.com/oembed?url=' + encodeURIComponent('https://www.youtube.com/watch?v=' + ytId) + '&format=json';
            const oRes = await fetch(oembedUrl);
            if (oRes.ok) {
              const oData = await oRes.json();
              if (oData.title) cleanTitle = oData.title;
              if (oData.author_name) channelName = oData.author_name;
              if (oData.thumbnail_url) thumbUrl = oData.thumbnail_url;
            }
          } catch (oeErr) {
            console.warn('YouTube oEmbed lookup skipped:', oeErr);
          }

          // Call native Android duration & metadata resolver
          if (window.NovaPulseAndroid && typeof window.NovaPulseAndroid.resolveMediaDetails === 'function') {
            try {
              const rawResolved = window.NovaPulseAndroid.resolveMediaDetails(url);
              const resolved = JSON.parse(rawResolved);
              if (resolved && resolved.ok) {
                if (resolved.duration && resolved.duration > 0) estDuration = resolved.duration;
                if (resolved.title && (!cleanTitle || cleanTitle.startsWith('YouTube Video ('))) cleanTitle = resolved.title;
                if (resolved.thumbnail && !thumbUrl.includes('ytimg.com')) thumbUrl = resolved.thumbnail;
              }
            } catch (resErr) {
              console.warn('Native resolveMediaDetails error:', resErr);
            }
          }
        } else {
          const p = u.pathname.split('/').filter(Boolean).pop();
          if (p && p.length > 2) {
            cleanTitle = decodeURIComponent(p).replace(/[_-]/g, ' ').replace(/\.[a-z0-9]+$/i, '');
          } else {
            cleanTitle = 'Media Stream (' + hostname + ')';
          }
          channelName = hostname || 'Direct Media Link';
        }
      } catch (e) {
        cleanTitle = 'Media Stream';
      }

      const simulatedInfo = {
        title: cleanTitle,
        channel: channelName,
        duration: estDuration,
        thumbnail: thumbUrl,
        availableResolutions: [1080, 720, 480],
        videoFormats: [
          { format_id: '1080p', ext: 'mp4', resolution: '1080p', note: 'Full HD 1080p Video (MP4)', filesize: null },
          { format_id: '720p', ext: 'mp4', resolution: '720p', note: 'Standard HD 720p Video (MP4)', filesize: null },
          { format_id: '480p', ext: 'mp4', resolution: '480p', note: 'Standard Definition 480p (MP4)', filesize: null }
        ],
        audioFormats: [
          { format_id: 'audio_mp3', ext: 'mp3', resolution: 'Audio Only', note: 'Studio Quality Audio (MP3)', filesize: null }
        ],
        formats: [
          { format_id: '1080p', ext: 'mp4', resolution: '1080p', note: 'Full HD Video (MP4)' },
          { format_id: 'audio_mp3', ext: 'mp3', resolution: 'Audio Only', note: 'Studio Audio (MP3)' }
        ]
      };

      data = {
        ok: true,
        info: simulatedInfo
      };
    } else {
      const res = await fetch('/api/inspect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url, browserCookies })
      });
      data = await res.json();
    }

    if (!data.ok) {
      if (data.smartAnalysis) {
        renderSmartUrlReport(data.smartAnalysis, url);
        return;
      }
      if (typeof showNovaToast === 'function') {
        showNovaToast(data.error || 'Failed to inspect link', 'fa-circle-exclamation');
      } else {
        alert('Inspection notice: ' + (data.error || 'Unknown error'));
      }
      return;
    }

    currentVideoInfo = data.info;
    window.currentVideoInfo = data.info;
    renderVideoPreview(data.info, data.existingMedia);
  } catch (err) {
    if (typeof showNovaToast === 'function') {
      showNovaToast('Inspection network error: ' + err.message, 'fa-circle-exclamation');
    } else {
      alert('Inspection failed: ' + err.message);
    }
  } finally {
    inspectBtn.querySelector('.btn-text').style.display = 'inline-flex';
    inspectBtn.querySelector('.btn-loader').style.display = 'none';
    inspectBtn.disabled = false;
  }
}

function renderSmartUrlReport(analysis, url) {
  const modal = document.getElementById('novaSmartUrlDiagnosticModal');
  if (!modal) {
    if (typeof showNovaToast === 'function') {
      showNovaToast(analysis.reason || 'Webpage link detected (not a media stream)', 'fa-circle-info');
    }
    return;
  }

  const categoryText = document.getElementById('smartUrlCategoryText');
  const categoryIcon = document.getElementById('smartUrlCategoryIcon');
  const domainBadge = document.getElementById('smartUrlDomainBadge');
  const titleText = document.getElementById('smartUrlTitleText');
  const descText = document.getElementById('smartUrlDescriptionText');
  const reasonText = document.getElementById('smartUrlReasonText');
  const suggestionText = document.getElementById('smartUrlSuggestionText');
  const openSnifferBtn = document.getElementById('smartUrlOpenSnifferBtn');

  if (categoryText) categoryText.textContent = analysis.category || 'Webpage Detected';
  if (categoryIcon && analysis.categoryIcon) categoryIcon.className = 'fa-solid ' + analysis.categoryIcon;
  if (domainBadge) domainBadge.textContent = analysis.domain || '';
  if (titleText) titleText.textContent = analysis.title || analysis.domain || 'Target Page';
  if (descText) descText.textContent = analysis.description || '';
  if (reasonText) reasonText.textContent = analysis.reason || 'This URL is a webpage, not direct media.';
  if (suggestionText) suggestionText.textContent = analysis.suggestion || 'Paste a direct media link or supported platform URL.';

  if (openSnifferBtn) {
    openSnifferBtn.onclick = () => {
      modal.style.display = 'none';
      window.location.hash = '#sniffer';
      const snifferInput = document.getElementById('snifferTargetUrl');
      if (snifferInput) snifferInput.value = url;
      if (typeof showNovaToast === 'function') {
        showNovaToast('Opened Web Sniffer to inspect this webpage', 'fa-satellite-dish');
      }
    };
  }

  modal.style.display = 'flex';
}

// 2. Render Preview UI
function renderVideoPreview(info, existingMedia = null) {
  previewCard.style.display = 'block';
  prevThumb.src = info.thumbnail;
  prevTitle.textContent = info.title;
  prevChannel.textContent = info.channel || 'Verified Source';
  prevDuration.textContent = formatDuration(info.duration);

  const maxH = info.availableResolutions.length ? Math.max(...info.availableResolutions) : 1080;
  maxResBadge.textContent = maxH >= 2160 ? '4K / 8K Ultra' : `${maxH}p HD`;

  // Render or update Recognizer In-Library Notice banner
  let notice = document.getElementById('recognizerLibraryNotice');
  if (!notice) {
    notice = document.createElement('div');
    notice.id = 'recognizerLibraryNotice';
    notice.style.cssText = 'background: rgba(245, 158, 11, 0.12); border: 1px solid rgba(245, 158, 11, 0.3); border-radius: 8px; padding: 10px 14px; margin: 12px 0; display: flex; align-items: center; justify-content: space-between; font-size: 0.85rem; color: #f59e0b;';
    const container = qualityGrid ? qualityGrid.parentNode : previewCard;
    if (container && qualityGrid) container.insertBefore(notice, qualityGrid);
  }

  if (existingMedia) {
    const exRes = existingMedia.resolution || 'Standard';
    const exSize = existingMedia.size ? formatBytes(existingMedia.size) : 'Ready';
    notice.innerHTML = `
      <div style="display: flex; align-items: center; gap: 10px;">
        <i class="fa-solid fa-circle-check" style="font-size: 1.15rem; color: #10b981;"></i>
        <div>
          <strong style="color: #fff;">Recognized in Local Library:</strong> 
          Already downloaded in <span class="pill pill-amber" style="font-size: 0.72rem; padding: 2px 7px; font-weight: bold; background: rgba(245, 158, 11, 0.2); color: #f59e0b;">${exRes}</span> (${exSize}). 
          <span style="color: var(--text-muted); font-size: 0.8rem; margin-left: 4px;">Selecting another resolution will ask to confirm upgrade.</span>
        </div>
      </div>
      <button class="btn-subtle" style="font-size: 0.78rem; padding: 4px 10px; margin-left: 10px; white-space: nowrap;" onclick="if(window.__currentExistingMedia) playLibraryTrackWithQueue(window.__currentExistingMedia)">
        <i class="fa-solid fa-play"></i> Play Existing
      </button>
    `;
    notice.style.display = 'flex';
    window.__currentExistingMedia = existingMedia;
  } else if (notice) {
    notice.style.display = 'none';
    window.__currentExistingMedia = null;
  }

  // Render Quality Chips
  qualityGrid.innerHTML = '';
  selectedQuality = null;
  btnDownloadCustomQuality.disabled = true;

  const popularResolutions = [4320, 2160, 1440, 1080, 720, 480, 360];
  const availableSet = new Set(info.availableResolutions);

  popularResolutions.forEach(res => {
    const isAvailable = availableSet.has(res) || info.availableResolutions.some(r => Math.abs(r - res) <= 20);
    const chip = document.createElement('div');
    chip.className = `quality-chip ${isAvailable ? '' : 'unavailable'}`;
    
    let label = `${res}p`;
    let sub = 'Standard';
    if (res >= 4320) { label = '8K UHD'; sub = '4320p'; }
    else if (res >= 2160) { label = '4K UHD'; sub = '2160p'; }
    else if (res >= 1440) { label = '2K QHD'; sub = '1440p'; }
    else if (res === 1080) { label = '1080p'; sub = 'Full HD'; }
    else if (res === 720) { label = '720p'; sub = 'HD'; }

    const isDownloadedInThisRes = existingMedia && existingMedia.resolution === `${res}p`;
    chip.innerHTML = `
      <span class="chip-res">${label} ${isDownloadedInThisRes ? '<span style="font-size: 0.65rem; background: rgba(16, 185, 129, 0.25); color: #10b981; padding: 1px 5px; border-radius: 4px; margin-left: 4px; vertical-align: middle;">In Library</span>' : ''}</span>
      <span class="chip-sub">${sub}</span>
    `;

    chip.addEventListener('click', () => {
      document.querySelectorAll('.quality-chip').forEach(c => c.classList.remove('selected'));
      chip.classList.add('selected');
      selectedQuality = res;
      btnDownloadCustomQuality.disabled = false;
      btnDownloadCustomQuality.innerHTML = `<i class="fa-solid fa-download"></i> Download in ${label}`;
    });

    qualityGrid.appendChild(chip);
  });

  // Render Stream Table (Feature 4 - Stream matrix)
  renderStreamTables(info.videoFormats, info.audioFormats);

  // Initialize AI Precision Cloud Trimmer
  if (window.PowerTrio && typeof window.PowerTrio.initTrimmerPreview === 'function') {
    window.PowerTrio.initTrimmerPreview(info);
  }

  // Auto-scroll to preview
  previewCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// 3. Render Stream Picker Tables
function renderStreamTables(videos, audios) {
  const vTbody = document.querySelector('#videoStreamTable tbody');
  const aTbody = document.querySelector('#audioStreamTable tbody');
  vTbody.innerHTML = '';
  aTbody.innerHTML = '';

  selectedVideoFormatId = null;
  selectedAudioFormatId = null;
  updateSelectedStreamText();

  videos.forEach(v => {
    const tr = document.createElement('tr');
    const sizeStr = v.filesize ? formatBytes(v.filesize) : (v.tbr ? `${v.tbr}k` : 'N/A');
    tr.innerHTML = `
      <td><input type="radio" name="video_stream" value="${v.format_id}" /></td>
      <td><strong>${v.format_id}</strong></td>
      <td>${v.resolution}</td>
      <td>${v.fps || '-'}</td>
      <td>${v.vcodec ? v.vcodec.split('.')[0] : v.ext}</td>
      <td>${sizeStr}</td>
    `;
    tr.addEventListener('click', () => {
      tr.querySelector('input').checked = true;
      vTbody.querySelectorAll('tr').forEach(r => r.classList.remove('selected'));
      tr.classList.add('selected');
      selectedVideoFormatId = v.format_id;
      updateSelectedStreamText();
    });
    vTbody.appendChild(tr);
  });

  audios.forEach(a => {
    const tr = document.createElement('tr');
    const sizeStr = a.filesize ? formatBytes(a.filesize) : (a.tbr ? `${a.tbr}k` : 'N/A');
    tr.innerHTML = `
      <td><input type="radio" name="audio_stream" value="${a.format_id}" /></td>
      <td><strong>${a.format_id}</strong></td>
      <td>${a.ext}</td>
      <td>${a.acodec ? a.acodec.split('.')[0] : '-'}</td>
      <td>${sizeStr}</td>
    `;
    tr.addEventListener('click', () => {
      tr.querySelector('input').checked = true;
      aTbody.querySelectorAll('tr').forEach(r => r.classList.remove('selected'));
      tr.classList.add('selected');
      selectedAudioFormatId = a.format_id;
      updateSelectedStreamText();
    });
    aTbody.appendChild(tr);
  });
}

function updateSelectedStreamText() {
  selectedStreamCode.textContent = `Video ID: ${selectedVideoFormatId || 'None'} + Audio ID: ${selectedAudioFormatId || 'None'}`;
  btnDownloadCustomStream.disabled = !(selectedVideoFormatId || selectedAudioFormatId);
}

function getActiveDownloadUrlAndMeta() {
  const inputEl = document.getElementById('urlInput');
  const inputVal = inputEl ? inputEl.value.trim() : '';
  let url = (currentVideoInfo && currentVideoInfo.webpage_url) ? currentVideoInfo.webpage_url : inputVal;
  let titleHint = (currentVideoInfo && currentVideoInfo.title) ? currentVideoInfo.title : (inputVal || 'Video Download');
  let thumbnail = (currentVideoInfo && currentVideoInfo.thumbnail) ? currentVideoInfo.thumbnail : '';
  const cookieSelect = document.getElementById('cookieBrowserSelect');
  const browserCookies = cookieSelect ? cookieSelect.value : 'none';
  const ghostDriveTurbo = window.__ghostDriveActive !== false;

  return { url, titleHint, thumbnail, browserCookies, ghostDriveTurbo };
}

function showDownloadStartedPopup(options = {}) {
  const modal = document.getElementById('downloadStartedModal');
  if (!modal) return;

  const thumbImg = document.getElementById('dlStartedThumb');
  const fallbackThumb = document.getElementById('dlStartedThumbFallback');
  const titleEl = document.getElementById('dlStartedTitle');
  const modeBadge = document.getElementById('dlStartedModeBadge');
  const folderEl = document.getElementById('dlStartedStorageFolder');

  if (options.thumbnail && thumbImg) {
    thumbImg.src = options.thumbnail;
    thumbImg.style.display = 'block';
    if (fallbackThumb) fallbackThumb.style.display = 'none';
  } else if (thumbImg) {
    thumbImg.style.display = 'none';
    if (fallbackThumb) fallbackThumb.style.display = 'flex';
  }

  if (titleEl) {
    titleEl.textContent = options.title || 'Video Download';
    titleEl.title = options.title || '';
  }

  if (modeBadge) {
    let modeText = 'Max Quality MP4';
    if (options.mode === 'audio') modeText = 'Extract MP3 Audio';
    else if (options.mode === 'custom-quality') modeText = `${options.quality || 1080}p Video`;
    else if (options.mode === 'custom-stream') modeText = 'Custom Stream';
    modeBadge.textContent = modeText;
  }

  if (folderEl) {
    folderEl.innerHTML = `<i class="fa-solid fa-folder"></i> ${options.outputDir ? options.outputDir.split('\\').slice(-2).join('\\') : 'Downloads'}`;
  }

  modal.style.display = 'flex';

  const closeBtn = document.getElementById('closeDownloadStartedModal');
  const stayBtn = document.getElementById('btnStayOnPage');
  const goBtn = document.getElementById('btnGoToDownloads');

  const hide = () => { modal.style.display = 'none'; };
  if (closeBtn) closeBtn.onclick = hide;
  if (stayBtn) stayBtn.onclick = hide;
  if (goBtn) {
    goBtn.onclick = () => {
      hide();
      if (typeof switchView === 'function') switchView('downloads');
    };
  }

  if (typeof showNovaToast === 'function') {
    showNovaToast(`Download started: ${options.title || 'Video'}`, 'fa-cloud-arrow-down');
  }
}

// Play library video with full Player Studio experience & follow-up queue
function playLibraryTrackWithQueue(clickedItem) {
  if (!clickedItem) return;

  // Retrieve current ordered media list from Library (respects active tab, sort, and search filter)
  const allItems = (typeof Library !== 'undefined' && typeof Library.getFilteredMedia === 'function')
    ? Library.getFilteredMedia()
    : [];

  const clickedIdx = allItems.findIndex(it => it.id === clickedItem.id);

  let queueItems = [];
  if (clickedIdx !== -1) {
    // YouTube style: clicked video is first/active, followed by next videos in order, then earlier videos
    queueItems = [
      clickedItem,
      ...allItems.slice(clickedIdx + 1),
      ...allItems.slice(0, clickedIdx)
    ];
  } else {
    queueItems = [clickedItem, ...allItems.filter(it => it.id !== clickedItem.id)];
  }

  // Atomically set queue, load item, and start playback
  if (typeof Playlist !== 'undefined' && typeof Playlist.setQueue === 'function') {
    Playlist.setQueue(queueItems, 0, true);
  } else if (typeof Playlist !== 'undefined') {
    Playlist.clear();
    Playlist.addItems(queueItems);
    Playlist.selectIndex(0, true);
  }

  if (typeof Library !== 'undefined') {
    if (typeof Library.recordRecentlyPlayed === 'function') Library.recordRecentlyPlayed(clickedItem);
    if (typeof Library.setActiveId === 'function') Library.setActiveId(clickedItem.id);
    const libContainer = document.getElementById('libraryContainer');
    if (libContainer && typeof Library.markActiveInDom === 'function') Library.markActiveInDom(libContainer, clickedItem.id);
  }

  // Directly navigate to Player Studio
  if (typeof Nova !== 'undefined' && typeof Nova.switchView === 'function') {
    Nova.switchView('player');
  } else if (typeof switchView === 'function') {
    switchView('player');
  }

  if (typeof syncPlayerStudioUI === 'function') {
    syncPlayerStudioUI();
  }

  // Deduplicate toast: only show once per unique track
  if (typeof showNovaToast === 'function') {
    const trackKey = clickedItem.id || clickedItem.url || clickedItem.name;
    if (window.__lastPlayedToastTrack !== trackKey) {
      window.__lastPlayedToastTrack = trackKey;
      showNovaToast(`Playing in Player Studio: ${clickedItem.name}`, 'fa-circle-play', 15000);
    }
  }
}
window.playLibraryTrackWithQueue = playLibraryTrackWithQueue;

function showAlreadyDownloadedModal(mediaItem, payload, clickedBtn = null, dlData = null) {
  const modal = document.getElementById('alreadyDownloadedModal');
  if (!modal) {
    if (confirm(`"${mediaItem.name}" is already downloaded in your library in ${mediaItem.resolution || 'existing format'}!\n\nClick OK to open and play it in Player Studio, or Cancel.`)) {
      playLibraryTrackWithQueue(mediaItem);
    }
    return;
  }

  const thumbImg = document.getElementById('alreadyDlThumb');
  const fallbackThumb = document.getElementById('alreadyDlThumbFallback');
  const titleEl = document.getElementById('alreadyDlTitle');
  const formatBadge = document.getElementById('alreadyDlFormatBadge');
  const resBadge = document.getElementById('alreadyDlResolutionBadge');
  const sizeBadge = document.getElementById('alreadyDlSizeBadge');
  const closeBtn = document.getElementById('closeAlreadyDownloadedModal');
  const cancelBtn = document.getElementById('btnCancelAlreadyDl');
  const playBtn = document.getElementById('btnPlayNowInStudio');
  const playBtnLabel = document.getElementById('btnPlayNowLabel');
  const redownloadBtn = document.getElementById('btnRedownloadAnyway');
  const redownloadLabel = document.getElementById('btnRedownloadLabel');
  const existingQualityText = document.getElementById('alreadyDlExistingQualityText');
  const requestedQualityText = document.getElementById('alreadyDlRequestedQualityText');
  const descEl = document.getElementById('alreadyDlDescription');

  const existingRes = mediaItem.resolution || '720p';
  const existingSize = mediaItem.size ? formatBytes(mediaItem.size) : 'Ready';
  const existingExt = (mediaItem.extension || 'mp4').toUpperCase().replace('.', '');

  let reqRes = 'Max Quality';
  if (dlData && dlData.requestedQuality) {
    reqRes = dlData.requestedQuality;
  } else if (payload && payload.quality) {
    reqRes = `${payload.quality}p`;
  } else if (payload && payload.mode === 'audio') {
    reqRes = 'Audio MP3';
  } else if (payload && payload.mode === 'max') {
    reqRes = 'Max Quality';
  } else if (payload && payload.mode) {
    reqRes = payload.mode;
  }

  if (titleEl) {
    titleEl.textContent = mediaItem.name || 'Video in Library';
    titleEl.title = mediaItem.name || '';
  }

  if (formatBadge) {
    formatBadge.textContent = existingExt;
  }

  if (resBadge) {
    resBadge.textContent = existingRes;
    resBadge.style.display = 'inline-block';
  }

  if (sizeBadge) {
    sizeBadge.textContent = existingSize;
  }

  if (existingQualityText) {
    existingQualityText.textContent = `${existingRes} (${existingSize})`;
  }

  if (requestedQualityText) {
    requestedQualityText.textContent = reqRes;
  }

  if (descEl) {
    if (existingRes.toLowerCase() === reqRes.toLowerCase()) {
      descEl.innerHTML = `This video already exists in your library in <strong>${existingRes}</strong> (${existingSize}). Do you still want to re-download it, play the existing version, or cancel?`;
      if (redownloadLabel) redownloadLabel.textContent = `Re-download in ${reqRes}`;
    } else {
      descEl.innerHTML = `This video is already in your library in <strong>${existingRes}</strong> (${existingSize}). Are you sure you want to download it in <strong>${reqRes}</strong>?`;
      if (redownloadLabel) redownloadLabel.textContent = `Download in ${reqRes}`;
    }
  }

  if (playBtnLabel) {
    playBtnLabel.textContent = `Keep & Play (${existingRes})`;
  }

  const thumbSrc = mediaItem.thumbnail || (currentVideoInfo && currentVideoInfo.thumbnail) || '';
  if (thumbSrc && thumbImg) {
    thumbImg.src = thumbSrc;
    thumbImg.style.display = 'block';
    if (fallbackThumb) fallbackThumb.style.display = 'none';
  } else if (thumbImg) {
    thumbImg.style.display = 'none';
    if (fallbackThumb) fallbackThumb.style.display = 'flex';
  }

  modal.style.display = 'flex';

  const hide = () => { modal.style.display = 'none'; };
  if (closeBtn) closeBtn.onclick = hide;
  if (cancelBtn) cancelBtn.onclick = hide;

  if (playBtn) {
    playBtn.onclick = () => {
      hide();
      playLibraryTrackWithQueue(mediaItem);
    };
  }

  if (redownloadBtn) {
    redownloadBtn.onclick = () => {
      hide();
      triggerDownload({ ...payload, forceRedownload: true }, clickedBtn);
    };
  }

  if (typeof showNovaToast === 'function') {
    showNovaToast(`"${mediaItem.name}" is already in your library (${existingRes})`, 'fa-circle-info');
  }
}
window.showAlreadyDownloadedModal = showAlreadyDownloadedModal;

// 3.5. Download Capsule Flight Animation into Downloads Navigation
function animateDownloadCapsuleFlight(sourceBtn, meta) {
  try {
    const targetNav = document.querySelector('.nova-nav-btn[data-view="downloads"]');
    if (!targetNav) return;

    // Source rect
    const srcRect = (sourceBtn && sourceBtn.getBoundingClientRect) ? sourceBtn.getBoundingClientRect() : {
      left: window.innerWidth / 2,
      top: window.innerHeight / 2,
      width: 180,
      height: 48
    };

    // Target rect (Downloads button in sidebar)
    const targetRect = targetNav.getBoundingClientRect();
    const targetX = targetRect.left + targetRect.width / 2;
    const targetY = targetRect.top + targetRect.height / 2;

    const titleText = meta?.titleHint || (currentVideoInfo && currentVideoInfo.title) || 'Downloading Video';
    const thumbUrl = (currentVideoInfo && currentVideoInfo.thumbnail) || '';
    const modeBadge = (meta?.mode || 'MAX').toUpperCase();

    // Create flying capsule
    const capsule = document.createElement('div');
    capsule.className = 'download-flight-capsule';
    capsule.innerHTML = `
      <div class="flight-capsule-inner">
        ${thumbUrl ? `<img class="flight-thumb" src="${thumbUrl}" alt="" />` : `<div class="flight-icon"><i class="fa-solid fa-bolt"></i></div>`}
        <div class="flight-details">
          <span class="flight-badge">${modeBadge}</span>
          <span class="flight-title">${escapeHtml(titleText)}</span>
        </div>
        <div class="flight-rocket"><i class="fa-solid fa-arrow-down-long fa-bounce"></i></div>
      </div>
    `;

    document.body.appendChild(capsule);

    // Initial positioning at the clicked button
    const startX = srcRect.left + srcRect.width / 2;
    const startY = srcRect.top + srcRect.height / 2;
    capsule.style.transform = `translate3d(${startX}px, ${startY}px, 0) translate(-50%, -50%) scale(0.6)`;
    capsule.style.opacity = '0';

    // Force reflow
    void capsule.offsetWidth;

    // Pop into view
    capsule.style.transition = 'all 0.28s cubic-bezier(0.175, 0.885, 0.32, 1.275)';
    capsule.style.opacity = '1';
    capsule.style.transform = `translate3d(${startX}px, ${startY}px, 0) translate(-50%, -50%) scale(1.05)`;

    // Fly & curve towards the Downloads sidebar button
    setTimeout(() => {
      capsule.style.transition = 'all 0.85s cubic-bezier(0.2, 0.8, 0.2, 1)';
      capsule.classList.add('morph-to-capsule');
      capsule.style.transform = `translate3d(${targetX}px, ${targetY}px, 0) translate(-50%, -50%) scale(0.22)`;
      capsule.style.opacity = '0.95';

      // Absorption upon arrival
      setTimeout(() => {
        capsule.style.transition = 'all 0.2s ease-in';
        capsule.style.transform = `translate3d(${targetX}px, ${targetY}px, 0) translate(-50%, -50%) scale(0)`;
        capsule.style.opacity = '0';

        // Trigger impact ripple effect on Downloads nav button
        targetNav.classList.remove('nav-download-absorb');
        void targetNav.offsetWidth;
        targetNav.classList.add('nav-download-absorb');

        // Increment & pulse badge
        const badge = document.getElementById('navDownloadsCount');
        if (badge) {
          const curVal = parseInt(badge.textContent, 10) || 0;
          badge.textContent = curVal + 1;
          badge.classList.remove('badge-pulse-glow');
          void badge.offsetWidth;
          badge.classList.add('badge-pulse-glow');
        }

        setTimeout(() => capsule.remove(), 250);

        if (typeof showNovaToast === 'function') {
          showNovaToast(`Enqueued in Downloads: "${titleText.slice(0, 34)}..."`, 'fa-cloud-arrow-down');
        }
      }, 820);
    }, 280);
  } catch (err) {
    console.warn('Capsule flight animation exception:', err);
  }
}


// ==========================================
// Storage Warning Popup Handler
// ==========================================
function showStorageWarningModal({ requiredFormatted, availableFormatted, onProceed }) {
  const modal = document.getElementById('storageWarningModal');
  const reqEl = document.getElementById('storageWarningRequired');
  const availEl = document.getElementById('storageWarningAvailable');
  const btnCancel = document.getElementById('btnCancelStorageWarning');
  const btnProceed = document.getElementById('btnProceedStorageWarning');
  const btnClose = document.getElementById('closeStorageWarningModal');

  if (!modal) {
    if (confirm(`Storage Warning: Download requires ~${requiredFormatted}, but only ${availableFormatted} is available. Proceed anyway?`)) {
      if (typeof onProceed === 'function') onProceed();
    }
    return;
  }

  if (reqEl) reqEl.textContent = requiredFormatted || '--';
  if (availEl) availEl.textContent = availableFormatted || '--';

  modal.style.display = 'flex';

  const cleanup = () => {
    modal.style.display = 'none';
    if (btnProceed) btnProceed.onclick = null;
    if (btnCancel) btnCancel.onclick = null;
    if (btnClose) btnClose.onclick = null;
  };

  if (btnProceed) {
    btnProceed.onclick = () => {
      cleanup();
      if (typeof onProceed === 'function') onProceed();
    };
  }

  if (btnCancel) btnCancel.onclick = cleanup;
  if (btnClose) btnClose.onclick = cleanup;
}

// 4. Download Trigger with instant button feedback & popup confirmation
async function triggerDownload(payload, clickedBtn = null) {
  // If user requested Secret Vault / Secure Folder and password not yet confirmed, prompt for encryption password
  if (payload.isSecret && !payload.isSecretConfirmed && typeof window.SecureVault !== 'undefined' && typeof window.SecureVault.promptSecretDownload === 'function') {
    window.SecureVault.promptSecretDownload({ ...payload, forceSecret: true }, (confirmedPayload) => {
      triggerDownload(confirmedPayload, clickedBtn);
    });
    return;
  }

  let origBtnContent = '';
  if (clickedBtn) {
    origBtnContent = clickedBtn.innerHTML;
    clickedBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Starting...';
    clickedBtn.disabled = true;
  }

  // Storage Space Safety Check (Android Kotlin Bridge & PC Node.js)
  if (!payload.bypassStorageCheck) {
    try {
      let clientFree = null;
      if (window.AlphaDeviceBridge && typeof window.AlphaDeviceBridge.getAvailableStorageBytes === 'function') {
        clientFree = window.AlphaDeviceBridge.getAvailableStorageBytes();
      }
      const estimatedBytes = payload.filesize || (payload.format && payload.format.filesize) || 120 * 1024 * 1024;
      const chkRes = await fetch('/api/storage/check-space', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ requiredBytes: estimatedBytes, clientFreeBytes: clientFree })
      });
      const chkData = await chkRes.json();
      if (chkData.ok && chkData.isLow) {
        if (clickedBtn && origBtnContent) {
          clickedBtn.innerHTML = origBtnContent;
          clickedBtn.disabled = false;
        }
        showStorageWarningModal({
          requiredFormatted: chkData.requiredFormatted,
          availableFormatted: chkData.freeFormatted,
          onProceed: () => {
            triggerDownload({ ...payload, bypassStorageCheck: true }, clickedBtn);
          }
        });
        return;
      }
    } catch (e) {
      console.warn('Storage check pre-flight skipped:', e);
    }
  }

  try {
    const powerOpts = (typeof window.NovaCoreSuite !== 'undefined' && typeof window.NovaCoreSuite.getPowerOptions === 'function') 
      ? window.NovaCoreSuite.getPowerOptions() 
      : {};
    const finalPayload = { ...powerOpts, ...payload };

    let data;
    // Always use backend /api/download unless running in standalone native APK (non-network server origin)
    if (window.NovaPulseAndroid && typeof window.NovaPulseAndroid.startNativeDownload === 'function' && !window.location.origin.includes(':4980') && !window.__EXPO_GO_PREVIEW__) {
      const nativeRes = window.NovaPulseAndroid.startNativeDownload(
        finalPayload.url,
        finalPayload.title || finalPayload.name || 'NovaPulse_Media',
        finalPayload.format || 'mp4',
        finalPayload.quality || '1080p'
      );
      try {
        data = JSON.parse(nativeRes);
      } catch (e) {
        data = { ok: false, error: nativeRes };
      }
    } else {
      const res = await fetch('/api/download', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(finalPayload)
      });
      data = await res.json();
    }
    if (!data.ok) {
      if (typeof showNovaToast === 'function') {
        showNovaToast('Failed to start download: ' + (data.error || 'Unknown error'), 'fa-circle-exclamation');
      }
      return;
    }

    if (data.alreadyDownloaded && data.mediaItem) {
      if (clickedBtn && clickedBtn.innerHTML.includes('Starting...')) {
        clickedBtn.innerHTML = origBtnContent;
        clickedBtn.disabled = false;
      }
      showAlreadyDownloadedModal(data.mediaItem, payload, clickedBtn, data);
      return;
    }

    if (data.alreadyActive) {
      if (typeof showNovaToast === 'function') {
        showNovaToast('This video is already in your download queue! Opening Downloads.', 'fa-circle-info');
      }
      if (typeof Nova !== 'undefined' && typeof Nova.switchView === 'function') {
        Nova.switchView('downloads');
      } else if (typeof switchView === 'function') {
        switchView('downloads');
      }
      return;
    }

    // Trigger visual capsule flight animation straight into Downloads tab
    animateDownloadCapsuleFlight(clickedBtn || document.getElementById('btnDownloadMax') || document.getElementById('prevThumb'), payload);

    // Immediately register active task in local queue map for instant UI feedback
    const taskId = data.downloadId || ('task_' + Date.now());
    const activeTitle = payload.title || payload.titleHint || (currentVideoInfo && currentVideoInfo.title) || 'Media Download';
    const activeThumb = (currentVideoInfo && currentVideoInfo.thumbnail) || '';
    const activeTaskObj = {
      id: taskId,
      title: activeTitle,
      url: payload.url,
      mode: payload.mode || 'video',
      status: 'downloading',
      progress: 0,
      percent: '0%',
      speed: 'Connecting...',
      eta: '--:--',
      thumbnail: activeThumb,
      outputDir: data.outputDir || 'Downloads/NovaPulse'
    };
    activeTasksMap.set(taskId, activeTaskObj);
    renderAllTasks();

    // Success popup modal
    showDownloadStartedPopup({
      title: activeTitle,
      thumbnail: activeThumb,
      mode: payload.mode,
      quality: payload.quality,
      outputDir: data.outputDir || 'Downloads/NovaPulse'
    });

    if (clickedBtn) {
      clickedBtn.innerHTML = '<i class="fa-solid fa-check"></i> Started!';
      setTimeout(() => {
        clickedBtn.innerHTML = origBtnContent;
        clickedBtn.disabled = false;
      }, 2000);
    }
  } catch (err) {
    if (typeof showNovaToast === 'function') {
      showNovaToast('Request error: ' + err.message, 'fa-circle-exclamation');
    }
  } finally {
    if (clickedBtn && clickedBtn.innerHTML.includes('Starting...')) {
      clickedBtn.innerHTML = origBtnContent;
      clickedBtn.disabled = false;
    }
  }
}

// Batch Queue Download
async function startBatchDownload() {
  const text = batchTextarea.value.trim();
  if (!text) {
    if (typeof showNovaToast === 'function') {
      showNovaToast('Enter at least one URL in the batch box.', 'fa-circle-exclamation');
    }
    return;
  }

  const urls = text.split('\n').map(u => u.trim()).filter(u => u.length > 0);
  const mode = batchModeSelect.value;

  let actualMode = 'max';
  let quality = null;
  if (mode.startsWith('custom-quality-')) {
    actualMode = 'custom-quality';
    quality = mode.replace('custom-quality-', '');
  } else if (mode === 'audio') {
    actualMode = 'audio';
  }

  for (const url of urls) {
    triggerDownload({
      url,
      mode: actualMode,
      quality,
      titleHint: url
    });
  }

  batchTextarea.value = '';
}

// Task UI Management
function createOrUpdateTaskUI(task) {
  activeTasksMap.set(task.id, task);
  renderAllTasks();
}

function updateTaskProgress(data) {
  const task = activeTasksMap.get(data.taskId);
  if (!task) return;
  if (task.status === 'paused' || task.status === 'cancelled' || task.isPaused) return;

  task.percent = data.percent;
  task.speed = data.speed;
  task.eta = data.eta;
  task.total = data.total;
  task.status = 'downloading';

  // Surgical DOM update without re-rendering entire list
  const card = document.getElementById(`task_${data.taskId}`);
  if (card) {
    const bar = card.querySelector('.task-progress-bar');
    const percentEl = card.querySelector('.task-percent');
    const speedEl = card.querySelector('.task-speed');
    const etaEl = card.querySelector('.task-eta');

    if (bar) bar.style.width = data.percent;
    if (percentEl) percentEl.textContent = data.percent;
    if (speedEl) speedEl.textContent = data.speed;
    if (etaEl) etaEl.textContent = `ETA: ${data.eta}`;
  }
}

function renderTask(task) {
  const card = document.getElementById(`task_${task.id}`);
  if (!card) {
    renderAllTasks();
    return;
  }

  // If status is completed or cancelled, always re-render to swap out pause/cancel buttons for Play/Folder actions
  if (task.status === 'completed' || task.status === 'cancelled') {
    renderAllTasks();
    return;
  }

  // If status changed to paused or downloading, swap buttons if needed
  const hasPauseBtn = !!card.querySelector('.btn-pause-download');
  const hasResumeBtn = !!card.querySelector('.btn-resume-download');
  if ((task.status === 'paused' && !hasResumeBtn) || ((task.status === 'downloading' || task.status === 'starting') && !hasPauseBtn)) {
    renderAllTasks();
    return;
  }

  // Update status badge
  const badge = card.querySelector('.task-status-pill');
  if (badge) {
    badge.className = `task-status-pill ${task.status}`;
    badge.textContent = task.status;
  }
  const speedEl = card.querySelector('.task-speed');
  if (speedEl) {
    speedEl.textContent = task.status === 'scheduled' ? 'Scheduled for off-peak (1 AM - 7 AM)' : (task.status === 'paused' ? 'Paused' : (task.speed || 'Initializing...'));
  }
  const etaEl = card.querySelector('.task-eta');
  if (etaEl) {
    etaEl.textContent = task.status === 'paused' ? 'ETA: --:--' : `ETA: ${task.eta || '--:--'}`;
  }
  const bar = card.querySelector('.task-progress-bar');
  if (bar && task.status === 'completed') {
    bar.style.width = '100%';
  }
}

function renderAllTasks() {
  const scheduledTasks = Array.from(activeTasksMap.values()).filter(t => t.status === 'scheduled');
  const runningTasks = Array.from(activeTasksMap.values()).filter(t => t.status === 'downloading' || t.status === 'starting' || t.status === 'processing');
  const activeCount = runningTasks.length + scheduledTasks.length;

  const navDownloadsCount = document.getElementById('navDownloadsCount');
  if (navDownloadsCount) {
    navDownloadsCount.textContent = activeCount;
    navDownloadsCount.style.display = activeCount > 0 ? 'inline-block' : 'none';
  }

  const qaActiveQueueCount = document.getElementById('qaActiveQueueCount');
  if (qaActiveQueueCount) {
    if (activeCount === 0) {
      qaActiveQueueCount.textContent = '0 active downloads';
    } else if (scheduledTasks.length > 0 && runningTasks.length > 0) {
      qaActiveQueueCount.textContent = `${runningTasks.length} active, ${scheduledTasks.length} scheduled`;
    } else if (scheduledTasks.length > 0) {
      qaActiveQueueCount.textContent = `${scheduledTasks.length} queued (Night Shift)`;
    } else {
      qaActiveQueueCount.textContent = `${runningTasks.length} active download${runningTasks.length === 1 ? '' : 's'}`;
    }
  }

  const btnStartAllScheduled = document.getElementById('btnStartAllScheduled');
  if (btnStartAllScheduled) {
    btnStartAllScheduled.style.display = scheduledTasks.length > 0 ? 'inline-flex' : 'none';
  }

  if (activeTasksMap.size === 0) {
    emptyTasks.style.display = 'block';
    tasksContainer.innerHTML = '';
    tasksContainer.appendChild(emptyTasks);
    return;
  }

  emptyTasks.style.display = 'none';
  tasksContainer.innerHTML = '';

  activeTasksMap.forEach(task => {
    const item = document.createElement('div');
    item.className = 'task-item';
    item.id = `task_${task.id}`;

    const isRunning = task.status === 'starting' || task.status === 'downloading' || task.status === 'processing';
    const isPaused = task.status === 'paused';
    const isScheduled = task.status === 'scheduled';
    const isCompleted = task.status === 'completed';

    // When completed, strictly omit Pause, Resume, and Cancel buttons
    const cancelHtml = (!isCompleted && (isRunning || isPaused || isScheduled)) ? `
      <button class="btn-subtle btn-cancel-download" data-task-id="${task.id}" style="color:var(--accent-red);" title="Cancel download">
        <i class="fa-solid fa-xmark"></i> Cancel
      </button>
    ` : '';

    const pauseResumeHtml = (!isCompleted) ? (isRunning ? `
      <button class="btn-subtle btn-pause-download" data-task-id="${task.id}" style="color:#f59e0b;" title="Pause download">
        <i class="fa-solid fa-pause"></i> Pause
      </button>
    ` : ((isPaused || task.status === 'failed') ? `
      <button class="btn-subtle btn-resume-download" data-task-id="${task.id}" style="color:#10b981;" title="Resume download">
        <i class="fa-solid fa-play"></i> Resume
      </button>
    ` : '')) : '';

    const scheduledHtml = isScheduled ? `
      <button class="btn-subtle btn-run-scheduled" data-task-id="${task.id}" style="color:var(--accent-cyan); font-weight:700;" title="Run download immediately, bypassing night shift schedule">
        <i class="fa-solid fa-play"></i> Start Now
      </button>
    ` : '';

    // Direct Play button for completed downloads
    const playCompletedHtml = isCompleted ? `
      <button class="btn-primary btn-play-completed-task" data-task-id="${task.id}" style="font-weight:700; padding:6px 14px; gap:6px; display:inline-flex; align-items:center;" title="Play directly in Player Studio">
        <i class="fa-solid fa-play"></i> Play
      </button>
    ` : '';

    const folderTarget = (task.outputDir || '').replace(/\\/g, '\\\\');
    const folderDisplay = (task.outputDir || '').split('\\').slice(-2).join('\\') || 'Downloads';

    const thumbUrl = task.thumbnail || '';
    const safeTitle = escapeHtml(task.title || 'Downloading media...');
    const statusLabel = task.status === 'scheduled' ? '🌙 Night Shift Scheduled' : task.status;

    item.innerHTML = `
      <div class="task-card-top-row">
        <div class="task-thumb-wrap">
          ${thumbUrl ? `
            <img class="task-thumb-img" src="${escapeHtml(thumbUrl)}" alt="" onerror="this.style.display='none'; if(this.nextElementSibling) this.nextElementSibling.style.display='flex';" />
          ` : ''}
          <div class="task-thumb-fallback" style="${thumbUrl ? 'display:none;' : 'display:flex;'}">
            <i class="${task.mode === 'audio' ? 'fa-solid fa-music' : 'fa-solid fa-film'}"></i>
          </div>
        </div>
        <div class="task-title-col">
          <div class="task-title" title="${safeTitle}">${safeTitle}</div>
          <div class="task-badge-row">
            <span class="task-status-pill ${task.status}">${statusLabel}</span>
          </div>
        </div>
      </div>
      <div class="task-progress-wrap">
        <div class="task-progress-bar" style="width: ${task.percent || (isCompleted ? '100%' : '0%')}"></div>
      </div>
      <div class="task-meta">
        <span class="task-percent">${isCompleted ? '100%' : (task.percent || '0%')}</span>
        <span class="task-speed">${task.status === 'scheduled' ? 'Scheduled for off-peak (1 AM - 7 AM)' : (task.status === 'paused' ? 'Paused' : (isCompleted ? 'Finished' : (task.speed || 'Initializing...')))}</span>
        <span class="task-eta">${task.status === 'paused' ? 'ETA: --:--' : (isCompleted ? 'Completed' : `ETA: ${task.eta || '--:--'}`)}</span>
      </div>
      <div class="task-actions">
        ${playCompletedHtml}
        ${scheduledHtml}
        ${pauseResumeHtml}
        <button class="btn-subtle" onclick="openFolder('${folderTarget}')">
          <i class="fa-solid fa-folder"></i> Folder: ${folderDisplay}
        </button>
        ${cancelHtml}
      </div>
    `;

    // Hook Play Completed button
    const playBtn = item.querySelector('.btn-play-completed-task');
    if (playBtn) {
      playBtn.addEventListener('click', () => {
        // Find matching media in Library
        let mediaItem = null;
        if (typeof Library !== 'undefined' && typeof Library.getMediaList === 'function') {
          const list = Library.getMediaList();
          if (task.savedFile) {
            mediaItem = list.find(m => m.fullPath === task.savedFile || (m.path && task.savedFile.endsWith(m.path)) || m.name === task.title);
          }
          if (!mediaItem) {
            mediaItem = list.find(m => m.name === task.title || (task.url && m.sourceUrl === task.url));
          }
        }
        if (!mediaItem) {
          // Construct fallback item
          const fileName = task.savedFile ? task.savedFile.split(/[\/\\]/).pop() : (task.title + '.mp4');
          mediaItem = {
            id: 'task_' + task.id,
            name: task.title,
            title: task.title,
            type: task.mode === 'audio' ? 'audio' : 'video',
            url: task.savedFile ? `/api/stream?file=${encodeURIComponent(task.savedFile)}` : (task.url || ''),
            fullPath: task.savedFile || '',
            thumbnail: task.thumbnail || ''
          };
        }
        if (typeof playLibraryTrackWithQueue === 'function') {
          playLibraryTrackWithQueue(mediaItem);
        } else if (typeof Playlist !== 'undefined' && typeof Playlist.playNow === 'function') {
          Playlist.playNow(mediaItem);
          if (typeof switchView === 'function') switchView('player');
        }
      });
    }

    const cancelBtn = item.querySelector('.btn-cancel-download');
    if (cancelBtn) {
      cancelBtn.addEventListener('click', async () => {
        cancelBtn.disabled = true;
        cancelBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Cancelling...';
        task.status = 'cancelled';
        renderAllTasks();
        if (typeof showNovaToast === 'function') {
          showNovaToast('Download cancelled', 'fa-xmark');
        }
        try {
          await fetch(`/api/downloads/${task.id}/cancel`, { method: 'POST' });
          renderAllTasks();
        } catch (e) {
          console.error('Cancel request error:', e);
        }
      });
    }

    const pauseBtn = item.querySelector('.btn-pause-download');
    if (pauseBtn) {
      pauseBtn.addEventListener('click', async () => {
        pauseBtn.disabled = true;
        pauseBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Pausing...';
        task.status = 'paused';
        task.speed = 'Paused';
        task.eta = '--:--';
        task.isPaused = true;
        renderAllTasks();
        if (typeof showNovaToast === 'function') {
          showNovaToast('Download paused', 'fa-pause');
        }
        try {
          await fetch(`/api/downloads/${task.id}/pause`, { method: 'POST' });
          renderAllTasks();
        } catch (e) {
          console.error('Pause request error:', e);
        }
      });
    }

    const resumeBtn = item.querySelector('.btn-resume-download');
    if (resumeBtn) {
      resumeBtn.addEventListener('click', async () => {
        resumeBtn.disabled = true;
        resumeBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Resuming...';
        task.status = 'starting';
        task.speed = 'Resuming...';
        task.eta = '--:--';
        task.isPaused = false;
        renderAllTasks();
        if (typeof showNovaToast === 'function') {
          showNovaToast('Resuming download...', 'fa-play');
        }
        try {
          const res = await fetch(`/api/downloads/${task.id}/resume`, { method: 'POST' });
          const data = await res.json();
          if (!res.ok || !data.ok) {
            if (typeof showNovaToast === 'function') {
              showNovaToast('Failed to resume: ' + (data.error || 'Server error'), 'fa-circle-exclamation');
            } else {
              alert('Failed to resume download: ' + (data.error || 'Server error'));
            }
            task.status = 'paused';
            task.speed = 'Paused';
            task.eta = '--:--';
            task.isPaused = true;
          }
          renderAllTasks();
        } catch (e) {
          console.error('Resume request error:', e);
          if (typeof showNovaToast === 'function') {
            showNovaToast('Failed to resume download (network error)', 'fa-circle-exclamation');
          }
          task.status = 'paused';
          task.speed = 'Paused';
          task.eta = '--:--';
          task.isPaused = true;
          renderAllTasks();
        }
      });
    }

    const runScheduledBtn = item.querySelector('.btn-run-scheduled');
    if (runScheduledBtn) {
      runScheduledBtn.addEventListener('click', async () => {
        runScheduledBtn.disabled = true;
        runScheduledBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Starting...';
        try {
          await fetch('/api/download/run-scheduled', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ taskId: task.id })
          });
          if (typeof showNovaToast === 'function') {
            showNovaToast('Forced immediate download', 'fa-play');
          }
          if (typeof fetchDownloads === 'function') fetchDownloads();
        } catch (e) {
          console.error('Run scheduled error:', e);
        }
      });
    }

    tasksContainer.prepend(item);
  });
}


function openFolder(folderPath) {
  fetch('/api/open-folder', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ folderPath })
  });
}

// Helpers
function formatDuration(seconds, forceHours = false) {
  if (isNaN(seconds) || seconds === null || seconds < 0) return forceHours ? '0:00:00' : '00:00';
  const total = Math.floor(seconds);
  const hrs = Math.floor(total / 3600);
  const mins = Math.floor((total % 3600) / 60);
  const secs = total % 60;
  const pad = n => (n < 10 ? '0' + n : n);

  if (hrs > 0 || forceHours) {
    return `${hrs}:${pad(mins)}:${pad(secs)}`;
  }
  return `${pad(mins)}:${pad(secs)}`;
}

function formatBytes(bytes) {
  if (!bytes) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

// Global HTML escaper — used by the subtitle menu and playlist rendering.
// (library.js keeps its own private copy inside its module scope.)
function escapeHtml(str) {
  return String(str === null || str === undefined ? '' : str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// =========================================================
// Phase 1 + Phase 2: Media Studio (Player, Playlist, Library Controller)
// =========================================================

function initMediaStudio() {
  const videoViewport = document.getElementById('videoViewport');
  const mainVideo = document.getElementById('mainVideoPlayer');
  const videoPlaceholder = document.getElementById('videoPlaceholder');
  const audioVisualBadge = document.getElementById('audioVisualBadge');
  const nowPlayingTitle = document.getElementById('nowPlayingTitle');
  const nowPlayingExt = document.getElementById('nowPlayingExt');
  const trackTypeBadge = document.getElementById('trackTypeBadge');

  const btnPlayPause = document.getElementById('btnPlayPause');
  const playIcon = document.getElementById('playIcon');
  const btnPrev = document.getElementById('btnPrev');
  const btnNext = document.getElementById('btnNext');
  const btnShuffle = document.getElementById('btnShuffle');
  const btnRepeat = document.getElementById('btnRepeat');
  const repeatBadge = document.getElementById('repeatBadge');

  const timeCurrent = document.getElementById('timeCurrent');
  const timeDuration = document.getElementById('timeDuration');
  const seekSlider = document.getElementById('seekSlider');
  const seekProgress = document.getElementById('seekProgress');

  const playbackSpeedSelect = document.getElementById('playbackSpeedSelect');
  const btnCaptions = document.getElementById('btnCaptions');
  const subtitleMenu = document.getElementById('subtitleMenu');
  const subtitleMenuList = document.getElementById('subtitleMenuList');
  const volumeSlider = document.getElementById('volumeSlider');
  const btnMute = document.getElementById('btnMute');
  const volumeIcon = document.getElementById('volumeIcon');
  const btnFullscreen = document.getElementById('btnFullscreen');

  const playerErrorBanner = document.getElementById('playerErrorBanner');
  const playerErrorMessage = document.getElementById('playerErrorMessage');
  const dismissPlayerError = document.getElementById('dismissPlayerError');
  const errorRetryBtn = document.getElementById('errorRetryBtn');
  const errorRemoveBtn = document.getElementById('errorRemoveBtn');

  // A-B Repeat controls
  const btnSetA = document.getElementById('btnSetA');
  const btnSetB = document.getElementById('btnSetB');
  const btnClearAB = document.getElementById('btnClearAB');
  const abStatus = document.getElementById('abStatus');
  const abMarkerA = document.getElementById('abMarkerA');
  const abMarkerB = document.getElementById('abMarkerB');

  // Side panels & tabs
  const tabPlaylistBtn = document.getElementById('tabPlaylistBtn');
  const tabLibraryBtn = document.getElementById('tabLibraryBtn');
  const panelPlaylist = document.getElementById('panelPlaylist');
  const panelLibrary = document.getElementById('panelLibrary');
  const playlistContainer = document.getElementById('playlistContainer');
  const libraryContainer = document.getElementById('libraryContainer');
  const playlistCount = document.getElementById('playlistCount');
  const libCount = document.getElementById('libCount');
  const clearPlaylistBtn = document.getElementById('clearPlaylistBtn');
  const refreshLibBtn = document.getElementById('refreshLibBtn');
  const libSearchInput = document.getElementById('libSearchInput');
  const libSortSelect = document.getElementById('libSortSelect');
  const playerToggleBtn = document.getElementById('playerToggleBtn');
  const mediaStudioSection = document.getElementById('mediaStudioSection');

  // ── Jump button ──────────────────────────────────────────────────
  if (playerToggleBtn && mediaStudioSection) {
    playerToggleBtn.addEventListener('click', () => {
      mediaStudioSection.scrollIntoView({ behavior: 'smooth' });
    });
  }

  // ── Error Banner ─────────────────────────────────────────────────
  if (dismissPlayerError) {
    dismissPlayerError.addEventListener('click', () => {
      if (playerErrorBanner) playerErrorBanner.style.display = 'none';
    });
  }

  if (errorRetryBtn) {
    errorRetryBtn.addEventListener('click', () => {
      if (playerErrorBanner) playerErrorBanner.style.display = 'none';
      const cur = Playlist.getCurrentItem();
      if (cur) {
        Playlist.playNow(cur);
      }
    });
  }

  if (errorRemoveBtn) {
    errorRemoveBtn.addEventListener('click', () => {
      if (playerErrorBanner) playerErrorBanner.style.display = 'none';
      const idx = Playlist.getCurrentIndex();
      if (idx >= 0) Playlist.removeItem(idx);
    });
  }

  // ── Tab switching ────────────────────────────────────────────────
  if (tabPlaylistBtn) {
    tabPlaylistBtn.addEventListener('click', () => {
      tabPlaylistBtn.classList.add('active');
      if (tabLibraryBtn) tabLibraryBtn.classList.remove('active');
      if (panelPlaylist) panelPlaylist.classList.add('active');
      if (panelLibrary) panelLibrary.classList.remove('active');
    });
  }

  if (tabLibraryBtn) {
    tabLibraryBtn.addEventListener('click', () => {
      tabLibraryBtn.classList.add('active');
      if (tabPlaylistBtn) tabPlaylistBtn.classList.remove('active');
      if (panelLibrary) panelLibrary.classList.add('active');
      if (panelPlaylist) panelPlaylist.classList.remove('active');
    });
  }


  // ── Library filter chips (Phase 1 + Phase 2 tabs) ────────────────
  document.querySelectorAll('.chip-filter').forEach(chip => {
    chip.addEventListener('click', () => {
      document.querySelectorAll('.chip-filter').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      Library.setActiveTab(chip.dataset.type);
      Library.renderList(libraryContainer);
    });
  });

  // ── Library search ───────────────────────────────────────────────
  if (libSearchInput) {
    libSearchInput.addEventListener('input', () => {
      Library.setFilter(libSearchInput.value);
      Library.renderList(libraryContainer);
    });
  }

  // ── Library sort (Phase 2) ───────────────────────────────────────
  if (libSortSelect) {
    libSortSelect.addEventListener('change', () => {
      Library.setSortMode(libSortSelect.value);
      Library.renderList(libraryContainer);
    });
  }

  if (refreshLibBtn) {
    refreshLibBtn.addEventListener('click', async () => {
      refreshLibBtn.disabled = true;
      const origHtml = refreshLibBtn.innerHTML;
      refreshLibBtn.innerHTML = '<i class="fa-solid fa-arrows-rotate fa-spin"></i> Scanning...';
      try {
        await loadAndRenderLibrary();
        if (typeof showNovaToast === 'function') {
          showNovaToast('Library refreshed successfully', 'fa-check');
        }
      } catch (e) {
        console.error('Error rescanning library:', e);
      } finally {
        refreshLibBtn.disabled = false;
        refreshLibBtn.innerHTML = origHtml;
      }
    });
  }

  // ── Neural Spoken Search button ────────────────────────────────────
  const btnToggleNeuralSearch = document.getElementById('btnToggleNeuralSearch');
  if (btnToggleNeuralSearch) {
    btnToggleNeuralSearch.addEventListener('click', async () => {
      const q = (libSearchInput ? libSearchInput.value : '').trim();
      if (!q) {
        if (typeof showNovaToast === 'function') {
          showNovaToast('Type search keyword in filter input first to search spoken transcripts!', 'fa-brain');
        } else {
          alert('Type search keyword in filter input first to search spoken audio transcripts!');
        }
        if (libSearchInput) libSearchInput.focus();
        return;
      }
      btnToggleNeuralSearch.innerHTML = '<i class="fa-solid fa-brain fa-spin"></i> Searching Audio...';
      try {
        const res = await fetch(`/api/transcripts/search?q=${encodeURIComponent(q)}`);
        const data = await res.json();
        if (data.ok && Array.isArray(data.results)) {
          const matchedIds = new Set(data.results.map(r => r.mediaId || r.id));
          const allMedia = Library.getMediaList();
          const filtered = allMedia.filter(m => matchedIds.has(m.id) || m.name.toLowerCase().includes(q.toLowerCase()));
          Library.renderList(libraryContainer, filtered);
          if (typeof showNovaToast === 'function') {
            showNovaToast(`Found ${data.results.length} spoken audio/transcript matches!`, 'fa-brain');
          }
        }
      } catch (err) {
        console.warn('Neural search error:', err);
      } finally {
        btnToggleNeuralSearch.innerHTML = '<i class="fa-solid fa-brain"></i> Neural Spoken Search';
      }
    });
  }

  if (clearPlaylistBtn) {
    clearPlaylistBtn.addEventListener('click', () => {
      Playlist.clear();
      Player.pause();
      resetPlayerUI();
    });
  }

  const btnSmartArrangeQueue = document.getElementById('btnSmartArrangeQueue');
  if (btnSmartArrangeQueue) {
    btnSmartArrangeQueue.addEventListener('click', () => {
      const qItems = [...Playlist.getItems()];
      if (!qItems || qItems.length <= 1) return;
      const curItem = Playlist.getCurrentItem();
      qItems.sort((a, b) => {
        const nameA = (a.name || a.filename || '').trim();
        const nameB = (b.name || b.filename || '').trim();
        return nameA.localeCompare(nameB, undefined, { numeric: true, sensitivity: 'base' });
      });
      const newCurIdx = curItem ? qItems.findIndex(it => it.id === curItem.id) : 0;
      Playlist.setQueue(qItems, newCurIdx >= 0 ? newCurIdx : 0);
      renderPlaylistView();
      if (typeof showNovaToast === 'function') {
        showNovaToast('Queue sorted smartly (Chapters & Episodes aligned)', 'fa-arrow-down-1-9');
      }
    });
  }

  // ── Player Studio Empty State Navigation Buttons ────────────────
  const btnPlayerGoToLibrary = document.getElementById('btnPlayerGoToLibrary');
  if (btnPlayerGoToLibrary) {
    btnPlayerGoToLibrary.addEventListener('click', () => {
      if (typeof Nova !== 'undefined' && typeof Nova.switchView === 'function') {
        Nova.switchView('library');
      } else if (typeof switchView === 'function') {
        switchView('library');
      }
    });
  }

  const btnPlayerGoToHome = document.getElementById('btnPlayerGoToHome');
  if (btnPlayerGoToHome) {
    btnPlayerGoToHome.addEventListener('click', () => {
      if (typeof Nova !== 'undefined' && typeof Nova.switchView === 'function') {
        Nova.switchView('home');
      } else if (typeof switchView === 'function') {
        switchView('home');
      }
    });
  }

  // ── Initialize Core Modules ──────────────────────────────────────
  Player.init(videoViewport, mainVideo);
  Playlist.init();

  // Restore UI state
  updateShuffleUI();
  updateRepeatUI();

  const savedSpeed = localStorage.getItem('ultimatePlayer.speed') || '1';
  playbackSpeedSelect.value = savedSpeed;

  const currentVol = Player.getVolume();
  volumeSlider.value = currentVol;
  updateVolumeIcon(currentVol);

  // ── A-B Repeat Wiring (Phase 2) ──────────────────────────────────
  if (btnSetA) {
    btnSetA.addEventListener('click', () => {
      Player.setAbPointA();
    });
  }
  if (btnSetB) {
    btnSetB.addEventListener('click', () => {
      Player.setAbPointB();
    });
  }
  if (btnClearAB) {
    btnClearAB.addEventListener('click', () => {
      Player.clearAbRepeat();
    });
  }

  Player.onABChange((a, b, active) => {
    // Update status text
    if (active && a !== null && b !== null) {
      abStatus.textContent = `A-B: ${formatDuration(a)} → ${formatDuration(b)}`;
      abStatus.classList.add('active');
      if (btnSetA) btnSetA.classList.add('active');
      if (btnSetB) btnSetB.classList.add('active');
    } else if (a !== null) {
      abStatus.textContent = `A: ${formatDuration(a)} → set B to activate`;
      abStatus.classList.remove('active');
      if (btnSetA) btnSetA.classList.add('active');
      if (btnSetB) btnSetB.classList.remove('active');
    } else {
      abStatus.textContent = '';
      abStatus.classList.remove('active');
      if (btnSetA) btnSetA.classList.remove('active');
      if (btnSetB) btnSetB.classList.remove('active');
    }

    // Update seek-bar A/B markers
    const duration = Player.getDuration();
    if (abMarkerA) {
      if (a !== null && duration > 0) {
        abMarkerA.style.display = 'block';
        abMarkerA.style.left = ((a / duration) * 100) + '%';
      } else {
        abMarkerA.style.display = 'none';
      }
    }
    if (abMarkerB) {
      if (b !== null && duration > 0) {
        abMarkerB.style.display = 'block';
        abMarkerB.style.left = ((b / duration) * 100) + '%';
      } else {
        abMarkerB.style.display = 'none';
      }
    }
  });

  // ── Keyboard Shortcut Hooks (Phase 2) ────────────────────────────
  Player.onKeyboardVolume((vol) => {
    volumeSlider.value = vol;
    updateVolumeIcon(vol);
  });
  Player.onKeyboardNext(() => {
    Playlist.next(true);
  });
  Player.onKeyboardPrev(() => {
    Playlist.previous(Player.getCurrentTime(), true);
  });
  Player.onKeyboardRepeat(() => {
    Playlist.cycleRepeatMode();
    updateRepeatUI();
  });
  Player.onKeyboardShuffle(() => {
    Playlist.toggleShuffle();
    updateShuffleUI();
  });

  // ── Player Callbacks ─────────────────────────────────────────────
  let showRemainingTime = false;
  if (timeDuration) {
    timeDuration.style.cursor = 'pointer';
    timeDuration.title = 'Click to toggle remaining time';
    timeDuration.addEventListener('click', () => {
      showRemainingTime = !showRemainingTime;
      const cur = Player.getCurrentTime();
      const dur = Player.getDuration();
      const hasHours = (!isNaN(dur) && dur >= 3600) || cur >= 3600;
      if (!isNaN(dur) && dur > 0) {
        if (showRemainingTime) {
          const remaining = Math.max(0, dur - cur);
          timeDuration.textContent = '-' + formatDuration(remaining, hasHours);
        } else {
          timeDuration.textContent = formatDuration(dur, hasHours);
        }
      }
      if (typeof showNovaToast === 'function') {
        showNovaToast(showRemainingTime ? 'Showing remaining time (-)' : 'Showing total duration', 'fa-clock');
      }
    });
  }

  Player.onTimeUpdate((currentTime, duration) => {
    const hasHours = (!isNaN(duration) && duration >= 3600) || currentTime >= 3600;
    timeCurrent.textContent = formatDuration(currentTime, hasHours);
    if (!isNaN(duration) && duration > 0) {
      if (showRemainingTime) {
        const remaining = Math.max(0, duration - currentTime);
        timeDuration.textContent = '-' + formatDuration(remaining, hasHours);
      } else {
        timeDuration.textContent = formatDuration(duration, hasHours);
      }
      const pct = (currentTime / duration) * 100;
      seekSlider.value = pct;
      seekProgress.style.width = pct + '%';

      // Update A-B markers positions dynamically if set
      const ab = Player.getAbState();
      if (abMarkerA && ab.a !== null) {
        abMarkerA.style.left = ((ab.a / duration) * 100) + '%';
      }
      if (abMarkerB && ab.b !== null) {
        abMarkerB.style.left = ((ab.b / duration) * 100) + '%';
      }
    }
  });

  Player.onPlayStateChange((isPlaying) => {
    if (isPlaying) {
      playIcon.className = 'fa-solid fa-pause';
      btnPlayPause.classList.add('playing');
      if (videoPlaceholder) {
        videoPlaceholder.style.display = 'none';
        videoPlaceholder.style.opacity = '0';
        videoPlaceholder.style.pointerEvents = 'none';
      }
    } else {
      playIcon.className = 'fa-solid fa-play';
      btnPlayPause.classList.remove('playing');
    }
  });

  Player.onError((msg, item) => {
    // If an online stream / iframe embed is active, suppress native HTML5 video errors
    if (typeof Player !== 'undefined' && typeof Player.getIsEmbedActive === 'function' && Player.getIsEmbedActive()) {
      return;
    }
    const name = item ? item.name : '';
    const type = item ? item.type : '';
    playerErrorMessage.textContent = `${type ? '[' + type.toUpperCase() + '] ' : ''}${msg}${name ? ' — ' + name : ''}`;
    playerErrorBanner.style.display = 'flex';
  });

  Player.onEnded(() => {
    Playlist.onMediaEnded();
  });

  // ── Playlist Callbacks ───────────────────────────────────────────
  Playlist.onItemChange((item, index, autoPlay, isRestart) => {
    if (!item) {
      Library.setActiveId(null);
      Library.markActiveInDom(libraryContainer, null);
      resetPlayerUI();
      return;
    }

    playerErrorBanner.style.display = 'none';

    // Hide video placeholder overlay immediately upon loading item
    if (videoPlaceholder) {
      videoPlaceholder.style.display = 'none';
      videoPlaceholder.style.opacity = '0';
      videoPlaceholder.style.pointerEvents = 'none';
    }

    // Keep the library's "now playing" highlight in sync with the queue
    Library.setActiveId(item.id);
    Library.markActiveInDom(libraryContainer, item.id);

    nowPlayingTitle.textContent = item.name;
    nowPlayingExt.textContent = (item.extension || '--').toUpperCase().replace('.', '');
    trackTypeBadge.textContent = item.type.toUpperCase();
    trackTypeBadge.className = `track-type-badge ${item.type}`;

    if (item.type === 'audio') {
      audioVisualBadge.style.display = 'flex';
    } else {
      audioVisualBadge.style.display = 'none';
    }

    let resumePos = 0;
    if (!isRestart && !autoPlay) {
      const savedPos = localStorage.getItem('ultimatePlayer.position');
      if (savedPos) resumePos = parseFloat(savedPos) || 0;
    }

    Player.loadItem(item, autoPlay, resumePos, isRestart);

    // Phase 2: Record in recently played when actually playing
    if (autoPlay) {
      Library.recordRecentlyPlayed(item);
    }

    renderPlaylistView();
  });

  Playlist.onPlaylistChange((items, activeIndex) => {
    renderPlaylistView();
  });

  // ── Playback Controls ────────────────────────────────────────────
  if (btnPlayPause) {
    btnPlayPause.addEventListener('click', () => {
      const cur = Playlist.getCurrentItem();
      if (!cur && Playlist.getItems().length > 0) {
        Playlist.selectIndex(0, true);
      } else {
        Player.togglePlay();
      }
    });
  }

  if (btnNext) btnNext.addEventListener('click', () => Playlist.next(true));
  if (btnPrev) btnPrev.addEventListener('click', () => Playlist.previous(Player.getCurrentTime(), true));

  // ── Seek Slider ──────────────────────────────────────────────────
  if (seekSlider) {
    seekSlider.addEventListener('input', () => {
      const duration = Player.getDuration();
      if (duration > 0) {
        const targetSec = (seekSlider.value / 100) * duration;
        const hasHours = duration >= 3600 || targetSec >= 3600;
        if (timeCurrent) timeCurrent.textContent = formatDuration(targetSec, hasHours);
        if (showRemainingTime && timeDuration) {
          const remaining = Math.max(0, duration - targetSec);
          timeDuration.textContent = '-' + formatDuration(remaining, hasHours);
        }
        if (seekProgress) seekProgress.style.width = seekSlider.value + '%';
      }
    });

    seekSlider.addEventListener('change', () => {
      const duration = Player.getDuration();
      if (duration > 0) {
        const targetSec = (seekSlider.value / 100) * duration;
        Player.seek(targetSec);
      }
    });

    // ── YouTube-Style Hover Timestamp Tooltips ──────────────────────
    const seekTrack = document.getElementById('seekTrack');
    const seekHoverTooltip = document.getElementById('seekHoverTooltip');
    if (seekTrack && seekHoverTooltip) {
      seekTrack.addEventListener('mousemove', (e) => {
        const duration = Player.getDuration();
        if (!duration || isNaN(duration) || duration <= 0) {
          seekHoverTooltip.style.opacity = '0';
          return;
        }
        const rect = seekTrack.getBoundingClientRect();
        const clickX = Math.max(0, Math.min(e.clientX - rect.left, rect.width));
        const pct = clickX / rect.width;
        const hoverSec = pct * duration;
        const hasHours = duration >= 3600 || hoverSec >= 3600;
        seekHoverTooltip.textContent = formatDuration(hoverSec, hasHours);
        seekHoverTooltip.style.left = `${clickX}px`;
        seekHoverTooltip.style.opacity = '1';
      });
      seekTrack.addEventListener('mouseleave', () => {
        seekHoverTooltip.style.opacity = '0';
      });
    }

    const miniSeekTrack = document.getElementById('miniSeekTrack');
    const miniSeekHoverTooltip = document.getElementById('miniSeekHoverTooltip');
    if (miniSeekTrack && miniSeekHoverTooltip) {
      miniSeekTrack.addEventListener('mousemove', (e) => {
        const duration = Player.getDuration();
        if (!duration || isNaN(duration) || duration <= 0) {
          miniSeekHoverTooltip.style.opacity = '0';
          return;
        }
        const rect = miniSeekTrack.getBoundingClientRect();
        const clickX = Math.max(0, Math.min(e.clientX - rect.left, rect.width));
        const pct = clickX / rect.width;
        const hoverSec = pct * duration;
        const hasHours = duration >= 3600 || hoverSec >= 3600;
        miniSeekHoverTooltip.textContent = formatDuration(hoverSec, hasHours);
        miniSeekHoverTooltip.style.left = `${clickX}px`;
        miniSeekHoverTooltip.style.opacity = '1';
      });
      miniSeekTrack.addEventListener('mouseleave', () => {
        miniSeekHoverTooltip.style.opacity = '0';
      });
    }
  }

  // ── Volume & Amplification Boost ────────────────────────────────
  const volumeAmpBadge = document.getElementById('volumeAmpBadge');
  if (volumeAmpBadge) {
    volumeAmpBadge.style.display = 'none'; // hidden by default at normal volume
  }

  if (volumeSlider) {
    volumeSlider.addEventListener('input', () => {
      const val = parseFloat(volumeSlider.value);
      if (val > 1.0) {
        Player.setVolume(1.0);
        Player.setAmplification(val);
        if (volumeAmpBadge) {
          volumeAmpBadge.style.display = 'inline-block';
          volumeAmpBadge.textContent = `BOOST ${(val * 100).toFixed(0)}%`;
        }
      } else {
        Player.setVolume(val);
        Player.setAmplification(1.0);
        if (volumeAmpBadge) {
          volumeAmpBadge.style.display = 'none';
        }
      }
      updateVolumeIcon(val);
    });
  }

  if (btnMute) {
    btnMute.addEventListener('click', () => {
      Player.toggleMute();
      const newVol = Player.getVolume();
      if (volumeSlider) volumeSlider.value = newVol;
      if (volumeAmpBadge) volumeAmpBadge.style.display = 'none';
      updateVolumeIcon(newVol);
    });
  }

  function updateVolumeIcon(vol) {
    if (!volumeIcon) return;
    if (vol === 0) {
      volumeIcon.className = 'fa-solid fa-volume-xmark';
    } else if (vol < 0.5) {
      volumeIcon.className = 'fa-solid fa-volume-low';
    } else {
      volumeIcon.className = 'fa-solid fa-volume-high';
    }
  }


  // ── Playback Rate ────────────────────────────────────────────────
  if (playbackSpeedSelect) {
    playbackSpeedSelect.addEventListener('change', () => {
      const rate = parseFloat(playbackSpeedSelect.value);
      Player.setPlaybackRate(rate);
    });
  }

  // ── Shuffle ──────────────────────────────────────────────────────
  if (btnShuffle) {
    btnShuffle.addEventListener('click', () => {
      Playlist.toggleShuffle();
      updateShuffleUI();
    });
  }

  function updateShuffleUI() {
    if (btnShuffle) btnShuffle.classList.toggle('active', Playlist.getIsShuffle());
  }

  // ── Repeat ───────────────────────────────────────────────────────
  if (btnRepeat) {
    btnRepeat.addEventListener('click', () => {
      Playlist.cycleRepeatMode();
      updateRepeatUI();
    });
  }

  function updateRepeatUI() {
    const mode = Playlist.getRepeatMode();
    const repeatLabel = document.getElementById('repeatLabel');
    const repeatIcon = document.getElementById('repeatIcon');
    if (typeof Player !== 'undefined' && typeof Player.setRepeatMode === 'function') {
      Player.setRepeatMode(mode);
    }
    if (mode === 'off') {
      btnRepeat.classList.remove('active', 'loop-video', 'loop-queue');
      if (repeatBadge) repeatBadge.textContent = '';
      if (repeatLabel) repeatLabel.textContent = 'Loop: Off';
      if (repeatIcon) repeatIcon.className = 'fa-solid fa-repeat';
      btnRepeat.title = 'Loop Mode: Off (Click to cycle)';
    } else if (mode === 'current') {
      btnRepeat.classList.remove('loop-queue');
      btnRepeat.classList.add('active', 'loop-video');
      if (repeatBadge) repeatBadge.textContent = '1';
      if (repeatLabel) repeatLabel.textContent = 'Loop: Video 🔂';
      if (repeatIcon) repeatIcon.className = 'fa-solid fa-repeat';
      btnRepeat.title = 'Loop Mode: Current Video (Continuous Loop Active)';
    } else if (mode === 'playlist') {
      btnRepeat.classList.remove('loop-video');
      btnRepeat.classList.add('active', 'loop-queue');
      if (repeatBadge) repeatBadge.textContent = 'ALL';
      if (repeatLabel) repeatLabel.textContent = 'Loop: Queue 🔁';
      if (repeatIcon) repeatIcon.className = 'fa-solid fa-repeat';
      btnRepeat.title = 'Loop Mode: Entire Queue Continuous Loop';
    }
  }

  // ── Subtitles / Captions (Phase 3) ──────────────────────────────
  function renderSubtitleMenu(tracks, currentId) {
    if (!subtitleMenuList) return;
    subtitleMenuList.innerHTML = '';

    // "Off" option
    const offBtn = document.createElement('button');
    offBtn.className = `subtitle-item ${currentId === 'off' ? 'active' : ''}`;
    offBtn.dataset.subId = 'off';
    offBtn.innerHTML = `<span class="sub-check">&#x2713;</span> Off`;
    offBtn.addEventListener('click', () => {
      Player.setSubtitleTrack('off');
      closeSubtitleMenu();
    });
    subtitleMenuList.appendChild(offBtn);

    if (Array.isArray(tracks) && tracks.length > 0) {
      tracks.forEach(track => {
        const itemBtn = document.createElement('button');
        const isActive = currentId === track.id;
        itemBtn.className = `subtitle-item ${isActive ? 'active' : ''}`;
        itemBtn.dataset.subId = track.id;
        const displayLabel = track.label || track.name || track.language;
        itemBtn.innerHTML = `<span class="sub-check">&#x2713;</span> ${escapeHtml(displayLabel)}`;
        itemBtn.addEventListener('click', () => {
          Player.setSubtitleTrack(track.id);
          closeSubtitleMenu();
        });
        subtitleMenuList.appendChild(itemBtn);
      });
    }
  }

  function updateSubtitleUI(tracks, currentId) {
    if (!btnCaptions) return;
    const hasSubs = Array.isArray(tracks) && tracks.length > 0;
    btnCaptions.disabled = !hasSubs;
    btnCaptions.classList.toggle('active', currentId !== 'off');
    btnCaptions.title = hasSubs ? `Subtitles (CC) — ${currentId === 'off' ? 'Off' : 'Active'}` : 'No Subtitles Available';
    renderSubtitleMenu(tracks, currentId);
  }

  function toggleSubtitleMenu() {
    if (!subtitleMenu) return;
    const isVisible = subtitleMenu.style.display !== 'none';
    if (isVisible) {
      closeSubtitleMenu();
    } else {
      openSubtitleMenu();
    }
  }

  function openSubtitleMenu() {
    if (!subtitleMenu || !btnCaptions || btnCaptions.disabled) return;
    subtitleMenu.style.display = 'block';
    btnCaptions.setAttribute('aria-expanded', 'true');
  }

  function closeSubtitleMenu() {
    if (!subtitleMenu) return;
    subtitleMenu.style.display = 'none';
    if (btnCaptions) btnCaptions.setAttribute('aria-expanded', 'false');
  }

  if (btnCaptions) {
    btnCaptions.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleSubtitleMenu();
    });
  }

  // Close subtitle menu when clicking outside
  document.addEventListener('click', (e) => {
    if (subtitleMenu && subtitleMenu.style.display !== 'none') {
      if (!subtitleMenu.contains(e.target) && !btnCaptions.contains(e.target)) {
        closeSubtitleMenu();
      }
    }
  });

  // Listen to Player subtitle state changes
  Player.onSubtitleChange((tracks, currentId) => {
    updateSubtitleUI(tracks, currentId);
  });

  // ── Fullscreen ───────────────────────────────────────────────────
  if (btnFullscreen) {
    btnFullscreen.addEventListener('click', () => Player.toggleFullscreen());
  }

  // ── Toast Notification Helper (Permanently Disabled as requested) ───
  function showNovaToast() {
    // Disabled completely: no toast notification popups across the entire app
    return;
  }

  function hideNovaToast() {
    const toast = document.getElementById('novaToast');
    if (toast) toast.style.display = 'none';
  }

  window.showNovaToast = showNovaToast;
  window.hideNovaToast = hideNovaToast;
  window.showToast = showNovaToast;

  // ── Snapshot / Screenshot Capture ────────────────────────────────
  const btnSnapshot = document.getElementById('btnSnapshot');
  if (btnSnapshot) {
    btnSnapshot.addEventListener('click', () => {
      const dataUrl = Player.takeSnapshot();
      if (dataUrl) {
        showNovaToast('📸 Video frame captured & downloaded to your device!', 'fa-camera');
      } else {
        showNovaToast('Snapshot available for video playback', 'fa-triangle-exclamation');
      }
    });
  }

  // ── Copy Stream / Media URL ──────────────────────────────────────
  const btnCopyStreamUrl = document.getElementById('btnCopyStreamUrl');
  if (btnCopyStreamUrl) {
    btnCopyStreamUrl.addEventListener('click', () => {
      const item = (typeof Player !== 'undefined' && Player.getCurrentItem && Player.getCurrentItem())
        || (typeof currentVideoInfo !== 'undefined' && currentVideoInfo)
        || { url: document.getElementById('urlInput')?.value };
      const copyText = (item && (item.url || item.webpage_url)) || (document.getElementById('urlInput')?.value) || window.location.href;
      if (copyText && navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(copyText).then(() => {
          showNovaToast('Stream URL copied to clipboard!', 'fa-copy');
        }).catch(() => {
          showNovaToast('Failed to copy stream URL', 'fa-triangle-exclamation');
        });
      } else {
        showNovaToast('No media stream URL to copy', 'fa-circle-info');
      }
    });
  }

  // ── Picture-in-Picture (PiP) ─────────────────────────────────────
  const btnPiP = document.getElementById('btnPiP');
  if (btnPiP) {
    btnPiP.addEventListener('click', async () => {
      const isPiP = await Player.togglePiP();
      btnPiP.classList.toggle('active', isPiP);
      if (isPiP) showNovaToast('Picture-in-Picture mode active', 'fa-clone');
    });
  }

  // ── Studio 5-Band Equalizer ──────────────────────────────────────
  const btnEqualizer = document.getElementById('btnEqualizer');
  const equalizerModal = document.getElementById('equalizerModal');
  const closeEqualizerModal = document.getElementById('closeEqualizerModal');
  const btnCloseEq = document.getElementById('btnCloseEq');
  const btnResetEq = document.getElementById('btnResetEq');
  const eqPresetSelect = document.getElementById('eqPresetSelect');
  const eqSliders = {
    60: { input: document.getElementById('eq60'), label: document.getElementById('eq60val') },
    250: { input: document.getElementById('eq250'), label: document.getElementById('eq250val') },
    1000: { input: document.getElementById('eq1k'), label: document.getElementById('eq1kval') },
    4000: { input: document.getElementById('eq4k'), label: document.getElementById('eq4kval') },
    14000: { input: document.getElementById('eq14k'), label: document.getElementById('eq14kval') }
  };

  if (btnEqualizer && equalizerModal) {
    btnEqualizer.addEventListener('click', () => {
      equalizerModal.style.display = 'flex';
    });
    if (closeEqualizerModal) closeEqualizerModal.addEventListener('click', () => equalizerModal.style.display = 'none');
    if (btnCloseEq) btnCloseEq.addEventListener('click', () => equalizerModal.style.display = 'none');

    Object.keys(eqSliders).forEach(freq => {
      const item = eqSliders[freq];
      if (item && item.input) {
        item.input.addEventListener('input', () => {
          const val = item.input.value;
          if (item.label) item.label.textContent = `${val >= 0 ? '+' : ''}${val}dB`;
          Player.setEqualizerBand(Number(freq), val);
        });
      }
    });

    if (eqPresetSelect) {
      eqPresetSelect.addEventListener('change', () => {
        const gains = Player.setEqualizerPreset(eqPresetSelect.value);
        Object.keys(gains).forEach(freq => {
          const item = eqSliders[freq];
          if (item && item.input) {
            item.input.value = gains[freq];
            if (item.label) item.label.textContent = `${gains[freq] >= 0 ? '+' : ''}${gains[freq]}dB`;
          }
        });
        showNovaToast(`Equalizer preset set to ${eqPresetSelect.options[eqPresetSelect.selectedIndex].text}`, 'fa-sliders');
      });
    }

    if (btnResetEq) {
      btnResetEq.addEventListener('click', () => {
        if (eqPresetSelect) eqPresetSelect.value = 'flat';
        const gains = Player.setEqualizerPreset('flat');
        Object.keys(gains).forEach(freq => {
          const item = eqSliders[freq];
          if (item && item.input) {
            item.input.value = gains[freq];
            if (item.label) item.label.textContent = `${gains[freq] >= 0 ? '+' : ''}${gains[freq]}dB`;
          }
        });
        showNovaToast('Equalizer reset to Flat', 'fa-rotate-left');
      });
    }
  }

  // ── Studio Video FX & Color Grading ──────────────────────────────
  const btnVideoFx = document.getElementById('btnVideoFx');
  const videoFxModal = document.getElementById('videoFxModal');
  const closeVideoFxModal = document.getElementById('closeVideoFxModal');
  const btnCloseVideoFx = document.getElementById('btnCloseVideoFx');
  const btnResetVideoFx = document.getElementById('btnResetVideoFx');
  const videoFxPresetSelect = document.getElementById('videoFxPresetSelect');

  const fxBrightness = document.getElementById('fxBrightness');
  const fxBrightnessVal = document.getElementById('fxBrightnessVal');
  const fxContrast = document.getElementById('fxContrast');
  const fxContrastVal = document.getElementById('fxContrastVal');
  const fxSaturation = document.getElementById('fxSaturation');
  const fxSaturationVal = document.getElementById('fxSaturationVal');
  const fxHue = document.getElementById('fxHue');
  const fxHueVal = document.getElementById('fxHueVal');
  const fxSepia = document.getElementById('fxSepia');
  const fxSepiaVal = document.getElementById('fxSepiaVal');
  const fxBlur = document.getElementById('fxBlur');
  const fxBlurVal = document.getElementById('fxBlurVal');

  if (btnVideoFx && videoFxModal) {
    btnVideoFx.addEventListener('click', () => {
      videoFxModal.style.display = 'flex';
    });
    if (closeVideoFxModal) closeVideoFxModal.addEventListener('click', () => videoFxModal.style.display = 'none');
    if (btnCloseVideoFx) btnCloseVideoFx.addEventListener('click', () => videoFxModal.style.display = 'none');

    const updateFxUiFromState = (f) => {
      if (fxBrightness) { fxBrightness.value = f.brightness; if (fxBrightnessVal) fxBrightnessVal.textContent = f.brightness + '%'; }
      if (fxContrast) { fxContrast.value = f.contrast; if (fxContrastVal) fxContrastVal.textContent = f.contrast + '%'; }
      if (fxSaturation) { fxSaturation.value = f.saturate; if (fxSaturationVal) fxSaturationVal.textContent = f.saturate + '%'; }
      if (fxHue) { fxHue.value = f.hueRotate; if (fxHueVal) fxHueVal.textContent = f.hueRotate + '°'; }
      if (fxSepia) { fxSepia.value = f.sepia; if (fxSepiaVal) fxSepiaVal.textContent = f.sepia + '%'; }
      if (fxBlur) { fxBlur.value = f.blur; if (fxBlurVal) fxBlurVal.textContent = f.blur + 'px'; }
    };

    if (fxBrightness) fxBrightness.addEventListener('input', () => { Player.setVideoFilter('brightness', fxBrightness.value); if (fxBrightnessVal) fxBrightnessVal.textContent = fxBrightness.value + '%'; });
    if (fxContrast) fxContrast.addEventListener('input', () => { Player.setVideoFilter('contrast', fxContrast.value); if (fxContrastVal) fxContrastVal.textContent = fxContrast.value + '%'; });
    if (fxSaturation) fxSaturation.addEventListener('input', () => { Player.setVideoFilter('saturate', fxSaturation.value); if (fxSaturationVal) fxSaturationVal.textContent = fxSaturation.value + '%'; });
    if (fxHue) fxHue.addEventListener('input', () => { Player.setVideoFilter('hueRotate', fxHue.value); if (fxHueVal) fxHueVal.textContent = fxHue.value + '°'; });
    if (fxSepia) fxSepia.addEventListener('input', () => { Player.setVideoFilter('sepia', fxSepia.value); if (fxSepiaVal) fxSepiaVal.textContent = fxSepia.value + '%'; });
    if (fxBlur) fxBlur.addEventListener('input', () => { Player.setVideoFilter('blur', fxBlur.value); if (fxBlurVal) fxBlurVal.textContent = fxBlur.value + 'px'; });

    if (videoFxPresetSelect) {
      videoFxPresetSelect.addEventListener('change', () => {
        const filters = Player.applyVideoFxPreset(videoFxPresetSelect.value);
        updateFxUiFromState(filters);
        showNovaToast(`Video FX preset: ${videoFxPresetSelect.options[videoFxPresetSelect.selectedIndex].text}`, 'fa-wand-magic-sparkles');
      });
    }

    if (btnResetVideoFx) {
      btnResetVideoFx.addEventListener('click', () => {
        if (videoFxPresetSelect) videoFxPresetSelect.value = 'none';
        Player.resetVideoFilters();
        updateFxUiFromState(Player.getVideoFilters());
        showNovaToast('Video FX reset to raw/normal', 'fa-rotate-left');
      });
    }
  }

  // ── Stats for Nerds / Playback HUD ───────────────────────────────
  const btnStats = document.getElementById('btnStats');
  const statsForNerds = document.getElementById('statsForNerds');
  const closeStatsBtn = document.getElementById('closeStatsBtn');
  let statsTimer = null;

  function updateStatsHud() {
    if (!statsForNerds || statsForNerds.style.display === 'none') return;
    const s = Player.getDiagnosticsStats();
    if (!s) return;
    const statRes = document.getElementById('statRes');
    const statViewport = document.getElementById('statViewport');
    const statFrames = document.getElementById('statFrames');
    const statBuffer = document.getElementById('statBuffer');
    const statBitrate = document.getElementById('statBitrate');
    const statSpeed = document.getElementById('statSpeed');
    const statAudio = document.getElementById('statAudio');
    const statEngine = document.getElementById('statEngine');

    if (statRes) statRes.textContent = s.resolution;
    if (statViewport) statViewport.textContent = s.viewport;
    if (statFrames) statFrames.textContent = s.frames;
    if (statBuffer) statBuffer.textContent = s.buffer;
    if (statBitrate) statBitrate.textContent = s.bitrate;
    if (statSpeed) statSpeed.textContent = s.speed;
    if (statAudio) statAudio.textContent = s.audio;
    if (statEngine) statEngine.textContent = s.engine;
  }

  if (btnStats && statsForNerds) {
    btnStats.addEventListener('click', () => {
      const isShown = statsForNerds.style.display !== 'none';
      statsForNerds.style.display = isShown ? 'none' : 'block';
      btnStats.classList.toggle('active', !isShown);
      if (!isShown) {
        updateStatsHud();
        if (statsTimer) clearInterval(statsTimer);
        statsTimer = setInterval(updateStatsHud, 1000);
      } else if (statsTimer) {
        clearInterval(statsTimer);
        statsTimer = null;
      }
    });

    if (closeStatsBtn) {
      closeStatsBtn.addEventListener('click', () => {
        statsForNerds.style.display = 'none';
        btnStats.classList.remove('active');
        if (statsTimer) {
          clearInterval(statsTimer);
          statsTimer = null;
        }
      });
    }
  }

  // ── Sleep Timer ──────────────────────────────────────────────────
  const btnSleepTimer = document.getElementById('btnSleepTimer');
  const sleepTimerModal = document.getElementById('sleepTimerModal');
  const closeSleepTimerModal = document.getElementById('closeSleepTimerModal');
  const sleepTimerStatus = document.getElementById('sleepTimerStatus');

  if (btnSleepTimer && sleepTimerModal) {
    btnSleepTimer.addEventListener('click', () => {
      sleepTimerModal.style.display = 'flex';
    });
    if (closeSleepTimerModal) closeSleepTimerModal.addEventListener('click', () => sleepTimerModal.style.display = 'none');

    document.querySelectorAll('.btn-sleep-opt').forEach(opt => {
      opt.addEventListener('click', () => {
        const mins = parseInt(opt.getAttribute('data-mins'), 10);
        if (mins > 0) {
          Player.setSleepTimer(
            mins,
            (remaining) => {
              if (sleepTimerStatus) {
                if (remaining > 0) {
                  const m = Math.floor(remaining / 60);
                  const s = remaining % 60;
                  sleepTimerStatus.textContent = `Sleeping in: ${m}:${s < 10 ? '0' : ''}${s}`;
                  btnSleepTimer.classList.add('active');
                } else {
                  sleepTimerStatus.textContent = 'Timer: Off';
                  btnSleepTimer.classList.remove('active');
                }
              }
            },
            () => {
              showNovaToast('🌙 Sleep timer ended — Player paused', 'fa-moon');
            }
          );
          showNovaToast(`🌙 Sleep timer set for ${mins} minutes`, 'fa-moon');
        } else {
          Player.cancelSleepTimer();
          if (sleepTimerStatus) sleepTimerStatus.textContent = 'Timer: Off';
          btnSleepTimer.classList.remove('active');
          showNovaToast('Sleep timer disabled', 'fa-moon');
        }
        sleepTimerModal.style.display = 'none';
      });
    });
  }

  // ── Local Subtitle File Loader (.srt / .vtt) ─────────────────────
  const btnLoadLocalSub = document.getElementById('btnLoadLocalSub');
  const subFileInput = document.getElementById('subFileInput');
  if (btnLoadLocalSub && subFileInput) {
    btnLoadLocalSub.addEventListener('click', () => subFileInput.click());
    subFileInput.addEventListener('change', async (e) => {
      const file = e.target.files && e.target.files[0];
      if (file) {
        const success = await Player.loadLocalSubtitleFile(file);
        if (success) {
          showNovaToast(`Loaded subtitles from ${file.name}`, 'fa-file-lines');
          closeSubtitleMenu();
        } else {
          showNovaToast('Could not parse subtitle file', 'fa-triangle-exclamation');
        }
      }
      subFileInput.value = '';
    });
  }

  // ── Reactive Ambilight Glow ─────────────────────────────────────
  const btnAmbilight = document.getElementById('btnAmbilight');
  if (btnAmbilight) {
    if (typeof Player.isAmbilightActive === 'function' && Player.isAmbilightActive()) {
      btnAmbilight.classList.add('active');
    }
    btnAmbilight.addEventListener('click', () => {
      if (typeof Player.toggleAmbilight === 'function') {
        const isActive = Player.toggleAmbilight();
        btnAmbilight.classList.toggle('active', isActive);
        showNovaToast(isActive ? 'Ambilight Glow: Active' : 'Ambilight Glow: Disabled', 'fa-sun');
      }
    });
  }

  // ── Batch URL Downloader ─────────────────────────────────────────
  const toggleBatchBtn = document.getElementById('toggleBatchBtn');
  const batchBox = document.getElementById('batchBox');
  const batchToggleText = document.getElementById('batchToggleText');
  const startBatchBtn = document.getElementById('startBatchBtn');
  const batchTextarea = document.getElementById('batchTextarea');
  const batchModeSelect = document.getElementById('batchModeSelect');

  if (toggleBatchBtn && batchBox) {
    toggleBatchBtn.addEventListener('click', () => {
      const isVisible = batchBox.style.display !== 'none';
      batchBox.style.display = isVisible ? 'none' : 'block';
      if (batchToggleText) {
        batchToggleText.textContent = isVisible ? 'Switch to Batch Queue Mode' : 'Close Batch Queue Mode';
      }
    });
  }

  if (startBatchBtn && batchTextarea) {
    startBatchBtn.addEventListener('click', async () => {
      const rawText = batchTextarea.value.trim();
      if (!rawText) {
        showNovaToast('Please enter at least one URL', 'fa-triangle-exclamation');
        return;
      }
      const lines = rawText.split('\n').map(l => l.trim()).filter(l => l.length > 0 && /^https?:\/\//i.test(l));
      if (lines.length === 0) {
        showNovaToast('No valid http/https URLs found', 'fa-triangle-exclamation');
        return;
      }

      const modeVal = batchModeSelect ? batchModeSelect.value : 'max';
      let mode = 'max';
      let quality = null;
      if (modeVal === 'audio') {
        mode = 'audio';
      } else if (modeVal.startsWith('custom-quality-')) {
        mode = 'custom-quality';
        quality = modeVal.replace('custom-quality-', '');
      }

      startBatchBtn.disabled = true;
      startBatchBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Queuing Batch...';

      try {
        const authToken = localStorage.getItem('novapulse_auth_token');
        const headers = { 'Content-Type': 'application/json' };
        if (authToken) headers['Authorization'] = 'Bearer ' + authToken;

        const res = await fetch('/api/download/batch', {
          method: 'POST',
          headers: headers,
          body: JSON.stringify({ urls: lines, mode, quality })
        });
        const data = await res.json();
        if (data.ok) {
          showNovaToast('🚀 Queued ' + data.count + ' downloads in Turbo Mode!', 'fa-rocket');
          batchTextarea.value = '';
          if (batchBox) batchBox.style.display = 'none';
          if (batchToggleText) batchToggleText.textContent = 'Switch to Batch Queue Mode';
          // Navigate to downloads tab to see progress
          if (typeof Nova !== 'undefined' && typeof Nova.switchView === 'function') {
            Nova.switchView('downloads');
          }
          if (typeof fetchDownloads === 'function') fetchDownloads();
        } else {
          showNovaToast(data.error || 'Failed to start batch', 'fa-triangle-exclamation');
        }
      } catch (err) {
        showNovaToast('Batch request failed: ' + err.message, 'fa-triangle-exclamation');
      } finally {
        startBatchBtn.disabled = false;
        startBatchBtn.innerHTML = '<i class="fa-solid fa-download"></i> Start Batch Download';
      }
    });
  }

  // ── Smart Clipboard Sniffer ──────────────────────────────────────
  const clipboardPill = document.getElementById('clipboardSnifferPill');
  const clipboardUrlText = document.getElementById('clipboardSnifferUrlText');
  const btnClipboardQuickDownload = document.getElementById('btnClipboardQuickDownload');
  const btnClipboardInspect = document.getElementById('btnClipboardInspect');
  const btnDismissClipboard = document.getElementById('btnDismissClipboard');
  let lastSniffedUrl = null;

  async function checkClipboardForMediaUrl() {
    try {
      if (!navigator.clipboard || !navigator.clipboard.readText) return;
      const text = await navigator.clipboard.readText();
      if (!text || typeof text !== 'string') return;
      const trimmed = text.trim();
      if (!/^https?:\/\/[^\s]+$/i.test(trimmed)) return;
      if (trimmed === lastSniffedUrl) return;

      const isMediaSite = /(youtube\.com|youtu\.be|tiktok\.com|instagram\.com|twitter\.com|x\.com|vimeo\.com|soundcloud\.com|reddit\.com|twitch\.tv|facebook\.com|\.m3u8|\.mpd|\.mp4|\.webm|\.mp3)/i.test(trimmed);
      if (isMediaSite && clipboardPill && clipboardUrlText) {
        lastSniffedUrl = trimmed;
        clipboardUrlText.textContent = trimmed.length > 55 ? trimmed.substring(0, 52) + '...' : trimmed;
        clipboardUrlText.dataset.fullUrl = trimmed;
        clipboardPill.style.display = 'flex';
      }
    } catch (e) {
      // Background clipboard permission may be blocked until user interacts
    }
  }

  const urlInputEl = document.getElementById('urlInput');
  if (urlInputEl) {
    urlInputEl.addEventListener('focus', () => {
      if (!urlInputEl.value) setTimeout(checkClipboardForMediaUrl, 100);
    });
  }

  if (btnDismissClipboard && clipboardPill) {
    btnDismissClipboard.addEventListener('click', () => {
      clipboardPill.style.display = 'none';
    });
  }

  if (btnClipboardQuickDownload && clipboardUrlText) {
    btnClipboardQuickDownload.addEventListener('click', () => {
      const fullUrl = clipboardUrlText.dataset.fullUrl;
      if (!fullUrl) return;
      const urlInput = document.getElementById('urlInput');
      if (urlInput) urlInput.value = fullUrl;
      clipboardPill.style.display = 'none';

      // Start download immediately
      startDownload({ url: fullUrl, mode: 'max' });
      showNovaToast('🚀 Turbo Download Started from Clipboard!', 'fa-bolt');
    });
  }

  if (btnClipboardInspect && clipboardUrlText) {
    btnClipboardInspect.addEventListener('click', () => {
      const fullUrl = clipboardUrlText.dataset.fullUrl;
      if (!fullUrl) return;
      const urlInput = document.getElementById('urlInput');
      if (urlInput) urlInput.value = fullUrl;
      clipboardPill.style.display = 'none';

      const inspectBtn = document.getElementById('inspectBtn');
      if (inspectBtn) inspectBtn.click();
    });
  }

  // ── Library Wiring ───────────────────────────────────────────────
  // Play Now: open directly in Player Studio, start playback, populate right-hand queue with follow-up library videos
  Library.onPlayNow((item) => {
    playLibraryTrackWithQueue(item);
  });

  // Whole-row click: play the file with full Player Studio experience & follow-up queue
  Library.onRowClick((item) => {
    const current = Playlist.getCurrentItem();
    if (current && current.id === item.id && Player.hasSource() && !Player.hasError()) {
      if (typeof Nova !== 'undefined' && typeof Nova.switchView === 'function') {
        Nova.switchView('player');
      } else if (typeof switchView === 'function') {
        switchView('player');
      }
      return;
    }
    playLibraryTrackWithQueue(item);
  });

  Library.onAddToPlaylist((item) => {
    Playlist.addItem(item, true);
  });

  // ── Initial Render ───────────────────────────────────────────────
  renderPlaylistView();
  loadAndRenderLibrary();

  // Restore current item on start WITHOUT auto-playing
  const initialItem = Playlist.getCurrentItem();
  if (initialItem) {
    const savedPos = parseFloat(localStorage.getItem('ultimatePlayer.position')) || 0;
    nowPlayingTitle.textContent = initialItem.name;
    nowPlayingExt.textContent = (initialItem.extension || '--').toUpperCase().replace('.', '');
    trackTypeBadge.textContent = initialItem.type.toUpperCase();
    trackTypeBadge.className = `track-type-badge ${initialItem.type}`;
    if (initialItem.type === 'audio') {
      audioVisualBadge.style.display = 'flex';
    }
    // Highlight the restored track in the library list as well
    Library.setActiveId(initialItem.id);
    Library.markActiveInDom(libraryContainer, initialItem.id);
    Player.loadItem(initialItem, false, savedPos);
  }
}

function resetPlayerUI() {
  const nowPlayingTitle = document.getElementById('nowPlayingTitle');
  const nowPlayingExt = document.getElementById('nowPlayingExt');
  const trackTypeBadge = document.getElementById('trackTypeBadge');
  const videoPlaceholder = document.getElementById('videoPlaceholder');
  const audioVisualBadge = document.getElementById('audioVisualBadge');
  const timeCurrent = document.getElementById('timeCurrent');
  const timeDuration = document.getElementById('timeDuration');
  const seekSlider = document.getElementById('seekSlider');
  const seekProgress = document.getElementById('seekProgress');

  if (nowPlayingTitle) nowPlayingTitle.textContent = 'No media loaded';
  if (nowPlayingExt) nowPlayingExt.textContent = '--';
  if (trackTypeBadge) trackTypeBadge.textContent = 'MEDIA';
  if (videoPlaceholder) {
    videoPlaceholder.style.display = 'flex';
    videoPlaceholder.style.opacity = '1';
    videoPlaceholder.style.pointerEvents = 'auto';
  }
  if (audioVisualBadge) audioVisualBadge.style.display = 'none';
  if (timeCurrent) timeCurrent.textContent = '00:00';
  if (timeDuration) timeDuration.textContent = '00:00';
  if (seekSlider) seekSlider.value = 0;
  if (seekProgress) seekProgress.style.width = '0%';
}

function syncPlayerStudioUI() {
  const current = (typeof Playlist !== 'undefined') ? Playlist.getCurrentItem() : null;
  const nowPlayingTitle = document.getElementById('nowPlayingTitle');
  const nowPlayingExt = document.getElementById('nowPlayingExt');
  const trackTypeBadge = document.getElementById('trackTypeBadge');
  const videoPlaceholder = document.getElementById('videoPlaceholder');
  const audioVisualBadge = document.getElementById('audioVisualBadge');
  const timeCurrent = document.getElementById('timeCurrent');
  const timeDuration = document.getElementById('timeDuration');
  const seekSlider = document.getElementById('seekSlider');
  const seekProgress = document.getElementById('seekProgress');
  const playIcon = document.getElementById('playIcon');
  const btnPlayPause = document.getElementById('btnPlayPause');

  if (current) {
    if (videoPlaceholder) {
      videoPlaceholder.style.display = 'none';
      videoPlaceholder.style.opacity = '0';
      videoPlaceholder.style.pointerEvents = 'none';
    }
    if (nowPlayingTitle) nowPlayingTitle.textContent = current.name || 'Media Track';
    if (nowPlayingExt) nowPlayingExt.textContent = (current.extension || '--').toUpperCase().replace('.', '');
    if (trackTypeBadge) {
      trackTypeBadge.textContent = (current.type || 'video').toUpperCase();
      trackTypeBadge.className = `track-type-badge ${current.type || 'video'}`;
    }
    if (audioVisualBadge) {
      audioVisualBadge.style.display = current.type === 'audio' ? 'flex' : 'none';
    }
    if (typeof Player !== 'undefined') {
      const cur = Player.getCurrentTime();
      const dur = Player.getDuration();
      const hasHours = (!isNaN(dur) && dur >= 3600) || cur >= 3600;
      if (timeCurrent) timeCurrent.textContent = formatDuration(cur, hasHours);
      if (timeDuration && !isNaN(dur) && dur > 0) {
        timeDuration.textContent = formatDuration(dur, hasHours);
      }
      if (!isNaN(dur) && dur > 0 && seekSlider && seekProgress) {
        const pct = (cur / dur) * 100;
        seekSlider.value = pct;
        seekProgress.style.width = pct + '%';
      }
      const isPlaying = !Player.isPaused() && Player.hasSource();
      if (playIcon) playIcon.className = isPlaying ? 'fa-solid fa-pause' : 'fa-solid fa-play';
      if (btnPlayPause) btnPlayPause.classList.toggle('playing', isPlaying);
    }
  } else {
    resetPlayerUI();
  }
  renderPlaylistView();
}

window.syncPlayerStudioUI = syncPlayerStudioUI;
window.renderPlaylistView = renderPlaylistView;
window.initMediaStudio = initMediaStudio;

function formatDurationSec(sec) {
  if (!sec || isNaN(sec)) return '';
  const s = Math.floor(sec);
  const hrs = Math.floor(s / 3600);
  const mins = Math.floor((s % 3600) / 60);
  const secs = s % 60;
  if (hrs > 0) {
    return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

function renderPlaylistView() {
  const container = document.getElementById('playlistContainer');
  const countEl = document.getElementById('playlistCount');
  if (!container) return;

  const items = Playlist.getItems();
  const currentIndex = Playlist.getCurrentIndex();

  if (countEl) countEl.textContent = items.length;

  if (items.length === 0) {
    container.innerHTML = `
      <div class="empty-playlist" id="emptyPlaylist">
        <i class="fa-solid fa-list-check"></i>
        <p>Playback Queue is Empty</p>
        <small>Select any video or music track to start playing.</small>
        <button class="btn-primary btn-mini" style="margin-top:14px;" onclick="if(typeof Nova!=='undefined')Nova.switchView('library')">
          <i class="fa-solid fa-layer-group"></i> Browse Library &amp; Play
        </button>
      </div>
    `;
    return;
  }

  container.innerHTML = '';
  let dragSrcIndex = null;

  items.forEach((item, idx) => {
    const el = document.createElement('div');
    el.className = `playlist-item yt-queue-item ${idx === currentIndex ? 'active' : ''}`;
    el.dataset.index = idx;
    el.draggable = true;

    const iconClass = item.type === 'video' ? 'fa-solid fa-film' : 'fa-solid fa-music';
    const safeName = escapeHtml(item.name);

    const isInf = item.repeatCount === 'infinite' || item.repeatCount === 'Infinity' || item.repeatCount === '∞' || item.repeatCount === Infinity;
    const repeatCount = item.repeatCount || 1;
    const isLooped = isInf || (repeatCount > 1);

    let thumbUrl = item.thumbnail || '';
    if (!thumbUrl || thumbUrl.endsWith('#t=1.0')) {
      const ytMatch = (item.name || item.filename || '').match(/\[([a-zA-Z0-9_-]{11})\]/);
      if (ytMatch) thumbUrl = `https://i.ytimg.com/vi/${ytMatch[1]}/mqdefault.jpg`;
    }
    const durationBadge = item.duration ? formatDurationSec(item.duration) : (item.type === 'video' ? (item.extension || 'MP4').toUpperCase().replace('.', '') : 'AUDIO');

    el.innerHTML = `
      <span class="pl-drag-handle" title="Drag to reorder"><i class="fa-solid fa-grip-vertical"></i></span>
      <div class="yt-queue-thumb-wrap">
        ${thumbUrl ? `
          <img class="yt-queue-thumb" src="${escapeHtml(thumbUrl)}" alt="${safeName}" loading="lazy" onerror="this.style.display='none'; if(this.nextElementSibling) this.nextElementSibling.style.display='flex';" />
          <div class="yt-queue-thumb-fallback" style="display:none;"><i class="${iconClass}"></i></div>
        ` : `
          <div class="yt-queue-thumb-fallback"><i class="${iconClass}"></i></div>
        `}
        <span class="yt-queue-duration">${durationBadge}</span>
        ${idx === currentIndex ? `
          <div class="yt-queue-now-playing-overlay" title="Playing Now">
            <span class="yt-eq-bar bar1"></span>
            <span class="yt-eq-bar bar2"></span>
            <span class="yt-eq-bar bar3"></span>
          </div>
        ` : `
          <div class="yt-queue-hover-play" title="Play Video">
            <i class="fa-solid fa-play"></i>
          </div>
        `}
      </div>
      <div class="yt-queue-info">
        <div class="yt-queue-title" title="${safeName}">${safeName}</div>
        <div class="yt-queue-meta">
          <span class="yt-channel-tag"><i class="fa-solid fa-circle-check"></i> Nova Media</span>
          <span class="yt-meta-dot">•</span>
          <span>${formatBytes(item.size)}</span>
        </div>
      </div>
      <div class="yt-queue-actions">
        <button class="btn-pl-loop ${isLooped ? 'active' : ''}" title="${isInf ? 'Repeat track (∞ Infinite)' : (isLooped ? `Repeat ${repeatCount}x` : 'Repeat track (1x)')}">
          <i class="fa-solid ${isInf ? 'fa-infinity' : 'fa-repeat'}"></i>${isInf ? ' <span class="pl-loop-text">∞</span>' : (isLooped ? ` <span class="pl-loop-text">${repeatCount}x</span>` : '')}
        </button>
        <button class="btn-pl-remove" title="Remove from queue">&times;</button>
      </div>
    `;

    // ── Click to play / pause ────────────────────────────────────
    el.addEventListener('click', (e) => {
      if (e.target.closest('.btn-pl-remove')) return;
      if (e.target.closest('.btn-pl-loop')) return;
      if (e.target.closest('.pl-drag-handle')) return;

      const isActive = idx === Playlist.getCurrentIndex();
      if (isActive && Player.hasSource() && !Player.hasError()) {
        Player.togglePlay();
      } else {
        Playlist.selectIndex(idx, true);
      }
    });

    const loopBtn = el.querySelector('.btn-pl-loop');
    if (loopBtn) {
      loopBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        const currentR = Playlist.getItemRepeatCount ? Playlist.getItemRepeatCount(idx) : (item.repeatCount || 1);
        const cycle = [1, 2, 3, 5, 'infinite'];
        const currentPos = cycle.indexOf(currentR);
        const nextR = currentPos === -1 ? 1 : cycle[(currentPos + 1) % cycle.length];
        if (typeof Playlist.setItemRepeatCount === 'function') {
          Playlist.setItemRepeatCount(idx, nextR);
        } else {
          item.repeatCount = nextR;
        }
        if (typeof showToast === 'function') {
          if (nextR === 'infinite') {
            showToast(`"${item.name || 'Track'}" set to loop infinitely (∞)`, 'info');
          } else {
            showToast(`"${item.name || 'Track'}" set to play ${nextR}x`, 'info');
          }
        }
        renderPlaylistView();
      });
    }

    el.querySelector('.btn-pl-remove').addEventListener('click', (e) => {
      e.stopPropagation();
      Playlist.removeItem(idx);
    });

    // ── Native Drag-and-Drop ─────────────────────────────────────
    el.addEventListener('dragstart', (e) => {
      dragSrcIndex = idx;
      el.classList.add('dragging');
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', idx.toString());
    });

    el.addEventListener('dragend', () => {
      el.classList.remove('dragging');
      container.querySelectorAll('.playlist-item').forEach(i => i.classList.remove('drag-over'));
    });

    el.addEventListener('dragover', (e) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      container.querySelectorAll('.playlist-item').forEach(i => i.classList.remove('drag-over'));
      el.classList.add('drag-over');
    });

    el.addEventListener('dragleave', () => {
      el.classList.remove('drag-over');
    });

    el.addEventListener('drop', (e) => {
      e.preventDefault();
      el.classList.remove('drag-over');
      const toIndex = parseInt(el.dataset.index, 10);
      if (dragSrcIndex !== null && dragSrcIndex !== toIndex) {
        Playlist.moveItem(dragSrcIndex, toIndex);
      }
      dragSrcIndex = null;
    });

    container.appendChild(el);
  });
}

async function loadAndRenderLibrary() {
  const container = document.getElementById('libraryContainer');
  const countEl = document.getElementById('libCount');
  const navLibCount = document.getElementById('navLibCount');
  const dashStatVideos = document.getElementById('dashStatVideos');
  const dashStatAudio = document.getElementById('dashStatAudio');
  const dashStatSize = document.getElementById('dashStatSize');

  const list = await Library.fetchLibrary();
  const totalCount = Array.isArray(list) ? list.length : 0;

  if (countEl) countEl.textContent = totalCount;
  if (navLibCount) navLibCount.textContent = totalCount;

  // Calculate statistics
  if (Array.isArray(list)) {
    const videoCount = list.filter(i => i.type === 'video').length;
    const audioCount = list.filter(i => i.type === 'audio').length;
    const totalBytes = list.reduce((acc, i) => acc + (i.size || 0), 0);

    if (dashStatVideos) dashStatVideos.textContent = videoCount;
    if (dashStatAudio) dashStatAudio.textContent = audioCount;
    if (dashStatSize) dashStatSize.textContent = (totalBytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
  }

  if (container) {
    Library.renderList(container);
  }
}

// Global exports for module integration
window.loadAndRenderLibrary = loadAndRenderLibrary;
window.fetchDownloads = fetchDownloads;
window.fetchStatus = fetchStatus;
window.playLibraryTrackWithQueue = playLibraryTrackWithQueue;
window.triggerDownload = triggerDownload;
window.getActiveDownloadUrlAndMeta = getActiveDownloadUrlAndMeta;

